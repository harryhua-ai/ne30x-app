#!/bin/sh
# Minimal GitHub Actions glue for A-side REMOTE Execution Plan publication
# (#82). The normal remote-A path uses a plain GitHub contents write — the
# only durable write primitive the remote A host needs: A composes the
# complete Plan payload, commits it to the designated docs/plans/ location
# (the commit itself is A's durable decision record), and the push-triggered
# workflow invokes this glue with --replace-current. An explicit
# workflow_dispatch with --replace <sha> remains the break-glass retry
# entry. This glue owns NO Plan semantics: it validates only its own
# inputs, resolves the exact prior revision from durable remote truth when
# asked (--replace-current), hands the payload PATH verbatim to the
# canonical `ght plan-publish` primitive, and propagates its outcome
# unchanged. Every durable predicate — Plan v1 schema/validation,
# immutable revisions, exact-prior CAS replacement, plan_id stability,
# durable pointer confirmation — is verified by ght itself. There is
# deliberately no retry-with-different-input, payload mending, or
# scheduling inference here: the workflow never generates or alters nodes,
# priorities, barriers, authorization ids, or max_concurrency.
#
# #156: the canonical invocation always carries --bind-contract-digests, so
# a remote A (no checkout, no local ght) may commit the complete A-owned
# scheduling decision with the node contract_digest LEFT OUT; ght itself
# then binds each unbound node's digest at publication time through the one
# canonical digest primitive (`ght contract-digest` behavior) and refuses
# stale bindings when the Contract changed between binding and publication.
# The glue computes no digest, mends no payload, and adds no scheduling
# content; a fully bound payload passes through binding untouched.
#
# Usage:
#   ght-plan-publish.sh <plan-path> [--replace <prior-revision-sha>
#                                     | --replace-current]
#
# Environment (test seams):
#   GHT_PLAN_PUBLISH_GHT_BIN   alternative ght entrypoint to exec
#   GHT_PLAN_PUBLISH_PYTHON    alternative python for the bundled ght.py
#   GHT_PLAN_PUBLISH_REMOTE    git remote to read the current pointer from
set -eu

die() {
    echo "ght-plan-publish: $1" >&2
    exit 1
}

require_hex() {
    case "$1" in
        ''|*[!0-9a-f]*) die "expected a 40-hex revision SHA, got '$1'; refusing to guess — fail closed" ;;
    esac
}

plan_path=""
replace=""
replace_current=0
while [ $# -gt 0 ]; do
    case "$1" in
        --replace)
            shift
            [ $# -ge 1 ] || die "--replace requires an explicit prior-revision value; refusing to guess — fail closed"
            replace=$1
            require_hex "$replace"
            shift
            ;;
        --replace-current)
            replace_current=1
            shift
            ;;
        -*)
            die "unknown argument '$1'; only --replace <prior-revision-sha> and --replace-current are supported — fail closed"
            ;;
        *)
            if [ -n "$plan_path" ]; then
                die "too many arguments; usage: ght-plan-publish.sh <plan-path> [--replace <sha> | --replace-current] — fail closed"
            fi
            plan_path=$1
            shift
            ;;
    esac
done

[ -n "$plan_path" ] || die "usage: ght-plan-publish.sh <plan-path> [--replace <prior-revision-sha> | --replace-current]"
[ "$replace_current" -eq 0 ] || [ -z "$replace" ] || die "--replace and --replace-current are mutually exclusive — fail closed"

# The payload must already exist durably in the repository (A committed it
# through the remote surface). The glue never creates, reads-to-rewrite, or
# mends it: the canonical primitive parses and publishes it verbatim.
[ -f "$plan_path" ] || die "plan payload '$plan_path' does not exist in this checkout; A must commit the complete Plan payload to the repository — fail closed"

if [ "$replace_current" -eq 1 ]; then
    # Resolve the exact prior revision from durable remote truth and hand it
    # to the canonical primitive: the CAS equality check itself stays with
    # ght. An absent (or transiently unreadable) pointer resolves to the
    # first-publish path — and if a pointer actually exists, the primitive's
    # own "already exists; publish with --replace" gate fails closed, so an
    # unreadable read can never publish a wrong revision.
    prior=$(git ls-remote "${GHT_PLAN_PUBLISH_REMOTE:-origin}" refs/ght/plans/current 2>/dev/null | cut -f1 || true)
    case "$prior" in
        [0-9a-f]*) replace=$prior ;;
        *) replace="" ;;
    esac
fi

echo "ght-plan-publish: invoking canonical plan-publish for '$plan_path'${replace:+ (replace $replace)}" >&2
if [ -n "$replace" ]; then
    set -- --replace "$replace"
else
    set --
fi
if [ -n "${GHT_PLAN_PUBLISH_GHT_BIN:-}" ]; then
    exec "${GHT_PLAN_PUBLISH_GHT_BIN}" --json plan-publish "$plan_path" \
        --bind-contract-digests "$@"
fi
exec "${GHT_PLAN_PUBLISH_PYTHON:-python3}" "$(dirname "$0")/ght.py" \
    --json plan-publish "$plan_path" --bind-contract-digests "$@"
