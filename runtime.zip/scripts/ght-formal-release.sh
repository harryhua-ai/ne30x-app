#!/bin/sh
# Minimal GitHub Actions glue for the canonical formal-release workflow
# (#125 R3 per A's exact-SHA review of 4e6c4e4). A's entire remote release
# act is ONE contents write of the designated dispatch record
# (docs/releases/dispatch.yaml, the #82 pattern). Per the R3 correction the
# record BINDS the exact accepted-main target SHA that A reconciled/froze
# BEFORE the write; the dispatch-record commit itself is trigger and
# authorization evidence only — it is NEVER the release target and never
# changes the release source cut.
#
# This glue owns NO release authority and NO publication semantics: it
# validates only its own inputs, extracts the dispatch record byte-exactly
# from the triggering commit's objects (never the mutable working tree),
# reads the frozen target from the record, verifies that nothing but
# governance-record writes sits between the frozen target and the trigger
# commit (any source change there is material drift: fail closed — A must
# reconcile, the drift is never absorbed by retargeting), extracts the
# CHANGELOG byte-exactly from the FROZEN TARGET's commit objects, runs the
# fail-closed authorization gate, and hands the frozen decision verbatim to
# the canonical `ght release-publish` primitive, which re-verifies every
# durable predicate itself (version format, accepted-main equality or
# governance-only advance for fresh publications, tag/Release collision and
# idempotent reconciliation, exact tag/Release/runtime read-back). There is
# deliberately no retry with different inputs, no notes mending, no version
# inference, and no GitHub signal read here: merge state, Issue DONE,
# Milestone completion, runtime/bootstrap need, and deadlines are not
# authorization surfaces.
#
# Usage:
#   ght-formal-release.sh <dispatch-record-path> <record-commit-sha>
#
#     <dispatch-record-path>  repository path of the designated dispatch
#                             record — ONLY the canonical
#                             docs/releases/dispatch.yaml is accepted
#                             (policy constant, #125 R4: never
#                             caller-selected, never redefined by a
#                             break-glass retry input)
#     <record-commit-sha>     the commit whose tree carries the record (the
#                             workflow passes github.sha — the triggering
#                             push commit; NOT the publication target)
#
# Environment (test seams):
#   GHT_FORMAL_RELEASE_GHT_BIN   alternative ght entrypoint to run
#   GHT_FORMAL_RELEASE_PYTHON    alternative python for gate + bundled ght.py
#   GHT_FORMAL_RELEASE_REMOTE    git remote to fetch the frozen target from
set -eu

die() {
    echo "ght-formal-release: $1; fail closed" >&2
    exit 1
}

[ "$#" -eq 2 ] || die "usage: ght-formal-release.sh <dispatch-record-path> <record-commit-sha> (got $# args)"

dispatch_path=$1
record_commit=$2

printf '%s' "$record_commit" | grep -Eq '^[0-9a-f]{7,40}$' ||
    die "record commit '$record_commit' is not an exact commit SHA"
case "$dispatch_path" in
    ''|-*|/*|*..*) die "dispatch record path '$dispatch_path' must be a relative repository path without traversal" ;;
esac
# #125 R4 (A review of a3807c7): the designated dispatch record is a
# repository-policy constant, never a caller-selectable surface — no
# invocation and no break-glass retry input can redefine which repository
# path counts as the release-cut governance record. Only the canonical
# formal-release record path is ever executed here.
[ "$dispatch_path" = "docs/releases/dispatch.yaml" ] ||
    die "dispatch record path '$dispatch_path' is not the designated formal-release governance record (docs/releases/dispatch.yaml); the designated path is policy and is never caller-selected — fail closed"

remote=${GHT_FORMAL_RELEASE_REMOTE:-origin}
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
python="${GHT_FORMAL_RELEASE_PYTHON:-python3}"

# The triggering commit must be a real commit in the target repository
# before anything is validated against it; an unfetchable trigger is a
# fail-closed verdict, never a guess.
git fetch -q "$remote" "$record_commit" 2>/dev/null ||
    die "record commit '$record_commit' is not fetchable from '$remote'"
git cat-file -e "$record_commit^{commit}" 2>/dev/null ||
    die "record commit '$record_commit' is not a commit in this repository"

tmpdir=$(mktemp -d)
trap 'rm -rf "$tmpdir"' EXIT

# The dispatch record is read byte-exactly from the triggering commit's
# objects — never the mutable working tree, never another ref.
if ! git show "$record_commit:$dispatch_path" > "$tmpdir/dispatch-record" \
        2> "$tmpdir/show.err"; then
    die "durable dispatch record '$dispatch_path' is not part of the triggering commit $record_commit ($(cat "$tmpdir/show.err"))"
fi

# The frozen decision is extracted from the record's flat head (never from
# inside the notes block): the version and the exact accepted-main target
# SHA that A reconciled/froze BEFORE the write. An empty extraction is not
# yet fatal: whether each is required is the gate's call (a cleared
# `action: none` record requests no release at all).
version=$(sed -n "1,/^release-notes-begin:/s/^version: *//p" "$tmpdir/dispatch-record" | head -n 1)
target=$(sed -n "1,/^release-notes-begin:/s/^target: *//p" "$tmpdir/dispatch-record" | head -n 1)

if [ -n "$target" ]; then
    # R3 binding: only a full exact frozen-target SHA is actionable here.
    printf '%s' "$target" | grep -Eq '^[0-9a-f]{40}$' ||
        die "dispatch record target '$target' is not an exact 40-hex frozen-target commit SHA (the gate enforces the same binding)"
    git fetch -q "$remote" "$target" 2>/dev/null ||
        die "frozen target '$target' is not fetchable from '$remote'"
    git cat-file -e "$target^{commit}" 2>/dev/null ||
        die "frozen target '$target' is not a commit in this repository"
    # The dispatch-record commit must sit STRICTLY AFTER the frozen target:
    # the frozen target is the accepted-main cut A froze BEFORE the write —
    # the record's own commit is never the release target.
    [ "$target" != "$record_commit" ] ||
        die "dispatch record binds itself ($record_commit) as the frozen target: the release target is the accepted-main cut A froze BEFORE the write, never the record's own commit"
    git merge-base --is-ancestor "$target" "$record_commit" 2>/dev/null ||
        die "frozen target '$target' is not an ancestor of the triggering commit $record_commit: the record is not bound to the accepted-main cut it claims"
    # Material-drift guard: between the frozen target and the triggering
    # commit, ONLY governance writes of the designated dispatch record may
    # exist. Any merge, or any commit touching any other path, is accepted
    # main moving past the frozen cut — fail closed and reconcile; the drift
    # is never absorbed by retargeting the release.
    for commit in $(git rev-list "$target..$record_commit"); do
        [ "$(git rev-list --parents -n 1 "$commit" | wc -w | tr -d ' ')" = "2" ] ||
            die "material drift: merge commit $commit sits between the frozen target $target and the dispatch record — A must reconcile the release cut"
        changed=$(git diff-tree --no-commit-id --name-only -r "$commit")
        [ "$changed" = "$dispatch_path" ] ||
            die "material drift: commit $commit between the frozen target $target and the dispatch record carries changes to:
$changed
accepted main moved past the frozen cut — A must reconcile; the drift is never absorbed by retargeting"
    done
    # The CHANGELOG is read byte-exactly from the FROZEN TARGET's commit
    # objects: the release's source cut is the frozen accepted-main target,
    # not the trigger write.
    if ! git show "$target:CHANGELOG.md" > "$tmpdir/CHANGELOG.md" \
            2> "$tmpdir/show.err"; then
        die "durable CHANGELOG 'CHANGELOG.md' is not part of the frozen target $target: commit it through A's canonical remote surface and re-freeze ($(cat "$tmpdir/show.err"))"
    fi
fi

# Fail-closed authorization gate: action semantics, frozen-target binding,
# User-only authorization, timing semantics present, CHANGELOG entry frozen
# in the target, verbatim Release Notes emitted. The gate's own evidence
# JSON goes to stderr so stdout can carry exactly the primitive's result
# document. The CHANGELOG is supplied only when a frozen target is bound;
# the gate itself refuses any release record that lacks one.
if [ -n "$target" ]; then
    set -- --changelog "$tmpdir/CHANGELOG.md"
else
    set --
fi
"$python" "$script_dir/formal_release_gate.py" \
    --version "$version" \
    --dispatch "$tmpdir/dispatch-record" \
    --emit-notes "$tmpdir/release-notes.md" "$@" 1>&2

# A cleared record (action: none) is a governance write, not a release:
# nothing is requested, nothing is published, and the run ends cleanly.
if [ ! -s "$tmpdir/release-notes.md" ]; then
    echo "ght-formal-release: no release requested (action: none); no publication attempted"
    exit 0
fi

printf '%s' "$version" | grep -Eq '^v[0-9]+(\.[0-9]+)*$' ||
    die "dispatch record carries no valid release version (got '$version')"

# Canonical publication: tag → GitHub Release → stamp/sync/activate runtime
# → full read-back, every durable predicate verified by the primitive itself.
# The gate path above is glue-internal: the primitive never sees it. The
# primitive carries the designated-record governance binding itself (#125
# R4): the policy-fixed designated path is a constant there, and the
# governance-only release-cut exception is granted ONLY by the designated
# record's own durable frozen-target binding — an accepted-main advance
# made solely of designated-record writes bound to this exact frozen
# target never changes the release source cut, so the FROZEN TARGET is
# published while any other drift still fails closed. No caller-supplied
# governance path exists. The tag is minted at the frozen target — never
# at the record's own commit.
ght_bin=${GHT_FORMAL_RELEASE_GHT_BIN:-}
if [ -n "$ght_bin" ]; then
    set -- "$ght_bin" --json release-publish
else
    set -- "$python" "$script_dir/ght.py" --json release-publish
fi
"$@" --version "$version" --target "$target" \
    --notes-file "$tmpdir/release-notes.md"
