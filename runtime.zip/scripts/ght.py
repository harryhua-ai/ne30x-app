#!/usr/bin/env python3
"""Launcher for the github-task CLI (Harry Dev execution governance)."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from github_task.cli import main  # noqa: E402

if __name__ == "__main__":
    main()
