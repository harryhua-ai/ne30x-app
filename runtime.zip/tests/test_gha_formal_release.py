"""#125 R3: the canonical formal-release GitHub Actions workflow — the
A-triggerable mechanical publication surface, corrected per A's exact-SHA
review of 4e6c4e4 (blocker: the R2 dispatch-record commit itself became
the frozen exact target, mixing trigger evidence into the release source
cut and breaking the exact accepted-main invariant).

R3 shape: A reconciles and freezes the exact accepted-main target BEFORE
the write; the dispatch record BINDS that frozen target SHA (`target:`)
and the workflow publishes THAT target — never the record's own commit.
The trigger stays the #82-pattern contents write of the designated
`docs/releases/dispatch.yaml` (one-to-one path binding; workflow_dispatch
is break-glass only). Between the frozen target and the trigger commit,
ONLY governance writes of the designated record may exist: any source
change there is material drift — fail closed, A reconciles, the drift is
never absorbed by retargeting. R4 (per A's exact-SHA review of a3807c7):
the governance-only exception is bound mechanically to the canonical
formal-release dispatch surface — the designated record path is a
repository-policy constant (no caller flag exists on the primitive, no
workflow input or break-glass variant can nominate or redefine a path),
and eligibility is granted ONLY by the designated record's own durable
frozen-target binding; every other fresh publication keeps exact
current-main equality. The record still mirrors the User authorization
durably and carries the Release Notes verbatim; no mirror/notes
source-cut prerequisite returns, and no merge, Issue DONE, Milestone,
schedule, runtime/bootstrap need, or deadline signal can start or
authorize a publication. B never authors the dispatch record.
"""

import json
import os
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
WORKFLOW = SKILL_ROOT.parent.parent / ".github" / "workflows" / "formal-release.yml"
GLUE = SKILL_ROOT / "scripts" / "ght-formal-release.sh"
GATE = SKILL_ROOT / "scripts" / "formal_release_gate.py"
CLI = SKILL_ROOT / "scripts" / "ght.py"

VERSION = "v9.9.9"
DISPATCH_PATH = "docs/releases/dispatch.yaml"
NOTES = "# v9.9.9\n\nRelease notes body, published verbatim from durable truth.\n"
# Syntactically valid stand-in frozen-target SHA for gate-level tests (the
# gate validates the exact 40-hex binding format; the glue-level tests bind
# real frozen-target commits).
GENERIC_TARGET = "1234567890abcdef1234567890abcdef12345678"
DISPATCH_TEMPLATE = """\
# Formal release dispatch record (A-authored governance surface, #125).
# One contents-write of this exact file to main is A's entire remote
# release act: it durably records the User authorization mirror, BINDS the
# exact accepted-main target A reconciled/froze BEFORE the write, and
# carries the frozen Release Notes. The record's own commit is trigger and
# evidence only — never the release target. Flat `key: value` lines only,
# then the verbatim notes block.
action: release
version: v9.9.9
target: {target}
authorized_by: User
authorized_on: 2026-09-23
timing: now
statement: User explicitly confirmed the concrete v9.9.9 release proposal (durable decision record, 2026-09-23)
release-notes-begin:
""" + NOTES + """release-notes-end:
"""


def dispatch_record(target=GENERIC_TARGET):
    return DISPATCH_TEMPLATE.format(target=target)


DISPATCH = dispatch_record()
CHANGELOG = """\
# Changelog

Harry Dev 正式版本的长期简要索引。

## v9.9.9 — 2026-09-23

- The release under test.

## v9.9.8 — 2026-09-01

- Earlier release.
"""

# Mock gh supporting exactly the surface `ght release-publish` reads/writes.
# GHT_TEST_FAIL_RELEASE makes the next Release write fail, to exercise
# partial-publication exposure and idempotent resume.
MOCK_GH = r'''#!/usr/bin/env python3
import json, os, shutil, sys
args = sys.argv[1:]
state_path = os.environ["GHT_RELEASE_STATE"]
state = json.load(open(state_path)) if os.path.exists(state_path) else {"releases": {}, "assets": {}}
def save():
    json.dump(state, open(state_path, "w"))
# The explicit --repo override is only valid before a repo-scoped
# subcommand, exactly like the real CLI (`gh api` refuses --repo) — the
# mock enforces the same argv shape (review R2 finding 2).
REPO_SCOPED_COMMANDS = ("issue", "pr", "release", "repo")
if args[:1] == ["--repo"]:
    command = args[2] if len(args) > 2 else None
    if command not in REPO_SCOPED_COMMANDS:
        print("unknown flag: --repo", file=sys.stderr)
        raise SystemExit(2)
    args = args[2:]
if args[:1] == ["api"] and ("--repo" in args or "-R" in args):
    print("unknown flag: --repo", file=sys.stderr)
    raise SystemExit(2)
if args[:2] == ["api", "user"]:
    if os.environ.get("GHT_TEST_FAIL_API_USER") == "1":
        # Simulate a GitHub App installation token: GET /user unsupported (#130).
        print("GET /user: installation access token cannot query users",
              file=sys.stderr)
        raise SystemExit(1)
    print(os.environ.get("GHT_TEST_PRINCIPAL", "acct"))
    raise SystemExit(0)
if args[:2] == ["repo", "view"]:
    print("example/repo")
    raise SystemExit(0)
if args[:3] == ["api", "-X", "POST"] and len(args) > 3 and args[3].endswith("/releases"):
    if os.environ.get("GHT_TEST_FAIL_RELEASE"):
        print("release write refused (test seam)", file=sys.stderr)
        raise SystemExit(1)
    body = json.loads(sys.stdin.read())
    tag = body["tag_name"]
    if tag in state["releases"]:
        print(json.dumps(state["releases"][tag]))
        raise SystemExit(0)
    rel = {"tag_name": tag, "name": body.get("name", tag), "draft": bool(body.get("draft")),
           "prerelease": bool(body.get("prerelease")), "body": body.get("body", ""),
           "id": len(state["releases"]) + 1}
    state["releases"][tag] = rel
    save()
    print(json.dumps(rel))
    raise SystemExit(0)
if args[:2] == ["release", "upload"]:
    # gh release upload <tag> <file...> [--clobber] (#165): the distribution
    # asset name is the file's basename; like the real CLI, an existing
    # same-name asset fails unless --clobber is passed (the reconciliation
    # contract never passes it).
    tag = args[2]
    if tag not in state["releases"]:
        print("release not found", file=sys.stderr)
        raise SystemExit(1)
    names = state.setdefault("assets", {}).setdefault(tag, [])
    for path in [a for a in args[3:] if not a.startswith("-")]:
        name = os.path.basename(path)
        dest = os.path.join(os.environ["GHT_ASSET_DIR"], name)
        if os.path.exists(dest) and "--clobber" not in args:
            print("asset with name %r already exists; use --clobber to "
                  "overwrite" % name, file=sys.stderr)
            raise SystemExit(1)
        os.makedirs(os.environ["GHT_ASSET_DIR"], exist_ok=True)
        shutil.copyfile(path, dest)
        if name not in names:
            names.append(name)
    save()
    raise SystemExit(0)
if args[:2] == ["release", "download"]:
    # gh release download <tag> --pattern <name> --dir <dir> — serves the
    # stored asset bytes like the real CLI (asset reconciliation read-back,
    # review R2 finding 4).
    tag = args[2]
    pattern = args[args.index("--pattern") + 1]
    outdir = args[args.index("--dir") + 1]
    if pattern not in state.get("assets", {}).get(tag, []):
        print("no assets match the pattern %r" % pattern, file=sys.stderr)
        raise SystemExit(1)
    src = os.path.join(os.environ["GHT_ASSET_DIR"], pattern)
    os.makedirs(outdir, exist_ok=True)
    shutil.copyfile(src, os.path.join(outdir, pattern))
    raise SystemExit(0)
if args[:1] == ["api"] and len(args) > 1 and "/releases/tags/" in args[1]:
    tag = args[1].rsplit("/", 1)[-1]
    if tag in state["releases"]:
        rel = dict(state["releases"][tag])
        rel["assets"] = [{"name": name, "size": 1}
                         for name in sorted(state.get("assets", {}).get(tag, []))]
        print(json.dumps(rel))
        raise SystemExit(0)
    print("Not Found", file=sys.stderr)
    raise SystemExit(1)
print("unsupported mock gh command", file=sys.stderr)
raise SystemExit(1)
'''


def run_glue(*args, env_extra=None, cwd=None):
    env = {"PATH": "/usr/bin:/bin"}
    env.update(env_extra or {})
    return subprocess.run(["sh", str(GLUE), *args],
                          capture_output=True, text=True, env=env, cwd=cwd)


def run_gate(*args, env_extra=None):
    env = {"PATH": "/usr/bin:/bin"}
    env.update(env_extra or {})
    return subprocess.run([sys.executable, str(GATE), *args],
                          capture_output=True, text=True, env=env)


class FormalReleaseSurfaceTests(unittest.TestCase):
    def _git(self, cwd, *args, input_text=None):
        env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
               "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t"}
        return subprocess.run(["git", *args], cwd=str(cwd),
                              capture_output=True, text=True, env=env,
                              input=input_text)

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ght-formal-release-"))
        self.origin = self.tmp / "origin.git"
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        (self.bin / "gh").write_text(MOCK_GH)
        (self.bin / "gh").chmod(os.stat(self.bin / "gh").st_mode | stat.S_IXUSR)
        self.state = self.tmp / "release-state.json"
        self.state.write_text(json.dumps({"releases": {}}))
        self.assets = self.tmp / "assets"
        self.assets.mkdir()
        self._git(self.tmp, "init", "--bare", str(self.origin), "-b", "main")
        seed = self.tmp / "seed"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(seed))
        (seed / "skills" / "github-task" / "scripts").mkdir(parents=True)
        (seed / "skills" / "github-task" / "scripts" / "ght.py").write_text(
            "# minimal ght runtime stub\n")
        (seed / "skills" / "github-task" / "SKILL.md").write_text("# skill\n")
        (seed / "CHANGELOG.md").write_text(CHANGELOG)
        self._git(seed, "add", "-A")
        self._git(seed, "commit", "-qm", "seed main")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        # R3 freeze semantics: the seed commit IS the exact accepted-main
        # cut A reconciles and freezes BEFORE the trigger write.
        self.target = self._git(seed, "rev-parse", "HEAD").stdout.strip()
        # Simulate A's remote act: one contents write of the dispatch
        # record (BINDING the frozen target) onto main. The resulting
        # commit is only the trigger + evidence commit — never the target.
        dispatch = seed / "docs" / "releases"
        dispatch.mkdir(parents=True)
        (dispatch / "dispatch.yaml").write_text(
            dispatch_record(target=self.target))
        self._git(seed, "add", "-A")
        self._git(seed, "commit", "-qm", "formal release dispatch v9.9.9")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        self.dispatch_commit = self._git(seed, "rev-parse", "HEAD").stdout.strip()
        self.assertNotEqual(self.dispatch_commit, self.target,
                            "the trigger write can never be the frozen target")
        self.worker = self.tmp / "worker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(self.worker))

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _run_env(self, **extra):
        env = {"PATH": f"{self.bin}:{os.environ['PATH']}",
               "GHT_RELEASE_STATE": str(self.state),
               "GHT_ASSET_DIR": str(self.assets),
               "GHT_FORMAL_RELEASE_PYTHON": sys.executable,
               "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
               "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t"}
        env.update(extra)
        return env

    def _release(self, commit=None, dispatch=DISPATCH_PATH, **extra):
        # The workflow passes github.sha — the commit whose tree carries
        # the dispatch record. The publication target comes FROM the record.
        return subprocess.run(
            ["sh", str(GLUE), dispatch, commit or self.dispatch_commit],
            capture_output=True, text=True, cwd=str(self.worker),
            env=self._run_env(**extra))

    def _remote_tag_sha(self, version=VERSION):
        out = self._git(self.worker, "ls-remote", "origin",
                        f"refs/tags/{version}", f"refs/tags/{version}^{{}}").stdout
        shas = [line.split()[0] for line in out.splitlines() if line.strip()]
        return shas[-1] if shas else None

    def _commit_dispatch(self, content, message="re-dispatch"):
        """Simulate a later A contents write of the dispatch record."""
        seed = self.tmp / "seed"
        self._git(seed, "fetch", "-q", "origin")
        self._git(seed, "reset", "-q", "--hard", "origin/main")
        (seed / "docs" / "releases" / "dispatch.yaml").write_text(content)
        self._git(seed, "add", "-A")
        self._git(seed, "commit", "-qm", message)
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        return self._git(seed, "rev-parse", "HEAD").stdout.strip()

    def _advance_main_with_source(self, name="late.txt", content="main moved on\n"):
        """Push an ordinary accepted source commit onto main (B-side work)."""
        moved = self.tmp / f"moved-{name}"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(moved))
        (moved / name).write_text(content)
        self._git(moved, "add", "-A")
        self._git(moved, "commit", "-qm", f"advance main ({name})")
        self._git(moved, "push", "-q", "origin", "HEAD:main")
        return self._git(moved, "rev-parse", "HEAD").stdout.strip()

    # -- the workflow/glue surface contract ------------------------------

    def test_workflow_glue_and_gate_exist_executable(self):
        self.assertTrue(WORKFLOW.exists(), "canonical formal-release workflow is missing")
        self.assertTrue(GLUE.exists(), "formal-release glue is missing")
        self.assertTrue(GLUE.stat().st_mode & stat.S_IXUSR,
                        "glue script must be executable")
        self.assertTrue(GATE.exists(), "authorization gate is missing")
        self.assertTrue(GATE.stat().st_mode & stat.S_IXUSR,
                        "gate script must be executable")

    def test_workflow_trigger_is_the_designated_dispatch_push(self):
        # Blocker 1 correction (R2, kept): A's canonical remote trigger is
        # the contents write of the designated dispatch record (#82
        # pattern). One-to-one path binding: only that exact file's push
        # starts a publication. workflow_dispatch stays as explicit
        # break-glass only. No event — schedule, milestone, issue,
        # pull_request, release, deployment, comment — can ever start a
        # publication.
        text = WORKFLOW.read_text()
        self.assertIn("push:", text)
        self.assertIn("branches: [main]", text)
        self.assertIn("paths: ['docs/releases/dispatch.yaml']", text,
                      "the trigger is bound one-to-one to the A dispatch record")
        self.assertNotIn("docs/releases/**", text)
        self.assertIn("workflow_dispatch:", text,
                      "explicit break-glass retry stays available to an admin")
        for trigger in ("schedule", "milestone", "issues", "pull_request",
                        "release", "deployment", "repository_dispatch",
                        "issue_comment"):
            self.assertIsNone(
                __import__("re").search(rf"(?m)^\s*{trigger}\s*:", text),
                f"event trigger {trigger!r} must never start a publication")

    def test_workflow_publishes_the_record_bound_target_not_the_trigger_commit(self):
        # R3 blocker correction: no workflow input may override the
        # publication target — the target always comes FROM the dispatch
        # record (the exact accepted-main SHA A froze before the write),
        # and the trigger commit is passed only as the record-carrying
        # commit. Full history is checked out so the frozen-range
        # predicates are verdicts over commit objects.
        text = WORKFLOW.read_text()
        self.assertIn("github.sha", text,
                      "the record-carrying commit defaults to the triggering commit")
        self.assertIn("FORMAL_RELEASE_RECORD_COMMIT", text,
                      "github.sha is the record commit, not the publication target")
        self.assertNotIn("inputs.target", text,
                         "no workflow input may override or retarget the "
                         "publication target")
        self.assertNotIn("FORMAL_RELEASE_TARGET", text,
                         "the R2 target-override seam is gone")
        self.assertIn("fetch-depth: 0", text,
                      "the frozen-range predicates read full commit history")

    def test_break_glass_retry_cannot_redefine_the_designated_record_path(self):
        # #125 R4 (A review of a3807c7): the designated dispatch-record
        # path — and with it the governance-only release-cut exception —
        # is a repository-policy constant. The workflow exposes NO
        # dispatch-path input, its env pins the literal designated path,
        # and the glue refuses any other path outright: no break-glass
        # invocation can point the release-cut governance binding at
        # another file.
        text = WORKFLOW.read_text()
        self.assertNotIn("dispatch_path", text,
                         "no workflow input or expression may select the "
                         "dispatch-record path")
        self.assertIn("FORMAL_RELEASE_DISPATCH: docs/releases/dispatch.yaml",
                      text, "the designated path is pinned as a policy "
                      "constant in the workflow env")
        result = run_glue("docs/releases/other.yaml", self.dispatch_commit,
                          cwd=str(self.worker),
                          env_extra=self._run_env())
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("never caller-selected", result.stderr,
                      "the glue only ever executes the designated record path")

    def test_workflow_supplies_the_release_publisher_identity(self):
        # #130 AC3: on the installation-token path the workflow supplies the
        # dedicated release-publication-only machine identity so the SAME
        # canonical primitive can execute; the workflow still owns NO
        # version/target/timing authority and the identity is audit metadata,
        # never release authorization.
        text = WORKFLOW.read_text()
        self.assertIn("GHT_RELEASE_PUBLISHER_ID: ght-formal-release-workflow", text,
                      "the installation-token path carries the dedicated "
                      "publication identity")
        self.assertNotIn("GHT_RECONCILER_ID", text,
                         "the completion-only identity is never reused for release")
        self.assertNotIn("GHT_PLAN_PUBLISHER_ID", text,
                         "the plan-publication-only identity is never reused for release")

    def test_workflow_routes_only_through_the_glue_with_minimal_permissions(self):
        text = WORKFLOW.read_text()
        self.assertIn("ght-formal-release.sh", text)
        self.assertNotIn("ght.py", text,
                         "the workflow must not invoke the runtime directly")
        self.assertNotIn("gh api", text,
                         "no duplicated publication logic via raw API calls")
        self.assertNotIn("gh release", text,
                         "no duplicated publication via the gh release CLI")
        self.assertIn("insteadOf", text,
                      "the private-repo runner must authenticate its git "
                      "reads for the primitive's packaging clone")
        self.assertIn("permissions:", text)
        self.assertIn("contents: write", text)
        self.assertNotIn("issues: write", text)
        self.assertNotIn("pull-requests:", text)
        self.assertEqual(text.count("set -euo pipefail"), 1)
        self.assertIn("$GITHUB_STEP_SUMMARY", text,
                      "outcome evidence must be durable in the run summary")
        self.assertIn("if: always()", text,
                      "failure must be exposed in the summary, never swallowed")

    # -- glue input validation (fail closed before the primitive) --------

    def test_glue_fails_closed_on_missing_or_bad_inputs(self):
        stub = self.tmp / "ght-stub-never.py"
        stub.write_text("#!/usr/bin/env python3\nraise SystemExit(0)\n")
        stub.chmod(stub.stat().st_mode | stat.S_IXUSR)
        cases = [
            (),  # no inputs at all
            (DISPATCH_PATH,),  # record commit missing
            (DISPATCH_PATH, self.dispatch_commit, "extra"),  # stray argv
            (DISPATCH_PATH, "not-a-sha"),  # not a SHA
            (DISPATCH_PATH, "ZZZ00"),
            ("../escape.yaml", self.dispatch_commit),  # traversal
            ("/etc/passwd", self.dispatch_commit),  # absolute path
            ("-dispatch.yaml", self.dispatch_commit),  # option-like path
            (DISPATCH_PATH, "e" * 40),  # unfetchable record commit
            ("docs/releases/absent.yaml", self.dispatch_commit),  # not in the commit
            ("docs/releases/other.yaml", self.dispatch_commit),  # R4: not the designated record path
        ]
        for args in cases:
            marker = self.tmp / f"invoked-{abs(hash(args))}.json"
            result = run_glue(*args, cwd=str(self.worker), env_extra=self._run_env(
                GHT_FORMAL_RELEASE_GHT_BIN=str(stub),
                GHT_STUB_OUT=str(marker)))
            self.assertNotEqual(result.returncode, 0, args)
            self.assertIn("fail closed", result.stderr, args)
            self.assertFalse(marker.exists(),
                             f"the primitive must never be invoked for {args}")

    # -- the dispatch-record gate failure-mode matrix ---------------------

    def _write_dispatch(self, base, content, name="d"):
        path = base / f"{name}-{abs(hash(content))}.yaml"
        path.write_text(content)
        return path

    def _changelog(self, base, content=CHANGELOG, name="c"):
        path = base / f"{name}-{abs(hash(content))}.md"
        path.write_text(content)
        return path

    def test_gate_accepts_a_valid_dispatch_record_and_emits_notes(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            dispatch = self._write_dispatch(base, DISPATCH)
            changelog = self._changelog(base)
            notes_out = base / "emitted-notes.md"
            result = run_gate("--version", VERSION,
                              "--dispatch", str(dispatch),
                              "--changelog", str(changelog),
                              "--emit-notes", str(notes_out))
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            evidence = json.loads(result.stdout)
            self.assertEqual(evidence["requested"], True)
            self.assertEqual(evidence["version"], VERSION)
            self.assertEqual(evidence["target"], GENERIC_TARGET,
                             "the frozen-target binding is part of the "
                             "gate evidence")
            self.assertEqual(evidence["authorized_by"], "User")
            self.assertEqual(evidence["timing"], "now")
            self.assertEqual(notes_out.read_text(), NOTES,
                             "the notes block is emitted verbatim")

    def test_gate_action_none_is_a_clean_no_request(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            content = ("# cleared dispatch record\n"
                       "action: none\n")
            dispatch = self._write_dispatch(base, content)
            changelog = self._changelog(base)
            notes_out = base / "emitted-notes.md"
            result = run_gate("--version", VERSION,
                              "--dispatch", str(dispatch),
                              "--changelog", str(changelog),
                              "--emit-notes", str(notes_out))
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            evidence = json.loads(result.stdout)
            self.assertEqual(evidence["requested"], False,
                             "a cleared record is a governance write, not a "
                             "failed release")
            self.assertFalse(notes_out.exists(),
                             "no notes are emitted without a release request")

    def test_gate_rejects_missing_mismatched_or_non_user_authorization(self):
        # AC2/AC5 + AC7-2/AC7-5: only an explicit, User-owned durable
        # authorization mirror covering the SAME version and timing
        # semantics passes. Merge, Issue DONE, Milestone completion,
        # runtime/bootstrap need, and deadline signals are spelled out here
        # and are all refused as authorized_by values. R3: a release record
        # must also bind the frozen exact target — a full 40-hex commit
        # SHA, never a ref, a short SHA, or an absent binding.
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            lines = DISPATCH.splitlines()
            begin = lines.index("release-notes-begin:")
            end = lines.index("release-notes-end:")
            head, block = lines[:begin], lines[begin:end + 1]

            def dispatch_with(**replacements):
                out = []
                for line in head:
                    key = line.split(":", 1)[0].strip()
                    if key in replacements:
                        out.append(f"{key}: {replacements[key]}")
                    else:
                        out.append(line)
                return "\n".join(out + block) + "\n"

            def without(key):
                return "\n".join(
                    [l for l in head if not l.startswith(f"{key}:")] + block) + "\n"

            cases = [
                ("action missing", "\n".join(
                    [l for l in head if not l.startswith("action:")] + block) + "\n",
                 "action"),
                ("action unknown", dispatch_with(action="deploy"), "action"),
                ("target missing", without("target"), "target"),
                ("target is a ref name", dispatch_with(target="main"), "40-hex"),
                ("target is a short sha", dispatch_with(target="abc1234"),
                 "40-hex"),
                ("target has non-hex garbage",
                 dispatch_with(target="zzz" * 13 + "z"), "40-hex"),
                ("authorized_by: A", dispatch_with(authorized_by="A"),
                 "not the User"),
                ("authorized_by: merge signal",
                 dispatch_with(authorized_by="merge of PR #123"),
                 "not the User"),
                ("authorized_by: milestone",
                 dispatch_with(authorized_by="milestone v1.0.x completed"),
                 "not the User"),
                ("authorized_by: issue done",
                 dispatch_with(authorized_by="Issue DONE"), "not the User"),
                ("authorized_by: runtime need",
                 dispatch_with(authorized_by="runtime bootstrap need"),
                 "not the User"),
                ("authorized_by: deadline",
                 dispatch_with(authorized_by="deadline 2026-10-01"),
                 "not the User"),
                ("authorized_by: lowercase user",
                 dispatch_with(authorized_by="user"), "not the User"),
                ("missing timing", without("timing"), "timing"),
                ("missing statement", without("statement"), "statement"),
                ("missing version key", without("version"), "version"),
                ("non key:value garbage line",
                 "\n".join(head + ["this line has no colon"] + block) + "\n",
                 "key: value"),
                ("empty statement", dispatch_with(statement=""), "statement"),
                ("notes block missing end marker",
                 "\n".join(head + lines[begin:end]) + "\n", "release-notes-end"),
                ("duplicate notes block", DISPATCH + DISPATCH, "duplicate"),
                ("empty notes", dispatch_with().replace(
                    "release-notes-begin:\n" + NOTES + "release-notes-end:\n",
                    "release-notes-begin:\n\nrelease-notes-end:\n"), "Notes"),
                ("changelog lacks the version entry", DISPATCH, "CHANGELOG"),
            ]
            stripped_changelog = CHANGELOG.replace(
                "## v9.9.9 — 2026-09-23", "## v9.9.7 — 2026-09-23")
            for name, content, expect in cases:
                dispatch = self._write_dispatch(base, content, name="m")
                changelog = self._changelog(
                    base, stripped_changelog if name == "changelog lacks the "
                    "version entry" else CHANGELOG)
                result = run_gate("--version", VERSION,
                                  "--dispatch", str(dispatch),
                                  "--changelog", str(changelog))
                self.assertNotEqual(result.returncode, 0, name)
                self.assertIn("fail closed", result.stdout + result.stderr, name)
                self.assertIn(expect, result.stdout + result.stderr, name)
            # Absent dispatch file at the requested path.
            result = run_gate("--version", VERSION,
                              "--dispatch", str(base / "absent.yaml"),
                              "--changelog", str(self._changelog(base)))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("fail closed", result.stdout + result.stderr)
            # A release record without the frozen target's CHANGELOG can
            # never pass, even with every field present.
            result = run_gate("--version", VERSION,
                              "--dispatch", str(self._write_dispatch(base, DISPATCH)),
                              "--emit-notes", str(base / "nope.md"))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("CHANGELOG", result.stdout + result.stderr)

    def test_gate_version_cross_check_fails_closed(self):
        # The glue extracts the version from the dispatch record's flat
        # head for argv assembly; the gate re-parses the record itself and
        # refuses any disagreement between the two reads.
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            result = run_gate("--version", "v9.9.8",
                              "--dispatch", str(self._write_dispatch(base, DISPATCH)),
                              "--changelog", str(self._changelog(base)))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("authorizes", result.stdout + result.stderr)

    def test_gate_version_prefix_siblings_fail_closed(self):
        # v9.9.9 must not be satisfied by a v9.9.90 changelog heading — the
        # version identity is exact, never a prefix.
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            changelog = CHANGELOG.replace("## v9.9.9 — 2026-09-23",
                                          "## v9.9.90 — 2026-09-23")
            result = run_gate("--version", VERSION,
                              "--dispatch", str(self._write_dispatch(base, DISPATCH)),
                              "--changelog", str(self._changelog(base, changelog)))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("CHANGELOG", result.stdout + result.stderr)

    # -- the canonical primitive invocation binding -----------------------

    def test_glue_invokes_canonical_primitive_with_exact_argv_and_payload_notes(self):
        # AC1/AC3: with every gate satisfied the glue hands the frozen
        # decision to the canonical `ght release-publish` primitive verbatim
        # — exact argv (the FROZEN TARGET from the record, never the
        # record's own commit), and a notes file whose bytes are exactly
        # the dispatch record's notes block (never regenerated, never
        # mended). #125 R4: NO governance-path argument reaches the
        # primitive — the designated-record binding is the primitive's own
        # policy constant, granted only by the record's durable
        # frozen-target binding; no authorization mirror field does either.
        with tempfile.TemporaryDirectory() as tmp:
            stub = Path(tmp) / "ght-stub.py"
            marker = Path(tmp) / "invocation.json"
            stub.write_text(
                "#!/usr/bin/env python3\n"
                "import json, os, sys\n"
                "argv = sys.argv[1:]\n"
                "notes = argv[argv.index('--notes-file') + 1]\n"
                "open(os.environ['GHT_STUB_OUT'], 'w').write(json.dumps(\n"
                "    {'argv': argv, 'notes': open(notes).read()}))\n")
            stub.chmod(stub.stat().st_mode | stat.S_IXUSR)
            result = run_glue(DISPATCH_PATH, self.dispatch_commit,
                              cwd=str(self.worker),
                              env_extra=self._run_env(
                                  GHT_FORMAL_RELEASE_GHT_BIN=str(stub),
                                  GHT_STUB_OUT=str(marker)))
            self.assertEqual(result.returncode, 0, result.stderr)
            seen = json.loads(marker.read_text())
            self.assertEqual(
                seen["argv"],
                ["--json", "release-publish", "--version", VERSION,
                 "--target", self.target, "--notes-file",
                 seen["argv"][seen["argv"].index("--notes-file") + 1]],
                "the glue passes only the frozen decision — no "
                "governance-path argument exists")
            self.assertNotIn("--governance-paths", seen["argv"],
                             "#125 R4: no caller-supplied governance binding "
                             "reaches the primitive; the designated-record "
                             "exception is the primitive's own policy")
            self.assertEqual(seen["argv"][seen["argv"].index("--target") + 1],
                             self.target,
                             "the primitive is aimed at the record-bound "
                             "frozen target, never the trigger commit")
            self.assertNotIn(self.dispatch_commit, seen["argv"],
                             "the record's own commit must never appear as "
                             "the publication target")
            self.assertNotIn("--dispatch", seen["argv"],
                             "authorization is gate-side only; the primitive "
                             "never receives the record as an authorization "
                             "surface")
            self.assertEqual(seen["notes"], NOTES,
                             "the primitive must publish the dispatch "
                             "record's notes bytes, verbatim")

    def test_action_none_dispatch_never_invokes_the_primitive(self):
        with tempfile.TemporaryDirectory() as tmp:
            stub = Path(tmp) / "ght-stub-never.py"
            marker = Path(tmp) / "invoked.json"
            stub.write_text(
                "#!/usr/bin/env python3\n"
                "import json, os, sys\n"
                "open(os.environ['GHT_STUB_OUT'], 'w').write("
                "json.dumps(sys.argv[1:]))\n")
            stub.chmod(stub.stat().st_mode | stat.S_IXUSR)
            cleared = ("# cleared\naction: none\n")
            new_commit = self._commit_dispatch(cleared, "clear dispatch record")
            result = run_glue(DISPATCH_PATH, new_commit,
                              cwd=str(self.worker),
                              env_extra=self._run_env(
                                  GHT_FORMAL_RELEASE_GHT_BIN=str(stub),
                                  GHT_STUB_OUT=str(marker)))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("no release requested", result.stdout + result.stderr)
            self.assertFalse(marker.exists(),
                             "a cleared record must never reach the primitive")

    # -- AC7 conformance scenarios end-to-end through the workflow glue --

    def test_valid_authorized_release_publishes_with_exact_target_read_back(self):
        # AC7-1 + AC7-6 (AC3/AC4): the valid path publishes the tag and the
        # GitHub Release on the SAME record-bound frozen exact target —
        # which is the accepted-main cut A froze BEFORE the trigger write,
        # never the dispatch record's own commit — the Release body is
        # byte-identical to the dispatch record's notes, and the runtime
        # read-back proves the requested release identity.
        result = self._release()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["tag"], "created")
        self.assertEqual(payload["release"], "created")
        self.assertEqual(payload["target"], self.target,
                         "the read-back names the frozen target")
        self.assertNotEqual(payload["target"], self.dispatch_commit,
                            "the trigger commit is never the release target")
        self.assertEqual(self._remote_tag_sha(), self.target,
                         "the published tag binds the frozen exact target SHA")
        release = json.loads(self.state.read_text())["releases"][VERSION]
        self.assertEqual(release["body"], NOTES,
                         "the Release body is the dispatch record's notes, verbatim")
        self.assertEqual(release["draft"], False)
        self.assertEqual(release["prerelease"], False)
        self.assertEqual(payload["runtime"]["release"], VERSION)
        self.assertTrue(self.target.startswith(payload["runtime"]["source_sha"]),
                        "the runtime capsule proves the frozen target source")
        self.assertEqual(payload["runtime"]["pin_ref_sha"],
                         payload["runtime"]["capsule_ref_sha"],
                         "activation read-back: pin and capsule are one object")

    def test_installation_token_publishes_through_the_release_publisher_identity(self):
        # #130 AC1/AC4: no human principal (installation token) + the
        # dedicated release-publisher identity → the canonical publication
        # path executes end-to-end and still binds the FROZEN target, never
        # the trigger commit; the identity is execution/audit plumbing only.
        result = self._release(GHT_TEST_FAIL_API_USER="1",
                               GHT_RELEASE_PUBLISHER_ID="ght-formal-release-workflow")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["tag"], "created")
        self.assertEqual(payload["release"], "created")
        self.assertEqual(self._remote_tag_sha(), self.target,
                         "the tag still binds the frozen exact target SHA")
        self.assertNotEqual(payload["target"], self.dispatch_commit)

    def test_installation_token_without_publisher_identity_fails_closed(self):
        # #130 AC1: no human principal and NO dedicated identity → fail
        # closed before any tag/Release write; nothing is published.
        result = self._release(GHT_TEST_FAIL_API_USER="1")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("fail closed", result.stdout + result.stderr)
        self.assertIsNone(self._remote_tag_sha(),
                          "an unidentifiable credential never publishes")

    def test_governance_only_redispatch_still_publishes_the_frozen_target(self):
        # R3: re-dispatching an unchanged frozen decision (an identical
        # governance write on top of the first one) must still publish the
        # SAME frozen target — the governance-only advance between the
        # frozen target and the newer trigger commit never changes the
        # release source cut.
        redispatch = self._commit_dispatch(
            "# re-dispatch of the same frozen decision\n"
            + dispatch_record(target=self.target),
            "re-dispatch the same frozen decision")
        self.assertNotEqual(redispatch, self.dispatch_commit)
        result = self._release(commit=redispatch)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["tag"], "created")
        self.assertEqual(payload["target"], self.target)
        self.assertEqual(self._remote_tag_sha(), self.target,
                         "the frozen target is published through a "
                         "governance-only advance")

    def test_missing_or_mismatched_authorization_fails_before_publication(self):
        # AC7-2 (AC2): a dispatch record absent from the trigger commit, or
        # one authorizing a version the frozen target's CHANGELOG does not
        # carry, stops everything before any publication write — no tag,
        # no Release.
        absent = self._release(dispatch="docs/releases/absent.yaml")
        self.assertNotEqual(absent.returncode, 0, absent.stdout + absent.stderr)
        self.assertIn("fail closed", absent.stderr)
        self.assertIsNone(self._remote_tag_sha(), "nothing may publish")
        self.assertEqual(json.loads(self.state.read_text())["releases"], {})
        other_commit = self._commit_dispatch(
            dispatch_record(target=self.target).replace(
                "version: v9.9.9", "version: v9.9.7"),
            "dispatch v9.9.7 (no cut entry)")
        other_run = self._release(commit=other_commit)
        self.assertNotEqual(other_run.returncode, 0,
                            other_run.stdout + other_run.stderr)
        self.assertIn("CHANGELOG", other_run.stdout + other_run.stderr)
        self.assertIsNone(self._remote_tag_sha("v9.9.7"),
                          "an uncut version publishes nothing")
        self.assertEqual(json.loads(self.state.read_text())["releases"], {})

    def test_material_drift_between_freeze_and_dispatch_fails_closed(self):
        # R3 (AC2/AC6): accepted main moving past the frozen cut is never
        # absorbed by the release. (a) A SOURCE commit lands before A's
        # dispatch write: the record written on top still binds the older
        # frozen target — the glue must refuse before the primitive. (b) A
        # merge commit enters the frozen range: same verdict.
        source_sha = self._advance_main_with_source("late.txt")
        seed = self.tmp / "seed"
        self._git(seed, "fetch", "-q", "origin")
        self._git(seed, "reset", "-q", "--hard", "origin/main")
        (seed / "docs" / "releases" / "dispatch.yaml").write_text(
            dispatch_record(target=self.target))
        self._git(seed, "add", "-A")
        self._git(seed, "commit", "-qm", "dispatch after un-reconciled drift")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        drifted_commit = self._git(seed, "rev-parse", "HEAD").stdout.strip()
        result = self._release(commit=drifted_commit)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("material drift", result.stderr)
        self.assertIn("late.txt", result.stderr,
                      "the drifting content is named in the verdict")
        self.assertIsNone(self._remote_tag_sha(),
                          "nothing is published from a drifted cut")
        self.assertEqual(json.loads(self.state.read_text())["releases"], {})

        # (b) a merge commit inside the frozen range is equally drift.
        side = self.tmp / "side"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(side))
        self._git(side, "checkout", "-q", "-b", "side-task", "origin/main")
        (side / "side.txt").write_text("side work\n")
        self._git(side, "add", "-A")
        self._git(side, "commit", "-qm", "side work")
        self._git(side, "checkout", "-q", "main")
        self._git(side, "merge", "--no-ff", "-q", "-m", "merge side work",
                  "side-task")
        self._git(side, "push", "-q", "origin", "main")
        merge_commit = self._commit_dispatch(
            dispatch_record(target=self.target),
            "dispatch across a merge drift")
        result = self._release(commit=merge_commit)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("material drift", result.stderr)
        self.assertIsNone(self._remote_tag_sha())
        self.assertEqual(json.loads(self.state.read_text())["releases"], {})
        self.assertTrue(source_sha)  # (a)'s drift commit stays asserted

    def test_target_drift_after_dispatch_fails_closed_at_the_primitive(self):
        # AC7-3 (AC2): accepted main advances with real source work AFTER
        # the dispatch write — the glue's frozen range is clean, so the
        # canonical primitive itself refuses: current accepted main is no
        # longer the frozen target and the advance is not governance-only.
        # Never auto-retarget; A must reconcile.
        self._advance_main_with_source("after.txt")
        self._git(self.worker, "fetch", "-q", "origin")
        result = self._release()
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("target drift", result.stdout + result.stderr)
        self.assertIsNone(self._remote_tag_sha(),
                          "nothing is published from a drifted decision")
        self.assertEqual(json.loads(self.state.read_text())["releases"], {})

    def test_governance_advance_after_dispatch_is_not_drift(self):
        # R3 mirror of the drift case: extra designated-record governance
        # writes landing between the dispatch and the publication read
        # (e.g. a re-dispatch racing the run) do NOT move the release cut —
        # the primitive's --governance-paths binding accepts exactly that
        # advance and still tags the frozen target.
        cleared_then_same = self._commit_dispatch(
            "# governance noise\n" + dispatch_record(target=self.target),
            "another governance write of the same decision")
        self._git(self.worker, "fetch", "-q", "origin")
        result = self._release(commit=self.dispatch_commit)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["target"], self.target)
        self.assertEqual(payload["tag"], "created")
        self.assertEqual(self._remote_tag_sha(), self.target)
        self.assertTrue(cleared_then_same)  # the advance commit is real

    def test_conflicting_tag_fails_closed_without_moving(self):
        # AC7-4 (AC4): the version tag already points elsewhere — the
        # publication fails closed and the published tag is never moved.
        other = self._git(self.worker, "commit-tree",
                          self._git(self.worker, "mktree", input_text="").stdout.strip(),
                          "-m", "unrelated commit").stdout.strip()
        self._git(self.worker, "push", "-q", "origin", f"{other}:refs/tags/{VERSION}")
        result = self._release()
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("collision", (result.stdout + result.stderr).lower())
        self.assertEqual(self._remote_tag_sha(), other,
                         "the colliding tag is never force-moved")
        self.assertEqual(json.loads(self.state.read_text())["releases"], {})

    def test_republication_is_idempotent_without_rewrite(self):
        # AC4: re-triggering with the same frozen decision reconciles —
        # idempotent tag/Release, one Release total, same capsule identity.
        first = self._release()
        self.assertEqual(first.returncode, 0, first.stdout + first.stderr)
        digest = json.loads(first.stdout)["runtime"]["digest"]
        again = self._release()
        self.assertEqual(again.returncode, 0, again.stdout + again.stderr)
        payload = json.loads(again.stdout)
        self.assertEqual(payload["tag"], "idempotent")
        self.assertEqual(payload["release"], "idempotent")
        self.assertEqual(payload["target"], self.target)
        self.assertEqual(payload["runtime"]["digest"], digest)
        self.assertEqual(len(json.loads(self.state.read_text())["releases"]), 1)

    def test_partial_publication_is_exposed_and_resumes_fail_closed(self):
        # AC6: a publication write that fails halfway leaves NO success
        # signal — the failure is exposed with the completed facts named —
        # and a re-run with the same frozen decision resumes to completion
        # without rewriting the already-published immutable facts.
        partial = self._release(GHT_TEST_FAIL_RELEASE="1")
        self.assertNotEqual(partial.returncode, 0, partial.stdout + partial.stderr)
        self.assertEqual(self._remote_tag_sha(), self.target,
                         "the completed tag fact is durable and exposed")
        self.assertEqual(json.loads(self.state.read_text())["releases"], {},
                         "the Release write did not succeed")
        resumed = self._release()
        self.assertEqual(resumed.returncode, 0, resumed.stdout + resumed.stderr)
        payload = json.loads(resumed.stdout)
        self.assertEqual(payload["tag"], "idempotent",
                         "resume never rewrites the existing immutable tag")
        self.assertEqual(payload["release"], "created")
        self.assertEqual(len(json.loads(self.state.read_text())["releases"]), 1)
        self.assertEqual(
            json.loads(self.state.read_text())["releases"][VERSION]["body"], NOTES)

    # -- AC8: the canonical documentation surface -------------------------

    def test_release_policy_documents_the_canonical_workflow_path(self):
        policy = (SKILL_ROOT.parent.parent / "docs" / "release-policy.md").read_text()
        self.assertIn(".github/workflows/formal-release.yml", policy,
                      "the canonical workflow is named in the release policy")
        self.assertIn("docs/releases/dispatch.yaml", policy,
                      "the A dispatch record convention is documented")
        self.assertIn(
            "User explicit authorization → A authorization mirror + "
            "exact-target freeze → A triggers canonical release workflow → "
            "workflow mechanical publication/read-back → A verifies durable "
            "release fact", policy,
            "the canonical normal path chain must be stated verbatim")
        self.assertIn("ght release-publish", policy,
                      "the workflow delegates to the canonical primitive")
        self.assertIn("authorized_by", policy)
        # R3 correction: the freeze precedes the trigger write; the record
        # binds the frozen target and never becomes it.
        self.assertIn("exact-target freeze 先于 trigger write", policy,
                      "the R3 ordering (freeze before the dispatch write) "
                      "is documented")
        self.assertIn("material drift", policy,
                      "the drift-not-absorbed rule is documented")
        self.assertIn("40-hex", policy,
                      "the record's exact frozen-target binding format is "
                      "documented")
        for invariant in ("NO RELEASE by default", "Timing ≠ Authority",
                          "workflow_dispatch"):
            self.assertIn(invariant, policy,
                          f"invariant/trigger discipline {invariant!r} must stay")
        self.assertNotIn("target_release", policy.replace("`target_release`", ""),
                         "no target_release Contract field may be introduced")


if __name__ == "__main__":
    unittest.main()
