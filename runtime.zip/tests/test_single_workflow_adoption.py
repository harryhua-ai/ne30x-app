"""Regression / isolated Git capsule smoke tests for #249's one-file caller."""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest
import zipfile
from unittest.mock import patch

from github_task.single_workflow_adoption import (
    DESTINATION, MARKER, SingleWorkflowAdoptionError, inspect, prepare,
)

PIN_A = "a" * 64
PIN_B = "b" * 64
SRC = Path(__file__).resolve().parents[1]


def command(*args, cwd, env=None):
    return subprocess.run(args, cwd=cwd, env=env, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def capsule_zip(*, unsafe=False):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in (
            "scripts/ght-gha-adapter.sh",
            "scripts/ght-gha-complete.sh",
            "scripts/ght-plan-publish.sh",
            "scripts/ght-gha-review-trigger.py",
            "scripts/ght-gha-review-verdict.py",
        ):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            mode = 0o755 if name in (
                "scripts/ght-gha-adapter.sh",
                "scripts/ght-gha-complete.sh",
            ) else 0o644
            info.external_attr = mode << 16
            archive.writestr(info, b"# fixture\n")
        if unsafe:
            archive.writestr("../outside.txt", "bad")
    return buffer.getvalue()


def runtime_capsule(files, release, source_sha):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, (content, mode) in sorted(files.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.external_attr = mode << 16
            archive.writestr(info, content)
    payload = buffer.getvalue()
    digest = hashlib.sha256(payload).hexdigest()
    manifest = {"v": 1, "kind": "runtime-capsule", "product": "harry-dev",
                "release": release, "source_sha": source_sha, "digest": digest}
    return payload, digest, manifest


class SingleWorkflowAdoptionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ght-single-"))
        self.root = self.tmp / "target"
        self.root.mkdir()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_fresh_and_idempotent_exact_one_file(self):
        first = prepare(self.root, PIN_A)
        self.assertEqual(first["changed_files"], [DESTINATION])
        all_files = [p.relative_to(self.root).as_posix()
                     for p in self.root.rglob("*") if p.is_file()]
        self.assertEqual(all_files, [DESTINATION])
        text = (self.root / DESTINATION).read_text()
        self.assertEqual(text.count(PIN_A), 3)
        self.assertNotIn("@GHT_RUNTIME_REF@", text)
        self.assertEqual(prepare(self.root, PIN_A)["changed_files"], [])

    def test_checkout_action_uses_verified_immutable_commit(self):
        text = (SRC / "workflow_templates" / "ght.yml").read_text()
        self.assertEqual(
            text.count("uses: actions/checkout@11d5960a326750d5838078e36cf38b85af677262"),
            3)
        self.assertNotRegex(text, r"uses:\s+actions/checkout@v[0-9]+")

    def test_explicit_upgrade_preserves_other_files(self):
        prepare(self.root, PIN_A)
        workflow = self.root / DESTINATION
        original_workflow = workflow.read_bytes()
        unrelated = self.root / "README.md"
        unrelated.write_bytes(b"project-owned\x00\xff")
        with self.assertRaises(SingleWorkflowAdoptionError):
            prepare(self.root, PIN_B)
        self.assertEqual(workflow.read_bytes(), original_workflow)
        result = prepare(self.root, PIN_B, upgrade_selector=True)
        self.assertEqual(result["changed_files"], [DESTINATION])
        self.assertEqual(unrelated.read_bytes(), b"project-owned\x00\xff")
        expected = ((SRC / "workflow_templates" / "ght.yml").read_bytes()
                    .replace(b"@GHT_RUNTIME_REF@", PIN_B.encode()))
        self.assertEqual(workflow.read_bytes(), expected)

    def test_legacy_files_require_separate_migration(self):
        f = self.root / ".github/workflows/ght-complete.yml"
        f.parent.mkdir(parents=True)
        f.write_text("project")
        with self.assertRaisesRegex(SingleWorkflowAdoptionError, "migration"):
            prepare(self.root, PIN_A, upgrade_selector=True)
        self.assertFalse((self.root / DESTINATION).exists())
        self.assertEqual(f.read_text(), "project")

    def test_unknown_legacy_script_and_agents_block_require_migration(self):
        script = self.root / "scripts/ght/custom-inherited-script.sh"
        script.parent.mkdir(parents=True)
        script.write_text("echo legacy")
        with self.assertRaisesRegex(SingleWorkflowAdoptionError, "migration"):
            prepare(self.root, PIN_A)
        script.unlink()
        (self.root / "AGENTS.md").write_text(
            "<!-- harry-dev:agents-managed begin v1 -->\\n")
        with self.assertRaisesRegex(SingleWorkflowAdoptionError, "migration"):
            prepare(self.root, PIN_A)

    def test_preflight_race_with_legacy_file_prevents_write(self):
        plan = inspect(self.root, PIN_A)
        old = self.root / ".github/workflows/ght-other.yml"
        old.parent.mkdir(parents=True)
        old.write_text("legacy")
        from github_task.single_workflow_adoption import apply
        with self.assertRaisesRegex(SingleWorkflowAdoptionError, "after preflight"):
            apply(plan)
        self.assertFalse((self.root / DESTINATION).exists())

    def test_completion_must_reload_runtime_bound_to_claim(self):
        text = (SRC / "workflow_templates" / "ght.yml").read_text()
        self.assertIn(
            'run: GHT_RUNTIME_DIR= sh "$GHT_RUNTIME_DIR/scripts/ght-gha-adapter.sh" complete',
            text)
        self.assertIn(
            'run: sh "$GHT_RUNTIME_DIR/scripts/ght-gha-adapter.sh" resolve',
            text)

    def test_managed_marker_is_not_arbitrary_overwrite_authority(self):
        path = self.root / DESTINATION
        path.parent.mkdir(parents=True)
        spoof = (MARKER +
                 "\nname: project-workflow\njobs:\n  deploy:\n    runs-on: self-hosted\n")
        path.write_bytes(spoof.encode())
        with self.assertRaisesRegex(SingleWorkflowAdoptionError, "project-owned"):
            prepare(self.root, PIN_A, upgrade_selector=True)
        self.assertEqual(path.read_bytes(), spoof.encode())
        wrong_marker = b"# ght-adoption-managed: evil\nname: project-workflow\n"
        path.write_bytes(wrong_marker)
        with self.assertRaises(SingleWorkflowAdoptionError):
            prepare(self.root, PIN_A, upgrade_selector=True)
        self.assertEqual(path.read_bytes(), wrong_marker)

    def test_modified_managed_workflow_is_not_upgrade_authority(self):
        prepare(self.root, PIN_A)
        path = self.root / DESTINATION
        original = path.read_bytes()
        modified = original + b"\n# project-owned addition\n"
        path.write_bytes(modified)
        with self.assertRaisesRegex(SingleWorkflowAdoptionError, "project-owned"):
            prepare(self.root, PIN_B, upgrade_selector=True)
        self.assertEqual(path.read_bytes(), modified)

    def test_managed_template_with_invalid_old_pin_is_not_upgrade_authority(self):
        path = self.root / DESTINATION
        path.parent.mkdir(parents=True)
        invalid = ((SRC / "workflow_templates" / "ght.yml").read_bytes()
                   .replace(b"@GHT_RUNTIME_REF@", b"A" * 64))
        path.write_bytes(invalid)
        with self.assertRaisesRegex(SingleWorkflowAdoptionError, "project-owned"):
            prepare(self.root, PIN_B, upgrade_selector=True)
        self.assertEqual(path.read_bytes(), invalid)

    def test_same_bytes_replacement_during_upgrade_is_detected(self):
        from github_task import single_workflow_adoption as adoption

        prepare(self.root, PIN_A)
        path = self.root / DESTINATION
        original = path.read_bytes()
        original_inode = path.stat().st_ino
        plan = inspect(self.root, PIN_B, upgrade_selector=True)
        racer = self.tmp / "same-bytes-racer"
        racer.write_bytes(original)
        racer_inode = racer.stat().st_ino
        real_open = os.open
        injected = False

        def replace_after_staging(name, flags, *args, **kwargs):
            nonlocal injected
            fd = real_open(name, flags, *args, **kwargs)
            if ".ght-adoption-" in os.fspath(name) and not injected:
                injected = True
                os.replace(racer, path)
            return fd

        with patch.object(adoption.os, "open", side_effect=replace_after_staging):
            with self.assertRaisesRegex(SingleWorkflowAdoptionError, "changed"):
                adoption.apply(plan)
        self.assertTrue(injected)
        self.assertNotEqual(original_inode, racer_inode)
        self.assertEqual(path.stat().st_ino, racer_inode)
        self.assertEqual(path.read_bytes(), original)

    def test_parent_symlink_replacement_during_create_is_refused(self):
        from github_task import single_workflow_adoption as adoption

        plan = inspect(self.root, PIN_A)
        parent = self.root / ".github/workflows"
        moved_parent = self.root / ".github/workflows-moved"
        outside = self.tmp / "outside"
        outside.mkdir()
        sentinel = outside / "sentinel"
        sentinel.write_bytes(b"outside data")
        real_open = os.open
        injected = False

        def replace_parent_before_create(name, flags, *args, **kwargs):
            nonlocal injected
            is_create = flags & os.O_CREAT
            is_workflow = (os.fspath(name) == os.fspath(self.root / DESTINATION)
                           or os.fspath(name) == "ght.yml")
            if is_create and is_workflow and not injected:
                injected = True
                os.rename(parent, moved_parent)
                parent.symlink_to(outside, target_is_directory=True)
            return real_open(name, flags, *args, **kwargs)

        with patch.object(adoption.os, "open", side_effect=replace_parent_before_create):
            with self.assertRaises(SingleWorkflowAdoptionError):
                adoption.apply(plan)
        self.assertTrue(injected)
        self.assertEqual(sentinel.read_bytes(), b"outside data")
        self.assertFalse((outside / "ght.yml").exists())
        self.assertFalse((moved_parent / "ght.yml").exists())

    def test_parent_symlink_replacement_during_upgrade_is_refused(self):
        from github_task import single_workflow_adoption as adoption

        prepare(self.root, PIN_A)
        path = self.root / DESTINATION
        original = path.read_bytes()
        plan = inspect(self.root, PIN_B, upgrade_selector=True)
        parent = path.parent
        moved_parent = self.root / ".github/workflows-moved"
        real_open = os.open
        injected = False

        def replace_parent_after_staging(name, flags, *args, **kwargs):
            nonlocal injected
            fd = real_open(name, flags, *args, **kwargs)
            if ".ght-adoption-" in os.fspath(name) and not injected:
                injected = True
                os.rename(parent, moved_parent)
                parent.symlink_to(moved_parent, target_is_directory=True)
            return fd

        with patch.object(adoption.os, "open", side_effect=replace_parent_after_staging):
            with self.assertRaises(SingleWorkflowAdoptionError):
                adoption.apply(plan)
        self.assertTrue(injected)
        self.assertTrue(parent.is_symlink())
        self.assertEqual((moved_parent / "ght.yml").read_bytes(), original)
        self.assertEqual(sorted(p.name for p in moved_parent.iterdir()), ["ght.yml"])

    def test_symlink_is_refused(self):
        external = self.tmp / "outside"
        external.write_text("safe")
        (self.root / ".github").symlink_to(self.tmp, target_is_directory=True)
        with self.assertRaises(SingleWorkflowAdoptionError):
            inspect(self.root, PIN_A)
        self.assertEqual(external.read_text(), "safe")

    def test_invalid_pin_fails_without_writes(self):
        for pin in ("latest", PIN_A[:-1], PIN_A.upper()):
            with self.assertRaises(SingleWorkflowAdoptionError):
                prepare(self.root, pin)
        self.assertEqual(list(self.root.rglob("*")), [])

    def _run_loader(self, *, unsafe=False, corrupt=False, missing=False,
                    bad_identity=False, move_ref=False, job="review"):
        payload = capsule_zip(unsafe=unsafe)
        digest = hashlib.sha256(payload).hexdigest()
        origin = self.tmp / "origin.git"
        checkout = self.tmp / "checkout"
        self.assertEqual(command("git", "init", "--bare", str(origin),
                                 cwd=self.tmp).returncode, 0)
        self.assertEqual(command("git", "clone", str(origin), str(checkout),
                                 cwd=self.tmp).returncode, 0)
        (checkout / "README.md").write_text("fixture")
        for args in [
            ("git", "add", "README.md"),
            ("git", "-c", "user.name=T", "-c", "user.email=t@x",
             "commit", "-m", "initial"),
        ]:
            p = command(*args, cwd=checkout)
            self.assertEqual(p.returncode, 0, p.stderr)
        manifest = {"v": 1, "kind": "runtime-capsule", "product": "harry-dev",
                    "release": "v1.1.7", "source_sha": "a" * 40, "digest": digest}
        if bad_identity:
            manifest["source_sha"] = "a" * 39
        (checkout / "runtime.zip").write_bytes(payload + (b"tampered" if corrupt else b""))
        (checkout / "MANIFEST.json").write_text(json.dumps(manifest))
        p = command("git", "add", "runtime.zip", "MANIFEST.json", cwd=checkout)
        self.assertEqual(p.returncode, 0, p.stderr)
        p = command("git", "-c", "user.name=T", "-c", "user.email=t@x",
                    "commit", "-m", "capsule", cwd=checkout)
        self.assertEqual(p.returncode, 0, p.stderr)
        runtime_ref = f"refs/ght/runtime/{digest}"
        if not missing:
            p = command("git", "push", "origin", f"HEAD:{runtime_ref}", cwd=checkout)
            self.assertEqual(p.returncode, 0, p.stderr)
        env = {**os.environ, "GHT_RUNTIME_REF": digest,
               "GITHUB_RUN_ID": "123", "GITHUB_RUN_ATTEMPT": "1",
               "GITHUB_ENV": str(self.tmp / "github-env"),
               "RUNNER_TEMP": str(self.tmp)}
        if move_ref:
            (checkout / "move.txt").write_text("new capsule ref target")
            p = command("git", "add", "move.txt", cwd=checkout)
            self.assertEqual(p.returncode, 0, p.stderr)
            p = command("git", "-c", "user.name=T", "-c", "user.email=t@x",
                        "commit", "-m", "mover", cwd=checkout)
            self.assertEqual(p.returncode, 0, p.stderr)
            moved_sha = command("git", "rev-parse", "HEAD", cwd=checkout).stdout.strip()
            p = command("git", "push", "origin", "HEAD:refs/heads/mover", cwd=checkout)
            self.assertEqual(p.returncode, 0, p.stderr)
            wrapper_dir = self.tmp / "git-wrapper"
            wrapper_dir.mkdir()
            wrapper = wrapper_dir / "git"
            wrapper.write_text(
                "#!/bin/sh\n"
                '"$GHT_TEST_REAL_GIT" "$@"\n'
                "status=$?\n"
                'if [ "$status" -eq 0 ] && [ "${1:-}" = fetch ] && '
                '[ "${GHT_TEST_MOVE_REF:-0}" = 1 ]; then\n'
                '  "$GHT_TEST_REAL_GIT" --git-dir="$GHT_TEST_ORIGIN" '
                'update-ref "$GHT_TEST_REF" "$GHT_TEST_MOVED_SHA"\n'
                "fi\n"
                "exit $status\n")
            wrapper.chmod(0o755)
            env.update({
                "PATH": str(wrapper_dir) + os.pathsep + os.environ["PATH"],
                "GHT_TEST_REAL_GIT": shutil.which("git"),
                "GHT_TEST_ORIGIN": str(origin),
                "GHT_TEST_REF": runtime_ref,
                "GHT_TEST_MOVED_SHA": moved_sha,
                "GHT_TEST_MOVE_REF": "1",
            })
        text = (SRC / "workflow_templates" / "ght.yml").read_text()
        sections = re.findall(
            r"      - name: Materialize and verify immutable local Runtime\n"
            r"        shell: bash\n        run: \|\n"
            r"((?:          .*\n|\n)+)", text)
        self.assertEqual(len(sections), 3)
        index = {"review": 0, "complete": 1, "plan": 2}[job]
        script = "\n".join(line[10:] if line.startswith("          ") else line
                           for line in sections[index].splitlines()) + "\n"
        run_file = self.tmp / "loader.sh"
        run_file.write_text(script)
        env_file = self.tmp / "github-env"
        env_file.write_text("")
        env["GITHUB_ENV"] = str(env_file)
        result = command("bash", str(run_file), cwd=checkout, env=env)
        return result, env_file

    def test_loader_runs_on_real_local_git_capsule_for_all_jobs(self):
        for job in ("review", "complete", "plan"):
            with self.subTest(job=job):
                # fresh git fixture for each job
                case = self.tmp / job
                case.mkdir()
                original_tmp, self.tmp = self.tmp, case
                try:
                    result, env_file = self._run_loader(job=job)
                    self.assertEqual(result.returncode, 0,
                                     result.stdout + result.stderr)
                    self.assertIn("GHT_RUNTIME_DIR=", env_file.read_text())
                    runtime_dir = Path(env_file.read_text().split("=", 1)[1].strip())
                    for name in ("ght-gha-adapter.sh", "ght-gha-complete.sh"):
                        self.assertTrue(os.access(runtime_dir / "scripts" / name, os.X_OK),
                                        f"{job} did not restore executable mode for {name}")
                finally:
                    self.tmp = original_tmp

    def test_corrupt_capsule_fails_closed(self):
        result, env_file = self._run_loader(corrupt=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("GHT_RUNTIME_DIR=", env_file.read_text())

    def test_unsafe_archive_fails_closed(self):
        result, env_file = self._run_loader(unsafe=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("GHT_RUNTIME_DIR=", env_file.read_text())

    def test_missing_capsule_fails_closed(self):
        result, env_file = self._run_loader(missing=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("GHT_RUNTIME_DIR=", env_file.read_text())

    def test_incomplete_source_identity_fails_closed(self):
        result, env_file = self._run_loader(bad_identity=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("GHT_RUNTIME_DIR=", env_file.read_text())

    def test_runtime_ref_moving_during_load_fails_closed(self):
        result, env_file = self._run_loader(move_ref=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Capsule ref moved during read", result.stdout + result.stderr)
        self.assertNotIn("GHT_RUNTIME_DIR=", env_file.read_text())

    def test_old_attempt_uses_bound_runtime_when_workflow_pin_has_moved(self):
        case = self.tmp / "attempt-pin-mismatch"
        case.mkdir()
        origin = case / "origin.git"
        checkout = case / "checkout"
        self.assertEqual(command("git", "init", "--bare", str(origin), cwd=case).returncode, 0)
        self.assertEqual(command("git", "clone", str(origin), str(checkout), cwd=case).returncode, 0)
        (checkout / "README.md").write_text("fixture")
        for args in (
            ("git", "add", "README.md"),
            ("git", "-c", "user.name=T", "-c", "user.email=t@x",
             "commit", "-m", "initial"),
        ):
            result = command(*args, cwd=checkout)
            self.assertEqual(result.returncode, 0, result.stderr)

        adapter = (SRC / "scripts" / "ght-gha-adapter.sh").read_bytes()
        complete = b"#!/bin/sh\necho attempt-bound-v1.1.6\n"
        required = {
            "scripts/ght-gha-complete.sh": (b"#!/bin/sh\necho workflow-pin-v1.1.7\n", 0o755),
            "scripts/ght-plan-publish.sh": (b"# fixture\n", 0o644),
            "scripts/ght-gha-review-trigger.py": (b"# fixture\n", 0o644),
            "scripts/ght-gha-review-verdict.py": (b"# fixture\n", 0o644),
        }
        current_files = {**required,
                         "scripts/ght-gha-adapter.sh": (adapter, 0o755)}
        bound_files = {**required,
                       "scripts/ght-gha-adapter.sh": (adapter, 0o755),
                       "scripts/ght-gha-complete.sh": (complete, 0o755)}

        def publish(files, release, source_sha):
            payload, digest, manifest = runtime_capsule(files, release, source_sha)
            (checkout / "runtime.zip").write_bytes(payload)
            (checkout / "MANIFEST.json").write_text(json.dumps(manifest))
            result = command("git", "add", "runtime.zip", "MANIFEST.json", cwd=checkout)
            self.assertEqual(result.returncode, 0, result.stderr)
            result = command("git", "-c", "user.name=T", "-c", "user.email=t@x",
                             "commit", "-m", f"capsule {release}", cwd=checkout)
            self.assertEqual(result.returncode, 0, result.stderr)
            result = command("git", "push", "origin",
                             f"HEAD:refs/ght/runtime/{digest}", cwd=checkout)
            self.assertEqual(result.returncode, 0, result.stderr)
            return payload, digest

        current_payload, current_digest = publish(
            current_files, "v1.1.7", "a" * 40)
        _bound_payload, bound_digest = publish(
            bound_files, "v1.1.6", "b" * 40)
        claim = {"task": 7, "status": "active",
                 "runtime": {"digest": bound_digest,
                             "release": "v1.1.6", "source_sha": "b" * 40}}
        (checkout / "CLAIM.json").write_text(json.dumps(claim))
        result = command("git", "add", "CLAIM.json", cwd=checkout)
        self.assertEqual(result.returncode, 0, result.stderr)
        result = command("git", "-c", "user.name=T", "-c", "user.email=t@x",
                         "commit", "-m", "active attempt", cwd=checkout)
        self.assertEqual(result.returncode, 0, result.stderr)
        result = command("git", "push", "origin", "HEAD:refs/ght/claims/7", cwd=checkout)
        self.assertEqual(result.returncode, 0, result.stderr)

        current_dir = case / "workflow-runtime"
        current_dir.mkdir()
        with zipfile.ZipFile(io.BytesIO(current_payload)) as archive:
            archive.extractall(current_dir)
        text = (SRC / "workflow_templates" / "ght.yml").read_text()
        sections = re.findall(
            r"      - name: Materialize and verify immutable local Runtime\n"
            r"        shell: bash\n        run: \|\n"
            r"((?:          .*\n|\n)+)", text)
        self.assertEqual(len(sections), 3)
        script = "\n".join(line[10:] if line.startswith("          ") else line
                           for line in sections[1].splitlines()) + "\n"
        loader = case / "loader.sh"
        loader.write_text(script)
        env_file = case / "github-env"
        env_file.write_text("")
        env = {**os.environ, "GHT_RUNTIME_REF": current_digest,
               "GITHUB_RUN_ID": "456", "GITHUB_RUN_ATTEMPT": "1",
               "GITHUB_ENV": str(env_file), "RUNNER_TEMP": str(case)}
        result = command("bash", str(loader), cwd=checkout, env=env)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        runtime_dir = next(line.split("=", 1)[1] for line in env_file.read_text().splitlines()
                           if line.startswith("GHT_RUNTIME_DIR="))
        self.assertTrue(os.access(Path(runtime_dir) / "scripts" / "ght-gha-complete.sh",
                                  os.X_OK))
        env.update({"GHT_RUNTIME_DIR": runtime_dir})
        result = command(
            "bash", "-c",
            'GHT_RUNTIME_DIR= sh "$GHT_RUNTIME_DIR/scripts/ght-gha-adapter.sh" complete 7 17',
            cwd=checkout, env=env)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("attempt-bound-v1.1.6", result.stdout + result.stderr)
        self.assertNotIn("workflow-pin-v1.1.7", result.stdout + result.stderr)


OWNER_GATE = "github.repository_owner == 'harryhua-ai'"


def _gha_truthy(value):
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, dict):
        return True
    if isinstance(value, str):
        return bool(value)
    return bool(value)


def _gha_text(value):
    if value is None:
        return ""
    if value is True:
        return "true"
    if value is False:
        return "false"
    return str(value)


def _gha_eq(left, right):
    return _gha_text(left).lower() == _gha_text(right).lower()


def _gha_contains(value, needle):
    return _gha_text(needle).lower() in _gha_text(value).lower()


def _gha_lookup(ctx, path):
    node = ctx
    for part in path.split("."):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node


class _GhaParser:
    """Evaluator for exactly the expression surface the three job `if:`
    conditions use: dotted identifiers, 'literals', true/false, ==, &&, ||,
    parentheses, contains(a, b) — with GitHub Actions string semantics
    (case-insensitive equality/contains, null coerce to empty)."""

    TOKENS = re.compile(r"\s*(&&|\|\||==|'[^']*'|\(|\)|,|"
                        r"[A-Za-z_][A-Za-z0-9_.]*|true|false)")

    def __init__(self, expr, ctx):
        self.expr = expr
        self.ctx = ctx
        self.tokens = []
        self.next = 0
        position = 0
        while position < len(expr):
            match = self.TOKENS.match(expr, position)
            if match is None:
                raise AssertionError(
                    f"unparseable expression near {expr[position:]!r}")
            self.tokens.append(match.group(1))
            position = match.end()

    def peek(self):
        return self.tokens[self.next] if self.next < len(self.tokens) else None

    def take(self, expected=None):
        token = self.peek()
        if expected is not None:
            assert token == expected, (token, expected, self.expr)
        self.next += 1
        return token

    def parse(self):
        value = self.parse_or()
        assert self.next == len(self.tokens), self.expr
        return value

    def parse_or(self):
        value = self.parse_and()
        while self.peek() == "||":
            self.take()
            right = self.parse_and()
            value = _gha_truthy(value) or _gha_truthy(right)
        return value

    def parse_and(self):
        value = self.parse_eq()
        while self.peek() == "&&":
            self.take()
            right = self.parse_eq()
            value = _gha_truthy(value) and _gha_truthy(right)
        return value

    def parse_eq(self):
        value = self.parse_atom()
        while self.peek() == "==":
            self.take()
            value = _gha_eq(value, self.parse_atom())
        return value

    def parse_atom(self):
        token = self.take()
        if token == "(":
            value = self.parse_or()
            self.take(")")
            return value
        if token == "contains":
            self.take("(")
            left = self.parse_or()
            self.take(",")
            right = self.parse_or()
            self.take(")")
            return _gha_contains(left, right)
        if token.startswith("'"):
            return token[1:-1]
        if token in ("true", "false"):
            return token == "true"
        return _gha_lookup(self.ctx, token)


def _gha_eval(expr, ctx):
    return _gha_truthy(_GhaParser(expr, ctx).parse())


def _job_conditions(text):
    conditions = {}
    for job in ("review_verdict", "complete", "publish"):
        match = re.search(
            rf"^  {job}:\n    if: >-\n((?:      [^\n]*\n)+)    runs-on:",
            text, re.MULTILINE)
        assert match, f"no if condition found for job {job}"
        conditions[job] = " ".join(
            line.strip() for line in match.group(1).splitlines())
    return conditions


def _branch(event_name, event, ref_name="main", inputs=None):
    event.setdefault("repository", {"default_branch": "main"})
    return {"github": {
                "repository_owner": None,
                "event_name": event_name,
                "event": event,
                "ref_name": ref_name,
                "repository": {"default_branch": "main"}},
            "inputs": inputs or {}}, event_name, ref_name


def _branch_contexts():
    branches = {}
    branches["review_submitted"] = _branch(
        "pull_request_review",
        {"pull_request": {"number": 7}, "review": {"state": "approved"}},
        "feature")
    branches["review_edited"] = _branch(
        "pull_request_review",
        {"pull_request": {"number": 7}, "review": {"state": "approved"},
         "changes": {}}, "feature")
    branches["review_dismissed"] = _branch(
        "pull_request_review",
        {"pull_request": {"number": 7}, "review": {"state": "dismissed"}},
        "feature")
    branches["comment_pr_areview"] = _branch(
        "issue_comment",
        {"issue": {"pull_request": {"number": 7}},
         "comment": {"body": "A REVIEW\nverdict body"}}, "feature")
    branches["comment_pr_plain"] = _branch(
        "issue_comment",
        {"issue": {"pull_request": {"number": 7}},
         "comment": {"body": "looks great, thanks"}}, "feature")
    branches["comment_plain_issue"] = _branch(
        "issue_comment",
        {"issue": {"number": 3}, "comment": {"body": "A REVIEW"}}, "main")
    branches["comment_edited_from_areview"] = _branch(
        "issue_comment",
        {"issue": {"pull_request": {"number": 7}},
         "comment": {"body": "x"},
         "changes": {"body": {"from": "A REVIEW\nold body"}}}, "feature")
    branches["pr_merged"] = _branch(
        "pull_request", {"pull_request": {"merged": True, "number": 7}})
    branches["pr_closed_unmerged"] = _branch(
        "pull_request", {"pull_request": {"merged": False, "number": 7}})
    branches["push_default"] = _branch("push", {}, "main")
    branches["push_feature"] = _branch("push", {}, "feature")
    branches["dispatch_complete"] = _branch(
        "workflow_dispatch", {}, "main", {"operation": "complete"})
    branches["dispatch_plan"] = _branch(
        "workflow_dispatch", {}, "main", {"operation": "plan-publish"})
    branches["dispatch_empty"] = _branch("workflow_dispatch", {}, "main", {})
    return branches


class WorkflowOwnerGateTests(unittest.TestCase):
    """#254 AC1: all three jobs gate on the exact target owner; every
    original event predicate and permission stays unchanged, and forks
    owned by harryhua-ai are NOT excluded."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ght-owner-gate-"))
        self.root = self.tmp / "target"
        self.root.mkdir()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    EXPECTED_RUN = {
        "review_verdict": {"review_submitted", "review_edited",
                           "review_dismissed", "comment_pr_areview",
                           "comment_edited_from_areview"},
        "complete": {"pr_merged", "dispatch_complete"},
        "publish": {"push_default", "dispatch_plan"},
    }

    ORIGINAL_PREDICATES = {
        "review_verdict": (
            "github.event_name == 'pull_request_review'",
            "github.event_name == 'issue_comment'",
            "github.event.issue.pull_request",
            "contains(github.event.comment.body, 'A REVIEW')",
            "contains(github.event.changes.body.from, 'A REVIEW')",
        ),
        "complete": (
            "github.event_name == 'pull_request'",
            "github.event.pull_request.merged == true",
            "github.event_name == 'workflow_dispatch'",
            "inputs.operation == 'complete'",
        ),
        "publish": (
            "github.event_name == 'push'",
            "github.ref_name == github.event.repository.default_branch",
            "github.event_name == 'workflow_dispatch'",
            "inputs.operation == 'plan-publish'",
        ),
    }

    ENTRIES = (
        ("self-owned-repository", "harryhua-ai", False),
        ("fork-owned-by-target", "harryhua-ai", True),
        ("owner-cased-actions-equality", "HARRYHUA-AI", False),
        ("non-target-owner", "acme", False),
        ("non-target-fork", "acme", True),
        ("unverifiable-owner", "", False),
    )

    def test_owner_gate_matrix_over_all_entries_and_event_branches(self):
        text = (SRC / "workflow_templates" / "ght.yml").read_text()
        conditions = _job_conditions(text)
        for label, owner, fork in self.ENTRIES:
            for branch_name, (ctx, event_name, ref_name) in \
                    _branch_contexts().items():
                ctx["github"]["repository_owner"] = owner
                ctx["github"]["repository"]["fork"] = fork
                for job, condition in conditions.items():
                    runs = _gha_eval(condition, ctx)
                    if owner.lower() == "harryhua-ai":
                        expected = branch_name in self.EXPECTED_RUN[job]
                    else:
                        expected = False
                    self.assertEqual(
                        runs, expected,
                        f"{label}/{job}/{branch_name} "
                        f"(event={event_name}, ref={ref_name}): "
                        f"runs={runs}, expected={expected}")

    def test_gate_leads_every_condition_and_preserves_original_predicates(self):
        text = (SRC / "workflow_templates" / "ght.yml").read_text()
        self.assertEqual(text.count(OWNER_GATE), 3)
        conditions = _job_conditions(text)
        for job, condition in conditions.items():
            self.assertTrue(condition.startswith(OWNER_GATE + " && ("),
                            f"{job} must gate on the owner before any event "
                            f"predicate: {condition}")
            for predicate in self.ORIGINAL_PREDICATES[job]:
                self.assertIn(predicate, condition,
                              f"{job} lost original predicate {predicate!r}")
        self.assertNotIn("fork", text,
                         "the owner gate must not exclude forks via a "
                         "repository.fork condition")

    def test_job_permissions_are_unchanged(self):
        text = (SRC / "workflow_templates" / "ght.yml").read_text()
        for fragment, count in (
                ("permissions:\n  contents: read", 1),
                ("      contents: read", 1),
                ("      contents: write", 2),
                ("      pull-requests: read", 2),
                ("      issues: read", 2),
                ("      issues: write", 1),
                ("      checks: write", 1)):
            self.assertEqual(text.count(fragment), count, fragment)

    def test_asset_invariant_locks_the_owner_gate(self):
        package = self.tmp / "package"
        shutil.copytree(SRC / "workflow_templates",
                        package / "workflow_templates")
        template = package / "workflow_templates" / "ght.yml"
        stripped = template.read_text().replace(OWNER_GATE + " &&\n      ", "")
        self.assertNotIn(OWNER_GATE, stripped)
        template.write_text(stripped)
        with self.assertRaisesRegex(SingleWorkflowAdoptionError, "invariant"):
            inspect(self.root, PIN_A, package_root=package)
        self.assertEqual(list(self.root.rglob("*")), [],
                         "an invariant-failing template adopts nothing")


if __name__ == "__main__":
    unittest.main()
