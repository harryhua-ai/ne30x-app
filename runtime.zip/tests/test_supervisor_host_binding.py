"""Execution-host binding regressions for the detached lease supervisor.

Agent hosts launch ght through an ephemeral per-command shell (`zsh -c ...`)
that exits as soon as the command finishes. Binding supervision to that
shell fails at the detached supervisor's late bind (the OS generation token
raises ESRCH) and the attempt is parked without any lease renewal — the
#228 parked-chain evidence. The supervisor must bind the process that
actually hosts the executor (the agent session / step shell / job shell).
"""

import contextlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

SKILL_ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(SKILL_ROOT))

from github_task import cli  # noqa: E402


def lineage_entry(pid, argv, token="fixture-token"):
    return {"pid": pid, "token": token, "argv": argv}


class CommandShellClassificationTests(unittest.TestCase):
    def test_ephemeral_command_shells(self):
        self.assertTrue(cli._argv_is_command_shell("/bin/zsh -c . snapshot.sh && ght claim 228"))
        self.assertTrue(cli._argv_is_command_shell("bash -lc 'ght discover --json'"))
        self.assertTrue(cli._argv_is_command_shell("sh -c ght acquire 228"))

    def test_non_command_shell_processes(self):
        self.assertFalse(cli._argv_is_command_shell("zcode-cli"))
        self.assertFalse(cli._argv_is_command_shell("-zsh"))
        self.assertFalse(cli._argv_is_command_shell("/bin/zsh"))
        self.assertFalse(cli._argv_is_command_shell("bash -e /home/runner/work/step.sh"))
        self.assertFalse(cli._argv_is_command_shell("python3 -c import\\ cli"))
        self.assertFalse(cli._argv_is_command_shell(None))
        self.assertFalse(cli._argv_is_command_shell(""))

    def test_resolution_skips_ephemeral_shell_to_session_host(self):
        lineage = [lineage_entry(100, "/bin/zsh -c ght claim 228"),
                   lineage_entry(77, "zcode-cli"),
                   lineage_entry(50, "zcode-host-local-1")]
        self.assertEqual(cli._resolve_execution_host(lineage)["pid"], 77)

    def test_resolution_keeps_step_shell_without_command_flag(self):
        lineage = [lineage_entry(100, "bash -e /runner/work/step.sh"),
                   lineage_entry(60, "Runner.Worker")]
        self.assertEqual(cli._resolve_execution_host(lineage)["pid"], 100)

    def test_resolution_all_command_shells_keeps_direct_parent(self):
        lineage = [lineage_entry(100, "sh -c ght claim 228 && work"),
                   lineage_entry(60, "bash -c runner-wrapper")]
        self.assertEqual(cli._resolve_execution_host(lineage)["pid"], 100)

    def test_resolution_uninspectable_ancestor_is_not_skipped(self):
        lineage = [lineage_entry(100, "/bin/zsh -c ght claim"),
                   lineage_entry(60, None)]
        self.assertEqual(cli._resolve_execution_host(lineage)["pid"], 60)

    def test_resolution_empty_lineage(self):
        self.assertIsNone(cli._resolve_execution_host([]))


class SpawnSupervisorBindingTests(unittest.TestCase):
    def _run_spawn(self, lineage, tmp, getppid=424242):
        ctx = SimpleNamespace(state=tmp, root=tmp)
        captured = {}

        def fake_liveness(pid, token):
            captured["pid"] = pid
            captured["token"] = token
            return SimpleNamespace(close=lambda: None)

        real_popen = cli.subprocess.Popen

        def fake_popen(*_args, **kwargs):
            captured["env"] = kwargs["env"]
            # A real child that acks the import handshake like the actual
            # supervisor bootstrap does; the pipe semantics stay real.
            write_fd = kwargs["pass_fds"][0]
            return real_popen(
                [sys.executable, "-c", f"import os; os.write({write_fd}, b'ready')"],
                **{**kwargs, "stdout": subprocess.DEVNULL,
                   "stderr": subprocess.DEVNULL})

        with mock.patch.object(cli, "_execution_host_lineage", return_value=lineage), \
             mock.patch.object(cli, "_ExecutionHostLiveness", side_effect=fake_liveness), \
             mock.patch.object(cli.subprocess, "Popen", side_effect=fake_popen), \
             mock.patch.object(cli.os, "getppid", return_value=getppid):
            result = cli._spawn_supervisor(ctx, 228)
        status = json.loads((tmp / "supervise-228.json").read_text())
        return result, captured, status

    def test_binds_session_host_not_ephemeral_wrapper(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            lineage = [lineage_entry(100, "/bin/zsh -c ght claim 228"),
                       lineage_entry(77, "zcode-cli", token="session-token")]
            result, captured, status = self._run_spawn(lineage, tmp)
            self.assertEqual(result, "spawned")
            self.assertEqual(captured["pid"], 77)
            self.assertEqual(captured["token"], "session-token")
            self.assertEqual(status["state"], "spawned")
            self.assertEqual(status["host_pid"], 77)
            recorded = json.loads(captured["env"]["GHT_SUPERVISE_HOST_LINEAGE"])
            self.assertEqual([e["pid"] for e in recorded], [100, 77])
            self.assertEqual(captured["env"]["GHT_SUPERVISE_HOST_PID"], "77")

    def test_unresolvable_host_fails_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            with mock.patch.object(cli, "_execution_host_lineage", return_value=[]), \
                 mock.patch.object(cli, "_execution_host_start_token",
                                   side_effect=OSError(3, "No such process")), \
                 mock.patch.object(cli, "_ExecutionHostLiveness",
                                   side_effect=OSError(3, "No such process")):
                with self.assertRaises(cli.CommandFailure) as ctx:
                    cli._spawn_supervisor(SimpleNamespace(state=tmp, root=tmp), 228)
            self.assertEqual(ctx.exception.code, cli.OWNERSHIP_LOST)
            status = json.loads((tmp / "supervise-228.json").read_text())
            self.assertEqual(status["state"], "spawn-failed")


class SuperviseBindTests(unittest.TestCase):
    def _run_supervise(self, env, liveness):
        context = SimpleNamespace(
            lease_minutes=6, executor_id="worker", github_principal="worker",
            remote_claim=lambda _issue: (None, None))
        status_writes = []

        def status_writer(_ctx, _issue, state, **extra):
            status_writes.append({"state": state, **extra})

        base_env = {k: v for k, v in os.environ.items()
                    if not k.startswith("GHT_SUPERVISE")}
        env = {**base_env, **env, "GHT_SUPERVISE_MAX_HOURS": "0"}
        bound = []

        def liveness_recording(pid, token):
            bound.append((pid, token))
            return liveness(pid, token)

        with mock.patch.dict(os.environ, env), \
             mock.patch.object(cli, "Context", return_value=context), \
             mock.patch.object(cli, "_ExecutionHostLiveness",
                               side_effect=liveness_recording), \
             mock.patch.object(cli, "_write_supervise_status",
                               side_effect=status_writer):
            try:
                cli._cmd_supervise(SimpleNamespace(remote="origin", repo=None, issue=228))
                code = 0
            except SystemExit as exited:
                code = exited.code
        return code, bound, status_writes

    def test_binds_non_shell_lineage_entry_not_wrapper(self):
        env = {"GHT_SUPERVISE_HOST_LINEAGE": json.dumps([
            {"pid": 100, "token": "wrapper-token", "argv": "/bin/zsh -c ght claim 228"},
            {"pid": 77, "token": "session-token", "argv": "zcode-cli"}])}
        code, bound, _ = self._run_supervise(env, lambda p, t: SimpleNamespace(
            wait=lambda _t: False, close=lambda: None))
        self.assertEqual(code, 0)
        self.assertEqual(bound, [(77, "session-token")])

    def test_dead_session_host_fails_closed_without_renewal(self):
        env = {"GHT_SUPERVISE_HOST_LINEAGE": json.dumps([
            {"pid": 100, "token": "wrapper-token", "argv": "/bin/zsh -c ght claim 228"},
            {"pid": 77, "token": "session-token", "argv": "zcode-cli"}])}

        def liveness(_pid, _token):
            raise OSError(3, "No such process")

        code, _bound, writes = self._run_supervise(env, liveness)
        self.assertEqual(code, 1)
        self.assertEqual(writes[0]["state"], "failed")
        self.assertIn("could not be bound", writes[0]["error"])

    def test_pinned_host_pid_path_unchanged(self):
        env = {"GHT_SUPERVISE_HOST_PID": "123",
               "GHT_SUPERVISE_HOST_START_TOKEN": "fixture-host"}
        _code, bound, _ = self._run_supervise(env, lambda p, t: SimpleNamespace(
            wait=lambda _t: False, close=lambda: None))
        self.assertEqual(bound, [(123, "fixture-host")])

    def test_pinned_pid_takes_priority_over_lineage(self):
        # Explicit operator pinning is never second-guessed: when both the
        # pinned PID/TOKEN and a lineage are present, the pin binds — even
        # though the lineage would resolve to a different host.
        env = {"GHT_SUPERVISE_HOST_PID": "123",
               "GHT_SUPERVISE_HOST_START_TOKEN": "pinned-token",
               "GHT_SUPERVISE_HOST_LINEAGE": json.dumps([
                   {"pid": 100, "token": "wrapper-token", "argv": "/bin/zsh -c ght claim"},
                   {"pid": 77, "token": "session-token", "argv": "zcode-cli"}])}
        _code, bound, _ = self._run_supervise(env, lambda p, t: SimpleNamespace(
            wait=lambda _t: False, close=lambda: None))
        self.assertEqual(bound, [(123, "pinned-token")])

    def test_malformed_lineage_fails_closed(self):
        code, _bound, writes = self._run_supervise(
            {"GHT_SUPERVISE_HOST_LINEAGE": "not-json"}, lambda p, t: None)
        self.assertEqual(code, 1)
        self.assertEqual(writes[0]["state"], "failed")


class SpawnPinnedPriorityTests(unittest.TestCase):
    def test_spawn_pinned_pid_overrides_lineage_resolution(self):
        # A pinned host at spawn time must bind exactly the pinned PID —
        # the lineage heuristic never overrides an explicit pin.
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            captured = {}

            def fake_liveness(pid, token):
                captured["pid"] = pid
                captured["token"] = token
                return SimpleNamespace(close=lambda: None)

            real_popen = cli.subprocess.Popen

            def fake_popen(*_args, **kwargs):
                captured["env"] = kwargs["env"]
                write_fd = kwargs["pass_fds"][0]
                return real_popen(
                    [sys.executable, "-c", f"import os; os.write({write_fd}, b'ready')"],
                    **{**kwargs, "stdout": subprocess.DEVNULL,
                       "stderr": subprocess.DEVNULL})

            lineage = [lineage_entry(100, "/bin/zsh -c ght claim 228"),
                       lineage_entry(77, "zcode-cli", token="session-token")]
            env = {"GHT_SUPERVISE_HOST_PID": "555",
                   "GHT_SUPERVISE_HOST_START_TOKEN": "pinned-token"}
            base_env = {k: v for k, v in os.environ.items()
                        if not k.startswith("GHT_SUPERVISE")}
            with mock.patch.dict(os.environ, {**base_env, **env}), \
                 mock.patch.object(cli, "_execution_host_lineage",
                                   return_value=lineage), \
                 mock.patch.object(cli, "_ExecutionHostLiveness",
                                   side_effect=fake_liveness), \
                 mock.patch.object(cli.subprocess, "Popen", side_effect=fake_popen):
                result = cli._spawn_supervisor(SimpleNamespace(state=tmp, root=tmp), 228)
            self.assertEqual(result, "spawned")
            self.assertEqual(captured["pid"], 555)
            self.assertEqual(captured["token"], "pinned-token")
            status = json.loads((tmp / "supervise-228.json").read_text())
            self.assertEqual(status["host_pid"], 555)
            self.assertEqual(captured["env"]["GHT_SUPERVISE_HOST_PID"], "555")


class CapsuleImportHandshakeTests(unittest.TestCase):
    """The detached supervisor's module tree dies with the spawning command
    under runtime-capsule dispatch (#228 live evidence: ModuleNotFoundError
    before the first renewal, status stuck at spawned). Startup is therefore
    deterministic: the command waits for the supervisor's import ack, and a
    supervisor that cannot import fails the spawn closed instead of leaving
    a dead 'spawned' record on a parked attempt."""

    def _run_spawn_with_child(self, child_code, ack_seconds=None):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            real_popen = cli.subprocess.Popen
            base_env = {k: v for k, v in os.environ.items()
                        if not k.startswith("GHT_SUPERVISE")}

            def child_popen(cmd, **kwargs):
                if "pass_fds" not in kwargs:
                    return real_popen(cmd, **kwargs)
                write_fd = kwargs["pass_fds"][0]
                return real_popen(
                    [sys.executable, "-c", child_code.format(fd=write_fd)],
                    **{**kwargs, "stdout": subprocess.DEVNULL,
                       "stderr": subprocess.DEVNULL})

            with contextlib.ExitStack() as stack:
                stack.enter_context(mock.patch.dict(os.environ, base_env))
                stack.enter_context(mock.patch.object(
                    cli, "_ExecutionHostLiveness",
                    side_effect=lambda _p, _t: SimpleNamespace(close=lambda: None)))
                stack.enter_context(mock.patch.object(
                    cli.subprocess, "Popen", side_effect=child_popen))
                if ack_seconds is not None:
                    stack.enter_context(mock.patch.object(
                        cli, "_SUPERVISE_IMPORT_ACK_SECONDS", ack_seconds))
                outcome: dict = {}
                try:
                    outcome["result"] = cli._spawn_supervisor(
                        SimpleNamespace(state=tmp, root=tmp), 228)
                except cli.CommandFailure as failure:
                    outcome["failure"] = failure
                status = json.loads((tmp / "supervise-228.json").read_text())
        return outcome, status

    def test_import_ack_completes_spawn(self):
        outcome, status = self._run_spawn_with_child(
            "import os; os.write({fd}, b'ready')")
        self.assertEqual(outcome["result"], "spawned")
        self.assertEqual(status["state"], "spawned")

    def test_child_death_before_ack_fails_spawn_closed(self):
        outcome, status = self._run_spawn_with_child("import time; time.sleep(0.05)")
        self.assertIn("failure", outcome)
        self.assertEqual(outcome["failure"].code, cli.OWNERSHIP_LOST)
        self.assertEqual(status["state"], "spawn-failed")
        self.assertIn("exited before completing its import", status["error"])

    def test_hung_child_hits_ack_bound_and_is_reaped(self):
        pid_file = tempfile.mktemp(prefix="supervise-hang-pid-")
        self.addCleanup(lambda: os.path.exists(pid_file) and os.unlink(pid_file))
        child_code = (f"import os, time; open({pid_file!r}, 'w').write(str(os.getpid())); "
                      "time.sleep(30)")
        outcome, status = self._run_spawn_with_child(child_code, ack_seconds=0.4)
        self.assertIn("failure", outcome)
        self.assertEqual(outcome["failure"].code, cli.OWNERSHIP_LOST)
        self.assertEqual(status["state"], "spawn-failed")
        self.assertIn("timed out", status["error"])
        # The hung child was terminated during the fail-closed teardown.
        child_pid = int(Path(pid_file).read_text())
        deadline = time.time() + 5
        while time.time() < deadline:
            try:
                os.kill(child_pid, 0)
            except ProcessLookupError:
                break
            time.sleep(0.05)
        else:
            self.fail("hung supervisor child was not reaped")

    def test_child_late_failure_survives_parent_spawn_record(self):
        # A supervisor that fails right after its import (late host-bind
        # failure) records `failed` itself, and that record must SURVIVE:
        # the spawned record is written before the child exists and the
        # parent never touches the status after the ack, so the child's
        # failure can never be overwritten back to a non-failure state —
        # the supervision gate reads this file and must see the real
        # failure (A R4 blocker: parent-late spawned overwrote child
        # failed on the pre-fix write order).
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            status_path = tmp / "supervise-228.json"
            real_popen = cli.subprocess.Popen
            base_env = {k: v for k, v in os.environ.items()
                        if not k.startswith("GHT_SUPERVISE")}
            write_fd_token = "GHT_WRITE_FD_TOKEN"
            child_code = (
                "import json, os; os.write(" + str(write_fd_token) + ", b'ready'); "
                "open(" + repr(str(status_path)) + ", 'w').write(json.dumps("
                "{'issue': 228, 'pid': 1, 'state': 'failed', "
                "'error': 'late host-bind failure'}))")

            def child_popen(cmd, **kwargs):
                if "pass_fds" not in kwargs:
                    return real_popen(cmd, **kwargs)
                write_fd = kwargs["pass_fds"][0]
                code = child_code.replace(str(write_fd_token), str(write_fd))
                return real_popen(
                    [sys.executable, "-c", code],
                    **{**kwargs, "stdout": subprocess.DEVNULL,
                       "stderr": subprocess.DEVNULL})

            with contextlib.ExitStack() as stack:
                stack.enter_context(mock.patch.dict(os.environ, base_env))
                stack.enter_context(mock.patch.object(
                    cli, "_ExecutionHostLiveness",
                    side_effect=lambda _p, _t: SimpleNamespace(close=lambda: None)))
                stack.enter_context(mock.patch.object(
                    cli.subprocess, "Popen", side_effect=child_popen))
                result = cli._spawn_supervisor(
                    SimpleNamespace(state=tmp, root=tmp), 228)
            self.assertEqual(result, "spawned")
            # Give the child's post-ack failure write a moment to land,
            # then assert the parent did NOT overwrite it.
            deadline = time.time() + 3
            status = json.loads(status_path.read_text())
            while status.get("state") != "failed" and time.time() < deadline:
                time.sleep(0.05)
                status = json.loads(status_path.read_text())
            self.assertEqual(status["state"], "failed")
            self.assertIn("late host-bind failure", status.get("error", ""))


@unittest.skipUnless(sys.platform == "darwin" or hasattr(os, "pidfd_open"),
                     "kernel process-exit watch unsupported on this platform")
class RealProcessChainTests(unittest.TestCase):
    """Real OS processes mirroring the #228 timeline: the supervisor-role
    child captures its lineage while the ephemeral command shell is alive,
    the shell then exits, and binding must land on the surviving session
    host — never on the exited shell."""

    def test_exited_wrapper_token_fails_and_surviving_host_binds(self):
        if shutil.which("/bin/sh") is None:
            self.skipTest("/bin/sh unavailable")
        role_code = ROLE_CODE.format(sk=str(SKILL_ROOT))
        wrapper_command = f"{sys.executable} -c {shlex.quote(role_code)}; exit 0"
        host = subprocess.Popen(
            [sys.executable, "-c",
             "import subprocess, sys, time; "
             f"subprocess.run({['/bin/sh', '-c', wrapper_command]!r}); "
             "time.sleep(15)"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            time.sleep(0.5)
            if host.poll() is not None:
                self.fail(host.communicate()[1])
            out, err = host.communicate(timeout=120)
            self.assertEqual(host.returncode, 0, err)
            result = json.loads(out.strip().splitlines()[-1])
            self.assertEqual(result["exited_wrapper_token_errno"], 3)
            self.assertNotEqual(result["resolved_pid"], result["wrapper_pid"])
            self.assertFalse(cli._argv_is_command_shell(result["resolved_argv"]))
            self.assertEqual(result["bind_surviving_host"], "OK")
        finally:
            if host.poll() is None:
                host.terminate()
                try:
                    host.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    host.kill()


ROLE_CODE = """
import json, os, signal, sys, time
sys.path.insert(0, {sk!r})
from github_task import cli

wrapper = os.getppid()
lineage = cli._execution_host_lineage()
resolved = cli._resolve_execution_host(lineage)
result = {{"wrapper_pid": wrapper, "resolved_pid": resolved["pid"],
          "resolved_argv": resolved.get("argv") or "",
          "resolved_lineage_pids": [entry["pid"] for entry in lineage]}}
os.kill(wrapper, signal.SIGKILL)
time.sleep(0.2)
try:
    cli._execution_host_start_token(wrapper)
    result["exited_wrapper_token_errno"] = None
except OSError as exc:
    result["exited_wrapper_token_errno"] = exc.errno
watch = cli._ExecutionHostLiveness(resolved["pid"], resolved["token"])
result["bind_surviving_host"] = "OK"
watch.close()
print(json.dumps(result), flush=True)
"""


if __name__ == "__main__":
    unittest.main()
