"""Coverage for safe combined downstream workflow adoption proposals."""

from __future__ import annotations

import hashlib
import shutil
import tempfile
import unittest
from pathlib import Path

from github_task.workflow_adoption import WorkflowAdoptionError, prepare


PIN_A = "a" * 64
PIN_B = "b" * 64
COMPLETE = ".github/workflows/ght-complete.yml"
PLAN = ".github/workflows/ght-plan-publish.yml"
ADAPTER = ".github/scripts/ght-gha-adapter.sh"
REVIEW_TRIGGER = ".github/scripts/ght-gha-review-trigger.py"
REVIEW_VERDICT = ".github/scripts/ght-gha-review-verdict.py"

LEGACY_COMPLETE_V1 = """name: ght-complete
# ght-adoption-managed: ght-complete/v1
on:
  pull_request:
    types: [closed]
  workflow_dispatch:
    inputs:
      issue:
        required: true
        type: string
      pr:
        required: true
        type: string
permissions:
  contents: write
  pull-requests: read
  issues: write
jobs:
  complete:
    if: github.event_name == 'workflow_dispatch' || github.event.pull_request.merged == true
    runs-on: ubuntu-latest
    env:
      GHT_RUNTIME_REF: "{pin}"
      GHT_RECONCILER_ID: ght-complete-workflow
    steps:
      - run: sh .github/scripts/ght-gha-adapter.sh complete
"""


class WorkflowAdoptionTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="ght-workflow-adoption-"))

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_fresh_project_gets_both_workflows_adapter_and_review_helpers_as_proposal(self):
        result = prepare(self.root, PIN_A)

        self.assertEqual(result["status"], "proposal_prepared")
        self.assertEqual(result["integration"], "not_verified")
        self.assertCountEqual(result["changed_files"], [
            COMPLETE, PLAN, ADAPTER, REVIEW_TRIGGER, REVIEW_VERDICT])
        self.assertFalse((self.root / ".github/workflows/formal-release.yml").exists())
        self.assertNotIn("skills/github-task/scripts/",
                         (self.root / COMPLETE).read_text())
        self.assertIn("refs/ght/runtime/", (self.root / ADAPTER).read_text())
        complete_text = (self.root / COMPLETE).read_text()
        self.assertIn("issue_comment:", complete_text)
        self.assertIn("types: [created, edited, deleted]", complete_text)
        self.assertIn("pull_request_review:", complete_text)
        self.assertIn("types: [submitted, edited, dismissed]", complete_text)
        self.assertIn("checks: write", complete_text)
        self.assertIn("python3 .github/scripts/ght-gha-review-trigger.py",
                      complete_text)
        self.assertEqual(
            (self.root / REVIEW_TRIGGER).read_bytes(),
            (Path(__file__).parents[1] / "scripts" / "ght-gha-review-trigger.py").read_bytes())
        self.assertEqual(
            (self.root / REVIEW_VERDICT).read_bytes(),
            (Path(__file__).parents[1] / "scripts" / "ght-gha-review-verdict.py").read_bytes())
        self.assertEqual(hashlib.sha256((self.root / REVIEW_TRIGGER).read_bytes()).hexdigest(),
                         "a183fc66c1ac21aa1f8e59ccac75f35c104b919d583cef07f1ed2d953f7d6941")
        self.assertEqual(hashlib.sha256((self.root / REVIEW_VERDICT).read_bytes()).hexdigest(),
                         "470d8a44c0fbb92909a16d401c945b43f598d39e2bd3e0b48d9a64591cd56dda")
        plan_text = (self.root / PLAN).read_text()
        self.assertIn("github.event.repository.default_branch", plan_text)
        self.assertNotIn("branches: [main]", plan_text)

    def test_completion_workflow_resolves_issue_from_canonical_candidate_branch(self):
        prepare(self.root, PIN_A)
        complete_text = (self.root / COMPLETE).read_text()

        self.assertIn("run: sh .github/scripts/ght-gha-adapter.sh resolve", complete_text)
        self.assertIn("steps.facts.outputs.issue", complete_text)
        self.assertIn("steps.facts.outputs.pr", complete_text)

    def test_initialized_project_only_fills_the_missing_default_workflow(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        complete.write_text(complete.read_text().replace(
            "# ght-adoption-managed: ght-complete/v2\n", ""))
        complete_before = complete.read_bytes()
        (self.root / PLAN).unlink()

        result = prepare(self.root, PIN_A)

        self.assertEqual(result["changed_files"], [PLAN])
        self.assertEqual((self.root / COMPLETE).read_bytes(), complete_before)

    def test_compatible_files_are_idempotent_and_unmerged_proposal_is_not_complete(self):
        prepare(self.root, PIN_A)
        before = {path: (self.root / path).read_bytes()
                  for path in (COMPLETE, PLAN, ADAPTER, REVIEW_TRIGGER, REVIEW_VERDICT)}

        result = prepare(self.root, PIN_A)

        self.assertEqual(result["status"], "already_compatible")
        self.assertEqual(result["changed_files"], [])
        self.assertEqual(result["integration"], "not_verified")
        self.assertNotEqual(result["integration"], "complete")
        self.assertEqual({path: (self.root / path).read_bytes() for path in before},
                         before)

    def test_initialized_v2_project_repairs_a_missing_review_helper_idempotently(self):
        prepare(self.root, PIN_A)
        before = {path: (self.root / path).read_bytes()
                  for path in (COMPLETE, PLAN, ADAPTER, REVIEW_VERDICT)}
        (self.root / REVIEW_TRIGGER).unlink()

        result = prepare(self.root, PIN_A)

        self.assertEqual(result["changed_files"], [REVIEW_TRIGGER])
        self.assertEqual(result["integration"], "not_verified")
        self.assertEqual({path: (self.root / path).read_bytes() for path in before},
                         before)

    def test_mismatched_helper_digest_fails_closed_before_any_other_write(self):
        prepare(self.root, PIN_A)
        helper = self.root / REVIEW_TRIGGER
        helper.write_text(helper.read_text() + "\n# altered\n")
        before = {path: (self.root / path).read_bytes()
                  for path in (COMPLETE, PLAN, ADAPTER, REVIEW_TRIGGER, REVIEW_VERDICT)}

        with self.assertRaisesRegex(WorkflowAdoptionError,
                                    "review helper.*digest|digest.*review helper"):
            prepare(self.root, PIN_A)

        self.assertEqual({path: (self.root / path).read_bytes() for path in before},
                         before)

    def test_v1_managed_completion_remains_compatible_but_review_requires_upgrade(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        complete.write_text(LEGACY_COMPLETE_V1.format(pin=PIN_A))
        (self.root / REVIEW_TRIGGER).unlink()
        (self.root / REVIEW_VERDICT).unlink()
        legacy = complete.read_bytes()

        result = prepare(self.root, PIN_A)

        self.assertEqual(result["changed_files"], [])
        self.assertEqual(result["review_check"], "upgrade_required")
        self.assertEqual(complete.read_bytes(), legacy)
        self.assertFalse((self.root / REVIEW_TRIGGER).exists())
        self.assertFalse((self.root / REVIEW_VERDICT).exists())

        upgraded = prepare(self.root, PIN_A, upgrade_selector=True)

        self.assertEqual(set(upgraded["changed_files"]),
                         {COMPLETE, REVIEW_TRIGGER, REVIEW_VERDICT})
        self.assertIn(PIN_A, complete.read_text())
        self.assertIn("pull_request_review:", complete.read_text())
        self.assertEqual(upgraded["integration"], "not_verified")
        self.assertEqual(upgraded["review_check"], "prepared")

    def test_authorized_upgrade_repairs_managed_v2_review_route_and_reports_prepared(
            self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        complete.write_text(complete.read_text().replace(
            "  issue_comment:\n    types: [created, edited, deleted]\n", ""))

        repaired = prepare(self.root, PIN_A, upgrade_selector=True)

        self.assertEqual(repaired["changed_files"], [COMPLETE])
        self.assertEqual(repaired["review_check"], "prepared")
        self.assertEqual(repaired["integration"], "not_verified")
        self.assertIn("  issue_comment:\n    types: [created, edited, deleted]",
                      complete.read_text())

    def test_partial_managed_marker_fails_closed_without_replacing_the_file(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        broken = complete.read_text().replace(
            "# ght-adoption-managed: ght-complete/v2", "# ght-adoption-managed: ght-complete/")
        complete.write_text(broken)
        before = complete.read_bytes()

        with self.assertRaisesRegex(WorkflowAdoptionError, "malformed.*marker|marker.*malformed"):
            prepare(self.root, PIN_A)

        self.assertEqual(complete.read_bytes(), before)

    def test_review_job_permission_loss_fails_closed_without_repairing_workflow(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        broken = complete.read_text().replace("      checks: write\n", "")
        complete.write_text(broken)
        before = complete.read_bytes()

        with self.assertRaisesRegex(WorkflowAdoptionError,
                                    "required read or checks: write permission"):
            prepare(self.root, PIN_A)

        self.assertEqual(complete.read_bytes(), before)

    def test_review_job_cannot_checkout_or_execute_pull_request_code(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        text = complete.read_text().replace(
            "ref: ${{ github.event.repository.default_branch }}",
            "ref: ${{ github.event.pull_request.head.sha }}")
        complete.write_text(text)
        before = complete.read_bytes()

        with self.assertRaisesRegex(WorkflowAdoptionError,
                                    "review events do not route through the canonical repo-local trigger"):
            prepare(self.root, PIN_A)

        self.assertEqual(complete.read_bytes(), before)

    def test_project_owned_v2_workflow_rejects_appended_review_command_without_writes(
            self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        text = complete.read_text().replace(
            "# ght-adoption-managed: ght-complete/v2\n", "")
        canonical_run = "        run: python3 .github/scripts/ght-gha-review-trigger.py"
        self.assertIn(canonical_run, text)
        text = text.replace(
            canonical_run,
            canonical_run + " && sh .github/scripts/extra-review-command.sh", 1)
        complete.write_text(text)
        # Keep caller validation from failing before the run invocation check.
        extra_command = self.root / ".github/scripts/extra-review-command.sh"
        extra_command.write_text("# refs/ght/runtime/ GHT_RUNTIME_REF ght complete\n")
        targets = (COMPLETE, PLAN, ADAPTER, REVIEW_TRIGGER, REVIEW_VERDICT,
                   ".github/scripts/extra-review-command.sh")
        before = {path: (self.root / path).read_bytes() for path in targets}

        with self.assertRaises(WorkflowAdoptionError):
            prepare(self.root, PIN_A)

        self.assertEqual({path: (self.root / path).read_bytes() for path in targets},
                         before)

    def _assert_project_owned_review_step_rejected_without_writes(self, step):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        text = complete.read_text().replace(
            "# ght-adoption-managed: ght-complete/v2\n", "")
        review_start = text.index("  review_verdict:\n")
        complete_start = text.index("\n  complete:\n", review_start)
        checkout = "      - uses: actions/checkout@v4"
        checkout_at = text.index(checkout, review_start, complete_start)
        text = text[:checkout_at] + f"{step}\n" + text[checkout_at:]
        complete.write_text(text)
        targets = (COMPLETE, PLAN, ADAPTER, REVIEW_TRIGGER, REVIEW_VERDICT)
        before = {path: (self.root / path).read_bytes() for path in targets}

        with self.assertRaises(WorkflowAdoptionError):
            prepare(self.root, PIN_A)

        self.assertEqual({path: (self.root / path).read_bytes() for path in targets},
                         before)

    def test_project_owned_review_job_rejects_extra_run_step_without_writes(self):
        self._assert_project_owned_review_step_rejected_without_writes(
            "      - run: echo unexpected-step")

    def test_project_owned_review_job_rejects_quoted_run_key_without_writes(self):
        self._assert_project_owned_review_step_rejected_without_writes(
            '      - "run": echo unexpected-step')

    def test_project_owned_review_job_rejects_spaced_uses_key_without_writes(self):
        self._assert_project_owned_review_step_rejected_without_writes(
            "      - uses : actions/github-script@v7")

    def test_missing_trusted_helper_fails_before_any_project_proposal_is_written(self):
        package_root = Path(tempfile.mkdtemp(prefix="ght-package-missing-helper-"))
        self.addCleanup(shutil.rmtree, package_root, ignore_errors=True)
        source_root = Path(__file__).parents[1]
        for relative in (
                "scripts/ght-gha-adapter.sh",
                "scripts/ght-gha-review-verdict.py",
                "workflow_templates/ght-complete.yml",
                "workflow_templates/ght-plan-publish.yml"):
            destination = package_root / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source_root / relative, destination)

        with self.assertRaisesRegex(WorkflowAdoptionError,
                                    "trusted review helper is missing"):
            prepare(self.root, PIN_A, package_root=package_root)

        self.assertFalse((self.root / COMPLETE).exists())
        self.assertFalse((self.root / PLAN).exists())
        self.assertFalse((self.root / ADAPTER).exists())

    def test_symlinked_review_helper_path_fails_closed(self):
        prepare(self.root, PIN_A)
        outside = self.root.parent / "ght-review-helper-outside.py"
        outside.write_text("# outside\n")
        self.addCleanup(outside.unlink, missing_ok=True)
        helper = self.root / REVIEW_TRIGGER
        helper.unlink()
        helper.symlink_to(outside)

        with self.assertRaisesRegex(WorkflowAdoptionError,
                                    "not a regular file"):
            prepare(self.root, PIN_A)

        self.assertEqual(outside.read_text(), "# outside\n")

    def test_project_owned_workflow_rejects_conflicting_effective_runtime_pins(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        text = complete.read_text().replace(
            "# ght-adoption-managed: ght-complete/v2\n", "")
        text = text.replace(
            "jobs:\n", f'env:\n  GHT_RUNTIME_REF: "{PIN_A}"\njobs:\n', 1)
        text = text.replace(
            f'    env:\n      GHT_RUNTIME_REF: "{PIN_A}"\n    steps:',
            f'    env:\n      GHT_RUNTIME_REF: "{PIN_B}"\n    steps:', 1)
        complete.write_text(text)
        before = {path: (self.root / path).read_bytes()
                  for path in (COMPLETE, PLAN, ADAPTER)}

        with self.assertRaisesRegex(
                WorkflowAdoptionError,
                rf"conflicting GHT_RUNTIME_REF pins: workflow-level \(indent 2, line \d+\)={PIN_A}; "
                rf"jobs\.complete \(indent 6, line \d+\)={PIN_B}"):
            prepare(self.root, PIN_A)

        self.assertEqual({path: (self.root / path).read_bytes() for path in before},
                         before)

    def test_project_owned_workflow_rejects_dynamic_job_runtime_override(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        text = complete.read_text().replace(
            "# ght-adoption-managed: ght-complete/v2\n", "")
        text = text.replace(
            "jobs:\n", f'env:\n  GHT_RUNTIME_REF: "{PIN_A}"\njobs:\n', 1)
        text = text.replace(
            f'      GHT_RUNTIME_REF: "{PIN_A}"',
            '      GHT_RUNTIME_REF: "${{ github.sha }}"', 1)
        complete.write_text(text)
        before = {path: (self.root / path).read_bytes()
                  for path in (COMPLETE, PLAN, ADAPTER)}

        with self.assertRaises(WorkflowAdoptionError) as raised:
            prepare(self.root, PIN_A)

        reason = str(raised.exception)
        self.assertIn("GHT_RUNTIME_REF", reason)
        self.assertIn("jobs.complete", reason)
        self.assertIn("${{ github.sha }}", reason)
        self.assertEqual({path: (self.root / path).read_bytes() for path in before},
                         before)

    def test_project_owned_workflow_rejects_non_digest_job_runtime_override(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        text = complete.read_text().replace(
            "# ght-adoption-managed: ght-complete/v2\n", "")
        text = text.replace(
            "jobs:\n", f'env:\n  GHT_RUNTIME_REF: "{PIN_A}"\njobs:\n', 1)
        text = text.replace(
            f'      GHT_RUNTIME_REF: "{PIN_A}"',
            '      GHT_RUNTIME_REF: "latest"', 1)
        complete.write_text(text)
        before = {path: (self.root / path).read_bytes()
                  for path in (COMPLETE, PLAN, ADAPTER)}

        with self.assertRaises(WorkflowAdoptionError) as raised:
            prepare(self.root, PIN_A)

        reason = str(raised.exception)
        self.assertIn("GHT_RUNTIME_REF", reason)
        self.assertIn("jobs.complete", reason)
        self.assertIn("latest", reason)
        self.assertEqual({path: (self.root / path).read_bytes() for path in before},
                         before)

    def test_project_owned_workflow_rejects_quoted_runtime_override_keys(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        canonical = complete.read_text()
        for key, value in (("\"GHT_RUNTIME_REF\"", '"${{ github.sha }}"'),
                           ("'GHT_RUNTIME_REF'", '"latest"')):
            with self.subTest(key=key):
                text = canonical.replace(
                    "# ght-adoption-managed: ght-complete/v2\n", "")
                text = text.replace(
                    "jobs:\n", f'env:\n  GHT_RUNTIME_REF: "{PIN_A}"\njobs:\n', 1)
                text = text.replace(
                    f'      GHT_RUNTIME_REF: "{PIN_A}"',
                    f"      {key}: {value}", 1)
                complete.write_text(text)
                before = {path: (self.root / path).read_bytes()
                          for path in (COMPLETE, PLAN, ADAPTER)}

                with self.assertRaises(WorkflowAdoptionError) as raised:
                    prepare(self.root, PIN_A)

                reason = str(raised.exception)
                self.assertIn("ambiguous GHT_RUNTIME_REF occurrence", reason)
                self.assertIn("jobs.complete", reason)
                self.assertIn("GHT_RUNTIME_REF", reason)
                self.assertIn(value, reason)
                self.assertEqual(
                    {path: (self.root / path).read_bytes() for path in before},
                    before)

    def test_project_owned_workflow_rejects_unseparated_pin_comment_suffix(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        text = complete.read_text().replace(
            "# ght-adoption-managed: ght-complete/v2\n", "")
        text = text.replace(
            "jobs:\n", f'env:\n  GHT_RUNTIME_REF: "{PIN_A}"\njobs:\n', 1)
        text = text.replace(
            f'      GHT_RUNTIME_REF: "{PIN_A}"',
            f'      GHT_RUNTIME_REF: {PIN_A}#latest', 1)
        complete.write_text(text)
        before = {path: (self.root / path).read_bytes()
                  for path in (COMPLETE, PLAN, ADAPTER)}

        with self.assertRaises(WorkflowAdoptionError) as raised:
            prepare(self.root, PIN_A)

        reason = str(raised.exception)
        self.assertIn("unprovable GHT_RUNTIME_REF value", reason)
        self.assertIn("jobs.complete", reason)
        self.assertIn(f"{PIN_A}#latest", reason)
        self.assertEqual({path: (self.root / path).read_bytes() for path in before},
                         before)

    def test_project_owned_workflow_accepts_repeated_matching_runtime_pins(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        text = complete.read_text().replace(
            "# ght-adoption-managed: ght-complete/v2\n", "")
        text = text.replace(
            "jobs:\n", f'env:\n  GHT_RUNTIME_REF: "{PIN_A}"\njobs:\n', 1)
        complete.write_text(text)
        before = {path: (self.root / path).read_bytes()
                  for path in (COMPLETE, PLAN, ADAPTER)}

        result = prepare(self.root, PIN_A)

        self.assertEqual(result["status"], "already_compatible")
        self.assertEqual(result["changed_files"], [])
        self.assertEqual({path: (self.root / path).read_bytes() for path in before},
                         before)

    def test_authorized_upgrade_updates_only_managed_workflow_pins(self):
        prepare(self.root, PIN_A)

        result = prepare(self.root, PIN_B, upgrade_selector=True)

        self.assertEqual(set(result["changed_files"]), {COMPLETE, PLAN})
        self.assertIn(PIN_B, (self.root / PLAN).read_text())
        self.assertEqual(result["integration"], "not_verified")

    def test_wrong_historical_pin_requires_an_explicit_authorized_upgrade(self):
        prepare(self.root, PIN_A)
        before = {path: (self.root / path).read_bytes()
                  for path in (COMPLETE, PLAN)}

        with self.assertRaisesRegex(
                WorkflowAdoptionError,
                "incompatible GHT_RUNTIME_REF pin.*authorized upgrade"):
            prepare(self.root, PIN_B)

        self.assertEqual({path: (self.root / path).read_bytes()
                          for path in before}, before)

    def test_managed_marker_does_not_accept_a_broken_canonical_caller(self):
        prepare(self.root, PIN_A)
        adapter = self.root / ADAPTER
        adapter.write_text(
            "#!/bin/sh\n"
            "# ght-adapter-managed: capsule-adapter/v1\n"
            "case \"${GHT_RUNTIME_REF:-}\" in\n"
            "  *) ;;\n"
            "esac\n"
            "git fetch origin \"+refs/ght/runtime/$GHT_RUNTIME_REF\"\n"
            "python3 - <<'PY'\n"
            "import hashlib, json, sys\n"
            "pin = sys.argv[3]\n"
            "manifest = json.load(open(sys.argv[2]))\n"
            "payload_digest = hashlib.sha256(open(sys.argv[1], \"rb\").read()).hexdigest()\n"
            "if payload_digest != pin:\n"
            "    raise SystemExit(1)\n"
            "if manifest.get(\"digest\") != pin:\n"
            "    raise SystemExit(1)\n"
            "PY\n"
            "unzip -q \"$runtime_tmp/runtime.zip\" -d \"$runtime_tmp/runtime\"\n"
            "# plan-publish\n"
            "exit 0\n")

        with self.assertRaisesRegex(
                WorkflowAdoptionError,
                "does not invoke canonical ght complete"):
            prepare(self.root, PIN_A)

    def test_managed_marker_does_not_replace_capsule_integrity_validation(self):
        prepare(self.root, PIN_A)
        adapter = self.root / ADAPTER
        adapter.write_text(
            "#!/bin/sh\n"
            "# ght-adapter-managed: capsule-adapter/v1\n"
            "case \"${GHT_RUNTIME_REF:-}\" in\n"
            "  *) ;;\n"
            "esac\n"
            "git fetch origin \"+refs/ght/runtime/$GHT_RUNTIME_REF\"\n"
            "python3 - <<'PY'\n"
            "import sys\n"
            "pin = sys.argv[3]\n"
            "PY\n"
            "exec \"${GHT_RUNTIME_DIR}/scripts/ght-gha-complete.sh\" complete \"$issue\" \"$pr\"\n"
            "exec \"${GHT_RUNTIME_DIR}/scripts/ght-plan-publish.sh\" \"$plan_path\" --replace-current\n")

        with self.assertRaisesRegex(
                WorkflowAdoptionError,
                "does not verify the runtime capsule payload and manifest"):
            prepare(self.root, PIN_A)

    def test_project_owned_conflict_is_preserved_and_blocks_all_writes(self):
        target = self.root / PLAN
        target.parent.mkdir(parents=True)
        target.write_text("name: project-owned plan workflow\n")

        with self.assertRaisesRegex(WorkflowAdoptionError, "project-owned"):
            prepare(self.root, PIN_A)

        self.assertEqual(target.read_text(), "name: project-owned plan workflow\n")
        self.assertFalse((self.root / COMPLETE).exists())
        self.assertFalse((self.root / ADAPTER).exists())

    def test_missing_permission_or_incompatible_call_path_blocks_without_repairing_over_owner(self):
        prepare(self.root, PIN_A)
        complete = self.root / COMPLETE
        canonical = complete.read_text()
        complete.write_text(canonical.replace("  issues: write\n", ""))
        with self.assertRaisesRegex(WorkflowAdoptionError, "issues: write"):
            prepare(self.root, PIN_A)

        complete.write_text(canonical.replace(
            ".github/scripts/ght-gha-adapter.sh", "skills/github-task/scripts/ght-gha-complete.sh"))
        with self.assertRaisesRegex(WorkflowAdoptionError, "caller"):
            prepare(self.root, PIN_A)

        complete.write_text(canonical.replace(
            ".github/scripts/ght-gha-adapter.sh", ".github/scripts/custom-complete.sh"))
        with self.assertRaisesRegex(WorkflowAdoptionError,
                                    "caller file is missing: .github/scripts/custom-complete.sh"):
            prepare(self.root, PIN_A)

    def test_symlinked_component_parent_is_not_followed_outside_the_checkout(self):
        outside = Path(tempfile.mkdtemp(prefix="ght-workflow-outside-"))
        self.addCleanup(shutil.rmtree, outside, ignore_errors=True)
        (self.root / ".github").symlink_to(outside, target_is_directory=True)

        with self.assertRaisesRegex(WorkflowAdoptionError, "parent is unsafe"):
            prepare(self.root, PIN_A)

        self.assertEqual(list(outside.iterdir()), [])


if __name__ == "__main__":
    unittest.main()
