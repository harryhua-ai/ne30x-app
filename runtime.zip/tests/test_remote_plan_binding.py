"""Remote-A mechanical Contract binding for Plan publication (#156).

Closes the post-#82/#91 remote-A authoring gap: an A with GitHub access but
NO target-repo checkout and NO local ght commits its COMPLETE A-owned
scheduling decision (membership, priority, ``after`` barriers,
``authorization_id`` — nodes carry NO hand-supplied digests) to the
designated ``docs/plans/current-plan.yaml`` payload through GitHub's durable
contents write; the push-triggered publication glue invokes the canonical
``ght plan-publish --bind-contract-digests`` primitive, which mechanically
binds every unbound node's ``contract_digest`` through the ONE canonical
digest primitive (``ght contract-digest`` == fresh ``parse_contract`` +
``contract_digest``) and then publishes through the unchanged exact-prior
CAS path.

These tests bind the #156 acceptance matrix end to end (offline: local bare
origin + checkout standing in for the runner workspace + a stub ``gh``):

- remote no-checkout binding/publication reaching the canonical ref (AC1/AC4);
- multi-node binding (AC5);
- invalid and unreadable Contracts failing closed (AC3/AC5);
- a Contract mutated BETWEEN binding and publication refusing the stale
  binding while the prior current Plan stays unchanged (AC3/AC4/AC5);
- byte/semantic preservation of every A-authored scheduling field — no
  invented, selected, reordered, or mutated membership/priority/barrier/
  authorization identity (AC3/AC5);
- proof that binding routes through the SAME canonical digest primitive as
  the ``ght contract-digest`` command rather than any duplicated logic
  (AC2/AC5), plus the shared-validation parser split (strict vs authoring).
"""

import contextlib
import io
import json
import os
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

SKILL_ROOT = Path(__file__).parents[1]
GLUE = SKILL_ROOT / "scripts" / "ght-plan-publish.sh"
CLI = SKILL_ROOT / "scripts" / "ght.py"

PLAN_REF = "refs/ght/plans/current"
PLAN_PATH_IN_REPO = "docs/plans/current-plan.yaml"


def _contract(intent_line: str) -> str:
    return (
        "## Remote binding fixture\n"
        "\n"
        "```ght-contract\n"
        "version: 1\n"
        "\n"
        "intent: >\n"
        f"  {intent_line}\n"
        "\n"
        "authority:\n"
        "  implementation: allowed\n"
        "\n"
        "acceptance:\n"
        "  - id: AC1\n"
        "    requirement: >\n"
        "      The Plan node carries the canonical digest of this Contract.\n"
        "```\n"
    )


CONTRACT_75 = _contract("Bind node 75 mechanically to this exact Contract.")
CONTRACT_75_MUTATED = _contract(
    "MUTATED after binding: node 75 must refuse the stale digest.")
CONTRACT_66 = _contract("Bind node 66 mechanically to its own distinct Contract.")


def _canonical_digest(body: str) -> str:
    from github_task.core import contract_digest, parse_contract
    return contract_digest(parse_contract(body))


def _make_repo(base: Path) -> Path:
    """A bare origin plus a real checkout standing in for the Actions
    runner's workspace (real git remote, real push credentials), and the
    stub `gh` the runner credential would carry."""
    origin = base / "origin.git"
    subprocess.run(["git", "init", "--bare", "-q", str(origin)], check=True)
    clone = base / "clone"
    subprocess.run(["git", "clone", "-q", str(origin), str(clone)], check=True)
    (clone / "README.md").write_text("init\n")
    git("add", "-A", cwd=clone)
    git("commit", "-qm", "init", cwd=clone)
    pushed = git("push", "-q", "origin", "HEAD", cwd=clone)
    assert pushed.returncode == 0, pushed.stderr
    fake_bin = base / "bin"
    fake_bin.mkdir(exist_ok=True)
    gh = fake_bin / "gh"
    gh.write_text(GH_STUB)
    gh.chmod(gh.stat().st_mode | stat.S_IXUSR)
    return clone


def git(*args, cwd: Path) -> subprocess.CompletedProcess:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
           "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t"}
    return subprocess.run(["git", *args], cwd=str(cwd),
                          capture_output=True, text=True, env=env)


GH_STUB = """#!/usr/bin/env python3
import json, os, sys

args = sys.argv[1:]
if args[:2] == ["api", "user"]:
    if os.environ.get("GHT_TEST_PRINCIPAL"):
        print(os.environ["GHT_TEST_PRINCIPAL"])
        sys.exit(0)
    sys.exit(1)  # installation-token condition, like a real runner credential

MUTATION_STATE = os.environ.get("GHT_TEST_MUTATION_STATE")
if args[:3] == ["issue", "view", "75"] and MUTATION_STATE:
    count = int(open(MUTATION_STATE).read().strip() or "0") + 1
    open(MUTATION_STATE, "w").write(str(count))
    if count >= 2 and os.environ.get("GHT_TEST_ISSUE_75_MUTATED_BODY"):
        body = os.environ["GHT_TEST_ISSUE_75_MUTATED_BODY"]
    else:
        body = os.environ["GHT_TEST_ISSUE_75_BODY"]
    print(json.dumps({
        "number": 75, "title": "Remote binding fixture",
        "state": "OPEN", "stateReason": None,
        "url": "https://github.com/example/repo/issues/75",
        "labels": [], "assignees": [], "comments": [], "body": body}))
    sys.exit(0)

for number in ("75", "66"):
    unreadable = f"GHT_TEST_ISSUE_{number}_UNREADABLE"
    if args[:3] == ["issue", "view", number] and os.environ.get(unreadable):
        sys.exit(1)
    if args[:3] == ["issue", "view", number]:
        body = os.environ[f"GHT_TEST_ISSUE_{number}_BODY"]
        print(json.dumps({
            "number": int(number), "title": "Remote binding fixture",
            "state": "OPEN", "stateReason": None,
            "url": f"https://github.com/example/repo/issues/{number}",
            "labels": [], "assignees": [], "comments": [], "body": body}))
        sys.exit(0)
sys.exit(1)
"""


def base_env(clone: Path) -> dict:
    env = {"PATH": f"{clone.parent / 'bin'}:/usr/bin:/bin",
           "GIT_CONFIG_GLOBAL": "/dev/null",
           "GIT_CONFIG_SYSTEM": "/dev/null",
           "GHT_TEST_ISSUE_75_BODY": CONTRACT_75,
           "GHT_TEST_ISSUE_66_BODY": CONTRACT_66,
           # Installation-token condition: no authenticated principal can be
           # resolved, so the canonical publication path carries the
           # plan-publication-only machine identity (audit metadata only).
           "GHT_PLAN_PUBLISHER_ID": "ght-plan-publish-workflow"}
    for var in ("GIT_AUTHOR_NAME", "GIT_AUTHOR_EMAIL", "GIT_COMMITTER_NAME",
                "GIT_COMMITTER_EMAIL", "EMAIL"):
        env.pop(var, None)
    return env


def glue_env(base: Path) -> dict:
    env = base_env(base)
    env["GHT_PLAN_PUBLISH_PYTHON"] = sys.executable
    return env


def run_glue(clone: Path, *args, env_extra=None):
    env = glue_env(clone)
    env.update(env_extra or {})
    return subprocess.run(["sh", str(GLUE), *args],
                          capture_output=True, text=True, env=env, cwd=str(clone))


def run_cli(clone: Path, *args, env_extra=None):
    env = base_env(clone)
    env.update(env_extra or {})
    return subprocess.run([sys.executable, str(CLI), "--json", *args],
                          cwd=str(clone), capture_output=True, text=True, env=env)


def write_authoring_plan(clone: Path, plan: dict) -> Path:
    """Remote-A's ONLY durable write: a GitHub contents commit of the
    scheduling decision to the designated payload file. No digest is ever
    present — remote A cannot produce one and must not need one."""
    target = clone / PLAN_PATH_IN_REPO
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(plan, indent=2) + "\n")
    git("add", "-A", cwd=clone)
    git("commit", "-qm", "A scheduling decision (remote authoring)", cwd=clone)
    return target


def current_pointer(clone: Path) -> str:
    return git("ls-remote", "origin", PLAN_REF, cwd=clone).stdout.split()[0]


def read_published_plan(clone: Path) -> dict:
    """Durable read-back of the exact published revision's PLAN.json."""
    revision = current_pointer(clone)
    git("fetch", "-q", "origin", PLAN_REF, cwd=clone)
    plan_text = git("show", "FETCH_HEAD:PLAN.json", cwd=clone).stdout
    return json.loads(plan_text)


class RemotePlanBindingTests(unittest.TestCase):
    maxDiff = None

    def test_remote_authoring_document_binds_and_publishes_without_local_ght(self):
        # AC1/AC2/AC4: a scheduling decision committed WITHOUT any digest —
        # the only durable write a checkout-less, ght-less remote A has —
        # reaches canonical current truth: the workflow-side canonical
        # invocation binds the node's contract_digest mechanically at
        # publication time and the exact plan_id/revision stay durably
        # readable. Nothing in the path needed the User, B, or a relayed
        # digest output.
        with tempfile.TemporaryDirectory() as tmp:
            clone = _make_repo(Path(tmp))
            authored = {"version": 1, "plan_id": "remote-156",
                        "nodes": [{"issue": 75, "authorization_id": "auth-75-156",
                                   "priority": 10}]}
            write_authoring_plan(clone, authored)
            self.assertNotIn("contract_digest",
                             (clone / PLAN_PATH_IN_REPO).read_text(),
                             "remote A never supplies a digest")
            result = run_glue(clone, PLAN_PATH_IN_REPO, "--replace-current")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            outcome = json.loads(result.stdout)
            self.assertEqual(outcome["plan_id"], "remote-156")
            self.assertEqual(len(outcome["revision"]), 40)
            self.assertEqual(outcome["nodes"], 1)
            self.assertEqual(outcome["ref"], PLAN_REF)
            self.assertEqual(current_pointer(clone), outcome["revision"],
                             "the current pointer durably exposes the exact revision")
            published = read_published_plan(clone)
            self.assertEqual(published["nodes"][0]["contract_digest"],
                             _canonical_digest(CONTRACT_75),
                             "the bound digest is the canonical primitive's output")
            self.assertEqual(published["plan_id"], "remote-156")

    def test_multi_node_authoring_binds_every_node(self):
        # AC5: several unbound nodes are each bound to their OWN Issue
        # Contract through the canonical primitive — never one digest for
        # all, never a partial bind.
        with tempfile.TemporaryDirectory() as tmp:
            clone = _make_repo(Path(tmp))
            authored = {"version": 1, "plan_id": "remote-156-multi",
                        "nodes": [
                            {"issue": 75, "authorization_id": "auth-75",
                             "priority": 400},
                            {"issue": 66, "authorization_id": "auth-66",
                             "priority": 250,
                             "after": [{"gate": "merged", "issue": 75}]}]}
            write_authoring_plan(clone, authored)
            result = run_glue(clone, PLAN_PATH_IN_REPO, "--replace-current")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            published = read_published_plan(clone)
            digests = {node["issue"]: node["contract_digest"]
                       for node in published["nodes"]}
            self.assertEqual(digests[75], _canonical_digest(CONTRACT_75))
            self.assertEqual(digests[66], _canonical_digest(CONTRACT_66))
            self.assertNotEqual(digests[75], digests[66])

    def test_invalid_contract_fails_binding_closed(self):
        # AC3/AC5: an unreadable/invalid Contract on any node fails the WHOLE
        # publication closed; no pointer ever appears.
        with tempfile.TemporaryDirectory() as tmp:
            clone = _make_repo(Path(tmp))
            write_authoring_plan(clone, {
                "version": 1, "plan_id": "remote-156-invalid",
                "nodes": [{"issue": 75, "authorization_id": "auth-75",
                           "priority": 1}]})
            result = run_glue(clone, PLAN_PATH_IN_REPO, "--replace-current",
                              env_extra={"GHT_TEST_ISSUE_75_BODY":
                                         "no ght-contract block here"})
            self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("contract", (result.stdout + result.stderr).lower())
            self.assertEqual(git("ls-remote", "origin", PLAN_REF,
                                 cwd=clone).stdout.strip(), "")

    def test_unreadable_issue_fails_binding_closed(self):
        # AC3/AC5: a genuinely unreadable Issue read (what a token without
        # issues:read produces) fails the binding closed — never a guessed
        # digest, never a pointer.
        with tempfile.TemporaryDirectory() as tmp:
            clone = _make_repo(Path(tmp))
            write_authoring_plan(clone, {
                "version": 1, "plan_id": "remote-156-unreadable",
                "nodes": [{"issue": 75, "authorization_id": "auth-75",
                           "priority": 1}]})
            result = run_glue(clone, PLAN_PATH_IN_REPO, "--replace-current",
                              env_extra={"GHT_TEST_ISSUE_75_UNREADABLE": "1"})
            self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("unreadable", (result.stdout + result.stderr).lower())
            self.assertEqual(git("ls-remote", "origin", PLAN_REF,
                                 cwd=clone).stdout.strip(), "")

    def test_contract_mutation_between_binding_and_publication_refuses_stale_binding(self):
        # AC3/AC4/AC5: binding and publication are two fresh canonical reads;
        # a Contract changed in between fails the publication closed and the
        # PRIOR current Plan stays exactly where it was (diagnostically
        # recoverable), never a silently stale binding.
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            clone = _make_repo(base)
            mutation_state = base / "issue-75-reads"
            mutation_state.write_text("0")
            # First publication: the unbound scheduling decision binds and
            # publishes normally (mutation machinery not yet armed — only one
            # read of #75 happens).
            first_plan = {"version": 1, "plan_id": "remote-156-stale",
                          "nodes": [{"issue": 75, "authorization_id": "auth-75-v1",
                                     "priority": 10}]}
            write_authoring_plan(clone, first_plan)
            result = run_glue(clone, PLAN_PATH_IN_REPO, "--replace-current")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            first_revision = json.loads(result.stdout)["revision"]
            self.assertEqual(current_pointer(clone), first_revision)
            # Second publication: the Contract mutates after the binding read
            # but before the publication-time fresh verification read.
            write_authoring_plan(clone, {
                "version": 1, "plan_id": "remote-156-stale",
                "nodes": [{"issue": 75, "authorization_id": "auth-75-v2",
                           "priority": 20}]})
            result = run_glue(clone, PLAN_PATH_IN_REPO, "--replace-current",
                              env_extra={"GHT_TEST_MUTATION_STATE":
                                         str(mutation_state),
                                         "GHT_TEST_ISSUE_75_MUTATED_BODY":
                                         CONTRACT_75_MUTATED})
            self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("digest", (result.stdout + result.stderr).lower())
            self.assertEqual(current_pointer(clone), first_revision,
                             "failure leaves the prior current Plan unchanged")
            self.assertEqual(read_published_plan(clone)["nodes"][0]["authorization_id"],
                             "auth-75-v1",
                             "the surviving current revision is the prior one")

    def test_a_authored_scheduling_fields_are_preserved_exactly(self):
        # AC3/AC5: mechanical binding may bind ONLY the Contract identity.
        # Membership, list order, priorities, after barriers, and
        # authorization ids survive publication with exact semantic (and
        # value-for-value) identity; nothing is invented, selected,
        # reordered, or mutated.
        with tempfile.TemporaryDirectory() as tmp:
            clone = _make_repo(Path(tmp))
            nodes = [
                {"issue": 66, "authorization_id": "auth-66-250", "priority": 250,
                 "after": [{"gate": "merged", "issue": 75}]},
                {"issue": 75, "authorization_id": "auth-75-400", "priority": 400},
            ]
            write_authoring_plan(clone, {"version": 1,
                                         "plan_id": "remote-156-fields",
                                         "nodes": nodes})
            result = run_glue(clone, PLAN_PATH_IN_REPO, "--replace-current")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            published = read_published_plan(clone)["nodes"]
            self.assertEqual([n["issue"] for n in published], [66, 75],
                             "membership AND authored order are preserved")
            for authored_node, published_node in zip(nodes, published):
                for field in ("issue", "authorization_id", "priority"):
                    self.assertEqual(published_node[field], authored_node[field],
                                     f"{field} must survive binding byte-identically")
                # An omitted after-barrier list normalizes to [] exactly as in
                # the strict direct path — canonical v1 semantics, not a
                # binding-side mutation.
                self.assertEqual(published_node["after"],
                                 authored_node.get("after", []))
                self.assertEqual(
                    set(published_node) - {"contract_digest"},
                    set(authored_node) | {"after"},
                    "binding adds ONLY the protocol-required Contract identity")

    def test_binding_value_equals_the_canonical_contract_digest_command(self):
        # AC2/AC5 (behavioral sameness): the digest the remote path binds is
        # value-identical to what the canonical `ght contract-digest` command
        # reports for the same Issue — one primitive, two entry points.
        with tempfile.TemporaryDirectory() as tmp:
            clone = _make_repo(Path(tmp))
            write_authoring_plan(clone, {
                "version": 1, "plan_id": "remote-156-sameness",
                "nodes": [{"issue": 75, "authorization_id": "auth-75",
                           "priority": 1}]})
            command = run_cli(clone, "contract-digest", "75",
                              env_extra={"GHT_TEST_PRINCIPAL": "a-remote-operator",
                                         # the machine publication identity is
                                         # plan-publish-only; the canonical digest
                                         # command runs under a real principal
                                         "GHT_PLAN_PUBLISHER_ID": ""})
            self.assertEqual(command.returncode, 0, command.stdout + command.stderr)
            reported = json.loads(command.stdout)["contract_digest"]
            result = run_glue(clone, PLAN_PATH_IN_REPO, "--replace-current")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            published = read_published_plan(clone)
            self.assertEqual(published["nodes"][0]["contract_digest"], reported)

    def test_binding_routes_through_the_canonical_primitive_not_a_copy(self):
        # AC2/AC5 (structural proof): the binding path calls the SAME
        # module-level parse_contract/contract_digest functions the
        # `ght contract-digest` command uses — no second parser/hash truth.
        from github_task import cli
        with tempfile.TemporaryDirectory() as tmp:
            clone = _make_repo(Path(tmp))
            payload = write_authoring_plan(clone, {
                "version": 1, "plan_id": "remote-156-structural",
                "nodes": [{"issue": 75, "authorization_id": "auth-75",
                           "priority": 1}]})
            calls = {"parse": 0, "digest": 0}
            real_parse, real_digest = cli.parse_contract, cli.contract_digest

            def counting_parse(body):
                calls["parse"] += 1
                return real_parse(body)

            def counting_digest(contract):
                calls["digest"] += 1
                return real_digest(contract)

            env = base_env(clone)
            saved = {k: os.environ.get(k) for k in env}
            os.environ.update(env)
            try:
                with mock.patch.object(cli, "parse_contract", counting_parse), \
                        mock.patch.object(cli, "contract_digest", counting_digest), \
                        contextlib.chdir(clone), \
                        contextlib.redirect_stdout(io.StringIO()):
                    cli.main(["--json", "plan-publish", str(payload),
                              "--bind-contract-digests"])
            finally:
                for key, value in saved.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value
            self.assertGreaterEqual(calls["parse"], 1,
                                    "binding must go through the canonical parser")
            self.assertGreaterEqual(calls["digest"], 1,
                                    "binding must go through the canonical digester")
            self.assertEqual(read_published_plan(clone)["nodes"][0]["contract_digest"],
                             real_digest(real_parse(CONTRACT_75)),
                             "the bound value is the canonical primitive's output")

    def test_direct_publish_without_binding_still_rejects_unbound_nodes(self):
        # AC6/#91 boundary: the direct local path keeps its strict semantics —
        # `ght plan-publish` WITHOUT the binding flag still refuses a digest-
        # free authoring document; the flag is the explicit, equivalent
        # direct surface for the same canonical publication.
        with tempfile.TemporaryDirectory() as tmp:
            clone = _make_repo(Path(tmp))
            payload = write_authoring_plan(clone, {
                "version": 1, "plan_id": "remote-156-direct",
                "nodes": [{"issue": 75, "authorization_id": "auth-75",
                           "priority": 1}]})
            strict = run_cli(clone, "plan-publish", str(payload))
            self.assertNotEqual(strict.returncode, 0)
            self.assertIn("contract_digest", strict.stdout)
            self.assertEqual(git("ls-remote", "origin", PLAN_REF,
                                 cwd=clone).stdout.strip(), "")
            bound = run_cli(clone, "plan-publish", str(payload),
                            "--bind-contract-digests")
            self.assertEqual(bound.returncode, 0, bound.stdout + bound.stderr)
            self.assertEqual(read_published_plan(clone)["nodes"][0]["contract_digest"],
                             _canonical_digest(CONTRACT_75))


class PlanAuthoringParserTests(unittest.TestCase):
    """The authoring surface shares the strict v1 Plan validation; the ONLY
    difference is that the authoring parser may leave contract_digest to
    mechanical binding (#156). No second schema truth exists."""

    UNBOUND = {"version": 1, "plan_id": "p",
               "nodes": [{"issue": 7, "authorization_id": "a", "priority": 1}]}

    def test_authoring_parser_accepts_unbound_nodes_strict_parser_rejects(self):
        from github_task.core import (ExecutionPlanError, parse_execution_plan,
                                      parse_plan_authoring)
        text = json.dumps(self.UNBOUND)
        parsed = parse_plan_authoring(text)
        self.assertEqual(parsed["nodes"][0]["contract_digest"], None)
        self.assertEqual(parsed["plan_id"], "p")
        with self.assertRaises(ExecutionPlanError):
            parse_execution_plan(text)

    def test_authoring_parser_keeps_hand_supplied_digest_verbatim(self):
        from github_task.core import parse_plan_authoring
        plan = json.loads(json.dumps(self.UNBOUND))
        plan["nodes"][0]["contract_digest"] = "a" * 64
        parsed = parse_plan_authoring(json.dumps(plan))
        self.assertEqual(parsed["nodes"][0]["contract_digest"], "a" * 64,
                         "a pre-bound node passes through untouched")

    def test_authoring_parser_shares_every_strict_validation_rule(self):
        from github_task.core import ExecutionPlanError, parse_plan_authoring
        # A hand-supplied non-hex digest is still rejected.
        bad_digest = json.loads(json.dumps(self.UNBOUND))
        bad_digest["nodes"][0]["contract_digest"] = "not-a-digest"
        with self.assertRaises(ExecutionPlanError):
            parse_plan_authoring(json.dumps(bad_digest))
        # Unknown node fields are still rejected.
        unknown = json.loads(json.dumps(self.UNBOUND))
        unknown["nodes"][0]["worker"] = "nobody"
        with self.assertRaises(ExecutionPlanError):
            parse_plan_authoring(json.dumps(unknown))
        # The barrier DAG check is the same shared validation.
        cyclic = {"version": 1, "plan_id": "p", "nodes": [
            {"issue": 7, "authorization_id": "a", "priority": 1,
             "after": [{"gate": "merged", "issue": 8}]},
            {"issue": 8, "authorization_id": "b", "priority": 1,
             "after": [{"gate": "merged", "issue": 7}]}]}
        with self.assertRaises(ExecutionPlanError):
            parse_plan_authoring(json.dumps(cyclic))
        # Duplicate membership, bad priority, and duplicate authorization
        # identities fail exactly as in the strict parser.
        duplicate = json.loads(json.dumps(self.UNBOUND))
        duplicate["nodes"].append(dict(duplicate["nodes"][0]))
        with self.assertRaises(ExecutionPlanError):
            parse_plan_authoring(json.dumps(duplicate))


if __name__ == "__main__":
    unittest.main()
