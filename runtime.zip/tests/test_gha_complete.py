"""Targeted validation for the post-merge Mechanical Reconciler bootstrap (#67).

The automation is deliberately thin glue: resolve (issue, pr) from canonical
metadata — or the explicit workflow_dispatch inputs — then invoke the
canonical `ght complete <issue> --pr <pr>` primitive. These tests bind the
workflow trigger contract and the glue's safe derivation / argv assembly /
fail-closed behavior. Completion semantics themselves stay owned and tested
by the runtime suite.
"""

import json
import stat
import subprocess
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
WORKFLOW = SKILL_ROOT.parent.parent / ".github" / "workflows" / "ght-complete.yml"
GLUE = SKILL_ROOT / "scripts" / "ght-gha-complete.sh"


def run_glue(mode, *args, env_extra=None):
    env = {"PATH": "/usr/bin:/bin"}
    env.update(env_extra or {})
    return subprocess.run(["sh", str(GLUE), mode, *args],
                          capture_output=True, text=True, env=env)


def write_stub(path: Path, body: str):
    path.write_text("#!/usr/bin/env python3\n" + body)
    path.chmod(path.stat().st_mode | stat.S_IXUSR)


class GhaCompleteBootstrapTests(unittest.TestCase):
    def test_workflow_and_glue_exist_with_executable_glue(self):
        self.assertTrue(WORKFLOW.exists(), "post-merge workflow is missing")
        self.assertTrue(GLUE.exists(), "glue script is missing")
        self.assertTrue(GLUE.stat().st_mode & stat.S_IXUSR,
                        "glue script must be executable")

    def test_workflow_triggers_and_routes_only_through_canonical_glue(self):
        # AC1/AC2: the workflow fires on PR closed + merged, offers the
        # explicit dispatch retry, and its steps only ever route through the
        # glue into the canonical primitive — no duplicated completion logic.
        text = WORKFLOW.read_text()
        self.assertIn("pull_request:", text)
        self.assertIn("types: [closed]", text)
        self.assertIn("workflow_dispatch:", text)
        self.assertIn("issue:", text)
        self.assertIn("pr:", text)
        self.assertIn("ght-gha-complete.sh resolve", text)
        self.assertIn("ght-gha-complete.sh complete", text)
        # The glue is the only completion entry; no raw API duplication.
        self.assertNotIn("ght.py", text,
                         "the workflow must not invoke ght.py directly")
        self.assertNotIn("gh api", text,
                         "no duplicated durable-fact logic via raw API calls")
        # Fail-closed shell discipline in the run steps.
        self.assertEqual(text.count("set -euo pipefail"), 2)
        self.assertIn("GHT_EXECUTOR_ID", text)

    def test_workflow_gates_auto_path_on_merged_and_sets_reconciler_identity(self):
        # #67 round-2: closed-but-unmerged PRs never start completion; the
        # job carries the minimal Issue permission; the completion step runs
        # under the #69 completion-only machine identity.
        text = WORKFLOW.read_text()
        self.assertIn("github.event_name == 'workflow_dispatch' || "
                      "github.event.pull_request.merged == true", text)
        self.assertIn("issues: write", text)
        self.assertIn("GHT_RECONCILER_ID", text)

    def test_workflow_skips_completion_for_not_applicable_prs(self):
        # #81 AC1/AC3: the completion step is gated on the resolve verdict —
        # a not-applicable merged PR (non-agent head ref) ends as a no-op
        # success with durable run-page evidence, and never reaches
        # `ght complete`; applicable-but-untrusted identities still fail the
        # resolve step itself.
        text = WORKFLOW.read_text()
        self.assertIn("if: steps.facts.outputs.applicable != 'false'", text,
                      "completion must be skipped for not-applicable PRs")
        self.assertIn("if: steps.facts.outputs.applicable == 'false'", text)
        self.assertIn("$GITHUB_STEP_SUMMARY", text,
                      "the no-op outcome leaves diagnosable evidence")
        self.assertIn("not a canonical ght attempt branch", text)

    def test_resolve_pull_request_derives_issue_from_canonical_branch(self):
        # AC3: the auto path derives the Issue from the canonical claim
        # branch agent/<issue>/<id> of the merged PR.
        result = run_glue("resolve", env_extra={
            "GHA_EVENT_NAME": "pull_request",
            "GHA_PR_NUMBER": "65",
            "GHA_HEAD_REF": "agent/45/c5268c3c"})
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual([line for line in result.stdout.splitlines() if line],
                         ["applicable=true", "issue=45", "pr=65"])

    def test_resolve_fails_closed_on_untrusted_candidate_identity(self):
        # #81 AC3: a ref that ENTERS the agent/ attempt namespace but is not
        # exactly agent/<digits>/<id> is applicable-but-untrusted; a missing
        # head ref is contradictory metadata. Both fail closed with
        # diagnostics — never silently ignored, never guessed.
        for head_ref in ("agent/abc/c5268c3c", "agent/45", "agent/",
                         "agent/45x/y", "agent/45/c5268c3c/extra", ""):
            result = run_glue("resolve", env_extra={
                "GHA_EVENT_NAME": "pull_request",
                "GHA_PR_NUMBER": "65",
                "GHA_HEAD_REF": head_ref})
            self.assertNotEqual(result.returncode, 0,
                                f"head ref {head_ref!r} must fail closed")
            self.assertIn("fail closed", result.stderr)

    def test_resolve_not_applicable_head_refs_no_op_success(self):
        # #81 AC1: a merged PR whose head ref is outside the attempt-branch
        # namespace has no canonical ght Candidate identity — A-owned
        # docs/release/other work is judged not applicable and must end as a
        # no-op SUCCESS (applicable=false), never a red failure.
        for head_ref in ("some-feature-branch", "docs/adoption",
                         "release/v1.0.3", "main", "fix/agent/45/x"):
            result = run_glue("resolve", env_extra={
                "GHA_EVENT_NAME": "pull_request",
                "GHA_PR_NUMBER": "65",
                "GHA_HEAD_REF": head_ref})
            self.assertEqual(result.returncode, 0,
                             f"head ref {head_ref!r} must be a no-op success: "
                             + result.stderr)
            lines = [line for line in result.stdout.splitlines() if line]
            self.assertEqual(lines, ["applicable=false"])
            self.assertIn("not applicable", result.stderr)
            self.assertNotIn("issue=", result.stdout)

    def test_resolve_dispatch_requires_explicit_numeric_inputs(self):
        # AC1/AC3: the dispatch retry uses explicit inputs, validated.
        result = run_glue("resolve", env_extra={
            "GHA_EVENT_NAME": "workflow_dispatch",
            "GHA_DISPATCH_ISSUE": "45",
            "GHA_DISPATCH_PR": "65"})
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual([line for line in result.stdout.splitlines() if line],
                         ["applicable=true", "issue=45", "pr=65"])
        for partial in ({"GHA_DISPATCH_ISSUE": "45"},
                        {"GHA_DISPATCH_PR": "65"},
                        {"GHA_DISPATCH_ISSUE": "45", "GHA_DISPATCH_PR": "sixty-five"}):
            result = run_glue("resolve", env_extra={
                "GHA_EVENT_NAME": "workflow_dispatch", **partial})
            self.assertNotEqual(result.returncode, 0, partial)

    def test_resolve_rejects_unsupported_event(self):
        result = run_glue("resolve", env_extra={"GHA_EVENT_NAME": "push"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("unsupported event", result.stderr)

    def test_complete_invokes_canonical_primitive_with_exact_argv(self):
        # AC2/AC6: the glue assembles exactly `ght --json complete <issue>
        # --pr <pr>` — no duplicated completion logic — via the test seam.
        with tempfile.TemporaryDirectory() as tmp:
            stub = Path(tmp) / "ght-stub.py"
            marker = Path(tmp) / "invocation.json"
            write_stub(stub,
                       "import json, os, sys\n"
                       "open(os.environ['GHT_STUB_OUT'], 'w').write("
                       "json.dumps(sys.argv[1:]))\n"
                       "print(json.dumps({'status': 'delivered'}))\n")
            result = run_glue("complete", "45", "65", env_extra={
                "GHT_COMPLETE_GHT_BIN": str(stub),
                "GHT_STUB_OUT": str(marker)})
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(marker.read_text()),
                             ["--json", "complete", "45", "--pr", "65"])

    def test_complete_propagates_failure_with_diagnostics(self):
        # AC5: a primitive failure exits non-zero, unchanged, with
        # diagnostics — no remediation guessing in the glue.
        with tempfile.TemporaryDirectory() as tmp:
            stub = Path(tmp) / "ght-fail.py"
            write_stub(stub,
                       "import sys\n"
                       "print('{\"ok\": false, \"error\": \"durable predicate failed\"}', "
                       "file=sys.stderr)\n"
                       "raise SystemExit(4)\n")
            result = run_glue("complete", "45", "65", env_extra={
                "GHT_COMPLETE_GHT_BIN": str(stub)})
            self.assertEqual(result.returncode, 4,
                             "the primitive's fail-closed exit code must propagate")
            self.assertIn("durable predicate failed", result.stderr)


if __name__ == "__main__":
    unittest.main()
