"""Focused read-only A Review preflight regression matrix."""

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).parents[1]
CLI = SKILL_ROOT / "scripts" / "ght.py"
REAL_GIT = shutil.which("git")
sys.path.insert(0, str(SKILL_ROOT))
sys.path.insert(0, str(SKILL_ROOT / "tests"))

from test_cli_safety import GIT_WRAPPER, IMPL_CONTRACT, MOCK_GH, issue_body  # noqa: E402


REVIEW_MOCK_GH = MOCK_GH.replace(
    'PR_VIEW_FIELDS = {"number", "state", "url", "headRefName", "headRefOid", "mergeCommit"}',
    'PR_VIEW_FIELDS = {"number", "state", "url", "headRefName", "headRefOid", "mergeCommit", "body"}',
)

REVIEW_GH_WRAPPER = r'''#!/usr/bin/env python3
import json
import os
import subprocess
import sys

args = sys.argv[1:]
if args[:1] == ["api"] and len(args) > 1 and "/compare/" in args[1]:
    comparison = args[1].rsplit("/compare/", 1)[1]
    base, head = comparison.split("...", 1)
    result = subprocess.run(
        [os.environ["GHT_TEST_REAL_GIT"], "diff", "--name-status", base, head],
        cwd=os.getcwd(), capture_output=True, text=True)
    if result.returncode:
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)
    files = []
    for row in result.stdout.splitlines():
        status, filename = row.split("\t", 1)
        files.append({"filename": filename, "status": status,
                      "additions": 0, "deletions": 0})
    print(json.dumps({
        "base_commit": {"sha": base},
        "commits": [{"sha": head}],
        "html_url": f"https://github.com/example/repo/compare/{base}...{head}",
        "files": files,
    }))
    raise SystemExit(0)

base = os.environ["GHT_TEST_BASE_GH"]
os.execv(base, [base, *args])
'''


class ReviewPreflightTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ght-review-preflight-"))
        self.origin = self.tmp / "origin.git"
        self.state = self.tmp / "issues.json"
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        self.base_gh = self.bin / "gh-base"
        self._write_executable(self.base_gh, REVIEW_MOCK_GH)
        self._write_executable(self.bin / "gh", REVIEW_GH_WRAPPER)
        self._write_executable(self.bin / "git", GIT_WRAPPER)
        self._git(self.tmp, "init", "--bare", str(self.origin), "-b", "main")
        seed = self.tmp / "seed"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(seed))
        (seed / "README.md").write_text("seed\n")
        self._git(seed, "add", ".")
        self._git(seed, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "seed")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        self.repo = self.tmp / "worker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(self.repo))
        self._git(self.repo, "config", "user.email", "w@t")
        self._git(self.repo, "config", "user.name", "w")
        self.state.write_text(json.dumps({
            "10": {"number": 10, "title": "Task ten", "state": "OPEN",
                   "stateReason": None,
                   "url": "https://github.com/example/repo/issues/10",
                   "body": issue_body(IMPL_CONTRACT), "labels": ["ready"], "comments": []},
        }, indent=2))
        self._env = {
            "PATH": f"{self.bin}:{os.environ['PATH']}",
            "GHT_TEST_STATE": str(self.state),
            "GHT_TEST_BASE_GH": str(self.base_gh),
            "GHT_TEST_REAL_GIT": REAL_GIT,
            "GHT_EXECUTOR_ID": "worker-1",
            "GHT_LEASE_MINUTES": "45",
            "GHT_SPAWN_SUPERVISOR": "0",
            "GIT_AUTHOR_NAME": "w", "GIT_AUTHOR_EMAIL": "w@t",
            "GIT_COMMITTER_NAME": "w", "GIT_COMMITTER_EMAIL": "w@t",
        }
        self.snapshot = self.tmp / "evidence.md"
        self.snapshot.write_text("AC1: verified by the focused regression fixture.\n")

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _write_executable(self, path, content):
        path.write_text(content)
        path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    def _git(self, cwd, *args):
        return subprocess.run([REAL_GIT, *args], cwd=cwd, capture_output=True,
                              text=True, env={**os.environ})

    def _ght(self, *args, env_extra=None):
        env = {**self._env, **(env_extra or {})}
        return subprocess.run([sys.executable, str(CLI), "--json", *args],
                              cwd=str(self.repo), capture_output=True, text=True, env=env)

    def _ght_ok(self, *args, env_extra=None):
        result = self._ght(*args, env_extra=env_extra)
        self.assertEqual(result.returncode, 0,
                         f"unexpected failure: {result.stdout} {result.stderr}")
        return json.loads(result.stdout)

    def _read_state(self):
        return json.loads(self.state.read_text())

    def _write_state(self, data):
        self.state.write_text(json.dumps(data, indent=2))

    def _update_pr(self, number=60, **changes):
        data = self._read_state()
        data[str(number)].update(changes)
        self._write_state(data)

    def _add_change_request(self, sha, *, pr=60):
        data = self._read_state()
        data[str(pr)].setdefault("pr_comments", []).append({
            "id": 701, "user": {"login": "reviewer"},
            "html_url": f"https://github.com/example/repo/pull/{pr}#issuecomment-701",
            "created_at": "2026-10-26T08:00:00Z",
            "body": ("A REVIEW — REQUEST_CHANGES\n\nReviewed exact Candidate:\n"
                     f"`{sha}`\n"),
        })
        self._write_state(data)

    def _first_delivery(self, *, pr=60):
        claim = self._ght_ok("claim", "10")
        self._git(self.repo, "checkout", "-q", "-b", claim["branch"], "origin/main")
        path = self.repo / "skills" / "demo.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("demo v1\n")
        self._git(self.repo, "add", "skills/demo.txt")
        self._git(self.repo, "commit", "-qm", "add demo")
        sha = self._git(self.repo, "rev-parse", "HEAD").stdout.strip()
        self._ght_ok("preserve", "10")
        data = self._read_state()
        data[str(pr)] = {
            "number": pr, "is_pr": True, "state": "OPEN",
            "url": f"https://github.com/example/repo/pull/{pr}",
            "headRefName": claim["branch"], "headRefOid": sha,
            "mergeCommit": None, "body": "", "reviews": [], "pr_comments": [],
        }
        self._write_state(data)
        self._ght_ok("deliver", "10", "--pr", str(pr), "--snapshot", str(self.snapshot))
        return claim, sha

    def _preflight(self, *, env_extra=None, issue=10):
        payload = self._ght_ok("inspect", str(issue), "--review-preflight",
                               env_extra=env_extra)
        return payload["review_preflight"]

    def test_review_preflight_first_delivery(self):
        _claim, sha = self._first_delivery()

        result = self._preflight()

        self.assertEqual(result["status"], "REVIEW_ENTRY_AVAILABLE")
        self.assertTrue(result["review_entry_available"])
        self.assertEqual(result["identity"]["current_sha"], sha)
        self.assertEqual(result["current_review"]["outcome"], "NONE")
        self.assertIsNone(result["prior_review"]["sha"])
        self.assertEqual(result["change_range"]["kind"], "first_delivery")
        self.assertTrue(result["binding"]["comment_mirror_synced"])
        self.assertTrue(result["binding"]["snapshot_synced"])

    def test_review_preflight_same_sha_repair_reports_prior_review(self):
        _claim, sha = self._first_delivery()
        self._add_change_request(sha)
        self._ght_ok("deliver", "10", "--pr", "60", "--snapshot", str(self.snapshot))

        result = self._preflight()

        self.assertEqual(result["status"], "REVIEW_ENTRY_AVAILABLE")
        self.assertEqual(result["current_review"]["outcome"], "REQUEST_CHANGES")
        self.assertEqual(result["prior_review"]["sha"], sha)
        self.assertEqual(result["prior_review"]["outcome"], "REQUEST_CHANGES")
        self.assertEqual(result["change_range"]["kind"], "same_sha_repair")

    def test_review_preflight_changed_sha_reports_review_and_changed_paths(self):
        _claim, prior_sha = self._first_delivery()
        self._add_change_request(prior_sha)
        self._ght_ok("acquire", "10")
        path = self.repo / "skills" / "demo.txt"
        path.write_text("demo v2\n")
        self._git(self.repo, "add", "skills/demo.txt")
        self._git(self.repo, "commit", "-qm", "correct demo")
        current_sha = self._git(self.repo, "rev-parse", "HEAD").stdout.strip()
        self._ght_ok("preserve", "10")
        self._ght_ok("deliver", "10", "--pr", "60", "--snapshot", str(self.snapshot))

        result = self._preflight()

        self.assertEqual(result["status"], "REVIEW_ENTRY_AVAILABLE")
        self.assertEqual(result["prior_review"]["sha"], prior_sha)
        self.assertEqual(result["prior_review"]["outcome"], "REQUEST_CHANGES")
        self.assertEqual(result["identity"]["current_sha"], current_sha)
        self.assertEqual(result["change_range"]["kind"], "changed_sha")
        self.assertEqual(result["change_range"]["base_sha"], prior_sha)
        self.assertEqual(result["change_range"]["head_sha"], current_sha)
        self.assertEqual([item["filename"] for item in result["change_range"]["files"]],
                         ["skills/demo.txt"])
        self.assertTrue(result["prior_review"]["evidence"])

    def test_review_preflight_missing_snapshot_blocks_entry(self):
        self._first_delivery()
        self._update_pr(body="ordinary PR description")

        result = self._preflight()

        self.assertEqual(result["status"], "BLOCKED")
        self.assertFalse(result["review_entry_available"])
        self.assertIn("snapshot_missing", {item["code"] for item in result["blockers"]})

    def test_review_preflight_wrong_pr_head_blocks_entry(self):
        _claim, sha = self._first_delivery()
        self._update_pr(headRefName="main", headRefOid="0" * 40)

        result = self._preflight()

        self.assertEqual(result["status"], "BLOCKED")
        self.assertFalse(result["binding"]["pr_head_matches_candidate"])
        self.assertEqual(result["identity"]["current_sha"], sha)
        self.assertIn("pr_head_mismatch", {item["code"] for item in result["blockers"]})

    def test_review_preflight_unreadable_review_surface_blocks_entry(self):
        self._first_delivery()

        result = self._preflight(env_extra={"GHT_TEST_FAIL_PR_REVIEWS": "1"})

        self.assertEqual(result["status"], "BLOCKED")
        self.assertFalse(result["review_surfaces"]["readable"])
        self.assertIn("review_unreadable", {item["code"] for item in result["blockers"]})

    def test_review_preflight_contract_drift_blocks_entry(self):
        self._first_delivery()
        data = self._read_state()
        data["10"]["body"] = issue_body(
            IMPL_CONTRACT.replace("The CLI runs.", "The CLI validates."))
        self._write_state(data)

        result = self._preflight()

        self.assertEqual(result["status"], "BLOCKED")
        self.assertFalse(result["binding"]["contract_digest_matches_claim"])
        self.assertIn("contract_mismatch", {item["code"] for item in result["blockers"]})

    def test_review_preflight_missing_delivery_mirror_blocks_entry(self):
        self._first_delivery()
        data = self._read_state()
        data["10"]["comments"] = []
        self._write_state(data)

        result = self._preflight()

        self.assertEqual(result["status"], "BLOCKED")
        self.assertFalse(result["binding"]["comment_mirror_synced"])
        self.assertIn("delivery_mirror_mismatch",
                      {item["code"] for item in result["blockers"]})


if __name__ == "__main__":
    unittest.main()
