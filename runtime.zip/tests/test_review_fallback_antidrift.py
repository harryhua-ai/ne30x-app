"""#145 — A review fallback anti-drift conformance.

Locks the #121 failure class against the single canonical executable
review-recognition semantics in ``github_task.core`` (``has_exact_sha_change_request``
/ ``evaluate_exact_sha_acceptance``): a fallback review comment can be
durably written while head/delivery/exact-Candidate surface facts all
match, yet the executable predicate does not recognize the verdict —
wrong marker grammar (``A REVIEW — REQUEST CHANGES`` with a space where
the canonical marker has an underscore), a wrong or missing Candidate
SHA binding, or marker text that only looks similar inside the body.
In every such case the authoritative review transition is NOT
established. These tests reuse the executable grammar itself and never
define a second parser, marker table, registry, or lifecycle.
"""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1]))

from github_task.core import (ACCEPTANCE_HEADER, CHANGE_REQUEST_HEADER,
                              evaluate_exact_sha_acceptance,
                              has_exact_sha_change_request)

# The #121 exact Candidate SHA.
CANDIDATE_SHA = "445704cd33804d109b695e59263573f4a9c1a7df"
OTHER_SHA = "a" * 40

# The drift variant actually written during #121: em dash + space instead
# of the canonical em dash + underscore.
DRIFTED_REQUEST_CHANGES = "A REVIEW — REQUEST CHANGES"


def _fallback_comment(header: str, sha: str | None) -> dict[str, str]:
    body = f"{header}\n\n"
    if sha is not None:
        body += f"Reviewed exact Candidate:\n{sha}\n\n"
    return {"body": body + "blocking findings / acceptance conclusion"}


class ReviewFallbackAntiDriftTests(unittest.TestCase):
    def test_space_drifted_request_changes_marker_is_not_recognized(self):
        # #121 AC5 failure class: the drifted marker is durably written,
        # bound to the correct exact Candidate SHA (head/delivery/SHA all
        # match), yet the executable predicate must fail closed — no
        # resumable correction truth exists.
        self.assertNotEqual(DRIFTED_REQUEST_CHANGES, CHANGE_REQUEST_HEADER,
                            "the drift variant must stay a distinct literal")
        comments = [_fallback_comment(DRIFTED_REQUEST_CHANGES, CANDIDATE_SHA)]
        blocking, unreadable = has_exact_sha_change_request(
            reviews=[], comments=comments, candidate_sha=CANDIDATE_SHA)
        self.assertEqual((blocking, unreadable), (False, []),
                         "a space-drifted fallback marker must not establish "
                         "an authoritative REQUEST_CHANGES")

    def test_canonical_request_changes_marker_is_recognized(self):
        comments = [_fallback_comment(CHANGE_REQUEST_HEADER, CANDIDATE_SHA)]
        blocking, unreadable = has_exact_sha_change_request(
            reviews=[], comments=comments, candidate_sha=CANDIDATE_SHA)
        self.assertEqual((blocking, unreadable), (True, []))

    def test_wrong_or_missing_candidate_sha_binding_is_not_recognized(self):
        for sha in (OTHER_SHA, None):
            with self.subTest(sha=sha):
                comments = [_fallback_comment(CHANGE_REQUEST_HEADER, sha)]
                blocking, unreadable = has_exact_sha_change_request(
                    reviews=[], comments=comments, candidate_sha=CANDIDATE_SHA)
                self.assertEqual((blocking, unreadable), (False, []),
                                 "wrong/missing exact-SHA binding must fail closed")

    def test_surface_similarity_is_not_recognition(self):
        # The marker text appearing anywhere but as the comment's review
        # header is not the verdict, even with the exact SHA quoted below
        # — textual similarity is not mechanical recognition.
        comments = [{"body": (f"note: do not write {DRIFTED_REQUEST_CHANGES!r} "
                              f"here; reviewed exact Candidate:\n{CANDIDATE_SHA}")},
                    {"body": (f"quoted: ```\n{CHANGE_REQUEST_HEADER}\n```\n"
                              f"Reviewed exact Candidate: {CANDIDATE_SHA}")}]
        blocking, unreadable = has_exact_sha_change_request(
            reviews=[], comments=comments, candidate_sha=CANDIDATE_SHA)
        self.assertEqual((blocking, unreadable), (False, []))

    def test_acceptance_side_requires_exact_recognition_before_merge(self):
        # AC4: an ACCEPTED fallback write only authorizes an expected-head
        # merge when the canonical executable semantics recognizes it bound
        # to the exact Candidate SHA; drifted grammar, wrong/missing SHA,
        # or an APPROVED review on another SHA never do.
        def acceptance(comment_bodies, reviews=None):
            return evaluate_exact_sha_acceptance(
                reviews=reviews or [],
                comments=[{"body": body} for body in comment_bodies],
                candidate_sha=CANDIDATE_SHA)

        canonical = (f"{ACCEPTANCE_HEADER}\n\nReviewed exact Candidate:\n"
                     f"{CANDIDATE_SHA}\n\nacceptance conclusion")
        rejected_bodies = [
            # hyphen drift
            canonical.replace("A REVIEW — ACCEPTED", "A REVIEW - ACCEPTED"),
            # wrong SHA binding
            _fallback_comment(ACCEPTANCE_HEADER, OTHER_SHA)["body"],
            # missing SHA binding
            _fallback_comment(ACCEPTANCE_HEADER, None)["body"],
        ]
        for body in rejected_bodies:
            with self.subTest(body=body.splitlines()[0]):
                result = acceptance([body])
                self.assertFalse(result["accepted"],
                                 "a non-canonical acceptance fallback must not "
                                 "authorize an expected-head merge")
                self.assertIsNone(result["source"])
        result = acceptance([canonical])
        self.assertTrue(result["accepted"])
        self.assertEqual(result["source"], "structured-comment")

    def test_native_review_surfaces_unchanged(self):
        # The native GitHub review surface keeps its existing semantics:
        # APPROVED bound to the exact SHA is accepted; APPROVED on another
        # SHA is reported and refused; native CHANGES_REQUESTED bound to
        # the exact SHA blocks.
        approved_exact = {"state": "APPROVED", "commit_id": CANDIDATE_SHA}
        result = evaluate_exact_sha_acceptance(reviews=[approved_exact],
                                               comments=[],
                                               candidate_sha=CANDIDATE_SHA)
        self.assertEqual((result["accepted"], result["source"]),
                         (True, "native-review"))
        approved_other = {"state": "APPROVED", "commit_id": OTHER_SHA}
        result = evaluate_exact_sha_acceptance(reviews=[approved_other],
                                               comments=[],
                                               candidate_sha=CANDIDATE_SHA)
        self.assertFalse(result["accepted"])
        self.assertEqual(result["approved_other_shas"], [OTHER_SHA])
        blocking, _ = has_exact_sha_change_request(
            reviews=[{"state": "CHANGES_REQUESTED", "commit_id": CANDIDATE_SHA}],
            comments=[], candidate_sha=CANDIDATE_SHA)
        self.assertTrue(blocking)


if __name__ == "__main__":
    unittest.main()
