"""Portability/conformance tests for the github-task Agent Skill entry point.

These checks bind SKILL.md to the contract of #56: a portable, host-neutral
Agent Skill whose protocol facts stay delegated to the real ``ght`` CLI
surface — the Skill never becomes a second, prose-implemented protocol.
"""

import re
import subprocess
import sys
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
CLI = SKILL_ROOT / "scripts" / "ght.py"
SKILL_MD = SKILL_ROOT / "SKILL.md"

# Host-specific install locations and machine-absolute paths must never
# appear in the portable Skill document.
FORBIDDEN_PATH_PATTERNS = (
    r"/Users/", r"/home/", r"[A-Za-z]:\\", r"(?m)^\s*/",
    r"~/\.", r"\.codex/", r"\.claude/", r"\.zcode/", r"\.agents/",
    r"\.config/ght\b",
)


def _frontmatter(text: str) -> str:
    match = re.match(r"\A---\n(.*?)\n---\n", text, flags=re.DOTALL)
    if not match:
        raise AssertionError("SKILL.md must start with a --- delimited frontmatter block")
    return match.group(1)


def _cli_subcommands() -> set[str]:
    """The real CLI surface, taken from ``ght --help`` itself."""
    result = subprocess.run([sys.executable, str(CLI), "--help"],
                            capture_output=True, text=True)
    if result.returncode:
        raise AssertionError(f"ght --help failed: {result.stderr}")
    choices = re.search(r"\{([^}]+)\}", result.stdout)
    if not choices:
        raise AssertionError("cannot parse ght --help subcommand choices")
    return {token.strip() for token in choices.group(1).split(",")}


class SkillConformanceTests(unittest.TestCase):
    def test_skill_md_exists_with_valid_portable_frontmatter(self):
        # AC1/AC5: the entry point exists and carries a portable Agent
        # Skill frontmatter — machine-parseable, `name: github-task`, a
        # non-empty description, and nothing host-specific.
        self.assertTrue(SKILL_MD.exists(), "skills/github-task/SKILL.md is missing")
        text = SKILL_MD.read_text()
        from github_task.core import ContractError, _parse_yaml_subset

        try:
            frontmatter = _parse_yaml_subset(_frontmatter(text))
        except ContractError as exc:
            self.fail(f"SKILL.md frontmatter does not parse: {exc}")
        self.assertEqual(frontmatter.get("name"), "github-task")
        description = frontmatter.get("description")
        self.assertIsInstance(description, str)
        self.assertTrue(description.strip(), "description must be non-empty")
        for pattern in FORBIDDEN_PATH_PATTERNS:
            self.assertIsNone(re.search(pattern, text),
                              f"SKILL.md must stay portable: matched {pattern!r}")

    def test_skill_references_only_real_ght_commands(self):
        # AC5: every `ght <command>` the Skill tells an agent to run must
        # exist on the current CLI surface, checked against the real
        # `ght --help` output.
        text = SKILL_MD.read_text()
        surface = _cli_subcommands()
        referenced = set(re.findall(r"`ght ([a-z][a-z-]*)", text))
        referenced = {name for name in referenced if not name.startswith("--")}
        self.assertTrue(referenced, "SKILL.md should reference concrete ght commands")
        unknown = sorted(referenced - surface)
        self.assertEqual(unknown, [],
                         f"SKILL.md references commands missing from the CLI surface")

    def test_stale_execution_capacity_recovery_is_same_attempt_and_fenced(self):
        skill = SKILL_MD.read_text()
        self.assertIn("recovery: execution_lease", skill)
        self.assertIn("blocked_recoveries", skill)
        self.assertIn("awaiting_review", skill)
        self.assertIn("kind:\n     resume", skill)
        self.assertIn("Lease expiry alone never authorizes `ght takeover`", skill)

    def test_executing_elsewhere_is_a_terminal_consumer_verdict(self):
        # #127: after `executing_elsewhere` the consumer contract is
        # terminal for that Issue this wake — no lease heartbeat/expiry/
        # wall-clock re-interpretation, no speculative acquire/takeover,
        # no duplicate dispatch, no lease-internals surfacing to A/User;
        # other runnable work stays admissible. Recovery is never judged
        # by the consumer from lease presence/absence or timing: the
        # future canonical discover verdict is the only recovery basis
        # (R2: the lease-state phrasing "resume once the lease is gone"
        # was A-rejected as consumer-side lease reasoning and must stay
        # out).
        skill = SKILL_MD.read_text()
        self.assertIn("executing_elsewhere", skill)
        self.assertIn("terminal admission verdict", skill)
        self.assertIn("heartbeat/expiry/wall-clock", skill)
        self.assertIn("speculative-acquire", skill)
        self.assertIn("duplicate-dispatch", skill)
        self.assertIn("lease internals", skill)
        self.assertIn("Continue admitting other genuinely runnable work", skill)
        self.assertIn("never lease presence or absence", skill)
        self.assertIn("is the only recovery basis", skill)
        self.assertNotIn("once the lease is gone", skill,
                         "consumer-side lease-state recovery reasoning "
                         "must not be reintroduced")

    def test_investigation_only_attempt_has_a_complete_canonical_workflow(self):
        # #164 AC2 (R2 blocker): the canonical Skill distinguishes the
        # investigation-only workflow inside the SAME operating flow — a
        # fresh zero-prompt B that claimed with `--mode investigate` finds
        # the complete supported terminal path (durable findings evidence
        # through `ght release --status investigated`), knows ght refuses
        # the implementation Candidate surfaces for an investigation-only
        # attempt, and the implementation-only gates stay intact as the
        # separate implementation branch (never relaxed, never skipped).
        skill = SKILL_MD.read_text()
        investigation_at = skill.find("Investigation-only attempt")
        self.assertGreaterEqual(
            investigation_at, 0,
            "the operating flow must carry the investigation-only branch")
        for literal in (
                "`--mode investigate`",
                "`ght release <issue> --status investigated --note",
                "ght refuses `ght preserve`",
                "no Candidate PR, no review loop, and no merge",
                "terminal `investigated` lineage is final"):
            self.assertIn(literal, skill,
                          f"investigation-only workflow anchor missing: "
                          f"{literal!r}")
        # The branch is reachable in the operating flow BEFORE the
        # implementation Candidate instructions: a consumer following the
        # Skill top-down meets the investigation terminal path first, never
        # an unconditional preserve → deliver → complete flow.
        self.assertLess(
            investigation_at, skill.index("ght scope-check <issue>"),
            "the investigation branch must precede the implementation "
            "Candidate path in the operating flow")
        # The implementation-only gates stay pinned on their own branch:
        # the investigation branch must not relax or remove them.
        for literal in ("ght scope-check <issue>", "ght preserve <issue>",
                        "ght deliver <issue> --pr <N>", "ght complete <issue>"):
            self.assertIn(literal, skill,
                          f"implementation-only gate anchor missing: {literal!r}")

    def test_discover_output_is_typed_fail_closed_consumption_contract(self):
        # #121 AC1/AC2: the canonical B guidance treats the structured
        # `ght discover` result as a typed contract — the complete
        # structured output is the admission input and the complete
        # `work[]` surface is consumed (direct-ready entries ride the
        # array tail and must survive), while schema mismatch, a
        # missing/unrecognized required work surface, or malformed/
        # truncated output fails closed with an explicit diagnostic and is
        # never misreported as an empty runnable frontier; only the
        # canonical no-work verdict is authoritative no-work.
        skill = SKILL_MD.read_text()
        for literal in (
                "typed contract",
                "complete `work[]` surface",
                "never substitutes an alternate key or an empty default",
                "fail closed",
                "never be reported as an empty runnable frontier",
                "authoritative no-work"):
            self.assertIn(literal, skill,
                          f"discover consumption-contract anchor missing: "
                          f"{literal!r}")
        # Falsification guards: the observed drift semantics must never
        # return to the canonical guidance — the alternate drift keys
        # (`candidates`, `items`), empty-default substitution, or treating
        # truncated text as parseable.
        for drift in ("`candidates`", "`items`",
                      "defaults to an empty",
                      "fall back to an empty",
                      "truncation is acceptable",
                      "truncated output may be"):
            self.assertNotIn(drift, skill,
                             f"discover consumer drift must stay out: "
                             f"{drift!r}")

    def test_docs_express_v1_concurrency_authority(self):
        # #89 AC9: the canonical surfaces express the V1 truth — a stable B
        # coordination identity may hold several independent authorized
        # ACTIVE executions, and A no longer carries a generic concurrency
        # authority. Docs-only RED/GREEN: the retired wording must stay out.
        skill = SKILL_MD.read_text()
        readme = (SKILL_ROOT / "README.md").read_text()
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        model = (SKILL_ROOT.parent.parent / "docs" / "operating-model.md").read_text()
        for retired in ("One ACTIVE Issue per `executor_id`",
                        "one-ACTIVE invariant",
                        "A alone decides whether to scale out",
                        "A authorizes useful concurrency",
                        # #89 review R3: A no longer holds ANY generic
                        # concurrency/scheduling decision — the remaining
                        # wordings retired from operating-model.md and
                        # A-project-rules.md this round must stay out too.
                        "Parallel B execution is an A planning",
                        "A's parallel decision",
                        "A owns semantic scheduling",
                        "Avoid unnecessary parallel B execution",
                        # #89 review R4: worker/topology scale-out is never
                        # conditioned on an A concurrency grant, and the
                        # "controlled-parallel" framing is retired with it.
                        "More persistent workers are added only when "
                        "A has deliberately authorized",
                        "Controlled parallel B execution",
                        "bounded by the A-authored envelope",
                        # #89 review R5: the global one-live-lease-per-
                        # direct-executor invariant is retired with the
                        # cross-Issue runtime gate — leases are per-Issue.
                        "one-live-lease-per-direct-executor",
                        # #89 review R6 (AC1/AC9): max_concurrency is a
                        # RETIRED field — current Plan semantics /
                        # publication authority must never list it, and
                        # A holds no scheduling authority dial.
                        "concurrency envelope (`max_concurrency`)",
                        "or `max_concurrency`",
                        "scheduling authority stays with A alone",
                        "envelope changes",
                        # #89 review R7: the no-Plan unique-selector /
                        # multiple-ready-stop model is retired — complete
                        # direct-ready worksets are B/host admission HOW.
                        "unique mechanically eligible",
                        "unique direct-ready",
                        "Multiple ready Issues without",
                        "without A-authored scheduling authority",
                        "single unconsumed direct",
                        "multiple ready labels as an implicit scheduler"):
            for name, text in (("README", readme), ("A-project-rules", rules),
                               ("operating-model", model), ("SKILL", skill)):
                self.assertNotIn(retired, text,
                                 f"{name} must not carry retired wording: {retired!r}")
        self.assertIn("0..N", skill, "SKILL.md states the multi-active model")

    def test_primary_b_orchestration_canonical_surface(self):
        # #97 AC1-AC8: the canonical B guidance fixes the execution shape —
        # one stable primary B coordination identity + 0..N ephemeral
        # per-Issue executors, continue-by-default coordination with
        # canonical stops only, work-conserving just-in-time admission,
        # thin coordinates-only launch capsules, capacity release at
        # deliver, accepted main as the only integration line, durable-
        # truth recovery, and repo-local ignored `.worktree/` with bounded
        # lifetime and local-first artifact reuse. No durable concurrency
        # metadata, scheduler, registry, or control plane is introduced.
        skill = SKILL_MD.read_text()
        readme = (SKILL_ROOT / "README.md").read_text()
        model = (SKILL_ROOT.parent.parent / "docs" / "operating-model.md").read_text()
        for literal in (
                "one stable primary B coordination identity",
                "0..N ephemeral per-Issue executors",
                "Continue-by-default, stop-by-exception",
                "Work-conserving just-in-time admission",
                "Thin launch capsules",
                "only primary B admits Issues",
                "releases the executor capacity",
                "Accepted main is the only durable integration line",
                "Recovery is durable reconstruction",
                ".worktree/"):
            self.assertIn(literal, skill,
                          f"primary-B orchestration literal missing: {literal!r}")
        # The canonical stop conditions are enumerated, and events are wake
        # reasons — never implicit stop points.
        self.assertIn("never implicit stop points", skill)
        self.assertIn("canonical stops", skill)
        # Admission ordering: claim/acquire before any isolated environment
        # or dispatch; never speculative.
        self.assertIn("before the isolated execution environment", skill)
        self.assertIn("never speculative", skill)
        # No durable concurrency metadata on the B behavior surface —
        # #101 R3: this live protocol rule is pinned ONLY on its owner
        # (SKILL.md); the retained model no longer asserts it.
        self.assertIn("worker-assignment metadata", skill,
                      "the concurrency-metadata prohibition belongs to the B owner")
        self.assertNotIn("does not add lane pools", model,
                         "the live concurrency rule must live only on the B owner")
        for banned in ("wave_id", "parallel_group"):
            self.assertNotIn(banned, skill)
            self.assertNotIn(banned, readme)
        # #101 R3/R4: retained docs are reference / non-normative navigation
        # with canonical-owner pointers — nothing else. Each carries its
        # non-normative banner, and each is verified against the REAL owner
        # anchors it must point to (not a generic "canonical" substring,
        # which would pass even with the pointers removed).
        retained = {
            "docs/adoption.md": (
                "Onboarding/runbook",
                ("prompts/A-project-rules.md", "skills/github-task/SKILL.md")),
            "docs/operating-model.md": (
                "薄概念导航",
                ("README.md#canonical-source-map", "skills/github-task/SKILL.md")),
            "docs/roles-and-authority.md": (
                "Onboarding/reference",
                ("prompts/A-project-rules.md", "skills/github-task/SKILL.md")),
        }
        for rel, (banner, anchors) in retained.items():
            text = (SKILL_ROOT.parent.parent / rel).read_text()
            self.assertIn(banner, text,
                          f"{rel} must open as non-normative navigation ({banner!r})")
            for anchor in anchors:
                self.assertIn(anchor, text,
                              f"{rel} must point to its real owner surface: {anchor!r}")
        # `.worktree/` is repo-local and ignored by the primary tree.
        gitignore = (SKILL_ROOT.parent.parent / ".gitignore").read_text()
        self.assertIn(".worktree/", gitignore,
                      "executor worktrees must be ignored by the primary tree")
        self.assertIn(".ght/", gitignore,
                      "ght local cache state is disposable host state")
        self.assertIn(".worktree/", readme,
                      "README documents the executor worktree location")
        # Mechanical ignore proof, not just the file content.
        import subprocess
        checked = subprocess.run(
            ["git", "-C", str(SKILL_ROOT.parent.parent), "check-ignore",
             ".worktree/executor-a", ".ght/executors/x"],
            capture_output=True, text=True)
        self.assertEqual(checked.returncode, 0, checked.stdout + checked.stderr)
        self.assertEqual(sorted(checked.stdout.split()),
                         [".ght/executors/x", ".worktree/executor-a"])
        # Bounded lifetime without a GC daemon; local-first artifacts.
        self.assertIn("bounded lifetime", skill)
        self.assertIn("never a polling GC daemon", skill)
        self.assertIn("local-first", skill)
        # Ephemeral integration executors are the only integration vehicle.
        self.assertIn(".worktree/integration-*", skill)
        self.assertIn("ephemeral integration executor", skill)
        # R2 (review 5787469914): negative guard for the RETIRED
        # persistent-worker / persistent-worktree production topology — the
        # legacy production sentences must not silently return. (The #31
        # migration paragraph stays: it is explicitly scoped historical.)
        for retired in ("persistent worker worktree",
                        "persistent B coordination identity(ies)",
                        "persistent independent worktree",
                        "one persistent Git worktree",
                        "The worktree belongs to the worker"):
            self.assertNotIn(retired, model,
                             f"operating-model must not carry retired topology: {retired!r}")
        # #101 R2 (review on 25c7722): the positive current-B-topology
        # conformance lives on its OWNER surface (SKILL.md); retained docs
        # are navigation/reference only and must not carry normative
        # topology assertions — anti-drift guard keeps it that way.
        for literal in ("one stable primary B coordination identity",
                        "0..N ephemeral per-Issue executors",
                        ".worktree/"):
            self.assertIn(literal, skill,
                          f"owner-surface topology literal missing: {literal!r}")
            self.assertNotIn(literal, model,
                             f"retained doc must not assert topology: {literal!r}")
        self.assertIn("skills/github-task/SKILL.md", model,
                      "the model must point to the canonical B surface")

    def test_canonical_source_map_and_retired_surfaces(self):
        # #101 AC1/AC2/AC4/AC8/AC9: the repo user entry carries the
        # canonical source map; duplicated handwritten protocol specs and
        # the template scaffold are retired and cannot return; retained
        # onboarding surfaces navigate, they do not claim normative
        # authority; derived references bind to the real executable source.
        root = SKILL_ROOT.parent.parent
        readme = (root / "README.md").read_text()
        # 1) The canonical source map exists at the user entry and assigns
        #    each fact class exactly one owner surface.
        for owner in ("prompts/A-project-rules.md",
                      "skills/github-task/SKILL.md",
                      "docs/prd.md",
                      "docs/release-policy.md",
                      "docs/decisions/",
                      "docs/plans/current-plan.yaml",
                      "docs/operating-model.md",
                      "docs/adoption.md"):
            self.assertIn(owner, readme,
                          f"canonical source map must name {owner!r}")
        self.assertIn("current-plan.yaml", readme)
        # 2) Retired normative documents / template scaffold stay retired.
        #    (roles-and-authority.md is THIN-MERGE, not retired: it retains
        #    the Architect meta-governance that has no other owner.)
        import os
        for retired in ("docs/task-contract.md", "docs/review-contract.md",
                        "docs/issue-sizing.md",
                        "template/AGENTS.md",
                        "template/.github/ISSUE_TEMPLATE/task.yml"):
            self.assertFalse((root / retired).exists(),
                             f"{retired} was retired by #101 and must not return")
        self.assertFalse((root / "template" / "docs").exists(),
                         "template/docs scaffold was retired")
        # 3) Retired production semantics do not reappear on the user
        #    entry surface.
        for retired in ("固定 B worker", "persistent worktree",
                        "并发 envelope", "concurrency envelope",
                        "ght orchestrate", "max_concurrency",
                        "single-ready", "one unconsumed direct ready"):
            self.assertNotIn(retired, readme,
                             f"README must not carry retired semantics: {retired!r}")
        # 4) The retained A prompt received the migrated sizing guidance;
        #    ADRs carry an explicit status.
        rules = (root / "prompts" / "A-project-rules.md").read_text()
        self.assertIn("Issue sizing", rules,
                      "issue-sizing guidance migrated to its A owner")
        adr = (root / "docs" / "decisions" / "0001-protected-main.md").read_text().lower()
        self.assertIn("status", adr, "ADRs must state their status")
        # 5) The entry README only navigates the executable surface — every
        #    `ght <command>` it names must exist on the real CLI.
        surface = _cli_subcommands()
        referenced = {name for name in
                      re.findall(r"`ght ([a-z][a-z-]*)", readme)
                      if not name.startswith("--")}
        unknown = referenced - surface
        self.assertEqual(unknown, set(),
                         f"README references commands missing from the CLI: {unknown}")
        # #108 AC7: the release-publication surface is documented as
        # decision-execution only — A owns version/target/membership/time.
        # The command reference surface is the skill README.
        skill_readme = (SKILL_ROOT / "README.md").read_text()
        self.assertIn("release-publish", skill_readme,
                      "the canonical publication entrypoint must be documented")
        self.assertIn("never chooses version/target/membership/time", skill_readme,
                      "the authority boundary must be stated at the entrypoint")
        self.assertIn("User owns whether/when/which version", skill_readme,
                      "the corrected authority model must be stated (User/A/B split)")
        self.assertIn("A owns post-authorization publication and read-back",
                      skill_readme)
        # #165 AC6: adoption guidance is target-project-context-first. The
        # entry README tells A to adopt THIS repository under Harry Dev
        # governance in the session already bound to it (no <owner/repo>
        # handoff, no canonical-source line inside the adoption prompt);
        # harryhua-ai/harry-dev is named only as the distribution/
        # provenance source — never as the repository a project is adopted
        # "into".
        self.assertIn("Initialize and adopt THIS repository under Harry Dev "
                      "governance", readme,
                      "the adoption prompt must be target-project-first")
        self.assertNotIn("Adopt the target repository <owner/repo> into Harry Dev",
                         readme, "the inverted adoption framing stays retired")
        self.assertNotIn("Canonical source: harryhua-ai/harry-dev", readme,
                         "the adoption prompt carries no canonical-source line")
        self.assertIn("provenance source", readme,
                      "harry-dev is framed as distribution/provenance source")
        self.assertIn("ght bootstrap", readme,
                      "the downstream first-launch bootstrap is navigable")

    def test_skill_delegates_engineering_how_to_superpowers(self):
        # #62 AC10: github-task stays the Harry Dev-specific protocol /
        # authority / durable-handoff layer; generic engineering HOW is
        # delegated to the Superpowers skills instead of being maintained
        # as a parallel methodology inside this Skill.
        text = SKILL_MD.read_text()
        readme = (SKILL_ROOT / "README.md").read_text()
        self.assertIn("Superpowers", text,
                      "the Skill must name the Superpowers delegation")
        self.assertIn("engineering HOW", text)
        self.assertIn("Superpowers", readme,
                      "README documents the same handoff boundary")
        # The duplicated generic execution-discipline bullets are removed
        # (significantly shrunk), not parallel-maintained.
        for retired in ("Failure-Mode Matrix before code",
                        "Focused-first validation",
                        "Unrelated/flaky stop rule"):
            self.assertNotIn(retired, text,
                             f"generic methodology bullet must go: {retired!r}")
        # The Harry Dev-specific protocol surface stays intact.
        low = text.lower()
        for required in ("scope-check", "preserve", "deliver", "complete",
                         "fail-closed"):
            self.assertIn(required, low)

    def test_risk_proportional_governance_canonical_surface(self):
        # #62 AC1-AC9: the canonical A/docs surfaces carry the
        # risk-proportional governance grammar with stable anchors.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        model = (SKILL_ROOT.parent.parent / "docs" / "operating-model.md").read_text()
        # AC1: depth derives from the change itself; the User never picks
        # a risk tier.
        self.assertIn("风险档位", rules)
        # AC3: Minimum Sufficient Verification as a named principle
        #        (#101: its owner surface is the B Skill; the model is thin
        #        navigation and no longer duplicates it).
        skill_text = SKILL_MD.read_text()
        self.assertIn("Minimum Sufficient Verification", skill_text)
        self.assertIn("Minimum Sufficient Verification", rules)
        # AC4: governance-overhead observability with a dogfooding method.
        self.assertIn("governance overhead", rules.lower())
        self.assertIn("dogfooding", rules.lower())
        # AC5: downstream verification boundary for pinned distributions
        #        (#101: owned by the B Skill).
        self.assertIn("pinned/released", skill_text)
        # AC6: three worked risk classes proving depth scales while the
        # ordinary path stays light.
        for anchor in ("ordinary narrow/local",
                       "cross-module / migration",
                       "high-risk concurrency/security/ownership/recovery"):
            self.assertIn(anchor, rules, f"missing risk class example: {anchor!r}")
        # AC8: self-review precedes EVERY durable review outcome.
        self.assertIn("自审", rules)
        # AC9: canonical review marker as strict protocol grammar + post-write
        # reconciliation, with conformance protection against drift.
        for literal in ("第一条非空行必须精确为",
                        "不得给 marker 增加",
                        "后必须重新读取"):
            self.assertIn(literal, rules)
        for literal in ("A REVIEW — ACCEPTED", "A REVIEW — REQUEST_CHANGES",
                        "Reviewed exact Candidate:"):
            self.assertIn(literal, rules)
        for drift in ("A REVIEW — ACCEPTED (delta-only)",
                      "A REVIEW — REQUEST_CHANGES（高风险）"):
            self.assertNotIn(drift, rules,
                             "marker variants must stay out of canonical text")

    def test_review_algorithm_and_trigger_routing_invariants(self):
        # #62 R2: the durable review-algorithm invariants compile as
        # compact A-side rules with stable literals; the Superpowers
        # delegation states explicit condition→Skill trigger routing
        # (including dispatching-parallel-agents) instead of the retired
        # vague methodology sentence; the merge-triggered closure rule is
        # present on both the A and B canonical surfaces.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        readme = (SKILL_ROOT / "README.md").read_text()
        text = SKILL_MD.read_text()
        for literal in ("No delivery, no review",
                        "Head moved, verdict dies",
                        "False ACCEPT",
                        "False REJECT",
                        "semantic-family scan",
                        "Review-entry gate",
                        "Review-exit rule"):
            self.assertIn(literal, rules,
                          f"review algorithm invariant missing: {literal!r}")
        # Merge-triggered closure: A-side handoff precondition + B-side
        # complete → refresh → re-discover admission rule.
        self.assertIn("before handoff", rules)
        self.assertIn("re-discover", text)
        self.assertIn("dispatching-parallel-agents", text)
        self.assertIn("not a host-wide mutex", text)
        self.assertIn("dispatching-parallel-agents", readme)
        # AC10 R2: explicit condition→Skill trigger routing; the vague
        # duplicated-methodology sentence is retired.
        for trigger in ("systematic-debugging", "test-driven-development",
                        "verification-before-completion"):
            self.assertIn(trigger, text, f"Superpowers trigger missing: {trigger!r}")
        self.assertNotIn("Use your normal engineering methodology", text,
                         "the vague duplicated-methodology sentence must go")
        # R3 (review 5278858622): the trigger routing pins condition→Skill
        # SEMANTICS, not just names — performance problems route to
        # systematic-debugging, and dispatching-parallel-agents fires on the
        # general condition (2+ independent runnable work items + host
        # capacity); a gate-opening merge is one instance, never the trigger.
        self.assertIn("performance problem", text,
                      "performance problems must route to systematic-debugging")
        self.assertIn("2+ independent runnable work items", text,
                      "the dispatch trigger is the general condition")
        self.assertNotIn("a merge opened gates and 2+", text,
                         "the merge-gated dispatch trigger stays retired")
        # R3: retirement/migration proof is bidirectional and distinct —
        # read/compatibility (legacy/historical data stays safely
        # readable/auditable) vs authoring/write path (new authoring cannot
        # recreate the retired semantic); wording-absence is explicitly not
        # proof. Pins A's canonical hardening against drift, and the compact
        # invariant must not redefine the read path as wording-absence.
        for literal in ("legacy/historical data remains safely readable/auditable",
                        "new authoring/write/publish paths cannot create the retired semantic",
                        "not proof of compatibility"):
            self.assertIn(literal, rules,
                          f"canonical retirement/migration semantics missing: {literal!r}")
        self.assertNotIn(
            "read path (retired wording/mechanism absent",
            rules,
            "the compact invariant must not equate wording-absence with "
            "read/compatibility proof")
        # R3: the A-owned authoritative verdict-surface hardening survives
        # reconciliation on the canonical A surface.
        for literal in ("native `APPROVED` review bound to the exact Candidate SHA",
                        "native `CHANGES_REQUESTED` review bound to the exact Candidate SHA",
                        "native `COMMENTED` review is advisory/non-authoritative"):
            self.assertIn(literal, rules,
                          f"authoritative verdict surface rule missing: {literal!r}")

    def test_multi_candidate_review_activation_throughput_only(self):
        # #119 AC1-AC4: the canonical A review surface hardens
        # multi-Candidate review activations — an activation enumerates ALL
        # new formal-delivered, independently reviewable Candidates instead
        # of stopping at the first one; every Candidate still binds its own
        # Contract/lineage/snapshot/exact head and completes its own
        # independent exact-SHA verdict; one Candidate's blocker or verdict
        # is never shared or inherited across Candidates; after an
        # in-activation merge A re-reads the relevant durable truth before
        # continuing the remaining Candidates; batching changes throughput
        # only, not review depth, and the per-Candidate review invariants
        # (first-substantive/correction review, exact-SHA, durable
        # write/read-back, expected-head merge) stay intact.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        # AC1: full enumeration instead of first-Candidate stop, with the
        # per-Candidate binding surface unchanged.
        for literal in (
                "Multi-Candidate review activation",
                "而不是发现第一个 Candidate 后默认停止",
                "自己的 Contract、claim/attempt/branch/PR lineage、"
                "Current Candidate Snapshot 与 exact PR head"):
            self.assertIn(literal, rules,
                          f"multi-Candidate activation rule missing: {literal!r}")
        # AC2: per-Candidate independent exact-SHA verdicts; a blocker and
        # a verdict never cross Candidate boundaries.
        for literal in (
                "不得阻塞无关 Candidate 继续 review",
                "不得跨 Candidate 共享或继承"):
            self.assertIn(literal, rules,
                          f"independent-verdict rule missing: {literal!r}")
        # AC3: post-merge durable reread — pre-merge reads are not
        # post-merge current facts for the remaining Candidates.
        for literal in (
                "重新读取相关 durable truth",
                "不得当作 merge 后的当前事实"):
            self.assertIn(literal, rules,
                          f"post-merge reread rule missing: {literal!r}")
        # AC4: anti-drift — batching is throughput-only, no batch verdict /
        # batch acceptance / moved-head acceptance inheritance, and the
        # existing per-Candidate invariants are named as intact.
        for literal in (
                "throughput only, not review depth",
                "没有 batch verdict、batch acceptance",
                "moved-head acceptance inheritance",
                "exact-SHA review, durable write/read-back, expected-head merge"):
            self.assertIn(literal, rules,
                          f"anti-drift rule missing: {literal!r}")

    def test_review_fallback_post_write_verification_anti_drift(self):
        # #145 AC1-AC4: a durably written fallback review comment is not
        # by itself an established review transition. The canonical A
        # guidance must require a post-write read-back that proves the
        # verdict is recognized by the current canonical executable review
        # predicate and bound to the exact Candidate SHA — comment
        # existence, an unmoved PR head, or visual text similarity are
        # explicitly insufficient; on verification failure A fails closed
        # with the real protocol-reconciliation blocker (no ready top-up,
        # no new attempt, no speculative acquire, no marker guessing), and
        # the same mechanical verification gates an ACCEPTED fallback
        # before any expected-head merge.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        for literal in (
                # AC1: write success != transition success; recognition +
                # exact-SHA binding are the verification, not surface checks.
                "fallback comment 写成功不等于 review transition 成立",
                "canonical executable review predicate 识别",
                "comment 存在、PR head 未移动或文本肉眼相似不足以完成 reconciliation",
                # AC3: fail closed on unrecognized REQUEST_CHANGES writes.
                "fail closed",
                "protocol-reconciliation blocker",
                "不得补 ready、新建 attempt、speculative acquire，"
                "或连续试写不同 marker 猜测协议",
                # AC4: the ACCEPTED side is verified the same way.
                "expected-head merge"):
            self.assertIn(literal, rules,
                          f"review fallback post-write verification rule "
                          f"missing: {literal!r}")

    def test_a_activation_completeness_enumerates_all_pending_transitions(self):
        # #123 AC1-AC6: canonical A guidance hardens the activation entry
        # invariant — before any no-work conclusion A must enumerate ALL
        # explicitly pending A-owned governance transitions from current
        # durable truth instead of narrowing the activation entry to
        # "find a new formal `ght:deliver` Candidate". Enumeration covers
        # formal delivered Candidate exact-SHA review, durable
        # `Resolution owner: A` / equivalent blocker/replan/reconciliation
        # requests, A-owned post-merge follow-through/read-back, and
        # authorization/Plan/governance transitions durable truth
        # explicitly routes to A. A durable A-owned blocker enters the
        # reconciliation workset even with no new formal Candidate and
        # keeps its real blocker classification, while a genuinely empty
        # A-owned transition surface may stop normally. "no new Candidate"
        # stays distinguishable from "no A-owned work"; the existing
        # per-Candidate exact-SHA review / REQUEST_CHANGES /
        # multi-Candidate verdict / head reread / expected-head merge /
        # release governance / fail-closed rules stay intact; the
        # post-merge completion architecture keeps owning completion; and
        # no queue/watcher/scheduler/daemon/lifecycle state/control plane,
        # new or changed ght command, or second durable transition parser
        # is introduced.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        # AC1: the entry invariant + the four enumerated transition classes.
        for literal in (
                "A activation completeness",
                "在形成任何 no-work 结论之前",
                "枚举全部明确 pending 的 A-owned governance transitions",
                "formal delivered Candidate 的 exact-SHA review",
                "`Resolution owner: A` 或等价的 durable blocker / replan / reconciliation 请求",
                "A merge 之后仍需完成的 A-owned durable follow-through / read-back",
                "authorization / Plan / governance transition"):
            self.assertIn(literal, rules,
                          f"activation entry invariant missing: {literal!r}")
        # AC2/AC5 blocked direction: a durable A-owned blocker enters the
        # workset even without a new formal Candidate and keeps its real
        # blocker classification instead of a fake empty workset.
        for literal in (
                "必须进入本次 reconciliation workset",
                "即使没有新的 formal Candidate",
                "也不得静默降级为 no work",
                "保留真实 blocker 分类"):
            self.assertIn(literal, rules,
                          f"durable A-owned blocker workset rule missing: "
                          f"{literal!r}")
        # AC3/AC5 empty direction: the two conclusions stay
        # distinguishable, a genuine empty surface may stop normally, and
        # informational comments are not A work.
        for literal in (
                "“no new Candidate” 只说明没有新的可 review Candidate",
                "从不等于 “no A-owned work”",
                "A-owned transition surface genuinely empty 时按 Stop condition 正常停止",
                "informational comment 本身不是 A work"):
            self.assertIn(literal, rules,
                          f"no-Candidate vs no-A-work distinction missing: "
                          f"{literal!r}")
        # AC4: entry enumeration only — the per-Candidate invariants are
        # named intact and no verdict/authorization/release is automated.
        for literal in (
                "该不变量只扩展 activation 入口枚举",
                "per-Candidate exact-SHA review、REQUEST_CHANGES correction、"
                "multi-Candidate independent verdict",
                "不共享 verdict、不自动 ACCEPT、不自动授权、不自动 release"):
            self.assertIn(literal, rules,
                          f"entry-enumeration-only rule missing: {literal!r}")
        # AC6: post-merge completion architecture stays canonical — no B
        # re-run after an ordinary merge, no copied complete predicates,
        # and merged-but-unreconciled residue routes to the existing
        # Mechanical Reconciler recovery surface.
        for literal in (
                "不要求 B 在正常 merge 后重新执行 complete",
                "不复制 complete predicates",
                "Mechanical Reconciler recovery/diagnostic surface"):
            self.assertIn(literal, rules,
                          f"post-merge completion preservation missing: "
                          f"{literal!r}")
        # Anti-drift: the incident behavior, fake enumeration commands,
        # and consumer-side shortcuts must stay out of canonical guidance.
        for drift in ("ght enumerate-work",
                      "ght pending-work",
                      "no new Candidate 即 no A-owned work",
                      "may skip the enumeration when no new Candidate exists"):
            self.assertNotIn(drift, rules,
                             f"activation-completeness drift must stay "
                             f"out: {drift!r}")

    def test_a_project_planning_loop_plan_track_forecast_replan(self):
        # #132 AC1-AC4: canonical A guidance defines the project-level
        # Plan → Track → Forecast → Replan loop — A forms/maintains an
        # iteration/project plan, tracks completed/active/remaining/blocked
        # work and major risks against real dependencies and the critical
        # path, and gives an evidence-based iteration/target-time judgment
        # when the available evidence supports one. Progress/forecast
        # answers require fresh durable project truth, distinguish known
        # facts from inference/uncertainty, never reduce to naive
        # Issue-count percentages, and never invent precise hours/dates or
        # certainty the evidence does not support. A material
        # plan-invalidating fact forces proactive reassessment/replan,
        # while immaterial ordinary progress does not force a
        # whole-project reforecast and a prior forecast is reused while
        # its material inputs remain valid. The loop preserves the A/B
        # planning-versus-execution boundary and adds no sizing/velocity/
        # scheduler mechanism or new ght primitive.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        # AC1: a coherent Plan → Track → Forecast → Replan responsibility.
        for literal in (
                "Plan → Track → Forecast → Replan",
                "maintain an iteration/project plan from current durable truth",
                "completed / active / remaining / blocked work and major risks",
                "real dependencies and the critical path",
                "evidence-based iteration / target-time judgment"):
            self.assertIn(literal, rules,
                          f"planning-loop responsibility missing: {literal!r}")
        # AC2: progress/forecast answers are evidence-first — fresh
        # durable truth before answering, facts vs inference vs
        # uncertainty, no naive percentages, no unsupported precise ETA,
        # and explicit uncertainty when evidence is insufficient.
        for literal in (
                "Before answering a User question about project progress",
                "must re-read the current relevant durable project truth",
                "Known facts, inference, and uncertainty must be distinguishable",
                "never reduced to naive Issue-count percentages",
                "never invents precise hours/dates or certainty",
                "A says so explicitly"):
            self.assertIn(literal, rules,
                          f"evidence-first progress/forecast rule missing: "
                          f"{literal!r}")
        # AC3: the reassessment boundary — material plan-invalidating
        # facts force proactive replan, while immaterial ordinary progress
        # does not force a full reforecast and a still-valid prior
        # forecast may be reused.
        for literal in (
                "requires the fresh-evidence check above",
                "material change to scope/priority/target time, "
                "critical-path state, dependencies, blockers, engineering "
                "complexity/risk, or actual progress versus plan",
                "reassess whether the current plan remains credible",
                "replan proactively",
                "rather than waiting to be asked",
                "without forcing a whole-project reforecast",
                "an unchanged prior forecast may be reused while its "
                "material inputs remain valid"):
            self.assertIn(literal, rules,
                          f"reassessment-boundary rule missing: {literal!r}")
        # AC4: the A/B planning-versus-execution boundary survives, and
        # the loop introduces no story-point/velocity/percentage
        # mechanism, scheduler, or ght primitive merely to forecast.
        self.assertIn("B retains ordinary engineering HOW, concrete "
                      "resource admission, worker/subagent count, and "
                      "execution topology", rules)
        self.assertIn("no new scheduler, database, lifecycle, or ght "
                      "primitive merely to produce forecasts", rules)
        for banned in ("story point", "velocity", "完成率"):
            self.assertNotIn(banned, rules,
                             f"A planning guidance must not import a "
                             f"sizing/velocity mechanism: {banned!r}")

    def test_a_self_update_activation_boundary(self):
        # #135 AC1-AC4: canonical A guidance separates A self-update
        # completion from activation — writing and reading back an updated
        # authoritative A definition or Package does not make the new role
        # effective for the pre-update role context; A must reload the
        # authoritative definition and refresh the role before continuing
        # work that relies on the changed definition. Refresh continues
        # from durable project truth without inventing a second A
        # identity, losing pending stewardship work, or creating authority
        # beyond the authoritative definition, and never alters User-owned
        # decisions or transfers B-owned engineering HOW/resource
        # authority to A. The boundary stays implementation-light: no new
        # lifecycle state, version database, updater daemon/service,
        # runtime capsule, scheduler, approval gate, or B implementation
        # Issue requirement.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        # AC1: update completion is explicitly separated from activation —
        # the durable write/read-back alone activates nothing for the
        # pre-update role context.
        for literal in (
                "A self-update activation boundary",
                "Update completion ≠ activation",
                "does not let the pre-update role context claim that newly "
                "introduced duties, authority, constraints, or decision "
                "rules are already active"):
            self.assertIn(literal, rules,
                          f"self-update activation rule missing: {literal!r}")
        # AC2: reload + refresh of the authoritative definition before
        # relying on the changed definition; refresh continues from
        # durable project truth without a second A identity, lost
        # stewardship work, or authority beyond the definition.
        for literal in (
                "reload/read the authoritative A definition and refresh "
                "the role",
                "before continuing work that relies on the changed "
                "definition",
                "continues from current durable project truth",
                "must not invent a second A identity, discard pending "
                "stewardship work, or create authority beyond what the "
                "authoritative definition actually grants"):
            self.assertIn(literal, rules,
                          f"refresh requirement missing: {literal!r}")
        # AC3: implementation-light — the invariant adds no lifecycle/
        # control-plane mechanism and never forces a B implementation
        # Issue for an otherwise A-owned role-text update.
        for literal in (
                "no new lifecycle label/state, A version database, "
                "updater daemon/service, runtime capsule, scheduler, or "
                "approval gate",
                "never requires a B implementation Issue merely to "
                "perform an otherwise A-owned role-text update"):
            self.assertIn(literal, rules,
                          f"implementation-light rule missing: {literal!r}")
        # AC4: the two failure modes the boundary rejects are pinned in
        # canonical text — old-context self-activation via self-editing,
        # and authority movement through refresh.
        self.assertIn("cannot bootstrap newly granted authority merely "
                      "because it edited its own definition", rules)
        self.assertIn("does not alter User-owned decisions and does not "
                      "transfer B-owned engineering HOW or resource "
                      "authority to A", rules)
        # Regression guards: direct self-activation claims and new
        # control-plane machinery must stay out of the canonical guidance.
        for drift in ("is effective immediately once written",
                      "the old role context may immediately use newly "
                      "granted authority",
                      "ght refresh-role",
                      "ght activate-a-role"):
            self.assertNotIn(drift, rules,
                             f"self-activation/new-mechanism drift must "
                             f"stay out: {drift!r}")

    def test_release_authority_user_gate_and_timing_constraint(self):
        # #110 AC1-AC5: formal release governance converges on an explicit
        # User authorization gate with Timing ≠ Authority as a general A
        # principle. The default state is NO RELEASE — User owns
        # whether/when/which version; A may assess readiness and propose,
        # but a proposal never self-authorizes publication; after
        # authorization A owns exact-target reconciliation through
        # fail-closed durable read-back while B stays mechanical-only.
        # The A Prompt and the release policy must agree, and the old
        # A-self-authorizing wording must not return.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        policy = (SKILL_ROOT.parent.parent / "docs" / "release-policy.md").read_text()
        # AC1: NO RELEASE default + User-owned decision + proposal ≠
        # authorization + ordinary progress signals do not authorize.
        for literal in (
                "NO RELEASE by default",
                "User owns whether/when/which version",
                "a release proposal is not an authorization",
                "explicit User authorization",
                "尽快完成",
                "Milestone 完成",
                "runtime/bootstrap need"):
            self.assertIn(literal, policy,
                          f"release policy missing User-gate semantics: {literal!r}")
        # AC2: Timing is a constraint, not authority — on the A owner
        # surface, as a general principle beyond release.
        for literal in (
                "Timing is a constraint, not authority",
                "never an authority delegation",
                "never an implicit grant of product, scope, release, acceptance",
                "never lowers Contract ACs, safety invariants, or DONE standards",
                "surface the trade-off to the User"):
            self.assertIn(literal, rules,
                          f"A Prompt missing timing-constraint rule: {literal!r}")
        # AC3: post-authorization responsibility boundary on A, mechanical
        # execution only on B.
        for literal in (
                "durable authorization mirror",
                "exact-target reconciliation",
                "durable read-back"):
            self.assertIn(literal, policy,
                          f"release policy missing post-authorization duty: {literal!r}")
        self.assertIn("不得自行选择或改变是否发布、version、timing", policy,
                      "B must stay mechanical-only in the release policy")
        # AC4: canonical trigger/precondition chain; the durable mirror
        # records the authorized version and User-specified timing
        # semantics but is never a self-service authority source; internal
        # technical events are not substitute triggers.
        for literal in (
                "User explicitly authorizes a concrete formal release",
                "A records a durable authorization mirror",
                "A reconciles/freezes exact target",
                "timing semantics",
                "不是替代 trigger"):
            self.assertIn(literal, policy,
                          f"canonical release trigger missing: {literal!r}")
        self.assertIn("绝不能通过写 comment / Issue state 自行生成 release authority",
                      policy, "the mirror must never mint release authority")
        # AC5: anti-drift — retired A-self-authorizing wordings stay out of
        # BOTH canonical surfaces (A Prompt and release policy).
        for retired in (
                # release-policy.md wording retired by #110:
                "A 是正式版本发布的唯一决策与执行责任方",
                "选择 next version 与 exact release target SHA",
                "A 根据项目 versioning policy 与 selected accepted change set 选择 next version",
                # A-project-rules.md wording retired by #110:
                "integration authority, and release authority",
                "Issue closure, and release/deploy authorization"):
            for name, text in (("A-project-rules", rules),
                               ("release-policy", policy)):
                self.assertNotIn(retired, text,
                                 f"{name} must not carry retired wording: {retired!r}")
        # Cross-surface agreement: the A Prompt states the same
        # proposal-is-not-authorization model and points at the policy.
        self.assertIn("a release proposal is not an authorization", rules)
        self.assertIn("docs/release-policy.md", rules)
    def test_acceptance_layers_distinct_a_vs_user_product(self):
        # #133 AC1-AC4: canonical A guidance and the release policy keep
        # Product Definition V1.1's acceptance layers distinct — A
        # acceptance / Issue-level DONE is an engineering judgment that
        # may accept and integrate work satisfying confirmed requirements
        # but is never final User product acceptance; User product
        # acceptance is a User-owned product judgment over the integrated
        # usable product, not a per-Issue/per-Candidate approval gate, and
        # later User feedback after a valid A acceptance is a new product
        # gap rather than retroactive defect evidence. Release guidance
        # keeps User product acceptance, explicit formal release
        # authorization, release-specific technical validation, and
        # Production Verified/deployed facts distinct; existing release
        # mechanics are preserved and no lifecycle state/label/database
        # field/User-per-Issue gate is added.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        policy = (SKILL_ROOT.parent.parent / "docs" / "release-policy.md").read_text()
        # AC1: A acceptance / Issue-level DONE is engineering judgment,
        # explicitly not final User product acceptance; A presents a
        # meaningful integrated, usable product state for User evaluation
        # when product acceptance is relevant.
        for literal in (
                "A acceptance 是工程判断",
                "可以接受并集成",
                "不是 final User product acceptance",
                "已集成、可实际使用的产品状态供 User 评估"):
            self.assertIn(literal, rules,
                          f"A-vs-User acceptance distinction missing: {literal!r}")
        # AC2: User-owned product judgment over the integrated usable
        # product, never a per-Issue/per-Candidate approval gate; later
        # User feedback after a valid A acceptance is a new product gap,
        # not retroactive evidence of a defective implementation/review.
        for literal in (
                "`User product acceptance` 由 User 拥有",
                "不是每个 Issue/Candidate 的逐项审批 gate",
                "不自动证明此前 B 实现或 A Review 错误"):
            self.assertIn(literal, rules,
                          f"User product acceptance boundary missing: {literal!r}")
        # AC3: release/production guidance keeps User product acceptance,
        # explicit formal release authorization, release-specific
        # technical validation, and Production Verified/deployed facts
        # distinct, and the preserved release invariants stay intact.
        for literal in (
                "release-specific technical validation",
                "不替代 User product acceptance",
                "`User product acceptance`、`Released`、`Production Verified` 保持独立",
                # preserved release mechanics (#110 model stays intact):
                "NO RELEASE by default",
                "explicit User authorization",
                "冻结 exact release target SHA",
                "durable post-publication read-back"):
            self.assertIn(literal, policy,
                          f"release acceptance-layer distinction missing: {literal!r}")
        self.assertIn("product acceptance 与 release authorization 仍由 User 拥有",
                      policy,
                      "product acceptance must not be worded as an A-owned "
                      "release decision")
        # AC1/AC3 anti-drift: the retired A-owned production/product
        # acceptance implications stay out of both canonical surfaces.
        for retired in (
                "production acceptance when required",
                "A owns production acceptance",
                "release/production acceptance",
                "release-specific validation / production acceptance"):
            for name, text in (("A-project-rules", rules),
                               ("release-policy", policy)):
                self.assertNotIn(retired, text,
                                 f"{name} must not carry retired wording: {retired!r}")
        # AC4: the distinction adds no machinery — the Contract schema
        # keeps exactly its existing required fields (no User-acceptance
        # field), the one-shot start-authority label stays `ready`, and
        # the A guidance keeps its explicit no-new-lifecycle-state guards.
        core_src = (SKILL_ROOT / "github_task" / "core.py").read_text()
        cli_src = (SKILL_ROOT / "github_task" / "cli.py").read_text()
        self.assertIn('required = ("version", "intent", "acceptance", "authority")',
                      core_src,
                      "Contract schema must not gain a User-acceptance field")
        self.assertIn('os.environ.get("GHT_READY_LABEL", "ready")', cli_src,
                      "the one-shot start-authority label must stay `ready`")
        for surface in (core_src, cli_src):
            for machinery in ("user_acceptance", "user-acceptance",
                              "product_accepted", "product-accepted"):
                self.assertNotIn(machinery, surface,
                                 f"runtime must not gain User-acceptance "
                                 f"machinery: {machinery!r}")
        self.assertIn("不要添加 `production-pending` 等 lifecycle label/state 来镜像该条件",
                      rules)
        self.assertIn("Do not add `reviewed`, `accepted`, `candidate-ready`", rules)
        self.assertIn("也不要添加 per-Issue User product acceptance gate", rules)

    def test_skill_readme_is_nonnormative_navigation_with_owner_map(self):
        # #109 AC1/AC2/AC5: the skill README is a thin, non-normative
        # navigation/reference surface. It owns no authorization,
        # claim-lifecycle, concurrency, or runtime state-machine semantics;
        # it carries only a minimal quick start, CLI/help/source pointers,
        # a canonical owner map, and troubleshooting anchors — and every
        # fact class is pointed to its one real owner so a reader can
        # recover all normative facts one-way without the README.
        readme = (SKILL_ROOT / "README.md").read_text()
        # 1) Non-normative banner + owner map naming each real owner
        #    surface (not this README) for its fact class.
        self.assertIn("non-normative", readme,
                      "README must open as non-normative navigation")
        for owner in ("prompts/A-project-rules.md",
                      "SKILL.md",
                      "github_task/",
                      "ght --help",
                      "GitHub / ght durable truth"):
            self.assertIn(owner, readme,
                          f"README owner map must point to {owner!r}")
        # 2) The retired normative sections stay retired — they were the
        #    second-owner drift; their semantics live on the owner
        #    surfaces (A Prompt / SKILL / runtime source + tests/help).
        for retired in ("Vocabulary: mechanical eligibility",
                        "Zero-prompt entrypoint",
                        "Pre-READY mechanical validation",
                        "Canonical intake semantics",
                        "Retained from v2",
                        "Intentionally excluded from v2",
                        "Ref namespaces",
                        "Terminal claim lineage",
                        "Automatic lease supervision",
                        "Branch hygiene"):
            self.assertNotIn(retired, readme,
                             f"README must not own normative semantics: {retired!r}")
        # 2b) #109 R2: semantic-family guards — the retired *meanings* stay
        #    out even when reintroduced under a different heading. Heading
        #    bans alone would pass while the old normative authorization
        #    semantics returned as reworded prose. Families are grounded in
        #    the exact wording this Issue retired from the README:
        #    - only-`ready`-authorizes-a-start: the retired single
        #      start-authority surface ("only `ready` authorizes a start");
        #    - one-shot-`ready`-required-for-a-new-attempt: retired
        #      claim-lifecycle semantics ("a new normal attempt requires the
        #      one-shot `ready` label");
        #    - plan-first-direct-ready-precedence: retired Plan-vs-ready
        #      exclusivity ("Plan-authorized start (XOR with direct ready)",
        #      direct-ready valid only "absent a Plan") — superseded by the
        #      independent start-authority surfaces model (AC3).
        #    Plain command/help references (`ght claim`, `ght ready-repair`,
        #    flag pointers, `ght --help`) stay allowed — they name no
        #    normative authorization semantics.
        plain = readme.replace("*", "").replace("`", "")
        for family, patterns in (
                ("only-ready-authorizes-a-start", (
                    r"only\s+ready\s+authorizes",
                    r"ready\s+is\s+the\s+(?:only|sole|single)\b",
                    r"the\s+(?:only|sole|single)\s+(?:\w+\s+){0,2}"
                    r"start(?:ing)?\s+authorit",
                )),
                ("one-shot-ready-required-for-a-new-attempt", (
                    r"new\s+normal\s+attempt\s+requires?",
                    r"requires?\s+(?:the\s+|a\s+)?"
                    r"(?:fresh|one-shot|unconsumed)\s+ready",
                    r"must\s+consume\s+(?:the\s+|a\s+|its\s+)?"
                    r"(?:fresh\s+|one-shot\s+|unconsumed\s+)?ready",
                )),
                ("plan-first-direct-ready-precedence", (
                    r"XOR\s+with\s+(?:a\s+)?(?:direct[\s-]*)?ready",
                    r"absent\s+a\s+Plan",
                    r"Plan\s+authorization[^.\n]{0,60}"
                    r"(?:takes?\s+precedence|comes?\s+first)",
                ))):
            for pattern in patterns:
                self.assertIsNone(
                    re.search(pattern, plain, flags=re.IGNORECASE),
                    f"README must not carry retired normative semantics "
                    f"({family}): /{pattern}/ matched")
        # 3) Every `ght <command>` the README names must exist on the
        #    real CLI surface — the pointer stays mechanically true.
        surface = _cli_subcommands()
        referenced = {name for name in
                      re.findall(r"`ght ([a-z][a-z-]*)", readme)
                      if not name.startswith("--")}
        self.assertTrue(referenced, "README should still name concrete commands")
        unknown = referenced - surface
        self.assertEqual(unknown, set(),
                         f"README references commands missing from the CLI: {unknown}")

    def test_dual_start_authority_surfaces_and_admission_layers(self):
        # #109 AC3: both canonical A and B surfaces state that direct
        # `ready` and Plan authorization are independent start-authority
        # surfaces — different Issues may be authorized through either or
        # both at the same time and compile into the complete workset,
        # while one Issue holding both live grants is ambiguous dual
        # authorization and fails closed — and that AUTHORIZED,
        # RUNNABLE, and ADMITTED are distinct layers: A authorizes the
        # backlog, ght compiles the gates-satisfied frontier, B admits
        # work-conservingly on real gates/capacity/conflicts.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        skill = SKILL_MD.read_text()
        for name, text in (("A-project-rules", rules), ("SKILL", skill)):
            self.assertIn("independent start-authority surfaces", text,
                          f"{name} must state the two start-authority surfaces")
            self.assertIn("dual authorization", text,
                          f"{name} must fail closed on same-Issue dual grants")
            self.assertIn("AUTHORIZED ≠ RUNNABLE ≠ ADMITTED", text,
                          f"{name} must keep the three layers distinct")
            self.assertIn("A authorizes the backlog", text,
                          f"{name} must state the authorization/admission split")

    def test_ab_guidance_states_accepted_topology_consistently(self):
        # #109 AC4: A and B guidance consistently express the accepted
        # topology — one stable primary B coordination identity plus 0..N
        # ephemeral per-Issue executors — and A holds no worker-count/
        # concurrency/topology authority. Docs-only hardening: the correct
        # runtime semantics are not touched to match prose.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        skill = SKILL_MD.read_text()
        for literal in ("one stable primary B coordination identity",
                        "0..N ephemeral per-Issue executors",
                        "no worker-count/concurrency/topology authority"):
            self.assertIn(literal, skill,
                          f"B surface missing accepted topology: {literal!r}")
            self.assertIn(literal, rules,
                          f"A surface missing accepted topology: {literal!r}")
        # The retired per-executor persistent-identity wording stays out
        # of the A surface too (its model-doc ban is pinned above).
        self.assertNotIn("persistent B coordination identity(ies)", rules)

    def test_skill_delegates_protocol_and_states_authority_boundary(self):
        # AC2/AC3: the Skill names the mechanical delegation and the
        # fail-closed/authority boundary instead of re-implementing
        # protocol judgments in prose.
        text = SKILL_MD.read_text().lower()
        for required in ("fail-closed", "ready", "request_changes", "merge",
                         "scope-check", "preserve", "deliver", "complete",
                         "takeover"):
            self.assertIn(required, text, f"SKILL.md must cover {required!r}")

    def test_product_traceability_prd_alignment(self):
        # #140 AC1-AC4: canonical A guidance closes the PRD 6.3
        # traceability loop — material engineering work / Task Contracts
        # identify a recoverable upstream product requirement or confirmed
        # product gap with enough specificity for a later A activation;
        # engineering design and B HOW stay free inside the Contract but
        # code/Prompt/Skill/workflow/tests never silently become the sole
        # source of changed product semantics (A explicitly reconciles the
        # upstream truth first); exact-Candidate acceptance reviews the
        # implementation against the confirmed upstream requirement, and
        # User product acceptance stays the later User-owned judgment. The
        # invariant adds no traceability registry, lifecycle label,
        # required ght-contract schema field, approval stage, or second
        # product truth.
        rules = (SKILL_ROOT.parent.parent / "prompts" / "A-project-rules.md").read_text()
        # AC1: recoverable upstream requirement / confirmed gap with
        # enough specificity, using existing durable surfaces only.
        for literal in (
                "Product traceability: upstream requirement → "
                "implementation → A acceptance",
                "identify the upstream product requirement or confirmed "
                "product gap the work implements or repairs",
                "enough specificity that a later A activation can "
                "determine what product semantic the work is expected to "
                "deliver or fix",
                "Narrow maintenance work needs no verbatim "
                "product-document quotation",
                "never a requirements database, traceability matrix, "
                "mandatory Contract schema field, or duplicate "
                "product-definition document"):
            self.assertIn(literal, rules,
                          f"upstream traceability rule missing: {literal!r}")
        # AC2: directionality — free HOW inside the Contract, no silent
        # redefinition, explicit upstream reconciliation before changed
        # downstream semantics are authorized.
        for literal in (
                "engineering design and B HOW choose implementation "
                "freely inside the Contract",
                "never silently become the sole source of changed "
                "product semantics",
                "explicitly updates/reconciles the applicable upstream "
                "product/project truth",
                "before authorizing downstream work under the changed "
                "semantic"):
            self.assertIn(literal, rules,
                          f"directionality rule missing: {literal!r}")
        # AC3: acceptance checks against the confirmed upstream
        # requirement; technical self-consistency + passing local tests
        # are not an acceptance reason; User product acceptance stays the
        # later User-owned judgment, never a per-Issue gate.
        for literal in (
                "reviews the implementation against the confirmed "
                "upstream requirement or product gap the Contract "
                "represents",
                "passing local tests is not accepted on that basis alone",
                "User product acceptance stays the later User-owned "
                "judgment",
                "never converted into a per-Issue gate"):
            self.assertIn(literal, rules,
                          f"upstream-acceptance rule missing: {literal!r}")
        # AC4: anti-drift — no traceability registry, lifecycle label,
        # approval stage, or traceability command/field mechanism is
        # introduced, and the Contract schema keeps exactly its existing
        # required fields.
        for drift in ("ght traceability", "traceability_id",
                      "traceability_status", "traceability gate",
                      "traceability registry"):
            self.assertNotIn(drift, rules,
                             f"traceability-mechanism drift must stay "
                             f"out: {drift!r}")
        core_src = (SKILL_ROOT / "github_task" / "core.py").read_text()
        self.assertIn('required = ("version", "intent", "acceptance", '
                      '"authority")', core_src,
                      "Contract schema must not gain a traceability field")


if __name__ == "__main__":
    unittest.main()
