"""Standalone downstream-consumption conformance (#153).

The accepted two-entry downstream product boundary must be literally
standalone for the core delivery loop:

- **A** operates from the canonical A Prompt (``prompts/A-project-rules.md``)
  plus the target project's durable GitHub/repository truth — never from a
  Harry Dev source checkout, and never by reading repo-local Harry Dev docs
  to discover required normative behavior.
- **B** operates from the complete installed ``github-task`` Skill package
  plus the target project's local checkout — its loading/runtime must not
  reach back into a Harry Dev source tree. External host capabilities
  (git, Python, GitHub credentials/CLI, Superpowers skills) are host
  capabilities, not source-tree dependencies.

The A-surface check mechanically rejects *required* repo-local normative
dependencies; the B-package check exercises representative load / CLI /
protocol entrypoints from an isolated copy of the package beside an
unrelated target repository with no Harry Dev source tree available, and
proves the no-reach-back property by observing actual file access (an
audit hook), not by grepping for preferred prose.
"""

import json
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
SOURCE_ROOT = Path(__file__).parents[3]
A_PROMPT = SOURCE_ROOT / "prompts" / "A-project-rules.md"

# Issue-body fixture used as protocol input inside the unrelated target
# repository (representative ght-contract block for parse/digest entrypoints).
TARGET_ISSUE_BODY = """# Add a greeting endpoint

Planning notes that are NOT part of the Contract.

```ght-contract
version: 1
intent: >
  Serve a greeting over HTTP.
acceptance:
  - id: AC1
    requirement: GET /greeting returns 200 and a non-empty body.
authority:
  implementation: allowed
depends_on: []
scope:
  forbidden:
    - secrets/**
```"""


# ---------------------------------------------------------------------------
# A-surface standalone conformance (#153 AC1/AC2/AC4a)
# ---------------------------------------------------------------------------

# Required-dependency grammar: a repo-local doc path (or the source-repo
# normative model) presented as runtime authority a downstream A must
# consult. Any match means the Prompt is not self-contained.
REQUIRED_DEPENDENCY_GRAMMAR = (
    # the retired governing-source sentence (#153 evidence on main)
    r"normative model in this repository",
    # required pointer grammars — a downstream A is told to consult the doc
    r"see `docs/[^`]+`",
    r"per `docs/[^`]+`",
    r"under `docs/[^`]+`",
    r"required by `docs/[^`]+`",
    r"according to `docs/[^`]+`",
    r"as defined in `docs/[^`]+`",
    r"governed by `docs/[^`]+`",
)

# Every repo-local Harry Dev doc mention that survives on the Prompt must
# sit inside an explicit demotion (developer/reference, never required
# authority) within its own sentence — a mention without demotion would
# read as required material.
DEMOTION_MARKERS = (
    "developer/reference",
    "developer reference",
    "reference document",
    "reference material",
    "non-normative",
    "not required downstream authority",
    "never required downstream authority",
    "a downstream A must not need it",
)


def _sentences(text: str) -> list[str]:
    """Split prose into sentence-ish units (period/newline bounded)."""
    units: list[str] = []
    for line in text.splitlines():
        units.extend(part.strip() for part in line.split(". "))
    return [unit for unit in units if unit]


class AStandaloneSurfaceTests(unittest.TestCase):
    """prompts/A-project-rules.md is self-contained for downstream A."""

    def setUp(self):
        self.rules = A_PROMPT.read_text()

    def test_no_required_repo_local_normative_dependencies(self):
        # AC2/AC4a: the Prompt must not present repo-local Harry Dev docs
        # or "the normative model in this repository" as required runtime
        # authority. This rejects the dependency *grammar*, not preferred
        # prose: any doc path bound by a consult/authority verb fails.
        for pattern in REQUIRED_DEPENDENCY_GRAMMAR:
            match = re.search(pattern, self.rules)
            if match is not None:
                self.fail("A Prompt carries a required repo-local normative "
                          f"dependency: /{pattern}/ matched {match.group(0)!r}")

    def test_repo_doc_mentions_are_demoted_in_context(self):
        # AC2: surviving mentions of docs/adoption.md / docs/release-policy.md
        # must be explicitly demoted to developer/reference material inside
        # the sentence that makes the mention — a bare mention without
        # demotion would be a required dependency by context.
        for doc in ("docs/adoption.md", "docs/release-policy.md"):
            for sentence in _sentences(self.rules):
                if f"`{doc}`" not in sentence:
                    continue
                demoted = any(marker in sentence for marker in DEMOTION_MARKERS)
                self.assertTrue(
                    demoted,
                    f"{doc} is mentioned without demotion in: {sentence!r}")

    def test_standalone_authority_statement_is_on_surface(self):
        # AC1/AC2: the Prompt itself must state the standalone boundary —
        # it is the canonical A behavior surface; the target project's
        # durable truth supplies project specifics; a Harry Dev source
        # checkout is never a runtime dependency; source docs are never a
        # second normative source.
        for literal in (
                "self-contained for normal downstream operation",
                "A Harry Dev source checkout is never a runtime dependency",
                "comes from the target project's own durable sources",
                "never required runtime authority",
                "never a second normative source"):
            self.assertIn(literal, self.rules,
                          f"standalone boundary statement missing: {literal!r}")

    # Source-project release-mechanism vocabulary (#153 R1): Harry Dev's own
    # named release mechanics must never appear on the canonical A Prompt,
    # even when no repo-local doc link is present — the Prompt carries only
    # the universal release-authority invariants; concrete release mechanics
    # come from the target project's own durable truth. Any match is
    # semantic leakage past the standalone boundary, not a wording nit.
    SOURCE_RELEASE_MECHANISM_LEAKAGE = (
        # version-scheme literals tied to the source project's scheme
        r"v\d+\.\d+\.x",
        r"v\d+\.\d+\.\d+",
        r"\bpatch release\b",
        # the source project's named release procedures / mechanisms
        r"Release Notes generation",
        r"durable authorization mirror",
        r"designated release dispatch",
        r"publication trigger",
        r"publication-activation",
        r"refreez",
        r"\bfreeze\b",
        r"frozen release target",
        # the source project's changelog file handling
        r"CHANGELOG\.md",
    )

    def test_no_source_project_release_mechanism_leakage(self):
        # AC2/AC4 (R1): the Prompt must not hardcode the source project's
        # own release mechanics — version-scheme literals, named release
        # procedures, or file-handling specifics — even when no repo-local
        # doc link is present. The R0 grammar/demotion checks could not see
        # this failure class; this one closes it.
        for pattern in self.SOURCE_RELEASE_MECHANISM_LEAKAGE:
            match = re.search(pattern, self.rules)
            if match is not None:
                self.fail("A Prompt hardcodes a source-project release "
                          f"mechanism: /{pattern}/ matched {match.group(0)!r}")

    def test_release_semantics_stay_universal_authority_invariants(self):
        # AC2 (R1): the release portions of the Prompt carry only the
        # universal invariants — User owns whether/when/which formal
        # release; A may assess/propose; publication only after explicit
        # authorization; merge/completion/milestone/urgency never imply a
        # release; concrete mechanisms come from the target project's own
        # durable truth and are never assumed as given when the project
        # defines none.
        for literal in (
                "User owns whether/when/which formal release",
                "a release proposal is not an authorization",
                "publication happens only after the User explicitly "
                "authorizes that concrete release",
                "never implies release authorization",
                "the target project's own durable release policy/mechanism",
                "must not treat any source-project-specific release "
                "mechanism as given"):
            self.assertIn(literal, self.rules,
                          f"universal release-authority invariant missing: "
                          f"{literal!r}")

    def test_core_delivery_loop_behaviors_live_on_the_prompt_surface(self):
        # AC1: normal downstream A operation — first bootstrap/adoption,
        # resume, planning/decomposition, READY authorization, exact-
        # Candidate review, integration/completion stewardship, and generic
        # release-authority handling — must be discoverable on the Prompt
        # surface itself. Bootstrap/adoption is the behavior whose runbook
        # previously lived only in docs/adoption.md; release mechanics
        # previously pointed at docs/release-policy.md.
        for literal in (
                # on-Prompt adoption runbook (minimum universal semantics)
                "First bootstrap and adoption",
                "no Harry Dev source checkout is required",
                "runs once per repository",
                "Inventory before changing anything",
                "source of truth, a command/trigger, or a derived/mirror",
                "Reconcile to the standard operating state",
                "Verify, then enter normal operation",
                # normal resume (existing on-surface semantics stay pinned)
                "rebuild current stewardship state from GitHub durable truth",
                # generic release-authority handling (project-supplied
                # mechanics, User-owned decision)
                "the target project's own durable release policy/mechanism"):
            self.assertIn(literal, self.rules,
                          f"on-surface behavior missing: {literal!r}")
        # The one-shot READY post-condition and the exact-Candidate review
        # entry gate are already canonical on this surface; they must not
        # have been moved away with the doc dependencies.
        for literal in ("ready must be absent", "No delivery, no review"):
            self.assertIn(literal, self.rules,
                          f"core loop invariant left the A surface: {literal!r}")


# ---------------------------------------------------------------------------
# B isolated-package conformance (#153 AC3/AC4b)
# ---------------------------------------------------------------------------

def _clean_env(home: str) -> dict[str, str]:
    """A host shell without any pointer into the Harry Dev source tree.

    Only declared host capabilities stay (git/python on PATH); no
    PYTHONPATH, no distribution-root override, nothing that names the
    Harry Dev checkout.
    """
    import os
    env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"),
           "HOME": home,
           "PYTHONPATH": "",
           "GHT_DISTRIBUTION_ROOT": "",
           "LC_ALL": "C"}
    return env


class IsolatedPackageTests(unittest.TestCase):
    """The installed github-task package works beside an unrelated repo."""

    def setUp(self):
        import os
        self._tmp = tempfile.TemporaryDirectory(prefix="ght153-")
        tmp = Path(self._tmp.name)
        # 1) The "installed" Skill package: a complete copy of
        #    skills/github-task/ standing alone (no Harry Dev tree around it).
        self.dist = tmp / "installed" / "github-task"
        shutil.copytree(
            SKILL_ROOT, self.dist,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git*"))
        # 2) The unrelated target repository: a fresh business repo holding
        #    none of the Harry Dev source surfaces.
        self.target = tmp / "acme-business-repo"
        self.target.mkdir()
        git = ["git", "-C", str(self.target)]
        for args in (["init", "-q"],
                     ["config", "user.name", "acme"],
                     ["config", "user.email", "dev@acme.example"],
                     ["config", "commit.gpgsign", "false"]):
            subprocess.run(git + args, check=True, capture_output=True)
        (self.target / "README.md").write_text("# ACME business repo\n")
        issue = self.target / "issue-42.md"
        issue.write_text(TARGET_ISSUE_BODY)
        subprocess.run(git + ["add", "."], check=True, capture_output=True)
        subprocess.run(git + ["commit", "-qm", "initial"], check=True,
                       capture_output=True)
        # Isolation preconditions: neither side carries the other's world.
        self.assertFalse((self.target / "prompts").exists())
        self.assertFalse((self.target / "docs" / "release-policy.md").exists())
        self.assertFalse((self.dist.parent / "prompts").exists())
        self.assertFalse((self.dist.parent / "docs").exists())
        self.env = _clean_env(str(tmp))
        self.assertEqual(self.env["PYTHONPATH"], "")

    def tearDown(self):
        self._tmp.cleanup()

    def _run(self, argv: list[str]):
        return subprocess.run(argv, cwd=str(self.target), env=self.env,
                              capture_output=True, text=True, timeout=120)

    def test_installed_package_is_complete_for_the_core_delivery_loop(self):
        # AC3: the copy alone must be the whole B distribution — entry
        # points, runtime modules, protocol scripts, and behavior documents.
        # #155: the canonical fenced worktree cleanup is package-owned
        # execution-runtime, so the installed copy must carry it too.
        # #166: the canonical project-AGENTS contract module (the shipped
        # managed block + the adoption/reconciliation primitive) is
        # package-owned as well — additive inventory extension.
        for rel in ("SKILL.md", "README.md",
                    "github_task/__init__.py", "github_task/core.py",
                    "github_task/cli.py", "github_task/github.py",
                    "github_task/orchestrator.py",
                    "github_task/agents_contract.py",
                    "scripts/ght.py",
                    "scripts/worktree_cleanup.py"):
            self.assertTrue((self.dist / rel).exists(),
                            f"installed package is incomplete: {rel} missing")

    def test_package_imports_stay_inside_the_package(self):
        # AC3: a static import audit over the RUNTIME surface — every
        # import in github_task/ and scripts/ is stdlib, package-relative,
        # or the package itself; no runtime module reaches for a Harry Dev
        # source-tree surface (prompts/docs siblings). (tests/ import each
        # other as sibling modules; that is suite wiring, not runtime.)
        import ast
        offenders: list[str] = []
        runtime = list((self.dist / "github_task").rglob("*.py")) + \
            list((self.dist / "scripts").rglob("*.py"))
        for py in sorted(runtime):
            tree = ast.parse(py.read_text())
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    names = [alias.name for alias in node.names]
                elif isinstance(node, ast.ImportFrom) and node.level == 0 \
                        and node.module:
                    names = [node.module]
                else:
                    continue
                for name in names:
                    root = name.split(".")[0]
                    if root in ("github_task", "tests"):
                        continue
                    if root not in sys.stdlib_module_names:
                        offenders.append(f"{py.relative_to(self.dist)}: {name}")
        self.assertEqual(offenders, [],
                         "runtime imports reach outside the installed package")

    def test_skill_document_loads_from_the_isolated_copy(self):
        # AC3/AC4b (load): the installed SKILL.md parses with the package's
        # own frontmatter parser, imported exclusively from the copy.
        code = (
            "import json, sys\n"
            f"sys.path.insert(0, {str(self.dist)!r})\n"
            "import github_task\n"
            "from github_task.core import _parse_yaml_subset, ContractError\n"
            f"text = open({str(self.dist / 'SKILL.md')!r},"
            " encoding='utf-8').read()\n"
            "import re\n"
            "fm = re.match(r'\\A---\\n(.*?)\\n---\\n', text, flags=re.DOTALL)\n"
            "assert fm, 'frontmatter missing'\n"
            "meta = _parse_yaml_subset(fm.group(1))\n"
            "print(json.dumps({'pkg': github_task.__file__,\n"
            "                  'name': meta.get('name')}))\n"
        )
        result = self._run([sys.executable, "-c", code])
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["name"], "github-task")
        # The loaded module is the installed copy, not a source-tree module.
        self.assertEqual(Path(payload["pkg"]).resolve().parents[1],
                         self.dist.resolve())

    def test_agents_adoption_runs_from_the_isolated_package(self):
        # AC1/AC2 (#166): the project-AGENTS adoption surface is part of the
        # standalone B distribution — from the isolated copy beside the
        # unrelated target repo, with a clean environment (no source tree,
        # no PYTHONPATH), `ght agents-adopt` prepares the target repo's root
        # AGENTS.md carrying exactly one canonical managed block.
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "agents_contract_isolated",
            self.dist / "github_task" / "agents_contract.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        result = self._run([sys.executable,
                            str(self.dist / "scripts" / "ght.py"),
                            "--json", "agents-adopt"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "created")
        text = (self.target / "AGENTS.md").read_text()
        self.assertEqual(text, module.MANAGED_BLOCK + "\n")
        self.assertEqual(text.count("harry-dev:agents-managed begin v"), 1)
        # idempotent from the isolated copy too
        again = self._run([sys.executable,
                           str(self.dist / "scripts" / "ght.py"),
                           "--json", "agents-adopt"])
        self.assertEqual(again.returncode, 0, again.stdout + again.stderr)
        self.assertEqual(json.loads(again.stdout.strip().splitlines()[-1])
                         ["status"], "current")

    def test_cli_help_and_version_run_beside_unrelated_repo(self):
        # AC4b (CLI): representative CLI entrypoints run with cwd in the
        # unrelated target repository and a clean environment.
        help_result = self._run(
            [sys.executable, str(self.dist / "scripts" / "ght.py"), "--help"])
        self.assertEqual(help_result.returncode, 0, help_result.stderr)
        for command in ("discover", "claim", "scope-check", "preserve",
                        "deliver", "complete"):
            self.assertIn(command, help_result.stdout)
        version_result = self._run(
            [sys.executable, str(self.dist / "scripts" / "ght.py"), "version"])
        self.assertEqual(version_result.returncode, 0, version_result.stderr)
        identity = json.loads(version_result.stdout)
        self.assertEqual(identity["product"], "harry-dev")
        # An isolated install without release provenance reports honestly
        # instead of wandering into whatever source tree might exist.
        self.assertEqual(identity["status"], "unreleased")

    def test_protocol_entrypoints_work_with_no_source_tree_access(self):
        # AC4b (protocol, behavioral no-reach-back proof): parse/digest the
        # unrelated repo's Contract under a Python audit hook that records
        # every opened file; the run must succeed and must never open a
        # path inside the Harry Dev source tree that exists on this host.
        code = (
            "import json, sys\n"
            "opened = []\n"
            "def _audit(event, args):\n"
            "    if event == 'open':\n"
            "        opened.append(str(args[0]))\n"
            "sys.addaudithook(_audit)\n"
            f"sys.path.insert(0, {str(self.dist)!r})\n"
            "from github_task.core import parse_contract, contract_digest\n"
            f"body = open({str(self.target / 'issue-42.md')!r},"
            " encoding='utf-8').read()\n"
            "contract = parse_contract(body)\n"
            "digest = contract_digest(contract)\n"
            "print(json.dumps({'digest': digest, 'opened': opened}))\n"
        )
        result = self._run([sys.executable, "-c", code])
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        # The protocol entrypoint really parsed the target repo's Contract.
        self.assertRegex(payload["digest"], r"^[0-9a-f]{16,}$")
        self.assertTrue(any("issue-42.md" in path for path in payload["opened"]))
        # Behavioral reach-back proof: nothing under the Harry Dev source
        # tree was opened, although it exists on this machine.
        reached = [path for path in payload["opened"]
                   if path.startswith(str(SOURCE_ROOT))]
        self.assertEqual(reached, [],
                         "isolated package read into the Harry Dev source tree")


if __name__ == "__main__":
    unittest.main()
