"""#166: the project AGENTS contract — one canonical, versioned managed
block shipped with the released github-task distribution, applied to the
TARGET repository safely and idempotently on first adoption.

The accepted model under test:

- **AC1** — the distribution ships ONE mechanically identifiable/versioned
  canonical AGENTS managed block (``github_task/agents_contract.py``),
  and harry-dev itself dogfoods a root ``AGENTS.md`` carrying exactly that
  block. The block is a small behavioral map of durable cross-project
  engineering/review invariants only — it never duplicates the A Prompt,
  the B Skill, Task Contract grammar, methodology, the automated-review
  workflow, repo maps, commands, or project documentation, and it grants
  no READY, execution, acceptance, merge, scheduling, or release
  authority.
- **AC2** — first adoption applies the managed block to the target
  repository idempotently: absent root ``AGENTS.md`` → a concise root
  file containing exactly the block; existing file → project-owned
  content preserved byte-for-byte and exactly one block reconciled;
  nested ``AGENTS.md`` / ``AGENTS.override.md`` instructions are never
  overwritten; material authority/security/credential conflicts in
  project-owned content are surfaced to A (fail closed — never silently
  adopted); re-running produces no duplicate block and no churn.
- **AC3** — adoption only PREPARES the bounded root-AGENTS source change
  (a working-tree proposal): the primitive never commits, never pushes,
  and integration stays on the target project's normal protected
  source-integration path.
- **AC4** — no-implicit-upgrade: a newer installed Skill never silently
  rewrites an adopted project's managed block (version-marker gated,
  fail closed); reconciliation to another block version is permitted only
  under a Harry Dev release upgrade ALREADY authorized for the project —
  the ``--upgrade`` flag is only the execution selector for that
  authorized path, never the authorization itself — and such a
  reconciliation touches ONLY the identifiable block while preserving
  project-owned content and still fails closed on material conflicts.
  The selector-only boundary is honest about its own limits: the surface
  cannot mechanically prove the prerequisite authorization (it has no
  authorization input to check), so every shipped surface states that the
  authorization must exist independently and that the flag must never be
  cited as its evidence — and the tests exercise the selector's
  mechanical effect only, never an authorization state.
  The whole malformed-marker family (mismatched begin/end versions,
  unmatched begin or end markers, doubled/nested markers) fails closed
  too — it is never reclassified as project-owned text. No registry,
  ref, database, daemon, or lifecycle state is introduced.

Every behavior is exercised offline in throwaway git repositories; the
adoption surface is purely local (no ``gh``, no network, no remote).
"""

import json
import os
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
SOURCE_ROOT = Path(__file__).parents[3]
CLI = SKILL_ROOT / "scripts" / "ght.py"
ROOT_AGENTS = SOURCE_ROOT / "AGENTS.md"

# The canonical markers of the managed block (kept in literal sync with the
# module under test so marker-scheme drift is caught even at RED time).
BEGIN_LITERAL = "harry-dev:agents-managed begin"
END_LITERAL = "harry-dev:agents-managed end"


def agents_contract():
    sys.path.insert(0, str(SKILL_ROOT))
    import github_task.agents_contract as module
    return module


def clean_env(home: str) -> dict[str, str]:
    env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"),
           "HOME": home,
           "PYTHONPATH": "",
           "GHT_DISTRIBUTION_ROOT": "",
           "GHT_INSTALLED_SKILL_DIR": "",
           "LC_ALL": "C"}
    return env


class AgentsAdoptionTests(unittest.TestCase):
    """`ght agents-adopt` against throwaway git repositories (offline)."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory(prefix="ght166-")
        self.repo = Path(self._tmp.name) / "acme-target"
        self.repo.mkdir()
        git = ["git", "-C", str(self.repo)]
        for args in (["init", "-q", "-b", "main"],
                     ["config", "user.name", "acme"],
                     ["config", "user.email", "dev@acme.example"],
                     ["config", "commit.gpgsign", "false"]):
            subprocess.run(git + args, check=True, capture_output=True)
        (self.repo / "README.md").write_text("# ACME business repo\n")
        self._git("add", ".")
        self._git("commit", "-qm", "initial")

    def tearDown(self):
        self._tmp.cleanup()

    # -- harness ---------------------------------------------------------

    def _git(self, *args):
        return subprocess.run(["git", "-C", str(self.repo), *args],
                              capture_output=True, text=True, check=True)

    def _adopt(self, *extra):
        return subprocess.run(
            [sys.executable, str(CLI), "--json", "agents-adopt", *extra],
            cwd=str(self.repo), env=clean_env(str(self._tmp.name)),
            capture_output=True, text=True, timeout=120)

    def _head(self):
        return self._git("rev-parse", "HEAD").stdout.strip()

    def _porcelain(self):
        return self._git("status", "--porcelain").stdout

    def _blocks(self, text):
        return re.findall(
            rf"<!-- {BEGIN_LITERAL} v(\d+) -->(.*?)<!-- {END_LITERAL} v(\d+) -->",
            text, flags=re.DOTALL)

    def _write_agents(self, text):
        (self.repo / "AGENTS.md").write_text(text)

    def _adopt_payload(self, result):
        return json.loads(result.stdout.strip().splitlines()[-1])

    # -- AC2: clean target repository ------------------------------------

    def test_clean_target_repo_prepares_exactly_one_concise_root_contract(self):
        # No root AGENTS.md: adoption prepares a concise root file that is
        # EXACTLY the canonical managed block — nothing else — and touches
        # no other path.
        module = agents_contract()
        self.assertFalse((self.repo / "AGENTS.md").exists())
        result = self._adopt()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "created")
        text = (self.repo / "AGENTS.md").read_text()
        self.assertEqual(text, module.MANAGED_BLOCK + "\n",
                         "the created root file is exactly the managed block")
        self.assertEqual(len(self._blocks(text)), 1)
        # exactly one block, delimited by versioned markers
        self.assertIn(f"<!-- {BEGIN_LITERAL} v{module.BLOCK_VERSION} -->", text)
        # no unrelated change: the working tree gained only AGENTS.md
        self.assertEqual(self._porcelain().split(), ["??", "AGENTS.md"])

    def test_adoption_is_idempotent_no_duplicate_or_churn(self):
        module = agents_contract()
        self.assertEqual(self._adopt().returncode, 0)
        first = (self.repo / "AGENTS.md").read_bytes()
        result = self._adopt()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "current")
        self.assertFalse(payload.get("changed"), payload)
        self.assertEqual((self.repo / "AGENTS.md").read_bytes(), first,
                         "re-adoption must not rewrite a single byte")
        self.assertEqual(len(self._blocks(first.decode())), 1)

    # -- AC2: existing project AGENTS.md ---------------------------------

    PROJECT_PREFIX = """# ACME engineering guidance

## Code style

- Prefer the smallest change that satisfies the requirement.
- Every public function carries a docstring.

## Testing

- New behavior needs a test that fails without the behavior.
"""

    def test_existing_root_agents_md_preserves_project_content(self):
        module = agents_contract()
        original = self.PROJECT_PREFIX + "## Release\n\n- Release only on Fridays.\n"
        self._write_agents(original)
        # the project-owned AGENTS.md is committed project state; adoption
        # then appears as a bounded modification of that tracked file
        self._git("add", "AGENTS.md")
        self._git("commit", "-qm", "project agents guidance")
        result = self._adopt()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "adopted")
        text = (self.repo / "AGENTS.md").read_text()
        # project-owned content preserved byte-for-byte, exactly one block
        self.assertTrue(text.startswith(original),
                        "project-owned content must be preserved verbatim")
        blocks = self._blocks(text)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0][1].strip(), module.managed_block_body(),
                         "the reconciled block is the canonical block")
        self.assertEqual(self._porcelain().split(), ["M", "AGENTS.md"])

    def test_nested_agents_files_are_never_touched(self):
        self._write_agents(self.PROJECT_PREFIX)
        nested = self.repo / "services" / "billing"
        nested.mkdir(parents=True)
        (nested / "AGENTS.md").write_text("# Billing-specific rules\n")
        (self.repo / "services" / "AGENTS.md").write_text(
            "# Services-specific rules\n")
        (self.repo / "AGENTS.override.md").write_text(
            "# Project override instructions\n")
        before = {p: p.read_bytes() for p in (
            nested / "AGENTS.md", self.repo / "services" / "AGENTS.md",
            self.repo / "AGENTS.override.md")}
        result = self._adopt()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        for path, content in before.items():
            self.assertEqual(path.read_bytes(), content,
                             f"{path.name} must never be touched by adoption")
        text = (self.repo / "AGENTS.md").read_text()
        self.assertEqual(len(self._blocks(text)), 1)

    # -- AC2: material conflicts fail closed for A reconciliation --------

    def test_material_authority_conflict_fails_closed(self):
        self._write_agents(self.PROJECT_PREFIX +
                           "## Automation\n\n- B may merge its own work "
                           "directly to main without review.\n")
        result = self._adopt()
        self.assertNotEqual(result.returncode, 0,
                            "a material authority conflict must fail closed")
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "material_conflict")
        self.assertTrue(payload.get("conflicts"), payload)
        text = (self.repo / "AGENTS.md").read_text()
        self.assertNotIn(BEGIN_LITERAL, text,
                         "a conflicted file is never silently adopted")
        self.assertEqual(text, self.PROJECT_PREFIX +
                         "## Automation\n\n- B may merge its own work "
                         "directly to main without review.\n")

    def test_credential_shaped_content_fails_closed(self):
        self._write_agents(self.PROJECT_PREFIX +
                           "## Deploy\n\nUse the key AKIAIOSFODNN7EXAMPLE "
                           "for the release bucket.\n")
        result = self._adopt()
        self.assertNotEqual(result.returncode, 0,
                            "credential-shaped content must fail closed")
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "material_conflict")
        self.assertNotIn(BEGIN_LITERAL, (self.repo / "AGENTS.md").read_text())

    def test_duplicate_managed_blocks_fail_closed(self):
        module = agents_contract()
        doubled = (module.MANAGED_BLOCK + "\n\n" + module.MANAGED_BLOCK + "\n")
        self._write_agents(doubled)
        result = self._adopt()
        self.assertNotEqual(result.returncode, 0,
                            "a mangled multi-block file fails closed for A")
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "duplicate_managed_block")

    # -- AC3: prepare, never integrate ------------------------------------

    def test_adoption_prepares_a_working_tree_change_and_never_integrates(self):
        head_before = self._head()
        result = self._adopt()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self._head(), head_before,
                         "adoption must never create a commit")
        self.assertEqual(self._porcelain().split(), ["??", "AGENTS.md"])
        # ... and no push target is consulted: the run above had no remote.

    def test_adopt_refuses_outside_a_git_repository(self):
        bare = Path(self._tmp.name) / "not-a-repo"
        bare.mkdir()
        result = subprocess.run(
            [sys.executable, str(CLI), "--json", "agents-adopt"],
            cwd=str(bare), env=clean_env(str(self._tmp.name)),
            capture_output=True, text=True, timeout=120)
        self.assertNotEqual(result.returncode, 0)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertIn("git", payload["error"].lower())

    def test_adopt_refuses_a_non_regular_agents_file(self):
        (self.repo / "AGENTS.md").symlink_to("README.md")
        result = self._adopt()
        self.assertNotEqual(result.returncode, 0,
                            "a symlinked AGENTS.md must fail closed")
        self.assertTrue((self.repo / "AGENTS.md").is_symlink())

    # -- AC4: no-implicit-upgrade; --upgrade is a selector, not a grant ---

    def test_newer_skill_never_implicitly_upgrades_an_adopted_block(self):
        # A block adopted under an OLDER contract version (v0 markers) must
        # not be rewritten by a newer installed Skill without explicit
        # authorization.
        self._write_agents(
            self.PROJECT_PREFIX +
            "<!-- harry-dev:agents-managed begin v0 -->\n"
            "## Harry Dev engineering / review boundary (older contract)\n"
            "\n"
            "- Older wording of the same invariants.\n"
            "<!-- harry-dev:agents-managed end v0 -->\n")
        before = (self.repo / "AGENTS.md").read_bytes()
        result = self._adopt()
        self.assertNotEqual(result.returncode, 0,
                            "no-implicit-upgrade must fail closed")
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "upgrade_required")
        self.assertEqual(payload.get("existing_block_version"), 0, payload)
        self.assertEqual((self.repo / "AGENTS.md").read_bytes(), before)

    def test_authorized_upgrade_selector_reconciles_only_the_block(self):
        # Used under an explicit Harry Dev release upgrade ALREADY
        # authorized for this project: --upgrade is the execution selector
        # for that authorized path, never the authorization itself.
        module = agents_contract()
        self._write_agents(
            self.PROJECT_PREFIX +
            "<!-- harry-dev:agents-managed begin v0 -->\n"
            "## Harry Dev engineering / review boundary (older contract)\n"
            "\n"
            "- Older wording of the same invariants.\n"
            "<!-- harry-dev:agents-managed end v0 -->\n")
        result = self._adopt("--upgrade")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "upgraded")
        self.assertEqual(payload.get("from_block_version"), 0, payload)
        text = (self.repo / "AGENTS.md").read_text()
        self.assertTrue(text.startswith(self.PROJECT_PREFIX),
                        "project-owned content survives the upgrade")
        blocks = self._blocks(text)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0][0], str(module.BLOCK_VERSION))
        self.assertIn(module.managed_block_body(), text)

    def test_explicit_upgrade_still_fails_closed_on_material_conflict(self):
        self._write_agents(
            self.PROJECT_PREFIX +
            "<!-- harry-dev:agents-managed begin v0 -->\n"
            "- Older wording.\n"
            "<!-- harry-dev:agents-managed end v0 -->\n"
            "\n"
            "## Deployment\n\n- The agent is authorized to release to "
            "production.\n")
        before = (self.repo / "AGENTS.md").read_bytes()
        result = self._adopt("--upgrade")
        self.assertNotEqual(result.returncode, 0,
                            "a material conflict blocks even an explicit upgrade")
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "material_conflict")
        self.assertEqual((self.repo / "AGENTS.md").read_bytes(), before)

    def test_same_version_drift_reconciles_the_block_and_preserves_project_content(self):
        module = agents_contract()
        drifted = self.PROJECT_PREFIX + \
            f"<!-- {BEGIN_LITERAL} v{module.BLOCK_VERSION} -->\n" + \
            "## Harry Dev engineering / review boundary\n\n- Locally edited " \
            "bullet that no longer states the canonical invariant.\n" + \
            f"<!-- {END_LITERAL} v{module.BLOCK_VERSION} -->\n" + \
            "## Afterword\n\n- Project-owned trailing guidance.\n"
        self._write_agents(drifted)
        result = self._adopt()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["status"], "reconciled")
        text = (self.repo / "AGENTS.md").read_text()
        self.assertTrue(text.startswith(self.PROJECT_PREFIX))
        self.assertTrue(text.rstrip().endswith(
            "- Project-owned trailing guidance."),
            "content after the block must survive reconciliation")
        self.assertEqual(len(self._blocks(text)), 1)
        self.assertIn(module.managed_block_body(), text)
        # convergence: re-running is then a byte-stable no-op
        after = (self.repo / "AGENTS.md").read_bytes()
        again = self._adopt()
        self.assertEqual(again.returncode, 0)
        self.assertEqual((self.repo / "AGENTS.md").read_bytes(), after)

    # -- review correction: the malformed-marker family fails closed -----

    def test_malformed_marker_family_fails_closed_in_reconcile(self):
        # The WHOLE malformed-marker family fails closed: a Harry Dev
        # managed marker that is not part of a well-formed, version-matched
        # begin/end pair is never reclassified as project-owned text and
        # then adopted/reconciled alongside a new or current block.
        module = agents_contract()
        current = module.BLOCK_VERSION
        older = current - 1 if current > 1 else current + 1
        malformed = {
            "begin v0 / end v1 (mismatched versions)":
                "<!-- harry-dev:agents-managed begin v0 -->\n- body\n"
                "<!-- harry-dev:agents-managed end v1 -->\n",
            f"begin v{current} / end v{older} (mismatched versions)":
                f"<!-- {BEGIN_LITERAL} v{current} -->\n- body\n"
                f"<!-- {END_LITERAL} v{older} -->\n",
            "bare begin marker (no end marker)":
                "<!-- harry-dev:agents-managed begin v0 -->\n"
                "- half-removed block body without any end marker\n",
            "bare end marker (no begin marker)":
                "- ordinary guidance\n\n"
                "<!-- harry-dev:agents-managed end v0 -->\n",
            "unmatched end marker before an otherwise valid block":
                "<!-- harry-dev:agents-managed end v0 -->\n\n"
                + module.MANAGED_BLOCK + "\n",
            "stray end marker after a complete block":
                module.MANAGED_BLOCK + "\n\n"
                "<!-- harry-dev:agents-managed end v0 -->\n",
            "doubled/nested begin marker":
                "<!-- harry-dev:agents-managed begin v0 -->\n"
                f"<!-- {BEGIN_LITERAL} v{current} -->\n"
                f"<!-- {END_LITERAL} v{current} -->\n",
        }
        for label, text in malformed.items():
            with self.subTest(case=label):
                # unit level: the structure is uninterpretable, not
                # project-owned text
                with self.assertRaises(module.MalformedManagedMarkersError):
                    module.find_managed_blocks("## Project\n\n" + text)
                # decision level: fail closed for A reconciliation
                decision = module.reconcile("## Project\n\n" + text)
                self.assertEqual(decision["status"], "malformed_markers",
                                 decision)
                self.assertEqual(decision["action"], "refuse")
                self.assertNotIn("content", decision,
                                 "a refusal never carries a prepared write")

    def test_malformed_markers_fail_closed_at_the_cli_and_change_nothing(self):
        before_cases = {
            "bare begin marker":
                self.PROJECT_PREFIX +
                "<!-- harry-dev:agents-managed begin v0 -->\n"
                "- half-removed block: begin without any end marker\n",
            "mismatched begin/end versions":
                self.PROJECT_PREFIX +
                "<!-- harry-dev:agents-managed begin v0 -->\n"
                "- older body\n"
                "<!-- harry-dev:agents-managed end v1 -->\n",
            "bare end marker":
                self.PROJECT_PREFIX +
                "- guidance\n\n<!-- harry-dev:agents-managed end v0 -->\n",
        }
        for label, text in before_cases.items():
            with self.subTest(case=label):
                self._write_agents(text)
                before = (self.repo / "AGENTS.md").read_bytes()
                result = self._adopt()
                self.assertNotEqual(
                    result.returncode, 0,
                    "malformed marker state must fail closed")
                payload = self._adopt_payload(result)
                self.assertEqual(payload["status"], "malformed_markers",
                                 payload)
                self.assertEqual((self.repo / "AGENTS.md").read_bytes(),
                                 before, "the file is preserved unchanged")
                # the upgrade selector cannot launder a malformed state
                again = self._adopt("--upgrade")
                self.assertNotEqual(again.returncode, 0)
                self.assertEqual((self.repo / "AGENTS.md").read_bytes(),
                                 before)

    # -- review correction: --upgrade is an execution selector, never the
    #    authorization itself (AC4) ---------------------------------------

    def test_upgrade_required_refusal_never_presents_the_flag_as_authorization(self):
        module = agents_contract()
        older_block_file = (
            self.PROJECT_PREFIX +
            "<!-- harry-dev:agents-managed begin v0 -->\n"
            "## Harry Dev engineering / review boundary (older contract)\n"
            "\n"
            "- Older wording of the same invariants.\n"
            "<!-- harry-dev:agents-managed end v0 -->\n")
        self._write_agents(older_block_file)
        before = (self.repo / "AGENTS.md").read_bytes()
        result = self._adopt()
        self.assertNotEqual(result.returncode, 0)
        payload = self._adopt_payload(result)
        self.assertEqual(payload["status"], "upgrade_required")
        # The old wording said a release upgrade "authorizes
        # `ght agents-adopt --upgrade`" — the flag presented as the grant.
        # The refusal must state the true AC4 direction: the authorization
        # must ALREADY exist, and the flag is only its execution selector.
        reason = module.reconcile(older_block_file)["reason"] \
            + " " + payload.get("error", "")
        self.assertNotRegex(reason, r"authoriz\w+\s+`ght agents-adopt")
        self.assertIn("already", reason)
        self.assertIn("execution selector", reason)
        self.assertEqual((self.repo / "AGENTS.md").read_bytes(), before)

    def test_shipped_surfaces_never_treat_the_upgrade_flag_as_the_grant(self):
        # The supported B path (this Skill + its docs + the shipped
        # surfaces) must be unambiguous: --upgrade is an execution selector
        # used under independently established authorization; no shipped
        # surface may present the flag as the grant, and none may imply
        # running it establishes the prerequisite project authorization.
        # Each shipped surface must also state the honest limit of the
        # selector-only design: the surface cannot mechanically prove the
        # prerequisite authorization, so the authorization is required to
        # exist independently and the flag is never its evidence.
        module = agents_contract()
        surfaces = {
            "github_task/agents_contract.py":
                Path(module.__file__).read_text(),
            "github_task/cli.py":
                (SKILL_ROOT / "github_task" / "cli.py").read_text(),
            "SKILL.md": (SKILL_ROOT / "SKILL.md").read_text(),
            "skills/github-task/README.md":
                (SKILL_ROOT / "README.md").read_text(),
            "README.md": (SOURCE_ROOT / "README.md").read_text(),
            "docs/adoption.md":
                (SOURCE_ROOT / "docs" / "adoption.md").read_text(),
        }
        banned_equations = (
            "authorizes `ght agents-adopt --upgrade`",
            "--upgrade is the explicit authorized",
            "explicitly authorized upgrade (`ght agents-adopt --upgrade`)",
            "authorized-upgrade surface",
            "explicitly authorized upgrade of the managed block",
        )
        # Per-surface anchor of the honesty statement: the surface says it
        # cannot mechanically prove/verify the prerequisite authorization.
        honesty_anchors = {
            "github_task/agents_contract.py": "cannot detect mechanically",
            "github_task/cli.py": "cannot mechanically",
            "SKILL.md": "cannot mechanically",
            "skills/github-task/README.md": "cannot mechanically",
            "README.md": "cannot mechanically",
            "docs/adoption.md": "cannot mechanically",
        }
        for name, text in surfaces.items():
            flat = " ".join(text.split())
            for banned in banned_equations:
                self.assertNotIn(
                    banned, text,
                    f"{name} presents the --upgrade flag as the grant")
            self.assertIn(
                " ".join(honesty_anchors[name].split()), flat,
                f"{name} must state that the surface cannot mechanically "
                "prove the prerequisite upgrade authorization")
        # positively: the supported B path states the selector semantics
        self.assertIn("execution selector", surfaces["SKILL.md"])
        self.assertIn("not itself the authorization", surfaces["SKILL.md"])
        self.assertIn("execution selector",
                      surfaces["github_task/agents_contract.py"])

    def test_reconcile_upgrade_selector_performs_no_mechanical_authorization_gate(self):
        # Pins the CHOSEN boundary exactly (the Contract permits the
        # selector-only design): reconcile() has no authorization input to
        # verify — with the selector set it performs the version-changing
        # write, full stop. Nothing in the surface refuses a missing
        # authorization, so no evidence may claim a mechanical refusal; the
        # honesty statement lives in the contract docstring and is pinned
        # here so the shipped surfaces can never drift back into implying
        # mechanical authorization proof.
        module = agents_contract()
        older_block = (
            self.PROJECT_PREFIX +
            "<!-- harry-dev:agents-managed begin v0 -->\n"
            "- Older contract wording.\n"
            "<!-- harry-dev:agents-managed end v0 -->\n")
        decision = module.reconcile(older_block, upgrade_selector=True)
        self.assertEqual(decision["action"], "write")
        self.assertEqual(decision["status"], "upgraded")
        self.assertEqual(decision.get("from_block_version"), 0)
        # the honesty statement is part of the shipped contract surface
        # (matched whitespace-insensitively: prose reflows must not defeat it)
        self.assertIn("cannot detect mechanically",
                      " ".join((module.reconcile.__doc__ or "").split()))

    # -- AC1: the shipped block itself ------------------------------------

    def test_shipped_block_carries_the_canonical_semantic_set(self):
        module = agents_contract()
        block = module.MANAGED_BLOCK
        # mechanically identifiable + versioned
        self.assertRegex(block, rf"<!-- {BEGIN_LITERAL} v\d+ -->")
        self.assertRegex(block, rf"<!-- {END_LITERAL} v\d+ -->")
        self.assertGreaterEqual(module.BLOCK_VERSION, 1)
        # the canonical minimum semantic set (exact wording is HOW)
        for anchor in (
                "Task Contract",
                "WHAT",
                "BOUNDARY",
                "DONE",
                "durable project engineering",
                "review guidance",
                "no READY, execution, acceptance, merge, scheduling, or "
                "release authority",
                "correctness",
                "regressions",
                "Contract/scope violations",
                "weak or missing tests",
                "security/data-integrity",
                "evidence, not proof",
                "negative path",
                "constructs the failure",
                "acceptance/integration authority",
                "User-owned"):
            self.assertIn(anchor, block, f"semantic anchor missing: {anchor!r}")
        # a small behavioral map only: it never duplicates the owned surfaces
        for banned in ("ght claim", "ght discover", "ght deliver",
                       "ght acquire", "ght scope-check", "superpowers",
                       "Superpowers", "refs/ght", "ght-contract\nversion:",
                       "```ght-contract", "ready label", "one-shot"):
            self.assertNotIn(banned, block,
                             f"the managed block must not duplicate owned "
                             f"surface content: {banned!r}")
        # concise
        self.assertLessEqual(len(block.splitlines()), 14,
                             "the managed block stays concise")

    def test_harry_dev_dogfoods_the_same_contract(self):
        module = agents_contract()
        self.assertTrue(ROOT_AGENTS.exists(),
                        "harry-dev must dogfood a root AGENTS.md")
        text = ROOT_AGENTS.read_text()
        blocks = re.findall(
            rf"<!-- {BEGIN_LITERAL} v(\d+) -->(.*?)<!-- {END_LITERAL} v(\d+) -->",
            text, flags=re.DOTALL)
        self.assertEqual(len(blocks), 1,
                         "the dogfooded root file carries exactly one block")
        self.assertEqual(blocks[0][0], str(module.BLOCK_VERSION))
        self.assertEqual(blocks[0][1].strip(), module.managed_block_body(),
                         "the dogfooded block is byte-identical to the "
                         "shipped canonical block")
        # the dogfood stays minimal: the file is the block (the contract's
        # own heading inside the block), not a second project doc
        self.assertLessEqual(len(text.splitlines()), 16)


if __name__ == "__main__":
    unittest.main()
