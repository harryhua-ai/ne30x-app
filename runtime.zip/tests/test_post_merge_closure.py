"""Post-merge Issue closure convergence for #171.

#166 exposed the gap: A's durable exact-Candidate acceptance + matching PR
merge + successful canonical `ght complete` still left the Issue OPEN until A
closed it by hand. The correction makes the canonical completion perform the
mechanical Issue close (state_reason completed) as the final reconciliation
step of the A-owned acceptance the completion already proves — never as an
independent DONE authority:

- close only when ALL of (durable exact-SHA A acceptance on the merged PR,
  merged head == that Candidate, terminal completion record) are proven from
  the same authoritative surfaces completion itself uses — AC2;
- missing or contradictory evidence fails closed without touching the Issue,
  a failed close mutation fails the command (never a silent "success" that
  leaves #166's observed state), and a retry converges idempotently — AC3;
- an already-closed Issue is never reopened or re-reasoned: converged
  success ONLY when its durable state_reason is already `completed`
  (A's own closure decision); any other/unknown reason is preserved
  untouched but is NOT successful convergence — the command fails closed
  (AC1: success is reported only when durable truth proves CLOSED with
  state_reason completed; A alone owns the lifecycle decision).

The tests run the real CLI against a local bare remote with the scripted
``gh``/``git`` pair, exactly like the rest of the runtime suite.
"""

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
CLI = SKILL_ROOT / "scripts" / "ght.py"
REAL_GIT = shutil.which("git")
sys.path.insert(0, str(SKILL_ROOT))
sys.path.insert(0, str(SKILL_ROOT / "tests"))

from test_cli_safety import MOCK_GH, GIT_WRAPPER, IMPL_CONTRACT, issue_body  # noqa: E402

CLAIM_REF = "refs/ght/claims/10"


def accept_comment(candidate_sha):
    return {"body": "A REVIEW — ACCEPTED\n\nReviewed exact Candidate:\n`" + candidate_sha + "`\n"}


def approved_review(candidate_sha):
    return {"state": "APPROVED", "commit_id": candidate_sha}


class PostMergeIssueClosureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ght-post-merge-closure-"))
        self.origin = self.tmp / "origin.git"
        self.state = self.tmp / "issues.json"
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        self._write_executable(self.bin / "gh", MOCK_GH)
        self._write_executable(self.bin / "git", GIT_WRAPPER)
        self._git(self.tmp, "init", "--bare", str(self.origin), "-b", "main")
        seed = self.tmp / "seed"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(seed))
        (seed / "README.md").write_text("seed\n")
        self._git(seed, "add", ".")
        self._git(seed, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "seed")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        self.repo = self.tmp / "worker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(self.repo))
        self._git(self.repo, "config", "user.email", "w@t")
        self._git(self.repo, "config", "user.name", "w")
        self.state.write_text(json.dumps({
            "10": {"number": 10, "title": "Task ten", "state": "OPEN",
                   "stateReason": None,
                   "url": "https://github.com/example/repo/issues/10",
                   "body": issue_body(IMPL_CONTRACT), "labels": ["ready"], "comments": []},
        }, indent=2))
        self._env = {
            "PATH": f"{self.bin}:{os.environ['PATH']}",
            "GHT_TEST_STATE": str(self.state),
            "GHT_TEST_REAL_GIT": REAL_GIT,
            "GHT_EXECUTOR_ID": "worker-1",
            "GHT_LEASE_MINUTES": "45",
            "GHT_SPAWN_SUPERVISOR": "0",
            "GIT_AUTHOR_NAME": "w", "GIT_AUTHOR_EMAIL": "w@t",
            "GIT_COMMITTER_NAME": "w", "GIT_COMMITTER_EMAIL": "w@t",
        }

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    # -- harness --------------------------------------------------------

    def _write_executable(self, path, content):
        path.write_text(content)
        path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    def _git(self, cwd, *args, input_text=None):
        return subprocess.run([REAL_GIT, *args], cwd=cwd, capture_output=True, text=True,
                              env={**os.environ}, input=input_text)

    def _ght(self, *args, env_extra=None):
        env = {**self._env, **(env_extra or {})}
        return subprocess.run([sys.executable, str(CLI), "--json", *args],
                              cwd=str(self.repo), capture_output=True, text=True, env=env)

    def _ght_ok(self, *args, env_extra=None):
        result = self._ght(*args, env_extra=env_extra)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return json.loads(result.stdout)

    def _ght_fail(self, *args, env_extra=None):
        result = self._ght(*args, env_extra=env_extra)
        self.assertNotEqual(result.returncode, 0,
                            f"expected failure, got: {result.stdout} {result.stderr}")
        return result.stdout + result.stderr

    def _issue(self, number=10):
        return json.loads(self.state.read_text())[str(number)]

    def _update_issue(self, number, **changes):
        data = json.loads(self.state.read_text())
        data[str(number)].update(changes)
        self.state.write_text(json.dumps(data, indent=2))

    def _inspect(self, number=10):
        return self._ght_ok("inspect", str(number))

    def _parked(self, number=10, pr=60):
        """Drive one attempt to the parked condition: durable Candidate
        delivery, capacity released, attempt still non-terminal."""
        claim = self._ght_ok("claim", str(number))
        self._git(self.repo, "checkout", "-q", "-b", claim["branch"], "origin/main")
        path = self.repo / "skills" / "demo.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("demo\n")
        self._git(self.repo, "add", "skills/demo.txt")
        self._git(self.repo, "commit", "-qm", "add demo")
        sha = self._git(self.repo, "rev-parse", "HEAD").stdout.strip()
        self._ght_ok("preserve", str(number))
        self.state.write_text(json.dumps({
            **json.loads(self.state.read_text()),
            str(pr): {"number": pr, "is_pr": True, "state": "OPEN",
                      "url": f"https://github.com/example/repo/pull/{pr}",
                      "headRefName": claim["branch"], "headRefOid": sha,
                      "mergeCommit": None, "reviews": [], "pr_comments": []},
        }, indent=2))
        self._ght_ok("deliver", str(number), "--pr", str(pr))
        return claim, sha

    def _merge_with_acceptance(self, pr, sha, *, source="review"):
        """A merges the Candidate PR and leaves the durable exact-SHA
        acceptance on the PR (native APPROVED review or structured comment)."""
        evidence = (approved_review(sha) if source == "review"
                    else None)
        comments = [] if source == "review" else [accept_comment(sha)]
        self._update_issue(pr, state="MERGED", headRefName=None,
                           headRefOid=sha,
                           mergeCommit={"oid": "m" * 40},
                           reviews=[evidence] if evidence else [],
                           pr_comments=comments)

    def _rewrite_claim_record(self, mutate):
        """Hand-craft one claim-ref mutation (simulates corrupted/forged
        durable state the runtime must fail closed on)."""
        current = self._inspect(10)
        record = mutate(json.loads(json.dumps(current["claim"])))
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(record, indent=1)).stdout.strip()
        tree = self._git(self.repo, "mktree",
                         input_text=f"100644 blob {blob}\tCLAIM.json\n").stdout.strip()
        commit = self._git(self.repo, "commit-tree", tree, "-p", current["claim_sha"],
                           "-m", "ght: hand-crafted record").stdout.strip()
        pushed = self._git(self.repo, "push", "--force", "origin", f"{commit}:{CLAIM_REF}")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)

    # -- the convergence (AC1) -----------------------------------------

    def test_successful_completion_closes_issue_with_state_reason_completed(self):
        # Durable exact-Candidate A acceptance (native APPROVED review bound
        # to the Candidate SHA) + matching merge + canonical completion → the
        # Issue converges to CLOSED with state_reason completed. #166's
        # observed "completion marker present but Issue OPEN" is no longer a
        # normal successful output.
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="review")
        payload = self._ght_ok("complete", "10", "--pr", "60")
        self.assertEqual(payload["status"], "delivered")
        self.assertEqual(payload["issue_closure"]["action"], "closed")
        self.assertEqual(payload["issue_closure"]["state_reason"], "COMPLETED")
        issue = self._issue()
        self.assertEqual(issue["state"], "CLOSED")
        self.assertEqual(issue["stateReason"], "COMPLETED")
        # The completion evidence comment still lands (idempotency marker).
        self.assertTrue(any("ght:complete:" in c["body"] for c in issue["comments"]))

    def test_failed_close_is_not_a_normal_success_and_retry_converges(self):
        # AC1+AC3: when the close mutation fails, the completion must NOT
        # exit 0 with the Issue left OPEN (that is exactly #166's observed
        # state); the attempt stays terminal and the idempotent retry —
        # which re-proves acceptance from durable truth first — converges.
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="comment")
        output = self._ght_fail("complete", "10", "--pr", "60",
                                env_extra={"GHT_TEST_FAIL_ISSUE_CLOSE": "1"})
        self.assertIn("Issue close failed", output)
        self.assertEqual(self._issue()["state"], "OPEN",
                         "a failed close must not be reported as success")
        self.assertEqual(self._inspect(10)["claim"]["status"], "delivered",
                         "the attempt itself stays terminal")
        payload = self._ght_ok("complete", "10", "--pr", "60")
        self.assertEqual(payload["issue_closure"]["action"], "closed")
        issue = self._issue()
        self.assertEqual(issue["state"], "CLOSED")
        self.assertEqual(issue["stateReason"], "COMPLETED")

    def test_retry_on_converged_issue_is_idempotent_noop(self):
        # AC3: re-running completion after convergence stays a green no-op —
        # even with the close surface "failing", because an already-closed
        # Issue is never mutated (never reopened, never re-reasoned).
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="review")
        first = self._ght_ok("complete", "10", "--pr", "60")
        self.assertEqual(first["issue_closure"]["action"], "closed")
        again = self._ght_ok("complete", "10", "--pr", "60",
                             env_extra={"GHT_TEST_FAIL_ISSUE_CLOSE": "1"})
        self.assertEqual(again["status"], "delivered")
        self.assertEqual(again["issue_closure"]["action"], "none")
        issue = self._issue()
        self.assertEqual(issue["state"], "CLOSED")
        self.assertEqual(issue["stateReason"], "COMPLETED")

    def test_pre_closed_other_reason_is_preserved_but_not_converged(self):
        # A manually closed the Issue with a non-completed reason
        # (NOT_PLANNED) before the reconciler ran: the mechanical close must
        # not overwrite A's manual lifecycle decision — never reopened,
        # never re-reasoned, state untouched. But preserving the state is
        # NOT successful completion convergence (A review of b3e567e): AC1's
        # terminal state (CLOSED + state_reason completed) is not true, so
        # `ght complete` must not report success — it fails closed while
        # leaving A's lifecycle decision exactly as it is.
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="comment")
        self._update_issue(10, state="CLOSED", stateReason="NOT_PLANNED")
        output = self._ght_fail("complete", "10", "--pr", "60")
        self.assertIn("state_reason", output)
        self.assertIn("NOT_PLANNED", output)
        self.assertEqual(self._inspect(10)["claim"]["status"], "delivered",
                         "the attempt itself stays terminal")
        issue = self._issue()
        self.assertEqual(issue["state"], "CLOSED",
                         "A's lifecycle decision is preserved untouched")
        self.assertEqual(issue["stateReason"], "NOT_PLANNED",
                         "never re-reasoned")

    def test_retry_on_preserved_other_reason_stays_nonconverged(self):
        # The same preserved-but-nonconverged semantics hold on retry: no
        # provenance distinction between a pre-existing manual closure and a
        # partial-success residue (A review of b3e567e) — a CLOSED Issue
        # with a non-completed reason never becomes a green `ght complete`.
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="comment")
        self._update_issue(10, state="CLOSED", stateReason="NOT_PLANNED")
        output = self._ght_fail("complete", "10", "--pr", "60")
        self.assertIn("NOT_PLANNED", output)
        again = self._ght_fail("complete", "10", "--pr", "60")
        self.assertIn("NOT_PLANNED", again)
        issue = self._issue()
        self.assertEqual(issue["state"], "CLOSED")
        self.assertEqual(issue["stateReason"], "NOT_PLANNED",
                         "retry neither re-reasons nor converges it green")

    def test_contradictory_post_close_reason_fails_closed_and_retry_stays_nonconverged(self):
        # AC1+AC3 adversarial (A review of d05c4fa): the close command
        # reports SUCCESS, but a fresh durable read shows the Issue CLOSED
        # with a CONTRADICTORY state_reason (e.g. a concurrent/manual "not
        # planned" transition wins the race). That must NOT be a normal
        # successful completion — AC1's terminal state (CLOSED +
        # state_reason completed) is unproven, so the command fails closed
        # instead of returning success for whatever reason it happens to
        # observe. This constructs the contradictory post-close reason
        # itself; it is not a simulated command failure (that is the
        # GHT_TEST_FAIL_ISSUE_CLOSE case above). The attempt stays terminal.
        # The residue is an already-CLOSED Issue with a non-completed
        # reason: on retry it is preserved untouched (never reopened, never
        # re-reasoned) and stays NON-converged (A review of b3e567e) — no
        # provenance distinction from a pre-existing manual closure, and no
        # green `ght complete` until A's lifecycle truth says completed.
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="comment")
        output = self._ght_fail("complete", "10", "--pr", "60",
                                env_extra={"GHT_TEST_CLOSE_REASON_OVERRIDE": "NOT_PLANNED"})
        self.assertIn("state_reason", output)
        self.assertIn("NOT_PLANNED", output)
        issue = self._issue()
        self.assertEqual(issue["state"], "CLOSED",
                         "the residue the surface actually wrote")
        self.assertEqual(issue["stateReason"], "NOT_PLANNED")
        self.assertEqual(self._inspect(10)["claim"]["status"], "delivered",
                         "the attempt itself stays terminal")
        again = self._ght_fail("complete", "10", "--pr", "60")
        self.assertIn("NOT_PLANNED", again)
        issue = self._issue()
        self.assertEqual(issue["state"], "CLOSED")
        self.assertEqual(issue["stateReason"], "NOT_PLANNED",
                         "an already-closed Issue is never re-reasoned, and a "
                         "non-completed reason never converges green")

    # -- fail-closed evidence boundaries (AC3) --------------------------

    def test_completion_without_acceptance_fails_closed_and_never_closes(self):
        # A merged the PR but left no durable exact-SHA acceptance: the
        # canonical acceptance predicate refuses, the attempt never
        # terminalizes, and the Issue stays OPEN.
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="comment")
        self._update_issue(60, reviews=[], pr_comments=[])
        output = self._ght_fail("complete", "10", "--pr", "60")
        self.assertIn("no durable A acceptance", output)
        self.assertEqual(self._issue()["state"], "OPEN")
        self.assertEqual(self._inspect(10)["claim"]["status"], "active")

    def test_terminal_completion_without_acceptance_fails_closed_and_never_closes(self):
        # The sharpest forged-evidence shape: a terminal `delivered` claim
        # WITH a completion record, but the acceptance evidence has vanished
        # and the Issue is still open (partial-success residue). The closure
        # re-proves the shared canonical acceptance predicate first and
        # fails closed; restoring the evidence lets the retry converge.
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="comment")
        self._ght_fail("complete", "10", "--pr", "60",
                       env_extra={"GHT_TEST_FAIL_ISSUE_CLOSE": "1"})
        self.assertEqual(self._inspect(10)["claim"]["status"], "delivered")
        self._update_issue(60, reviews=[], pr_comments=[])
        output = self._ght_fail("complete", "10", "--pr", "60")
        self.assertIn("no durable A acceptance", output)
        self.assertEqual(self._issue()["state"], "OPEN")
        self._update_issue(60, pr_comments=[accept_comment(sha)])
        self._ght_ok("complete", "10", "--pr", "60")
        issue = self._issue()
        self.assertEqual(issue["state"], "CLOSED")
        self.assertEqual(issue["stateReason"], "COMPLETED")

    def test_merged_head_identity_mismatch_never_closes(self):
        # AC3: contradictory merge identity — the PR reports a head that is
        # not the preserved Candidate — never terminalizes and never closes.
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="comment")
        self._update_issue(60, headRefOid="0" * 40)
        output = self._ght_fail("complete", "10", "--pr", "60")
        self.assertIn("head does not equal the preserved Candidate", output)
        self.assertEqual(self._issue()["state"], "OPEN")
        self.assertEqual(self._inspect(10)["claim"]["status"], "active")

    def test_terminal_record_without_completion_evidence_fails_closed(self):
        # AC3: a terminal claim whose completion record is missing (corrupted
        # durable state) is refused outright — nothing closes.
        _claim, sha = self._parked(10)
        self._merge_with_acceptance(60, sha, source="review")
        self._ght_ok("complete", "10", "--pr", "60")
        self._update_issue(10, state="OPEN", stateReason=None)  # unconverged residue
        self._rewrite_claim_record(lambda record: {
            key: value for key, value in record.items() if key != "completed"})
        output = self._ght_fail("complete", "10", "--pr", "60")
        self.assertIn("terminal without a completion record", output)
        self.assertEqual(self._issue()["state"], "OPEN")


if __name__ == "__main__":
    unittest.main()
