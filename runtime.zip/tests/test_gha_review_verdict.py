"""Regression tests for the GitHub-only, exact-SHA review check."""

import importlib.util
import hashlib
import io
import json
import sys
import unittest
import zipfile
from pathlib import Path
from unittest.mock import Mock, patch


SKILL_ROOT = Path(__file__).parents[1]
SCRIPT = SKILL_ROOT / "scripts" / "ght-gha-review-verdict.py"
WORKFLOW = SKILL_ROOT.parent.parent / ".github" / "workflows" / "ght-complete.yml"
sys.path.insert(0, str(SKILL_ROOT))

from github_task.core import ACCEPTANCE_HEADER, evaluate_exact_sha_acceptance


CANDIDATE_SHA = "445704cd33804d109b695e59263573f4a9c1a7df"
OTHER_SHA = "a" * 40
CLAIM_ID = "executor-20261010T095505-34cc423c"
BRANCH = "agent/45/3a8140af"
DELIVERED_AT = "2026-10-10T09:55:12Z"
EXECUTION_BASE = "1563a21bdc0d9ff465464e338938904d16d909ab"


def load_verifier():
    spec = importlib.util.spec_from_file_location("ght_gha_review_verdict", SCRIPT)
    if spec is None or spec.loader is None:
        raise AssertionError(f"review verifier is missing: {SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepted_comment(sha=CANDIDATE_SHA):
    return {
        "id": 901,
        "updated_at": DELIVERED_AT,
        "body": (f"{ACCEPTANCE_HEADER}\n\nReviewed exact Candidate:\n"
                 f"{sha}\n\nReviewed by A."),
    }


def observation(*, head_sha=CANDIDATE_SHA, snapshot_sha=CANDIDATE_SHA,
                comments=None, reviews=None):
    snapshot = (
        "<!-- ght:candidate-snapshot:v1 -->\n"
        "## Current Candidate Snapshot — #45 / PR #65\n"
        f"- exact Candidate: `{snapshot_sha}`\n"
        f"- claim: `{CLAIM_ID}` · branch: `{BRANCH}` · "
        f"execution_base: `{EXECUTION_BASE}`\n"
        f"- authority: direct `ready` · delivered: {DELIVERED_AT}\n"
        "<!-- /ght:candidate-snapshot:v1 -->\n"
    )
    return {
        "repository": "owner/repo",
        "issue": 45,
        "pr": {
            "number": 65,
            "state": "open",
            "head": {
                "sha": head_sha,
                "ref": BRANCH,
                "repo": {"full_name": "owner/repo"},
            },
            "body": snapshot,
        },
        "claim_sha": "b" * 40,
        "claim": {
            "v": 3,
            "task": 45,
            "claim_id": CLAIM_ID,
            "status": "active",
            "branch": BRANCH,
            "execution_base": EXECUTION_BASE,
            "candidate": {"sha": CANDIDATE_SHA},
            "delivery": {
                "pr": 65,
                "sha": CANDIDATE_SHA,
                "delivered_at": DELIVERED_AT,
            },
            "runtime": {
                "digest": "c" * 64,
                "release": "v1.1.3",
                "source_sha": "d" * 40,
            },
        },
        "runtime": {
            "digest": "c" * 64,
            "release": "v1.1.3",
            "source_sha": "d" * 40,
        },
        "runtime_ref_sha": "e" * 40,
        "reviews": [] if reviews is None else reviews,
        "comments": [accepted_comment()] if comments is None else comments,
    }


class GhaReviewVerdictTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.verifier = load_verifier()

    def evaluate(self, before, after=None, predicate=evaluate_exact_sha_acceptance):
        return self.verifier.evaluate_and_bind(
            before, before if after is None else after, predicate)

    def test_canonical_fallback_verdict_is_pass(self):
        result = self.evaluate(observation())
        self.assertEqual(result["verdict"], "PASS")
        self.assertEqual(result["pr"], 65)
        self.assertEqual(result["candidate_sha"], CANDIDATE_SHA)
        self.assertEqual(result["runtime"], observation()["runtime"])
        self.assertTrue(result["evidence_id"])
        self.assertTrue(result["checked_at"])

    def test_noncanonical_or_wrong_sha_fallback_fails_closed(self):
        for comment in (
            {**accepted_comment(), "body": "A REVIEW — ACCEPTED\nwrong grammar"},
            accepted_comment(OTHER_SHA),
        ):
            with self.subTest(body=comment["body"]):
                result = self.evaluate(observation(comments=[comment]))
                self.assertEqual(result["verdict"], "FAIL")

    def test_stale_after_head_or_snapshot_change_is_not_pass(self):
        before = observation()
        changed_head = observation(head_sha=OTHER_SHA)
        result = self.evaluate(before, changed_head)
        self.assertEqual(result["verdict"], "UNKNOWN")
        self.assertIn("changed", result["reason"].lower())

        changed_snapshot = observation(snapshot_sha=OTHER_SHA)
        result = self.evaluate(before, changed_snapshot)
        self.assertEqual(result["verdict"], "UNKNOWN")

        changed_comment = observation(comments=[{
            "id": 901,
            "updated_at": "2026-10-10T10:00:00Z",
            "body": "A REVIEW — REQUEST_CHANGES\nchanged after the first read",
        }])
        result = self.evaluate(before, changed_comment)
        self.assertEqual(result["verdict"], "UNKNOWN")

    def test_native_review_exact_sha_keeps_existing_semantics(self):
        review = {"id": 44, "state": "APPROVED", "commit_id": CANDIDATE_SHA}
        result = self.evaluate(observation(reviews=[review], comments=[]))
        self.assertEqual(result["verdict"], "PASS")

        other_sha = {"id": 45, "state": "APPROVED", "commit_id": OTHER_SHA}
        result = self.evaluate(observation(reviews=[other_sha], comments=[]))
        self.assertEqual(result["verdict"], "FAIL")

    def test_dismissed_and_stale_native_review_surfaces_do_not_pass(self):
        dismissed = {"id": 44, "state": "DISMISSED", "commit_id": CANDIDATE_SHA}
        result = self.evaluate(observation(reviews=[dismissed], comments=[]))
        self.assertEqual(result["verdict"], "FAIL")

        result = self.evaluate(observation(head_sha=OTHER_SHA,
                                           reviews=[{"id": 44, "state": "APPROVED",
                                                     "commit_id": CANDIDATE_SHA}],
                                           comments=[]))
        self.assertEqual(result["verdict"], "UNKNOWN")
        self.assertEqual(result["pr_head_sha"], OTHER_SHA)

    def test_unreadable_review_surface_is_unknown(self):
        inputs = observation()
        inputs["reviews"] = None
        result = self.evaluate(inputs)
        self.assertEqual(result["verdict"], "UNKNOWN")
        self.assertIn("reviews", result["reason"].lower())

    def test_machine_check_calls_only_the_injected_canonical_predicate(self):
        predicate = Mock(return_value={
            "accepted": True,
            "source": "structured-comment",
            "unreadable": [],
            "approved_other_shas": [],
        })
        inputs = observation()
        result = self.evaluate(inputs, predicate=predicate)
        self.assertEqual(result["verdict"], "PASS")
        predicate.assert_called_once_with(
            reviews=inputs["reviews"],
            comments=inputs["comments"],
            candidate_sha=CANDIDATE_SHA,
        )

    def test_runtime_loader_uses_predicate_from_attempt_bound_capsule(self):
        runtime_zip = io.BytesIO()
        with zipfile.ZipFile(runtime_zip, "w") as archive:
            archive.writestr("github_task/__init__.py", "")
            archive.writestr(
                "github_task/core.py",
                "def evaluate_exact_sha_acceptance(*, reviews, comments, candidate_sha):\n"
                "    return {'accepted': candidate_sha == 'bound', 'source': 'bound-runtime', "
                "'unreadable': [], 'approved_other_shas': []}\n",
            )
        payload = runtime_zip.getvalue()
        digest = hashlib.sha256(payload).hexdigest()
        source_sha = "d" * 40
        manifest = json.dumps({"digest": digest, "release": "v1.1.3",
                               "source_sha": source_sha}).encode()
        claim = {"runtime": {"digest": digest, "release": "v1.1.3",
                              "source_sha": source_sha}}
        with patch.object(self.verifier, "_read_ref_files",
                          return_value=({"runtime.zip": payload,
                                         "MANIFEST.json": manifest}, "e" * 40)) as read_ref:
            temporary, identity, ref_sha, predicate = self.verifier._load_runtime(claim)
            try:
                self.assertEqual(predicate(reviews=[], comments=[], candidate_sha="bound")["source"],
                                 "bound-runtime")
                self.assertEqual(identity["digest"], digest)
                self.assertEqual(ref_sha, "e" * 40)
                read_ref.assert_called_once_with(
                    f"refs/ght/runtime/{digest}", ("runtime.zip", "MANIFEST.json"))
            finally:
                temporary.cleanup()

    def test_check_run_permission_failure_cannot_leave_a_pass(self):
        result = self.verifier.verify_and_publish(
            observation(), observation(), evaluate_exact_sha_acceptance,
            lambda _check: (_ for _ in ()).throw(PermissionError("checks:write denied")),
        )
        self.assertEqual(result["verdict"], "UNKNOWN")
        self.assertIn("checks:write", result["reason"])

    def test_check_run_is_bound_to_pr_head_and_reports_evidence_identity(self):
        result = self.evaluate(observation())
        with patch.object(self.verifier, "_gh_api", return_value={"id": 123}) as api:
            created = self.verifier._create_check_run("owner/repo", result)
        self.assertEqual(created["id"], 123)
        args, kwargs = api.call_args
        self.assertEqual(args[0], "repos/owner/repo/check-runs")
        payload = kwargs["payload"]
        self.assertEqual(payload["head_sha"], CANDIDATE_SHA)
        self.assertEqual(payload["external_id"], result["evidence_id"])
        self.assertEqual(payload["conclusion"], "success")
        summary = payload["output"]["summary"]
        for required in ("PR: #65", CANDIDATE_SHA, "v1.1.3", "Evidence identity:",
                         "Checked at:", "Verdict: **PASS**", "Reason:"):
            self.assertIn(required, summary)
        self.assertIn(result["evidence_id"], payload["output"]["text"])
        self.assertIn("runtime_ref_sha", payload["output"]["text"])

    def test_workflow_routes_fallback_and_native_review_lifecycle_to_helper(self):
        text = WORKFLOW.read_text()
        self.assertIn("issue_comment:", text)
        self.assertIn("types: [created, edited, deleted]", text)
        self.assertIn("pull_request_review:", text)
        self.assertIn("types: [submitted, edited, dismissed]", text)
        self.assertIn("github.event_name == 'pull_request_review'", text)
        self.assertIn("contains(github.event.comment.body, 'A REVIEW')", text)
        self.assertIn("contains(github.event.changes.body.from, 'A REVIEW')", text)
        self.assertIn("checks: write", text)
        self.assertIn("GITHUB_STEP_SUMMARY", SCRIPT.read_text())
        self.assertIn("ref: ${{ github.event.repository.default_branch }}", text)
        self.assertIn("ght-gha-review-trigger.py", text)


if __name__ == "__main__":
    unittest.main()
