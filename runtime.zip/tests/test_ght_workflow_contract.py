"""Contract checks for the repository's single GHT Actions entry."""

from __future__ import annotations

import ast
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
SKILL_ROOT = ROOT / "skills" / "github-task"
WORKFLOWS = ROOT / ".github" / "workflows"
PIN = "51246b453b115008b0e7032a2e741964921c2e208311cae91a00bcd2c926c2c8"


def job_block(text: str, name: str) -> str:
    marker = f"\n  {name}:\n"
    start = text.index(marker) + len(marker)
    following = re.search(r"(?m)^  [A-Za-z0-9_-]+:\s*$", text[start:])
    end = start + following.start() if following else len(text)
    return text[start:end]


class GhtWorkflowContractTests(unittest.TestCase):
    def setUp(self):
        self.workflow = (WORKFLOWS / "ght.yml").read_text(encoding="utf-8")

    def test_one_rendered_entry_is_pinned_to_the_active_runtime(self):
        self.assertIn("name: ght\n", self.workflow)
        template_path = SKILL_ROOT / "workflow_templates" / "ght.yml"
        template = template_path.read_bytes()
        self.assertEqual(template.count(b"@GHT_RUNTIME_REF@"), 3)
        self.assertEqual(
            (WORKFLOWS / "ght.yml").read_bytes(),
            template.replace(b"@GHT_RUNTIME_REF@", PIN.encode("ascii")))
        self.assertEqual(
            sorted(path.name for path in WORKFLOWS.glob("ght*.yml")),
            ["ght.yml"])
        self.assertEqual(
            re.findall(r'(?m)^\s+GHT_RUNTIME_REF: "([0-9a-f]{64})"$',
                       self.workflow),
            [PIN, PIN, PIN])
        self.assertEqual(self.workflow.count(
            "uses: actions/checkout@11d5960a326750d5838078e36cf38b85af677262"), 3)

    def test_exact_sha_review_and_owner_gate_route_through_active_runtime(self):
        events = self.workflow.split("\njobs:", 1)[0]
        review = job_block(self.workflow, "review_verdict")
        self.assertIn("pull_request_review:", events)
        self.assertIn("types: [submitted, edited, dismissed]", events)
        self.assertIn("issue_comment:", events)
        self.assertIn("types: [created, edited, deleted]", events)
        self.assertIn("github.repository_owner == 'harryhua-ai'", review)
        self.assertIn("github.event_name == 'pull_request_review'", review)
        self.assertIn("github.event.issue.pull_request", review)
        self.assertIn("contains(github.event.comment.body, 'A REVIEW')", review)
        self.assertIn("contains(github.event.changes.body.from, 'A REVIEW')", review)
        self.assertIn("checks: write", review)
        self.assertIn("ght-gha-review-trigger.py", review)

    def test_completion_requires_a_merged_pr_or_explicit_completion_dispatch(self):
        events = self.workflow.split("\njobs:", 1)[0]
        complete = job_block(self.workflow, "complete")
        self.assertIn("pull_request:", events)
        self.assertIn("types: [closed]", events)
        self.assertIn("workflow_dispatch:", events)
        self.assertIn("options: [complete, plan-publish]", events)
        self.assertIn("github.repository_owner == 'harryhua-ai'", complete)
        self.assertIn("github.event.pull_request.merged == true", complete)
        self.assertIn("inputs.operation == 'complete'", complete)
        self.assertIn('ght-gha-adapter.sh" resolve', complete)
        self.assertIn('ght-gha-adapter.sh" complete', complete)
        self.assertIn("GHT_RECONCILER_ID: ght-complete-workflow", complete)
        self.assertIn("steps.facts.outputs.applicable != 'false'", complete)

    def test_authorized_plan_route_is_default_branch_scoped(self):
        events = self.workflow.split("\njobs:", 1)[0]
        publish = job_block(self.workflow, "publish")
        self.assertIn("paths: ['docs/plans/current-plan.yaml']", events)
        self.assertIn("github.repository_owner == 'harryhua-ai'", publish)
        self.assertIn("github.ref_name == github.event.repository.default_branch", publish)
        self.assertIn("inputs.operation == 'plan-publish'", publish)
        self.assertIn("GHT_PLAN_PUBLISHER_ID: ght-plan-publish-workflow", publish)
        self.assertIn('ght-gha-adapter.sh" plan-publish', publish)
        self.assertIn("issues: read", publish)
        self.assertNotIn("issues: write", publish)

    def test_roadmap_projection_watches_the_new_entry_and_keeps_other_workflows(self):
        roadmap_path = WORKFLOWS / "roadmap-status.yml"
        roadmap = roadmap_path.read_text(encoding="utf-8")
        self.assertIn(
            "workflows: [ght, formal-release, roadmap-status-review-signal]",
            roadmap)
        self.assertIn("github.event.workflow_run.name == 'ght'", roadmap)
        self.assertNotIn("ght-complete", roadmap)
        self.assertIn("github.event.workflow_run.name == 'formal-release'", roadmap)
        self.assertIn("github.event.workflow_run.name == 'roadmap-status-review-signal'",
                      roadmap)
        self.assertTrue((WORKFLOWS / "formal-release.yml").is_file())
        self.assertTrue((WORKFLOWS / "roadmap-status-review-signal.yml").is_file())

    def test_retired_generator_has_no_cli_import_and_new_adoption_remains(self):
        package = SKILL_ROOT / "github_task"
        templates = SKILL_ROOT / "workflow_templates"
        self.assertFalse((package / "workflow_adoption.py").exists())
        self.assertTrue((package / "single_workflow_adoption.py").is_file())
        self.assertEqual(sorted(path.name for path in templates.glob("*.yml")),
                         ["ght.yml"])

        tree = ast.parse((package / "cli.py").read_text(encoding="utf-8"))
        imports = [node for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
        old_imports = [node for node in imports
                       if node.module == "workflow_adoption"
                       or (node.module and node.module.endswith(".workflow_adoption"))
                       or any(alias.name == "workflow_adoption"
                              for alias in node.names)]
        single_imports = [node for node in imports
                          if node.level == 1 and node.module in (None, "")
                          and any(alias.name == "single_workflow_adoption"
                                  for alias in node.names)]
        self.assertEqual(old_imports, [])
        self.assertTrue(single_imports)


if __name__ == "__main__":
    unittest.main()
