"""Tests for routing GitHub review events to the canonical verifier."""

import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch


SCRIPT = Path(__file__).parents[1] / "scripts" / "ght-gha-review-trigger.py"
VERIFIER = SCRIPT.with_name("ght-gha-review-verdict.py")


def load_trigger():
    spec = importlib.util.spec_from_file_location("ght_gha_review_trigger", SCRIPT)
    if spec is None or spec.loader is None:
        raise AssertionError(f"review trigger is missing: {SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class GhaReviewTriggerTests(unittest.TestCase):
    def run_event(self, event_name, event):
        self.assertTrue(SCRIPT.is_file(), f"review trigger is missing: {SCRIPT}")
        trigger = load_trigger()
        with tempfile.TemporaryDirectory() as temporary:
            event_path = Path(temporary) / "event.json"
            event_path.write_text(json.dumps(event), encoding="utf-8")
            with patch.dict(os.environ, {
                    "GITHUB_EVENT_NAME": event_name,
                    "GITHUB_EVENT_PATH": str(event_path),
            }), patch.object(trigger.subprocess, "run",
                             return_value=Mock(returncode=0)) as run:
                result = trigger.main()
        return result, run

    def test_native_review_lifecycle_routes_by_pr_not_stale_review_payload(self):
        for action in ("submitted", "edited", "dismissed"):
            with self.subTest(action=action):
                event = {
                    "action": action,
                    "pull_request": {"number": 65},
                    "review": {"id": 44, "state": "APPROVED",
                               "commit_id": "a" * 40},
                }
                result, run = self.run_event("pull_request_review", event)
                self.assertEqual(result, 0)
                run.assert_called_once_with([sys.executable,
                                             str(VERIFIER), "65"], check=False)

    def test_top_level_comment_fallback_routes_its_pull_request(self):
        event = {
            "action": "deleted",
            "issue": {"number": 65, "pull_request": {"url": "https://api.example/pr/65"}},
            "changes": {"body": {"from": "A REVIEW — ACCEPTED"}},
        }
        result, run = self.run_event("issue_comment", event)
        self.assertEqual(result, 0)
        run.assert_called_once_with([sys.executable, str(VERIFIER), "65"], check=False)


if __name__ == "__main__":
    unittest.main()
