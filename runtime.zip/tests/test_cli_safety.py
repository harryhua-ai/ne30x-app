"""End-to-end safety tests for the github-task v3 CLI.

The suite runs the real CLI against a local bare remote with a scripted
``gh`` that models the GitHub CLI's actual behavior (supported JSON fields
only, URL-shape Issue/PR distinction, transient mirror failures) and a
``git`` wrapper that can inject lost push responses.
"""

import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).parents[1]
CLI = SKILL_ROOT / "scripts" / "ght.py"
REAL_GIT = shutil.which("git")
sys.path.insert(0, str(SKILL_ROOT))

CLAIM_REF = "refs/ght/claims/"           # canonical non-branch namespace
LEGACY_CLAIM_REF = "refs/heads/claims/"  # pre-cutover namespace (sticky for old attempts)

MOCK_GH = r'''#!/usr/bin/env python3
import fcntl
import json
import os
import subprocess
import sys
import time
from pathlib import Path

STATE = Path(os.environ["GHT_TEST_STATE"])
# Concurrent gh invocations (parallel orchestrated traces) must serialize
# on the state file: hold an exclusive lock for this invocation's lifetime.
_LOCK = open(str(STATE) + ".lock", "w")
fcntl.flock(_LOCK, fcntl.LOCK_EX)
ME = os.environ.get("GHT_TEST_GITHUB_PRINCIPAL", "acct")
REPO_URL = "https://github.com/example/repo"

ISSUE_FIELDS = {"number", "title", "body", "state", "stateReason", "url",
                "labels", "assignees", "comments"}
LABELS_FIELDS = {"number", "state", "url", "labels"}
PR_FIELDS = {"number", "state", "url"}
PR_VIEW_FIELDS = {"number", "state", "url", "headRefName", "headRefOid", "mergeCommit"}


def load():
    return json.loads(STATE.read_text())


def save(data):
    STATE.write_text(json.dumps(data, indent=2))


def log(args):
    data = load()
    data.setdefault("__calls", []).append(args)
    save(data)


def render(record, fields):
    known = ISSUE_FIELDS | LABELS_FIELDS | PR_FIELDS | PR_VIEW_FIELDS
    for field in fields:
        if field not in known:
            print(f'Unknown JSON field: "{field}"', file=sys.stderr)
            raise SystemExit(1)
    out = {}
    if "number" in fields:
        out["number"] = record["number"]
    if "title" in fields:
        out["title"] = record.get("title", "")
    if "body" in fields:
        out["body"] = record.get("body", "")
    if "state" in fields:
        out["state"] = record.get("state", "OPEN")
    if "stateReason" in fields:
        # gh returns null for open issues and "COMPLETED"/"NOT_PLANNED"/
        # "REOPENED" for closed ones; a closed issue always carries a reason.
        out["stateReason"] = record.get("stateReason")
    if "url" in fields:
        out["url"] = record.get("url")
    if "labels" in fields:
        out["labels"] = [{"name": label} for label in record.get("labels", [])]
    if "assignees" in fields:
        out["assignees"] = [{"login": login} for login in record.get("assignees", [])]
    if "comments" in fields:
        out["comments"] = record.get("comments", [])
    if "milestone" in fields:
        milestone = record.get("milestone")
        out["milestone"] = {"title": milestone} if milestone else None
    if "headRefName" in fields:
        out["headRefName"] = record.get("headRefName")
    if "headRefOid" in fields:
        out["headRefOid"] = record.get("headRefOid")
    if "mergeCommit" in fields:
        out["mergeCommit"] = record.get("mergeCommit")
    return out


args = sys.argv[1:]
log(args)

if args[:2] == ["api", "user"]:
    if os.environ.get("GHT_TEST_FAIL_API_USER") == "1":
        # Simulate a GitHub App installation token: GET /user unsupported.
        print("GET /user: installation access token cannot query users",
              file=sys.stderr)
        raise SystemExit(1)
    print(ME)
    raise SystemExit(0)

if args[:2] == ["repo", "view"]:
    print("example/repo")
    raise SystemExit(0)

if args[:1] == ["api"]:
    parts = (args[1] if len(args) > 1 else "").split("/")
    if (len(parts) == 6 and parts[0] == "repos" and parts[3] == "pulls"
            and parts[5] == "reviews"):
        if os.environ.get("GHT_TEST_FAIL_PR_REVIEWS") == "1":
            print("reviews surface unavailable", file=sys.stderr)
            raise SystemExit(1)
        print(json.dumps(load()[str(int(parts[4]))].get("reviews", [])))
        raise SystemExit(0)
    if (len(parts) == 6 and parts[0] == "repos" and parts[3] == "issues"
            and parts[5] == "comments"):
        if os.environ.get("GHT_TEST_FAIL_PR_COMMENTS") == "1":
            print("comments surface unavailable", file=sys.stderr)
            raise SystemExit(1)
        print(json.dumps(load()[str(int(parts[4]))].get("pr_comments", [])))
        raise SystemExit(0)
    print("unsupported api path", file=sys.stderr)
    raise SystemExit(1)

if not args or args[0] not in ("issue", "pr"):
    print("unsupported mock gh command", file=sys.stderr)
    raise SystemExit(1)

data = load()
kind, sub = args[0], args[1]
rest = args[2:]

if sub == "list" and kind == "issue":
    if os.environ.get("GHT_TEST_FAIL_ISSUE_LIST") == "1":
        print("issue listing surface unavailable", file=sys.stderr)
        raise SystemExit(1)
    label = rest[rest.index("--label") + 1]
    listed = []
    for number in sorted((n for n in data if n.isdigit()), key=int):
        record = data[number]
        if (isinstance(record, dict) and record.get("state") == "OPEN"
                and not record.get("is_pr")
                and label in (record.get("labels") or [])):
            listed.append({"number": int(number)})
    print(json.dumps(listed))
    raise SystemExit(0)

if sub == "edit" and kind == "pr":
    number = str(int(rest[0].lstrip("#")))
    body = rest[rest.index("--body-file") + 1]
    if number not in data or not data[number].get("is_pr"):
        print(f"no pull requests found for #{number}", file=sys.stderr)
        raise SystemExit(1)
    data[number]["body"] = Path(body).read_text()
    save(data)
    print(data[number]["url"])
    raise SystemExit(0)

if sub == "view":
    if os.environ.get("GHT_TEST_FAIL_ISSUE_VIEW") == "1":
        # #91 R2: a genuinely unreadable remote read (adapter/transport
        # failure — e.g. a token without issues:read on a real runner),
        # distinct from an invalid Contract body.
        print("issue read surface unavailable", file=sys.stderr)
        raise SystemExit(1)
    number = int(rest[0].lstrip("#"))
    record = data[str(number)]
    is_pr = record.get("is_pr", False)
    if "--json" in rest:
        fields = [f for f in rest[rest.index("--json") + 1].split(",") if f]
        if kind == "pr":
            if not is_pr:
                print("no pull requests found", file=sys.stderr)
                raise SystemExit(1)
            rendered = render(record, fields)
            # GitHub resolves the PR head to the live branch tip; model the
            # same dynamic resolution when the branch ref is reachable.
            if "headRefOid" in rendered and record.get("headRefName"):
                tip = subprocess.run(
                    [os.environ.get("GHT_TEST_REAL_GIT", "git"), "rev-parse",
                     "--verify", "--quiet", record["headRefName"]],
                    capture_output=True, text=True)
                if tip.returncode == 0 and tip.stdout.strip():
                    rendered["headRefOid"] = tip.stdout.strip()
            print(json.dumps(rendered))
            raise SystemExit(0)
        # Modern gh issue view returns PR objects; GHT_TEST_OLD_GH models
        # versions that refuse instead.
        if is_pr and os.environ.get("GHT_TEST_OLD_GH") == "1":
            print("Could not resolve to an issue", file=sys.stderr)
            raise SystemExit(1)
        print(json.dumps(render(record, fields)))
        raise SystemExit(0)
    print(record.get("title", ""))
    raise SystemExit(0)

if sub == "close" and kind == "issue":
    # #171: the mechanical post-completion Issue close. The mock models the
    # real CLI surface (`gh issue close <n> --reason completed|not planned`)
    # and GitHub's state_reason rendering: an open Issue closes with the
    # mapped reason; an already-closed Issue stays untouched (exit 0, like
    # the real CLI) so idempotent retries observe convergence, not an error.
    number = int(rest[0].lstrip("#"))
    record = data[str(number)]
    if os.environ.get("GHT_TEST_FAIL_ISSUE_CLOSE") == "1":
        print("simulated issue close failure", file=sys.stderr)
        raise SystemExit(1)
    if record.get("state") != "CLOSED":
        reason = rest[rest.index("--reason") + 1] if "--reason" in rest else ""
        record["state"] = "CLOSED"
        record["stateReason"] = "COMPLETED" if reason == "completed" else "NOT_PLANNED"
        override = os.environ.get("GHT_TEST_CLOSE_REASON_OVERRIDE")
        if override:
            # #171 adversarial: the close command reports success (exit 0)
            # but the DURABLE state_reason contradicts the requested one —
            # e.g. a concurrent/manual lifecycle transition wins the race.
            # Distinct from GHT_TEST_FAIL_ISSUE_CLOSE (a failed command).
            record["stateReason"] = override
        save(data)
    print(f"{REPO_URL}/issues/{number}#close")
    raise SystemExit(0)

if sub == "edit":
    number = int(rest[0].lstrip("#"))
    record = data[str(number)]
    failures_left = int(os.environ.get("GHT_TEST_FAIL_REMOVE_LABEL_TIMES", "0"))
    remove_calls = record.setdefault("__remove_calls", 0)
    if "--remove-label" in rest and failures_left and remove_calls < failures_left:
        record["__remove_calls"] = remove_calls + 1
        save(data)
        print("simulated label removal failure", file=sys.stderr)
        raise SystemExit(1)
    i = 0
    while i < len(rest):
        flag = rest[i]
        if flag == "--remove-label" and rest[i + 1] in record.setdefault("labels", []):
            record["labels"].remove(rest[i + 1])
            i += 2
        elif flag == "--add-label" and rest[i + 1] not in record.setdefault("labels", []):
            record["labels"].append(rest[i + 1])
            i += 2
        else:
            i += 1
    save(data)
    print(f"{REPO_URL}/issues/{number}#edit")
    raise SystemExit(0)

if sub == "create" and kind == "pr":
    # GitHub resolves the PR head to the branch tip; the mock reads the
    # real sha from the invoking worktree (gh's cwd), like the real server
    # resolves the pushed branch.
    import subprocess
    head = rest[rest.index("--head") + 1]
    fail_issues = [part.strip() for part in
                   os.environ.get("GHT_TEST_FAIL_PR_CREATE_ISSUES", "").split(",")
                   if part.strip()]
    if any(head.startswith(f"agent/{issue}/") for issue in fail_issues):
        print(f"simulated pr create failure for {head}", file=sys.stderr)
        raise SystemExit(1)
    sha = subprocess.run([os.environ["GHT_TEST_REAL_GIT"], "rev-parse", "HEAD"],
                         capture_output=True, text=True).stdout.strip()
    existing = [n for n, r in data.items()
                if isinstance(r, dict) and r.get("is_pr")]
    number = max([int(n) for n in existing] + [90]) + 1
    url = f"{REPO_URL}/pull/{number}"
    data[str(number)] = {
        "number": number, "is_pr": True, "state": "OPEN",
        "url": url, "headRefName": head, "headRefOid": sha,
        "mergeCommit": None, "reviews": [], "pr_comments": [],
    }
    save(data)
    print(url)
    raise SystemExit(0)

if sub == "comment":
    number = int(rest[0].lstrip("#"))
    body = rest[rest.index("--body") + 1]
    data[str(number)].setdefault("comments", []).append({
        "body": body, "author": {"login": ME},
        "createdAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    })
    save(data)
    print(f"{REPO_URL}/issues/{number}/comment")
    raise SystemExit(0)

print("unsupported subcommand", file=sys.stderr)
raise SystemExit(1)
'''

GIT_WRAPPER = r'''#!/usr/bin/env python3
import os
import subprocess
import sys

real_git = os.environ["GHT_TEST_REAL_GIT"]
argv = sys.argv[1:]
log_file = os.environ.get("GHT_TEST_GIT_LOG")
if log_file:
    with open(log_file, "a") as handle:
        handle.write(" ".join(argv) + "\n")
if (os.environ.get("GHT_TEST_FAIL_FETCH") == "1"
        and argv[:1] == ["fetch"]):
    print("simulated fetch transport failure", file=sys.stderr)
    raise SystemExit(1)
if (os.environ.get("GHT_TEST_FAIL_LS_REMOTE") == "1"
        and argv[:1] == ["ls-remote"]):
    print("simulated ls-remote transport failure", file=sys.stderr)
    raise SystemExit(1)
replace_on_delete = os.environ.get("GHT_TEST_REPLACE_ON_DELETE")
if replace_on_delete and argv[:1] == ["push"]:
    refname, newsha = replace_on_delete.split("|", 1)
    argv = [newsha + ":" + refname if v == ":" + refname else v for v in argv]
fail_refspec = os.environ.get("GHT_TEST_FAIL_PUSH_REFSPEC")
if fail_refspec and argv[:1] == ["push"] and any(fail_refspec in value for value in argv):
    print(f"simulated push failure for refspec containing {fail_refspec!r}", file=sys.stderr)
    raise SystemExit(1)
result = subprocess.run([real_git, *argv])
if (result.returncode == 0 and argv[:1] == ["push"] and
        any("refs/ght/claims/" in value or "refs/heads/claims/" in value
            for value in argv)):
    racer = os.environ.get("GHT_TEST_RACER_DIR")
    overwrite = os.environ.get("GHT_TEST_RACE_OVERWRITE")
    if racer and overwrite:
        ref = os.environ.get("GHT_TEST_RACE_REF", "refs/ght/claims/10")
        subprocess.run([real_git, "-C", racer, "push", "--force", "origin",
                        f"{overwrite}:{ref}"], capture_output=True, text=True)
    if os.environ.get("GHT_TEST_FAIL_PUSH_RESPONSE") == "1":
        # Simulate a lost push response: the push landed, the caller sees failure.
        print("simulated lost push response", file=sys.stderr)
        raise SystemExit(1)
raise SystemExit(result.returncode)
'''


IMPL_CONTRACT = """```ght-contract
version: 1
intent: >
  A small runnable baseline.
acceptance:
  - id: AC1
    requirement: The CLI runs.
authority:
  implementation: allowed
depends_on: []
scope:
  forbidden:
    - template/**
```
"""

INVESTIGATION_CONTRACT = IMPL_CONTRACT.replace(
    "authority:\n  implementation: allowed", "authority:\n  implementation: investigation-only")

DEP_OPEN = IMPL_CONTRACT.replace("depends_on: []", "depends_on:\n  - 5")
DEP_CLOSED = IMPL_CONTRACT.replace("depends_on: []", "depends_on:\n  - 4")


def issue_body(block):
    return f"# Task\n\nPlanning metadata outside the Contract.\n\n{block}"


class CliSafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="github-task-v3-"))
        self.origin = self.tmp / "origin.git"
        self.state = self.tmp / "issues.json"
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        self._write_executable(self.bin / "gh", MOCK_GH)
        self._write_executable(self.bin / "git", GIT_WRAPPER)
        self._git(self.tmp, "init", "--bare", str(self.origin), "-b", "main")
        seed = self.tmp / "seed"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(seed))
        (seed / "README.md").write_text("seed\n")
        self._git(seed, "add", ".")
        self._git(seed, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "seed")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        self.repo = self.tmp / "worker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(self.repo))
        self._git(self.repo, "config", "user.email", "w@t")
        self._git(self.repo, "config", "user.name", "w")
        self.state.write_text(json.dumps({
            "10": {"number": 10, "title": "Task ten", "state": "OPEN",
                   "url": "https://github.com/example/repo/issues/10",
                   "milestone": "v1.0.0",
                   "body": issue_body(IMPL_CONTRACT), "labels": ["ready"], "comments": []},
            "11": {"number": 11, "title": "Task eleven", "state": "OPEN",
                   "url": "https://github.com/example/repo/issues/11",
                   "body": issue_body(INVESTIGATION_CONTRACT), "labels": ["ready"], "comments": []},
            "2": {"number": 2, "title": "Old PR", "state": "OPEN", "is_pr": True,
                  "url": "https://github.com/example/repo/pull/2",
                  "body": issue_body(IMPL_CONTRACT), "labels": ["ready"], "comments": []},
            "4": {"number": 4, "title": "Closed dep", "state": "CLOSED",
                  "stateReason": "COMPLETED",
                  "url": "https://github.com/example/repo/issues/4",
                  "body": "done work", "labels": [], "comments": []},
            "5": {"number": 5, "title": "Open dep", "state": "OPEN",
                  "url": "https://github.com/example/repo/issues/5",
                  "body": "in flight", "labels": [], "comments": []},
            "12": {"number": 12, "title": "Task twelve", "state": "OPEN",
                   "url": "https://github.com/example/repo/issues/12",
                   "body": issue_body(DEP_OPEN), "labels": ["ready"], "comments": []},
            "13": {"number": 13, "title": "Task thirteen", "state": "OPEN",
                   "url": "https://github.com/example/repo/issues/13",
                   "body": issue_body(DEP_CLOSED), "labels": ["ready"], "comments": []},
            "14": {"number": 14, "title": "Task fourteen", "state": "OPEN",
                   "url": "https://github.com/example/repo/issues/14",
                   "milestone": "v1.0.0",
                   "body": issue_body(IMPL_CONTRACT), "labels": ["ready"], "comments": []},
            "15": {"number": 15, "title": "Task fifteen", "state": "OPEN",
                   "url": "https://github.com/example/repo/issues/15",
                   "body": issue_body(IMPL_CONTRACT), "labels": ["ready"], "comments": []},
        }, indent=2))
        self._env = {
            "PATH": f"{self.bin}:{os.environ['PATH']}",
            "GHT_TEST_STATE": str(self.state),
            "GHT_TEST_REAL_GIT": REAL_GIT,
            "GHT_EXECUTOR_ID": "worker-1",
            "GHT_LEASE_MINUTES": "45",
            "GHT_SPAWN_SUPERVISOR": "0",
            "GIT_AUTHOR_NAME": "w", "GIT_AUTHOR_EMAIL": "w@t",
            "GIT_COMMITTER_NAME": "w", "GIT_COMMITTER_EMAIL": "w@t",
        }
        self._activate_default_runtime_pin()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    _PIN_PAYLOAD_CACHE = {}

    def _activate_default_runtime_pin(self):
        """#98 R3: the discovery identity gate requires the repo's durable
        runtime identity proof (refs/ght/runtime/current). Fixtures
        activate a pin whose digest matches SKILL_ROOT — the exact runtime
        under test — so every ght invocation proves its own identity
        exactly like a properly activated repository. The payload is
        computed once per process and re-planted per test repo."""
        import github_task.cli as ght_cli
        cached = CliSafetyTests._PIN_PAYLOAD_CACHE.get("payload")
        if cached is None:
            payload, manifest = ght_cli._runtime_capsule_payload(SKILL_ROOT)
            # SKILL_ROOT is an unstamped working tree; a capsule an adapter
            # can materialize must carry a coherent release identity.
            manifest["release"] = "v1.0.3"
            manifest["source_sha"] = "f" * 40
            CliSafetyTests._PIN_PAYLOAD_CACHE["payload"] = (payload, manifest)
        payload, manifest = CliSafetyTests._PIN_PAYLOAD_CACHE["payload"]
        payload_file = self.tmp / "pin-runtime.zip"
        payload_file.write_bytes(payload)
        payload_blob = self._git(self.repo, "hash-object", "-w",
                                 str(payload_file)).stdout.strip()
        manifest_blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                                  input_text=json.dumps(
                                      manifest, sort_keys=True)).stdout.strip()
        tree = self._git(self.repo, "mktree", input_text=(
            f"100644 blob {payload_blob}\truntime.zip\n"
            f"100644 blob {manifest_blob}\tMANIFEST.json\n")).stdout.strip()
        identity_env = {**os.environ,
                        "GIT_AUTHOR_NAME": "ght", "GIT_AUTHOR_EMAIL": "ght@harry-dev",
                        "GIT_COMMITTER_NAME": "ght", "GIT_COMMITTER_EMAIL": "ght@harry-dev"}
        commit = self._git(self.repo, "commit-tree", tree,
                           "-m", "fixture runtime capsule",
                           env=identity_env).stdout.strip()
        pushed = self._git(self.repo, "push", "-q", "origin",
                           f"{commit}:refs/ght/runtime/current")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        # The pin alone is not a complete activated state: the pinned
        # capsule must exist at its content-addressed ref too (exactly
        # what `ght sync-runtime` publishes before activation), so
        # attempt-bound capsule materialization resolves.
        pushed = self._git(self.repo, "push", "-q", "origin",
                           f"{commit}:refs/ght/runtime/{manifest['digest']}")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)

    # -- helpers --------------------------------------------------------

    def _write_executable(self, path, content):
        path.write_text(content)
        path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    def _git(self, cwd, *args, env=None, input_text=None):
        return subprocess.run([REAL_GIT, *args], cwd=cwd, capture_output=True, text=True,
                              env=env or {**os.environ}, input=input_text)

    def _ght(self, *args, cwd=None, env_extra=None):
        env = {**self._env, **(env_extra or {})}
        return subprocess.run([sys.executable, str(CLI), "--json", *args], cwd=str(cwd or self.repo),
                              capture_output=True, text=True, env=env)

    def _ght_json(self, *args, **kwargs):
        result = self._ght(*args, **kwargs)
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError:
            self.fail(f"non-JSON output: {result.stdout} {result.stderr}")
        return result, payload

    def _issue(self, number):
        return json.loads(self.state.read_text())[str(number)]

    def _update_issue(self, number, **changes):
        data = json.loads(self.state.read_text())
        data[str(number)].update(changes)
        self.state.write_text(json.dumps(data, indent=2))

    def _calls(self):
        return json.loads(self.state.read_text()).get("__calls", [])

    def _claim(self, number=10, mode=None, env_extra=None):
        args = ["claim", str(number)]
        if mode:
            args += ["--mode", mode]
        result, payload = self._ght_json(*args, env_extra=env_extra)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return payload

    def _checkout_claim_branch(self, claim):
        result = self._git(self.repo, "checkout", "-q", "-b", claim["branch"], "origin/main")
        self.assertEqual(result.returncode, 0, result.stderr or "branch checkout failed")

    def _commit_on_branch(self, relpath, content):
        path = self.repo / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        # Stage only the named path: local ght state (claim caches, lease
        # fencing tokens) is worker-local and never belongs to a Candidate.
        self._git(self.repo, "add", relpath)
        self._git(self.repo, "commit", "-qm", f"add {relpath}")
        return self._git(self.repo, "rev-parse", "HEAD").stdout.strip()

    def _open_pr(self, number, head_branch, head_sha, state="OPEN", reviews=None,
                 pr_comments=None, body=None):
        """Model A opening the Candidate PR for the given exact head SHA."""
        data = json.loads(self.state.read_text())
        data[str(number)] = {
            "number": number, "is_pr": True, "state": state,
            "url": f"https://github.com/example/repo/pull/{number}",
            "headRefName": head_branch, "headRefOid": head_sha,
            "mergeCommit": None,
            "reviews": reviews if reviews is not None else [],
            "pr_comments": pr_comments if pr_comments is not None else [],
        }
        if body is not None:
            data[str(number)]["body"] = body
        self.state.write_text(json.dumps(data, indent=2))

    def _merge_pr(self, number, merge_commit="mergesha0000000000000000000000000000000"):
        """Model A's durable exact-SHA acceptance and merge of the PR head."""
        data = json.loads(self.state.read_text())
        record = data[str(number)]
        record["state"] = "MERGED"
        record["mergeCommit"] = {"oid": merge_commit}
        # A posts the canonical structured exact-SHA ACCEPT on the PR before
        # merging (native self-approval is refused by same-account platforms,
        # so this is the canonical fallback surface of the review contract).
        head = record.get("headRefOid")
        record.setdefault("pr_comments", []).append({
            "body": "A REVIEW — ACCEPTED\n\nReviewed exact Candidate:\n"
                    f"`{head}`\n\nacceptance conclusion\n\nMerge authorization applies "
                    "only while PR head remains this exact SHA."})
        self.state.write_text(json.dumps(data, indent=2))

    def _advance_origin_main(self, *files):
        """Accepted main moves forward with the given (relpath, content)
        commits — the independent integration movement an active attempt may
        need to reconcile against (#104)."""
        upstream = self.tmp / "upstream"
        if not upstream.exists():
            self._git(self.tmp, "clone", "-q", str(self.origin), str(upstream))
            self._git(upstream, "config", "user.email", "u@t")
            self._git(upstream, "config", "user.name", "u")
        for relpath, content in files:
            path = upstream / relpath
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content)
            self._git(upstream, "add", relpath)
            self._git(upstream, "commit", "-qm", f"upstream {relpath}")
        pushed = self._git(upstream, "push", "-q", "origin", "HEAD:main")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        return self._git(upstream, "rev-parse", "HEAD").stdout.strip()

    def _merge_origin_main(self):
        """Reconcile the worker's claim branch onto the advanced accepted main."""
        self._git(self.repo, "fetch", "-q", "origin")
        merged = self._git(self.repo, "merge", "--no-edit", "-q", "origin/main")
        self.assertEqual(merged.returncode, 0, merged.stdout + merged.stderr)
        return self._git(self.repo, "rev-parse", "HEAD").stdout.strip()

    # -- #104: accepted-main reconciliation -------------------------------

    def test_accepted_main_forbidden_movement_does_not_pollute_scope(self):
        # AC1: main moved a path that is forbidden to THIS Issue after the
        # attempt started; reconciling the same attempt onto accepted main
        # must not fail scope merely because of those main-only paths.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        self._commit_on_branch("skills/demo.txt", "demo\n")
        main_tip = self._advance_origin_main(("template/upstream.md", "upstream owns this\n"),
                                             ("docs/shared.md", "shared\n"))
        reconciled = self._merge_origin_main()
        self.assertNotEqual(reconciled, main_tip)
        result, payload = self._ght_json("scope-check", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["pass"])
        self.assertEqual(payload["paths"]["template/upstream.md"], "MAIN_ATTRIBUTED")
        self.assertEqual(payload["paths"]["docs/shared.md"], "ALLOWED",
                         "attribution only relieves forbidden matches; allowed "
                         "paths keep their ordinary verdict")
        self.assertEqual(payload["main_lineage"]["attributed_paths"],
                         ["template/upstream.md"])
        self.assertEqual(payload["main_lineage"]["ref"], "refs/heads/main")
        self.assertEqual(payload["main_lineage"]["remote"], "origin")
        self.assertEqual(payload["main_lineage"]["sha"], main_tip)
        # preserve stores the reconciled exact Candidate with a passing scope
        result, payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["scope"]["pass"])
        self.assertEqual(payload["candidate_sha"], reconciled)

    def test_candidate_owned_forbidden_edit_still_fails_after_main_movement(self):
        # AC1: main-only attribution never covers content the Candidate
        # itself introduced — a real forbidden edit fails closed even when
        # accepted main also moved (other) forbidden paths.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        self._commit_on_branch("skills/demo.txt", "demo\n")
        self._advance_origin_main(("template/upstream.md", "upstream owns this\n"))
        self._merge_origin_main()
        self._commit_on_branch("template/candidate.md", "crossing the boundary\n")
        result = self._ght("scope-check", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertFalse(payload["pass"])
        self.assertEqual(payload["paths"]["template/candidate.md"], "FORBIDDEN")
        self.assertEqual(payload["paths"]["template/upstream.md"], "MAIN_ATTRIBUTED")
        self.assertEqual(
            [v["path"] for v in payload["violations"]], ["template/candidate.md"])
        result = self._ght("preserve", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)

    def test_unreadable_accepted_main_lineage_fails_closed(self):
        # AC2: with a forbidden path in the candidate diff and no readable
        # accepted-main ref on the REMOTE, attribution would be guesswork —
        # fail closed instead of ignoring or silently violating. The proof
        # reads the remote's current main directly (R2 review), so deleting
        # only the local tracking ref must not fake unreadability.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        self._commit_on_branch("skills/demo.txt", "demo\n")
        self._commit_on_branch("template/candidate.md", "candidate-authored\n")
        deleted = self._git(self.origin, "update-ref", "-d", "refs/heads/main")
        self.assertEqual(deleted.returncode, 0, deleted.stderr)
        result = self._ght("scope-check", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("accepted-main lineage cannot be proven", result.stdout)
        result = self._ght("preserve", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("accepted-main lineage cannot be proven", result.stdout)

    def test_diverged_accepted_main_lineage_fails_closed(self):
        # AC2: accepted main rewritten onto unrelated history — the
        # execution_base is provably not an ancestor, so no path may be
        # attributed to "accepted main" and the verdict fails closed.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        self._commit_on_branch("skills/demo.txt", "demo\n")
        self._commit_on_branch("template/candidate.md", "candidate-authored\n")
        tree = self._git(self.repo, "mktree", input_text="").stdout.strip()
        orphan = self._git(self.repo, "commit-tree", tree, "-m", "unrelated main history",
                           env=self._env).stdout.strip()
        pushed = self._git(self.repo, "push", "-q", "--force", "origin",
                           f"{orphan}:main")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        result = self._ght("scope-check", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("is not an ancestor of accepted main", result.stdout)

    def test_stale_tracking_ref_is_not_current_main_attribution(self):
        # AC2 (R2 review): durable main advances AFTER the worker's local
        # origin/main tracking ref went stale. Attribution must bind to the
        # remote's CURRENT accepted-main exact SHA, never to the stale
        # tracking ref: until the current tip's object is locally provable
        # the verdict fails closed with that exact SHA in the diagnostic;
        # once fetched, the same Candidate rebinds and passes against it.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        self._commit_on_branch("skills/demo.txt", "demo\n")
        first_tip = self._advance_origin_main(
            ("template/upstream.md", "upstream owns this\n"))
        self._merge_origin_main()
        second_tip = self._advance_origin_main(
            ("docs/shared.md", "shared moved on accepted main\n"))
        stale_local = self._git(self.repo, "rev-parse",
                                "refs/remotes/origin/main").stdout.strip()
        self.assertEqual(stale_local, first_tip,
                         "fixture precondition: the local tracking ref is stale")
        result = self._ght("scope-check", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("accepted-main lineage cannot be proven", result.stdout)
        self.assertIn(second_tip[:12], result.stdout)
        result = self._ght("preserve", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("accepted-main lineage cannot be proven", result.stdout)
        fetched = self._git(self.repo, "fetch", "-q", "origin")
        self.assertEqual(fetched.returncode, 0, fetched.stderr)
        result, payload = self._ght_json("scope-check", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["pass"])
        self.assertEqual(payload["paths"]["template/upstream.md"], "MAIN_ATTRIBUTED")
        self.assertEqual(payload["main_lineage"]["sha"], second_tip,
                         "attribution binds to the CURRENT accepted-main exact SHA")
        self.assertEqual(payload["main_lineage"]["attributed_paths"],
                         ["template/upstream.md"])

    def test_stale_forbidden_content_against_moved_main_is_not_attributed(self):
        # AC2 (R2 review): the Candidate carries v1 of a forbidden path that
        # accepted main has since moved to v2. Proven against the stale
        # tracking ref the content would look "identical to main" and pass;
        # bound to the CURRENT exact main object it differs, so the path
        # stays a strict forbidden violation — stale tracking state must
        # never launder stale forbidden content through attribution.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        self._commit_on_branch("skills/demo.txt", "demo\n")
        first_tip = self._advance_origin_main(("template/upstream.md", "v1\n"))
        self._merge_origin_main()
        second_tip = self._advance_origin_main(("template/upstream.md", "v2\n"))
        # Make the CURRENT main object locally provable WITHOUT refreshing
        # the stale remote-tracking ref (a fetch from the named remote
        # would opportunistically refresh it): fetch from the raw URL into
        # a side ref, so the proof's content leg is exercised in isolation
        # — it must diff against the exact current main object, not the
        # stale tracking ref.
        fetched = self._git(self.repo, "fetch", "-q", str(self.origin),
                            "+refs/heads/main:refs/ght/fixture-current-main")
        self.assertEqual(fetched.returncode, 0, fetched.stderr)
        stale_local = self._git(self.repo, "rev-parse",
                                "refs/remotes/origin/main").stdout.strip()
        self.assertEqual(stale_local, first_tip,
                         "fixture precondition: the tracking ref is stale at v1")
        result, payload = self._ght_json("scope-check", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertFalse(payload["pass"])
        self.assertEqual(payload["paths"]["template/upstream.md"], "FORBIDDEN")
        result = self._ght("preserve", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)


    def test_deliver_retry_moved_local_head_is_not_stale_success(self):
        # AC3: a durable delivery must never short-circuit `deliver` into
        # success once the head moved past the delivered Candidate; the
        # retry fails closed with the exact-SHA recovery path instead.
        claim, sha = self._delivered_parked(number=10, pr=68)
        self._commit_on_branch("skills/demo.txt", "v2 work continues\n")
        result = self._ght("deliver", "10", "--pr", "68")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("must bind the current exact Candidate", result.stdout)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["delivery"]["sha"], sha,
                         "the stale retry must not move the durable delivery record")
        self.assertIsNone(self._lease_remote_sha(claim["claim_id"]),
                          "the failed retry must not mint an execution lease")

    def test_deliver_retry_moved_branch_head_is_not_stale_success(self):
        # AC3: the preserved candidate branch head moving past the durable
        # delivery (out-of-band push) must equally refuse the stale-success
        # reconciliation.
        claim, sha = self._delivered_parked(number=10, pr=71)
        self._commit_on_branch("skills/demo.txt", "unpreserved push\n")
        pushed = self._git(self.repo, "push", "-q", "origin",
                           f"HEAD:refs/heads/{claim['branch']}")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        result = self._ght("deliver", "10", "--pr", "71")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("must not reconcile as 'delivery already durable'", result.stdout)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["delivery"]["sha"], sha)

    def test_accepted_main_reconciliation_end_to_end_redelivery(self):
        # AC5: faithful integration-reconciliation fixture — a delivered
        # attempt reconciles onto advanced accepted main, scope-check →
        # preserve → deliver forms a NEW exact Candidate, and A's exact-SHA
        # review gate ("head moved, verdict dies") stays intact.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha1 = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(80, claim["branch"], sha1)
        result, _payload = self._ght_json("deliver", "10", "--pr", "80")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # Accepted main advances with a path forbidden to THIS Issue.
        self._advance_origin_main(("template/upstream.md", "upstream owns this\n"))
        result, _payload = self._ght_json("acquire", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        reconciled = self._merge_origin_main()
        result, payload = self._ght_json("scope-check", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["paths"]["template/upstream.md"], "MAIN_ATTRIBUTED")
        result, payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["candidate_sha"], reconciled)
        self.assertNotEqual(reconciled, sha1)
        self._open_pr(80, claim["branch"], reconciled)
        result, payload = self._ght_json("deliver", "10", "--pr", "80")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["candidate_sha"], reconciled,
                         "re-delivery records the NEW exact Candidate, not the stale one")
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["delivery"]["sha"], reconciled)
        # "Head moved, verdict dies": A's acceptance bound to sha1 must not
        # complete the reconciled Candidate sha2.
        data = json.loads(self.state.read_text())
        record = data["80"]
        record["state"] = "MERGED"
        record["mergeCommit"] = {"oid": "reconciledmerge000000000000000000000"}
        record["pr_comments"] = [{
            "body": "A REVIEW — ACCEPTED\n\nReviewed exact Candidate:\n`" + sha1 + "`\n"}]
        self.state.write_text(json.dumps(data, indent=2))
        result = self._ght("complete", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no durable A acceptance", result.stdout)
        # A fresh exact-SHA verdict on the NEW Candidate completes the task.
        self._merge_pr(80)
        result, payload = self._ght_json("complete", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["candidate_sha"], reconciled)

    # -- AC1: runnable CLI and canonical GitHub intake ------------------

    def test_version_entrypoint(self):
        # The version surface reports the Harry Dev distribution identity
        # resolved from the runtime's own source tree (exact semantics are
        # covered by test_version_reports_harry_dev_distribution_identity).
        result, payload = self._ght_json("version")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(payload["product"], "harry-dev")
        self.assertIn(payload["status"], ("released", "unreleased"))
        self.assertNotIn("github-task v", result.stdout)
        human = self._ght("--version")
        self.assertEqual(human.returncode, 0)
        self.assertIn("harry-dev", human.stdout)
        self.assertNotIn("github-task v", human.stdout)

    def test_claim_accepts_eligible_open_issue(self):
        claim = self._claim(10)
        self.assertTrue(claim["ref_sha"])
        self.assertEqual(claim["authority"], "allowed")
        self.assertIsNone(claim["supersedes"],
                          "a fresh-lineage claim supersedes nothing")
        remote_sha = self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "10")
        self.assertIn(claim["ref_sha"], remote_sha.stdout)
        self.assertEqual(self._issue(10)["labels"], [])

    def test_intake_never_requests_unsupported_json_fields(self):
        self._claim(10)
        for call in self._calls():
            self.assertNotIn("isPullRequest", " ".join(call),
                             "intake depends on an unsupported gh issue view field")

    def test_rejects_pull_request_even_when_ready(self):
        result = self._ght("claim", "2")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("Pull Request", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "2").stdout.strip(), "")

    def test_rejects_pull_request_via_pr_view_fallback(self):
        result = self._ght("claim", "2", env_extra={"GHT_TEST_OLD_GH": "1"})
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("Pull Request", result.stdout)

    def test_rejects_not_open_issue(self):
        self._update_issue(10, state="CLOSED")
        result = self._ght("claim", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)

    # -- AC3: one-shot READY, dependency gate, mirror repair -------------

    def test_open_hard_dependency_blocks_before_claim(self):
        result = self._ght("claim", "12")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("still open", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "12").stdout.strip(), "")
        self.assertEqual(self._issue(12)["labels"], ["ready"],
                         "a rejected intake must not consume the READY authorization")

    def test_closed_dependency_needs_no_invented_lifecycle_label(self):
        self._claim(13)
        self.assertEqual(self._issue(4)["labels"], [],
                         "closed dependency carries no lifecycle label by construction")

    def test_transient_ready_removal_failure_is_repaired(self):
        result, payload = self._ght_json("claim", "10",
                                         env_extra={"GHT_TEST_FAIL_REMOVE_LABEL_TIMES": "1"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["ready_mirror"]["consumed"])
        self.assertEqual(payload["ready_mirror"]["attempts"], 2)
        self.assertEqual(self._issue(10)["labels"], [])

    def test_ready_is_one_shot_and_terminal_claim_blocks_new_attempts(self):
        first = self._claim(10)
        # READY is one-shot: a second immediate claim is rejected outright...
        result = self._ght("claim", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        # ...and even a stale mirror cannot revive ownership while an ACTIVE
        # claim exists.
        self._update_issue(10, labels=["ready"])
        result = self._ght("claim", "10")
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)
        self.assertIn("ACTIVE", result.stdout)
        self._update_issue(10, labels=[])
        result, payload = self._ght_json("release", "10", "--status", "investigated",
                                         "--note", "investigation answered the Contract")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # An investigated report answered the Contract: it is final, and no
        # fresh READY can start an attempt over it — new work belongs on a
        # new Issue.
        self._update_issue(10, labels=["ready"])
        result = self._ght("claim", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("new Issue", result.stdout)
        inspected = self._ght_json("inspect", "10")[1]
        self.assertEqual(inspected["claim"]["claim_id"], first["claim_id"],
                         "the terminal claim ref must be left untouched")

    def test_unrepairable_ready_mirror_fails_closed(self):
        result, payload = self._ght_json(
            "claim", "10", env_extra={"GHT_TEST_FAIL_REMOVE_LABEL_TIMES": "99"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("FAIL-CLOSED", result.stdout)
        self.assertFalse(payload["ready_mirror"]["consumed"])
        # Claim CAS remains ownership truth...
        self.assertTrue(self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "10").stdout.strip())
        # ...but the stale mirror blocks every gated continuation.
        result = self._ght("verify", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("stale READY", result.stdout)
        result = self._ght("heartbeat", "10", "--force")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        # The owning worker repairs the mirror; the attempt can continue.
        self._update_issue(10, **{"__remove_calls": 0})
        result, payload = self._ght_json("ready-repair", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["ready_mirror"]["consumed"])
        result = self._ght("verify", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_takeover_repairs_ready_mirror_left_by_crash(self):
        # The crash claim fails closed on the stale mirror (by design) while
        # its CAS ownership stands.
        result, _payload = self._ght_json(
            "claim", "10", env_extra={"GHT_TEST_FAIL_REMOVE_LABEL_TIMES": "99",
                                      "GHT_LEASE_MINUTES": "0"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "10").stdout.strip())
        self.assertEqual(self._issue(10)["labels"], ["ready"],
                         "crash before removal leaves the stale mirror in place")
        stale = self._ght_json("inspect", "10")[1]
        deadline = time.time() + 5
        while stale["claim_state"] != "STALE" and time.time() < deadline:
            time.sleep(0.2)
            stale = self._ght_json("inspect", "10")[1]
        result, payload = self._ght_json(
            "takeover", "10", "--evidence", "worker crashed before READY removal",
            env_extra={"GHT_TAKEOVER_GRACE_MINUTES": "0", "GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["claim_id"], stale["claim"]["claim_id"],
                         "takeover preserves the durable attempt identity")
        self.assertEqual(self._issue(10)["labels"], [],
                         "takeover must repair the stale READY mirror")
        result = self._ght("verify", "10", env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_terminal_delivery_blocked_by_stale_ready_mirror(self):
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # A stale `ready` appearing mid-attempt (e.g. unauthorized relabel)
        # must block terminal delivery: delivered-plus-ready would let the
        # label masquerade as fresh authorization for a future attempt.
        self._update_issue(10, labels=["ready"])
        result = self._ght("deliver", "10", "--pr", "60")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("stale READY", result.stdout)
        inspected = self._ght_json("inspect", "10")[1]
        self.assertEqual(inspected["claim"]["status"], "active")
        self._update_issue(10, labels=[])
        self._open_pr(60, claim["branch"], sha)
        result, payload = self._ght_json("deliver", "10", "--pr", "60",
                                         "--note", "candidate for review")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["candidate_sha"], sha)

    # -- AC2: CAS ownership, isolation, reconciliation -------------------

    def test_claim_race_lost_is_fail_closed(self):
        other = self.tmp / "racer"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(other))
        env = {**self._env, "GHT_EXECUTOR_ID": "worker-2"}
        subprocess.run([sys.executable, str(CLI), "--json", "claim", "10"], cwd=str(other),
                       capture_output=True, text=True, env=env)
        racer_sha = self._git(other, "ls-remote", "origin", CLAIM_REF + "10").stdout.strip()
        self.assertTrue(racer_sha)
        # The winner consumed READY; a loser that somehow still sees the
        # stale mirror (or races its recreate) is stopped by the ACTIVE
        # ownership check, never granted a second ownership.
        self._update_issue(10, labels=["ready"])
        result = self._ght("claim", "10")
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)
        self.assertIn("ACTIVE", result.stdout)

    def test_lost_push_response_is_reconciled_from_remote_truth(self):
        result, payload = self._ght_json("claim", "10",
                                         env_extra={"GHT_TEST_FAIL_PUSH_RESPONSE": "1"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["reconciled"])
        remote_sha = self._git(
            self.repo, "ls-remote", "origin", CLAIM_REF + "10").stdout.split()[0]
        self.assertEqual(remote_sha, payload["ref_sha"])

    def test_ambiguous_push_without_remote_proof_fails_closed(self):
        # The push lands but is then overwritten by a competing claim before
        # reconciliation reads the remote: the remote does not prove our
        # update, so the command must not report success.
        racer = self.tmp / "racer2"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(racer))
        racer_commit = self._git(racer, "commit-tree", "HEAD^{tree}", "-m", "hijack",
                                 env=self._env).stdout.strip()
        result, _payload = self._ght_json("claim", "10", env_extra={
            "GHT_TEST_FAIL_PUSH_RESPONSE": "1",
            "GHT_TEST_RACER_DIR": str(racer),
            "GHT_TEST_RACE_OVERWRITE": racer_commit,
        })
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('"ok": false', result.stdout)

    def test_ownership_loss_is_fail_closed(self):
        self._claim(10)
        racer = self.tmp / "loser"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(racer))
        sha = self._git(racer, "ls-remote", "origin", CLAIM_REF + "10").stdout.split()[0]
        self._git(racer, "fetch", "-q", "origin", CLAIM_REF + "10")
        # A competing worker rewrites the claim record under its own identity.
        record = json.loads(self._git(racer, "show", f"{sha}:CLAIM.json").stdout)
        record["claim_id"] = "hijacker-20260916T000000-deadbeef"
        blob = self._git(racer, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(record, indent=1)).stdout.strip()
        tree = self._git(racer, "mktree",
                         input_text=f"100644 blob {blob}\tCLAIM.json\n").stdout.strip()
        hijack = self._git(racer, "commit-tree", tree, "-p", sha, "-m", "hijack",
                           env=self._env).stdout.strip()
        moved = self._git(racer, "push", f"--force-with-lease={CLAIM_REF}10:{sha}",
                          "origin", f"{hijack}:{CLAIM_REF}10")
        self.assertEqual(moved.returncode, 0, moved.stderr)
        result = self._ght("heartbeat", "10", "--force")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("ownership", (result.stdout + result.stderr).lower())

    def test_coordination_identity_holds_multiple_active_issues(self):
        # #89 AC2: one stable coordination identity may hold several
        # independent authorized ACTIVE executions — each with its own
        # claim lineage and lease; per-Issue duplicate-start stays unique.
        self._claim(10)
        self._update_issue(13, labels=["ready"])
        result, second = self._ght_json("claim", "13")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        first = self._ght_json("inspect", "10")[1]["claim"]
        second_claim = self._ght_json("inspect", "13")[1]["claim"]
        self.assertNotEqual(first["claim_id"], second_claim["claim_id"])
        self.assertEqual(first["executor_id"], second_claim["executor_id"])
        # Same-Issue duplicate start is still refused (CAS uniqueness).
        self._update_issue(13, labels=["ready"])
        result = self._ght("claim", "13")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_takeover_with_another_live_attempt_succeeds(self):
        # #89 AC5: recovering one stale attempt does not serialize against
        # an independent live attempt of the same coordination identity.
        self._claim(10, env_extra={"GHT_LEASE_MINUTES": "0"})
        result, live = self._ght_json("claim", "13",
                                      env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        stale = self._ght_json("inspect", "10")[1]
        deadline = time.time() + 5
        while stale["claim_state"] != "STALE" and time.time() < deadline:
            time.sleep(0.2)
            stale = self._ght_json("inspect", "10")[1]
        self.assertEqual(stale["claim_state"], "STALE")
        result = self._ght("takeover", "10", "--evidence", "crashed worker",
                           env_extra={"GHT_TAKEOVER_GRACE_MINUTES": "0",
                                      "GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self._ght_json("inspect", "13")[1]["claim"]["claim_id"],
                         live["claim_id"],
                         "the independent live attempt is untouched")

    def test_takeover_recovers_stale_claim_without_fresh_ready(self):
        self._claim(10, env_extra={"GHT_LEASE_MINUTES": "0"})
        stale = self._ght_json("inspect", "10")[1]
        deadline = time.time() + 5
        while stale["claim_state"] != "STALE" and time.time() < deadline:
            time.sleep(0.2)
            stale = self._ght_json("inspect", "10")[1]
        result, payload = self._ght_json(
            "takeover", "10", "--evidence", "worker crashed mid-attempt",
            env_extra={"GHT_TAKEOVER_GRACE_MINUTES": "0", "GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # AC15/AC3: takeover replaces the execution HOLDER and fencing
        # identity, never the durable attempt identity or branch.
        self.assertEqual(payload["claim_id"], stale["claim"]["claim_id"],
                         "the durable attempt identity is preserved")
        self.assertTrue(payload["attempt_identity_preserved"])
        self.assertEqual(payload["branch"], stale["claim"]["branch"])
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["executor_id"], "worker-2")
        self.assertEqual(inspected["taken_over_evidence"] if "taken_over_evidence" in inspected
                         else inspected.get("takeover_evidence"), "worker crashed mid-attempt")
        self.assertNotIn("supersedes", payload,
                         "takeover recovers the same attempt; it supersedes nothing")
        # Takeover is recovery of the same attempt: READY is not required
        # and none was available.
        self.assertEqual(self._issue(10)["labels"], [])

    def test_terminal_claim_cannot_be_taken_over(self):
        self._claim(10)
        result, _ = self._ght_json("release", "10", "--status", "investigated",
                                   "--note", "investigation recorded")
        self.assertEqual(result.returncode, 0)
        result = self._ght("takeover", "10", "--evidence", "x",
                           env_extra={"GHT_LEASE_MINUTES": "0", "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 5, result.stdout + result.stderr)

    def test_heartbeat_renews_lease_and_survives_response_loss(self):
        self._claim(10, env_extra={"GHT_LEASE_MINUTES": "1"})
        result, payload = self._ght_json("heartbeat", "10", "--force",
                                         env_extra={"GHT_LEASE_MINUTES": "45"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["renewed"])
        extended = payload["lease_expires_at"]
        result, payload = self._ght_json("heartbeat", "10", "--force",
                                         env_extra={"GHT_LEASE_MINUTES": "45",
                                                    "GHT_TEST_FAIL_PUSH_RESPONSE": "1"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["renewed"])
        self.assertGreaterEqual(payload["lease_expires_at"], extended)

    # -- AC4: authority boundaries ---------------------------------------

    def test_investigation_only_authority_executes_and_cannot_deliver_candidate(self):
        claim = self._claim(11, mode="investigate")
        self.assertEqual(claim["authority"], "investigation-only")
        result = self._ght("claim", "11")  # default --mode implement
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self._checkout_claim_branch(claim)
        self._commit_on_branch("notes/findings.md", "findings\n")
        result = self._ght("scope-check", "11")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result = self._ght("preserve", "11")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("investigation-only", result.stdout)
        result = self._ght("deliver", "11", "--pr", "30")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("investigation-only", result.stdout)
        result, payload = self._ght_json("release", "11", "--status", "investigated",
                                         "--note", "RCA recorded")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "11")[1]
        self.assertEqual(inspected["claim"]["status"], "investigated")
        self.assertIsNone(inspected["claim"]["candidate"])

    def test_investigation_only_implementation_mode_is_rejected(self):
        result = self._ght("claim", "11")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("investigation-only", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "11").stdout.strip(), "")

    def test_implementation_allowed_single_attempt_covers_investigation_stage(self):
        # No promotion ceremony: an implementation-allowed attempt may start
        # in investigation mode and still deliver the Candidate.
        claim = self._claim(10, mode="investigate")
        self.assertEqual(claim["authority"], "allowed")
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result = self._ght("scope-check", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["candidate_sha"], sha)
        self._open_pr(20, claim["branch"], sha)
        result, payload = self._ght_json("deliver", "10", "--pr", "20",
                                         "--note", "ready for A review")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # Delivery is not terminal: the task continues through review.
        self.assertEqual(payload["status"], "active")
        self._merge_pr(20)
        result, payload = self._ght_json("complete", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "delivered")

    # -- AC5: deprecated v2 semantics stay out ---------------------------

    def test_claim_record_has_no_deprecated_semantics(self):
        self._claim(10)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        for banned in ("policy_digest", "lane", "preferred_lane", "mode", "promotion",
                       "plan_gate", "investigation_artifact"):
            self.assertNotIn(banned, inspected)
        self.assertIn("contract_digest", inspected)
        self.assertIn("executor_id", inspected)

    def test_runtime_source_has_no_deprecated_surfaces(self):
        sources = "\n".join(
            path.read_text()
            for path in sorted((SKILL_ROOT / "github_task").glob("*.py")))
        for banned in ("policy_digest", "preferred_lane", "lane_pool", "plan_gate",
                       "lifecycle/executing", "lifecycle/done", "lifecycle/blocked",
                       "investigation_artifact", "isPullRequest"):
            self.assertNotIn(banned, sources)

    def test_mirror_writes_are_ready_removal_and_comments_only(self):
        self._claim(10, env_extra={"GHT_TEST_FAIL_REMOVE_LABEL_TIMES": "1"})
        for call in self._calls():
            if call[:2] == ["issue", "edit"]:
                self.assertIn("--remove-label", call)
                self.assertNotIn("--add-label", call)

    def test_contract_change_blocks_but_metadata_edit_does_not(self):
        self._claim(10)
        self._update_issue(10, body=issue_body(IMPL_CONTRACT).replace("Planning metadata",
                                                                      "Edited planning metadata"))
        result = self._ght("verify", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._update_issue(10, body=issue_body(IMPL_CONTRACT.replace(
            "intent: >\n  A small runnable baseline.", "intent: >\n  A changed baseline.")))
        result = self._ght("verify", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)

    # -- scope and delivery identity --------------------------------------

    def test_forbidden_scope_blocks_delivery(self):
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        self._commit_on_branch("template/AGENTS.md", "crossing the boundary\n")
        result = self._ght("scope-check", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        result = self._ght("preserve", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        result = self._ght("deliver", "10", "--pr", "21")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)

    def test_delivery_preserves_exact_candidate_sha(self):
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["candidate_sha"], sha)
        remote_branch = self._git(
            self.repo, "ls-remote", "origin", f"refs/heads/{claim['branch']}").stdout.strip().split()[0]
        self.assertEqual(remote_branch, sha)
        self._open_pr(22, claim["branch"], sha)
        result, payload = self._ght_json("deliver", "10", "--pr", "22",
                                         "--note", "candidate for review")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "10")[1]
        self.assertEqual(inspected["claim"]["status"], "active",
                         "delivery hands off for review; A's merge completes the task")
        self.assertEqual(inspected["claim"]["candidate"]["sha"], sha)
        self.assertEqual(inspected["claim"]["delivery"]["pr"], 22)
        comments = self._issue(10)["comments"]
        self.assertTrue(any(sha in c["body"] for c in comments))
        self._merge_pr(22)
        result, payload = self._ght_json("complete", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "10")[1]
        self.assertEqual(inspected["claim"]["status"], "delivered")
        self.assertEqual(inspected["claim"]["completed"]["merge_commit"], "mergesha0000000000000000000000000000000")

    # ----- #63 zero-prompt B discovery + Current Candidate Snapshot -----

    def test_discover_claims_unique_direct_ready(self):
        # AC1/AC5/AC12: exactly one direct-ready Issue → the decision is an
        # auto claim of that Issue, from a checkout whose remote identifies
        # the repo. Nothing is consumed by discovery itself.
        self._update_issue(10, labels=["ready"])
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["repo"], "example/repo",
                         "the repo is auto-detected from the checkout")
        self.assertEqual(payload["action"], "claim")
        self.assertEqual(payload["issue"], 10)
        # #164 AC2: an implementation-allowed claim decision keeps its
        # existing shape — no mode surface, plain `ght claim <issue>`.
        self.assertNotIn("mode", payload)

    def test_discover_investigation_only_direct_ready_claims_investigate_mode(self):
        # #164 AC1/AC2: a sole otherwise-eligible direct-ready
        # investigation-only Issue is a runnable investigation claim
        # decision carrying the unambiguous investigate-mode admission —
        # never a dead end, never an implementation claim.
        self._update_issue(11, labels=["ready"])
        for number in (10, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "claim",
                         "an investigation-only direct-ready Issue is runnable work")
        self.assertEqual(payload["issue"], 11)
        self.assertEqual(payload.get("mode"), "investigate",
                         "the decision names the investigate-mode admission")
        self.assertEqual(self._issue(11)["labels"], ["ready"],
                         "discovery never consumes the ready authorization")

    def test_discover_investigation_verdict_claim_command_end_to_end(self):
        # #164 AC2 end-to-end: the discover verdict's admission is the
        # exact existing claim command — mode read from the verdict, no
        # out-of-band instruction, no silent implement default; the
        # investigation attempt keeps its existing investigated terminal
        # disposition and never preserves a Candidate.
        self._update_issue(11, labels=["ready"])
        for number in (10, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "claim")
        self.assertEqual(payload["issue"], 11)
        self.assertEqual(payload["mode"], "investigate")
        # The canonical B consumer maps the verdict mechanically:
        # action `claim` + `mode: investigate` → `ght claim 11 --mode investigate`.
        result, claimed = self._ght_json("claim", "11", "--mode", "investigate")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(claimed["authority"], "investigation-only")
        self.assertEqual(claimed["mode"], "investigate")
        # #164 R2 (AC2 blocker): the Skill's investigation branch is backed
        # by real refusals — the implementation Candidate surfaces stay
        # closed for an investigation-only attempt, so the only supported
        # terminal path is the investigation report/release below.
        result = self._ght("preserve", "11")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("investigation-only", result.stdout + result.stderr)
        result = self._ght("deliver", "11", "--pr", "21")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("investigation-only", result.stdout + result.stderr)
        result, payload = self._ght_json("release", "11", "--status", "investigated",
                                         "--note", "admission end-to-end recorded")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "11")[1]
        self.assertEqual(inspected["claim"]["status"], "investigated")
        self.assertIsNone(inspected["claim"]["candidate"])

    def _direct_ready_entry(self, payload, number):
        """The direct-ready verdict surface for one Issue, in either the
        single-item claim shortcut or the handoff workset shape."""
        if payload.get("action") == "claim" and payload.get("issue") == number:
            return {"issue": number, "runnable": True,
                    "mode": payload.get("mode"),
                    "reason": payload.get("reason", "")}
        return next(w for w in payload["work"] if w["issue"] == number)

    def _only_investigation_ready(self):
        for number in (10, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        self._update_issue(11, labels=["ready"])

    def _plant_prior_claim(self, number, *, status="active", executor_id="worker-other",
                           lease_expires_at="2099-01-01T00:00:00Z", delivery=None,
                           resource_reclaim=False, reclaim_tombstone=False):
        """Plant one prior claim lineage record on the Issue's canonical
        claim ref (complete v3 required fields; a foreign executor identity
        by default so the own-attempt continuation paths stay out of the
        way and the direct-ready lineage classification is what runs)."""
        record = {
            "v": 3, "task": number,
            "claim_id": f"prior-{number}",
            "github_principal": "acct",
            "executor_id": executor_id,
            "claimed_at": "2026-01-01T00:00:00Z",
            "lease_expires_at": lease_expires_at,
            "execution_base": "0" * 40,
            "status": status,
            "branch": f"agent/{number}/prior",
            "contract_digest": "d" * 64,
        }
        if delivery is not None:
            record["delivery"] = delivery
        if resource_reclaim:
            record["resource_reclaim"] = {
                "v": 1, "authorized_at": "2026-01-01T00:00:00Z",
                "reason": "execution-resource cleanup (#147)"}
        if reclaim_tombstone:
            record["reclaim_tombstone"] = True
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(record, indent=1)).stdout.strip()
        tree = self._git(self.repo, "mktree",
                         input_text=f"100644 blob {blob}\tCLAIM.json\n").stdout.strip()
        commit = self._git(self.repo, "commit-tree", tree,
                           "-m", f"prior claim lineage {number}").stdout.strip()
        pushed = self._git(self.repo, "push", "-q", "--force", "origin",
                           f"{commit}:refs/ght/claims/{number}")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)

    def test_discover_investigation_ready_with_active_prior_claim_is_not_runnable(self):
        # #164 R2 (AC3 blocker): the investigation-only mode is derived
        # INSIDE the existing lineage gates — a ready investigation Issue
        # with a prior ACTIVE claim is a non-runnable lineage fact, never a
        # runnable `mode: investigate` admission the canonical claim would
        # refuse (false runnable).
        self._only_investigation_ready()
        self._plant_prior_claim(11)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = self._direct_ready_entry(payload, 11)
        self.assertFalse(entry["runnable"],
                         "a prior ACTIVE claim lineage is never a runnable new start")
        self.assertNotIn("mode", entry,
                         "no investigation mode is admitted for a non-runnable verdict")
        self.assertIn("ACTIVE claim lineage", entry["reason"])
        result = self._ght("claim", "11", "--mode", "investigate")
        self.assertNotEqual(result.returncode, 0,
                            "the canonical intake refuses the same lineage fact")
        self.assertIn("ACTIVE", result.stdout + result.stderr)

    def test_discover_investigation_ready_with_stale_prior_claim_is_not_runnable(self):
        # #164 R2 (AC3 blocker): a STALE prior claim recovers through the
        # canonical stale-holder path — discovery must not admit a fresh
        # `mode: investigate` start over it.
        self._only_investigation_ready()
        self._plant_prior_claim(11, lease_expires_at="2020-01-01T00:00:00Z")
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = self._direct_ready_entry(payload, 11)
        self.assertFalse(entry["runnable"],
                         "a STALE claim lineage is never a runnable new start")
        self.assertNotIn("mode", entry)
        self.assertIn("STALE claim", entry["reason"])
        result = self._ght("claim", "11", "--mode", "investigate")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("expired", result.stdout + result.stderr)

    def test_discover_investigation_ready_with_parked_lineage_is_not_runnable(self):
        # #164 R2 (AC3 blocker): a parked lineage (non-terminal attempt with
        # a durable delivered Candidate) keeps its durable identity — a
        # fresh investigation admission must not overwrite it, and the
        # canonical intake refuses the same state.
        self._only_investigation_ready()
        self._plant_prior_claim(11, delivery={"branch": "agent/11/prior",
                                              "sha": "0" * 40})
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = self._direct_ready_entry(payload, 11)
        self.assertFalse(entry["runnable"],
                         "a parked delivered lineage is never a runnable new start")
        self.assertNotIn("mode", entry)
        result = self._ght("claim", "11", "--mode", "investigate")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("parked", result.stdout + result.stderr)

    def test_discover_investigation_ready_with_terminal_investigated_is_not_runnable(self):
        # #164 R2 (AC3 blocker): a terminal `investigated` lineage answered
        # the Contract — discovery must not re-admit it as runnable
        # investigation work; new work belongs on a new Issue.
        self._only_investigation_ready()
        self._plant_prior_claim(11, status="investigated")
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = self._direct_ready_entry(payload, 11)
        self.assertFalse(entry["runnable"],
                         "a terminal investigated lineage is final")
        self.assertNotIn("mode", entry)
        self.assertIn("terminal", entry["reason"].lower())
        self.assertIn("investigated", entry["reason"])
        result = self._ght("claim", "11", "--mode", "investigate")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("terminal", result.stdout + result.stderr)

    def test_discover_investigation_ready_with_pending_reclaim_fence_is_not_runnable(self):
        # #164 R3 (AC3 blocker): a prior terminal blocked Claim carrying a
        # pending `resource_reclaim` marker (the #147 reclaim-tombstone
        # shape: status=blocked + reclaim_tombstone=true + resource_reclaim)
        # fences EVERY new start at the canonical claim intake, BEFORE
        # terminal classification — discovery must not advertise it as a
        # runnable investigation start the canonical `ght claim --mode
        # investigate` provably refuses. Clearing the marker restores normal
        # investigation admission (positive control).
        self._only_investigation_ready()
        self._plant_prior_claim(11, status="blocked",
                                resource_reclaim=True, reclaim_tombstone=True)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = self._direct_ready_entry(payload, 11)
        self.assertFalse(entry["runnable"],
                         "a pending execution-resource reclaim fence is never "
                         "a runnable new start")
        self.assertNotIn("mode", entry,
                         "no investigation mode is admitted past the reclaim fence")
        self.assertIn("reclaim", entry["reason"].lower())
        result = self._ght("claim", "11", "--mode", "investigate")
        self.assertNotEqual(result.returncode, 0,
                            "the canonical intake refuses the same fenced state")
        self.assertIn("reclaim", result.stdout + result.stderr)
        # Positive control: the marker cleared (#147 --confirm-removal
        # strips it from the same lineage) restores normal investigation
        # admission — discovery re-admits the investigate start and the
        # emitted claim command actually succeeds over the re-startable
        # blocked lineage.
        self._plant_prior_claim(11, status="blocked")
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = self._direct_ready_entry(payload, 11)
        self.assertTrue(entry["runnable"],
                        "a cleared marker restores normal admission for a "
                        "re-startable blocked lineage")
        self.assertEqual(entry.get("mode"), "investigate")
        result, claimed = self._ght_json("claim", "11", "--mode", "investigate")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(claimed["mode"], "investigate")

    def test_discover_implementation_ready_with_pending_reclaim_fence_is_not_runnable(self):
        # #164 R3 (AC3): the same canonical pending-reclaim predicate fences
        # BOTH modes — an implementation-allowed direct-ready Issue behind
        # the marker is equally non-runnable (one shared predicate, no
        # second judgment).
        self._update_issue(10, labels=["ready"])
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        self._plant_prior_claim(10, status="blocked", resource_reclaim=True)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = self._direct_ready_entry(payload, 10)
        self.assertFalse(entry["runnable"],
                         "the reclaim fence holds for implementation authority too")
        self.assertNotIn("mode", entry)
        self.assertIn("reclaim", entry["reason"].lower())

    def test_discover_investigation_mode_only_for_genuinely_eligible_new_start(self):
        # #164 R2 (AC3): the mode is emitted ONLY where the canonical intake
        # would accept it — a reclaimable terminal lineage (delivered)
        # admits a genuinely new attempt, so discovery emits the
        # investigate admission AND the emitted claim command succeeds.
        self._only_investigation_ready()
        self._plant_prior_claim(11, status="delivered",
                                lease_expires_at="2020-01-01T00:00:00Z")
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = self._direct_ready_entry(payload, 11)
        self.assertTrue(entry["runnable"],
                        "a reclaimable terminal lineage admits a genuinely new attempt")
        self.assertEqual(entry.get("mode"), "investigate")
        result, claimed = self._ght_json("claim", "11", "--mode", "investigate")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(claimed["mode"], "investigate")

    def test_discover_investigation_only_fail_closed_gates_hold(self):
        # #164 AC3: the investigation admission is only for
        # otherwise-eligible Issues — an unsatisfied hard dependency keeps
        # the entry non-runnable with the durable gate diagnostic, and no
        # mode surface is emitted for a non-runnable verdict.
        for number in (10, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        self._update_issue(11, labels=["ready"])
        self._update_issue(11, body=issue_body(
            INVESTIGATION_CONTRACT.replace("depends_on: []",
                                           "depends_on:\n  - 5")))
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = self._direct_ready_entry(payload, 11)
        self.assertFalse(entry["runnable"],
                         "an unsatisfied dependency stays fail-closed for "
                         "investigation-only authority too")
        self.assertNotIn("mode", entry)
        self.assertIn("dependency", entry["reason"].lower())

    def test_discover_investigation_only_rides_plan_handoff_workset(self):
        # #164 AC1 (conflict-free Plan branch): the same direct-ready
        # eligibility covers the Plan path — a ready investigation-only
        # Issue outside the Plan's nodes rides the handoff workset as
        # runnable investigation work with the investigate-mode admission.
        self._update_issue(11, labels=["ready"])
        for number in (10, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        entries = [w for w in payload["work"] if w["issue"] == 11]
        self.assertEqual(len(entries), 1,
                         "the investigation Issue appears exactly once")
        entry = entries[0]
        self.assertEqual(entry["source"], "direct-ready")
        self.assertTrue(entry["runnable"])
        self.assertEqual(entry.get("mode"), "investigate")
        self.assertIn("ght claim 11 --mode investigate", entry["reason"])
        self.assertEqual(self._issue(11)["labels"], ["ready"],
                         "discovery never consumes the ready authorization")

    def test_discover_no_plan_multi_ready_hands_off_complete_workset(self):
        # #89 R7 (AC3/AC10): with NO current Plan, discovery still hands
        # off the complete independent direct-ready workset — several
        # eligible ready Issues are a deterministic workset for B/host
        # admission, not a unique-selector/ambiguity stop. Discovery
        # consumes nothing: every one-shot ready label survives.
        result = self._ght("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["action"], "handoff")
        work = payload["work"]
        self.assertEqual([w["issue"] for w in work],
                         [10, 11, 12, 13, 14, 15],
                         "the workset is complete and deterministically ordered")
        by_issue = {w["issue"]: w for w in work}
        for entry in work:
            self.assertEqual(entry["source"], "direct-ready")
        for number in (10, 13, 14, 15):
            self.assertTrue(by_issue[number]["runnable"],
                            f"#{number} is mechanically eligible")
        self.assertTrue(by_issue[11]["runnable"],
                        "investigation-only direct-ready is runnable "
                        "investigation work (#164), not a dead end")
        self.assertEqual(by_issue[11].get("mode"), "investigate")
        self.assertIn("ght claim 11 --mode investigate",
                      by_issue[11]["reason"],
                      "the admission names the exact existing claim command")
        self.assertFalse(by_issue[12]["runnable"],
                         "an unsatisfied dependency is a durable reason, "
                         "still represented in the workset")
        for number in (10, 11, 12, 13, 14, 15):
            self.assertEqual(self._issue(number)["labels"], ["ready"],
                             "discovery never consumes the ready authorization")

    def _fabricate_resumable_attempt(self, number, pr_number, env_extra=None):
        # One complete delivered attempt whose PR carries an authoritative
        # exact-SHA REQUEST_CHANGES — the durable continuation state.
        claim = self._claim(number, env_extra=env_extra)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", str(number),
                                          env_extra=env_extra)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(pr_number, claim["branch"], sha)
        result, _payload = self._ght_json("deliver", str(number),
                                          "--pr", str(pr_number),
                                          env_extra=env_extra)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        data = json.loads(self.state.read_text())
        data[str(pr_number)].setdefault("pr_comments", []).append({
            "body": "A REVIEW — REQUEST_CHANGES\n\nReviewed exact Candidate:\n"
                    f"`{sha}`\n\nblocking findings"})
        self.state.write_text(json.dumps(data, indent=2))

    def test_discover_no_plan_resume_and_direct_ready_both_in_workset(self):
        # #89 R8 (AC10): continuation precedence is admission priority,
        # never global exclusivity — no Plan + one REQUEST_CHANGES
        # continuation + one independent direct-ready Issue ⇒ ONE handoff
        # workset with the resume ordered first and the fresh authorized
        # work still visible, its ready label unconsumed.
        self._fabricate_resumable_attempt(10, 60)
        for number in (11, 12, 13, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        self.assertEqual([w["issue"] for w in payload["work"]], [10, 14],
                         "continuation first, fresh authorized work visible")
        self.assertEqual(payload["work"][0]["source"], "resume")
        self.assertEqual(payload["work"][0]["kind"], "resume")
        self.assertTrue(payload["work"][0]["runnable"])
        self.assertEqual(payload["work"][1]["source"], "direct-ready")
        self.assertTrue(payload["work"][1]["runnable"])
        self.assertEqual(self._issue(14)["labels"], ["ready"],
                         "discovery never consumes the ready authorization")

    def test_discover_no_plan_multiple_resumes_in_admission_workset(self):
        # #89 R8 (AC10): several resumable attempts are the complete
        # admission workset (lowest Issue first) — never one resume action
        # with the others demoted to a side list.
        self._fabricate_resumable_attempt(10, 60)
        self._fabricate_resumable_attempt(14, 61)
        for number in (11, 12, 13, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        self.assertEqual([w["issue"] for w in payload["work"]], [10, 14],
                         "both continuations ride the workset, lowest first")
        for entry in payload["work"]:
            self.assertEqual(entry["source"], "resume")
            self.assertTrue(entry["runnable"])

    def test_contract_digest_is_the_canonical_a_surface(self):
        # #91 AC1: `ght contract-digest <issue>` reports the exact digest
        # the claim gate binds — the one canonical primitive, no second
        # implementation — and fails closed on an unreadable Contract.
        result, payload = self._ght_json("contract-digest", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        from github_task.core import contract_digest, parse_contract
        self.assertEqual(payload["contract_digest"],
                         contract_digest(parse_contract(issue_body(IMPL_CONTRACT))))
        self._update_issue(11, body="no contract block here")
        result, _payload = self._ght_json("contract-digest", "11")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("contract", result.stdout.lower())

    def test_plan_publish_binds_fresh_issue_contract_digests(self):
        # #91 AC2/AC5: publication fresh-reads every node's Issue Contract
        # with the canonical primitive; a hand-computed/stale digest, an
        # unreadable Contract, or one mismatched node among several fails
        # the WHOLE publication closed with the current ref unmoved.
        self._update_issue(15, labels=[])
        good = self._orchestration_plan([{"issue": 15, "priority": 1}])
        result, _payload = self._ght_json("contract-digest", "15")
        canonical = json.loads(result.stdout)["contract_digest"]

        # The canonical digest publishes.
        result, payload = self._publish_plan(good)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        first = payload["revision"]

        # A stale digest (the Contract content itself changed after the
        # digest was read) fails closed and the ref stays on the prior
        # revision.
        self._update_issue(15, body=issue_body(INVESTIGATION_CONTRACT))
        stale = self._orchestration_plan([{"issue": 15, "priority": 2}])
        stale["nodes"][0]["contract_digest"] = canonical
        result = self._ght("plan-publish", self._write_plan(stale),
                           "--replace", first)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("digest", result.stdout.lower())
        self.assertEqual(self._git(self.repo, "ls-remote", "origin",
                                   self.PLAN_REF).stdout.split()[0], first)

        # A hand-mangled digest fails closed before any ref mutation.
        mangled = self._orchestration_plan([{"issue": 15, "priority": 3}])
        mangled["nodes"][0]["contract_digest"] = "f" * 64
        result = self._ght("plan-publish", self._write_plan(mangled),
                           "--replace", first)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("digest", result.stdout.lower())
        self.assertEqual(self._git(self.repo, "ls-remote", "origin",
                                   self.PLAN_REF).stdout.split()[0], first)

        # One mismatched node among several prevents the WHOLE publication
        # (no half-publish); the matching node never lands alone.
        self._update_issue(14, labels=[])
        multi = self._orchestration_plan([
            {"issue": 15, "priority": 5}, {"issue": 14, "priority": 4}])
        multi["nodes"][1]["contract_digest"] = "e" * 64
        result = self._ght("plan-publish", self._write_plan(multi),
                           "--replace", first)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("14", result.stdout)
        self.assertEqual(self._git(self.repo, "ls-remote", "origin",
                                   self.PLAN_REF).stdout.split()[0], first,
                         "no half-publish: the good node never lands alone")

        # An unreadable Contract on any node fails closed.
        self._update_issue(14, body="still no contract block")
        unreadable = self._orchestration_plan([
            {"issue": 15, "priority": 5}, {"issue": 14, "priority": 4}])
        result = self._ght("plan-publish", self._write_plan(unreadable),
                           "--replace", first)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self._git(self.repo, "ls-remote", "origin",
                                   self.PLAN_REF).stdout.split()[0], first)

        # The normal replacement flow (AC4): refresh the digest from the
        # canonical surface, then publish the replacement.
        result, _payload = self._ght_json("contract-digest", "15")
        fresh = json.loads(result.stdout)["contract_digest"]
        replacement = self._orchestration_plan([{"issue": 15, "priority": 7}])
        replacement["nodes"][0]["contract_digest"] = fresh
        result, payload = self._ght_json("plan-publish",
                                         self._write_plan(replacement),
                                         "--replace", first)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotEqual(payload["revision"], first)

    def test_contract_digest_fails_closed_when_issue_read_fails(self):
        # #91 R2 (AC5): a genuinely UNREADABLE remote read — the gh adapter
        # fails, e.g. a token without issues:read on a real runner — is a
        # different failure from an invalid Contract body; the canonical
        # surface fails closed on the read itself, never a guessed digest.
        result = self._ght("contract-digest", "10",
                           env_extra={"GHT_TEST_FAIL_ISSUE_VIEW": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_plan_publish_fails_closed_when_issue_read_fails(self):
        # #91 R2 (AC5): the fresh-read digest gate fails closed when the
        # Issue read itself is unavailable; refs/ght/plans/current never
        # appears (no half-published pointer). Kept separate from the
        # invalid-Contract case above.
        self._update_issue(15, labels=[])
        plan = self._orchestration_plan([{"issue": 15, "priority": 1}])
        result = self._ght("plan-publish", self._write_plan(plan),
                           env_extra={"GHT_TEST_FAIL_ISSUE_VIEW": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      self.PLAN_REF).stdout.strip(),
            "", "an unreadable read must never publish a pointer")

    def test_plan_publish_rejects_retired_field_even_as_null(self):
        # #89 R10 (AC1/AC6): the authoring gate is a PRESENCE check — an
        # authored `"max_concurrency": null` document fails closed before
        # any ref mutation, because the exact input text is what gets
        # persisted into canonical PLAN.json.
        doc = self._orchestration_plan([{"issue": 15, "priority": 1}])
        doc["max_concurrency"] = None
        result = self._ght("plan-publish", self._write_plan(doc))
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("max_concurrency", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/plans/current").stdout.strip(),
            "", "fail-closed happened before the current ref moved")

    def test_plan_publish_rejects_retired_max_concurrency(self):
        # #89 R9 (AC1/AC6): a NEWLY authored Plan revision carrying the
        # retired max_concurrency envelope fails closed before any ref
        # mutation, while historical/legacy revisions remain readable
        # (audit-only) through the same parser.
        from github_task.core import parse_execution_plan
        legacy = self._orchestration_plan([{"issue": 15, "priority": 1}])
        legacy["max_concurrency"] = 3
        parsed = parse_execution_plan(json.dumps(legacy))
        self.assertEqual(parsed.get("max_concurrency"), 3,
                         "legacy revisions stay readable/auditable")
        result = self._ght("plan-publish", self._write_plan(legacy))
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("max_concurrency", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/plans/current").stdout.strip(),
            "", "fail-closed happened before the current ref moved")

    def test_discover_consumed_plan_node_does_not_hide_fresh_ready(self):
        # #89 R9 (AC10): a consumed/non-runnable historical Plan node must
        # not hide a fresh valid direct-ready authorization for the same
        # Issue — both stay visible in the handoff workset.
        self._update_issue(14, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 14, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, claimed = self._plan_claim(14, "wave-1-14-a")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # The attempt is blocked: the plan authorization stays consumed
        # while the Issue's claim lineage is no longer ACTIVE.
        result, _payload = self._ght_json("release", "14", "--status", "blocked",
                                          "--note", "blocked; A replans")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # A fresh one-shot authorization lands afterwards: the historical
        # node is consumed, the new grant is live.
        self._update_issue(14, labels=["ready"])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        entries = [w for w in payload["work"] if w["issue"] == 14]
        self.assertEqual(len(entries), 2,
                         "both the consumed node and the fresh grant show")
        kinds = sorted(w["source"] for w in entries)
        self.assertEqual(kinds, ["direct-ready", "plan"])
        node = next(w for w in entries if w["source"] == "plan")
        self.assertFalse(node["runnable"], "the historical node stays not-runnable")
        fresh = next(w for w in entries if w["source"] == "direct-ready")
        self.assertTrue(fresh["runnable"],
                        f"the fresh grant stays visible: {fresh['reason']}")

    def test_discover_single_eligible_keeps_blocked_reasons_visible(self):
        # #89 R9 (AC10): the single-item claim convenience fires only when
        # the eligible Issue is the ONLY ready-listed entry; with another
        # blocked ready item present, discovery hands off the complete
        # workset so the blocked durable reason stays visible.
        for number in (13, 14, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff",
                         "a blocked ready item prevents the claim shortcut")
        by_issue = {w["issue"]: w for w in payload["work"]}
        self.assertTrue(by_issue[10]["runnable"])
        self.assertTrue(by_issue[11]["runnable"],
                        "investigation-only direct-ready is runnable "
                        "investigation work (#164)")
        self.assertEqual(by_issue[11].get("mode"), "investigate")
        self.assertIn("investigation", by_issue[11]["reason"].lower())
        self.assertFalse(by_issue[12]["runnable"],
                         "the blocked reason stays on the canonical surface")

    def _expire_attempt_lease(self, number):
        """#98: simulate the lease supervisor dying between activations —
        the claim record's lease expiry passes while the delivered attempt
        stays parked (delivery durable, lease ref already released)."""
        temp_ref = f"refs/ght-read/expire-{number}"
        fetched = self._git(self.repo, "fetch", "-q", "origin",
                            f"+refs/ght/claims/{number}:{temp_ref}")
        self.assertEqual(fetched.returncode, 0, fetched.stderr)
        rec = json.loads(self._git(self.repo, "show",
                                   f"{temp_ref}:CLAIM.json").stdout)
        rec["lease_expires_at"] = "2020-01-01T00:00:00Z"
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(rec, indent=1)).stdout.strip()
        tree = self._git(self.repo, "mktree",
                         input_text=f"100644 blob {blob}\tCLAIM.json\n").stdout.strip()
        commit = self._git(self.repo, "commit-tree", tree,
                           "-p", temp_ref,
                           "-m", "lease supervisor died").stdout.strip()
        pushed = self._git(self.repo, "push", "--force", "origin",
                           f"{commit}:refs/ght/claims/{number}")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        self._git(self.repo, "update-ref", "-d", temp_ref)

    def test_discover_resumes_parked_attempt_after_lease_expiry(self):
        # #98 AC1/AC5(a)/(b): a parked delivered attempt whose lease expired
        # (supervisor went away) still surfaces as resumable correction —
        # riding the complete workset ahead of fresh authorized work, never
        # folded into "waiting A review" or a 0-runnable answer.
        self._fabricate_resumable_attempt(10, 60)
        self._expire_attempt_lease(10)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        issues = [w["issue"] for w in payload["work"]]
        self.assertEqual(issues[0], 10,
                         "the continuation leads the admission workset")
        work10 = payload["work"][0]
        self.assertEqual(work10["source"], "resume")
        self.assertTrue(work10["runnable"])
        self.assertIn(14, issues,
                      "fresh authorized work stays visible beside it")
        self.assertEqual(self._issue(14)["labels"], ["ready"])

    def test_discover_offers_same_owner_recovery_for_expired_lease_residue(self):
        state_dir = "state-discover-expired"
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        claim = self._claim(10, env_extra={"GHT_STATE_DIR": state_dir})
        self._rewrite_claim_record(10, lease_expires_at="2000-01-01T00:00:00Z")
        lease = self._read_lease_record(claim["claim_id"])
        lease["lease_expires_at"] = "2000-01-01T00:00:00Z"
        self._rewrite_lease_ref(claim["claim_id"], lease)

        result, payload = self._ght_json(
            "discover", env_extra={"GHT_STATE_DIR": state_dir,
                                   "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "resume")
        self.assertEqual(payload["issue"], 10)
        self.assertEqual(payload["claim_id"], claim["claim_id"])
        self.assertEqual(payload["recovery"], "execution_lease")
        self.assertNotIn(10, payload.get("executing_elsewhere", []))

    def test_discover_reports_grace_wait_without_calling_expired_lease_live(self):
        state_dir = "state-discover-grace"
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        claim = self._claim(10, env_extra={"GHT_STATE_DIR": state_dir})
        lease = self._read_lease_record(claim["claim_id"])
        lease["lease_expires_at"] = time.strftime(
            "%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 60))
        self._rewrite_lease_ref(claim["claim_id"], lease)

        result, payload = self._ght_json(
            "discover", env_extra={"GHT_STATE_DIR": state_dir,
                                   "GHT_TAKEOVER_GRACE_MINUTES": "30"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotIn(10, payload.get("executing_elsewhere", []))
        self.assertEqual(payload["action"], "stop")
        self.assertEqual(payload["blocked_recoveries"][0]["issue"], 10)
        self.assertFalse(payload["blocked_recoveries"][0]["reacquirable"])
        self.assertIn("grace", payload["reason"].lower())

    def test_discover_live_lease_elsewhere_is_terminal_and_work_conserving(self):
        # #127 (AC1/AC2/AC5/AC6) — the #125 incident class: an own ACTIVE
        # attempt with a valid live execution lease and an authoritative
        # exact-SHA REQUEST_CHANGES is a terminal executing_elsewhere
        # verdict for this wake — never a resume offer, never runnable,
        # with none of the lease's capacity internals surfacing in the
        # consumer-visible output — while other genuinely runnable work is
        # still admitted by the same verdict (work-conserving, not
        # host-wide blocking).
        self._fabricate_resumable_attempt(10, 60)
        acquired, acquired_payload = self._ght_json("acquire", "10")
        self.assertEqual(acquired.returncode, 0, acquired.stdout + acquired.stderr)
        self.assertTrue(acquired_payload["execution_lease"]["fencing_token"],
                        "the fixture now holds the live lease in another session")
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["executing_elsewhere"], [10],
                         "the live-lease attempt is named as executing elsewhere")
        self.assertNotIn(10, [w["issue"] for w in payload.get("work", [])],
                         "an executing-elsewhere attempt is never an admission item")
        serialized = json.dumps(payload)
        for internal in ("fencing_token", "lease_expires_at", "heartbeat_at",
                         "acquired_at", "renewed_at"):
            self.assertNotIn(internal, serialized,
                             "lease capacity internals never surface to A/User")
        self.assertTrue(any(w["issue"] == 14 and w["runnable"]
                            for w in payload.get("work", [])),
                        "executing_elsewhere is work-conserving: unrelated "
                        "runnable work is still admitted")
        self.assertNotEqual(payload.get("action"), "no_work",
                            "executing elsewhere is not silently folded into "
                            "a genuine no-work answer")

    def test_discover_wrong_executor_sees_expired_residue_as_owned_not_runnable(self):
        claim = self._claim(10)
        self._expire_execution_lease(claim["claim_id"])
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])

        result, payload = self._ght_json(
            "discover", env_extra={"GHT_EXECUTOR_ID": "worker-2",
                                   "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "stop")
        self.assertNotIn(10, payload.get("executing_elsewhere", []))
        ownership = next(item for item in payload["foreign_ownership"]
                         if item["issue"] == 10)
        self.assertIn("worker-1", ownership["reason"])
        self.assertIn("takeover", ownership["reason"].lower())

        result = self._ght("acquire", "10", env_extra={"GHT_EXECUTOR_ID": "worker-2",
                                                         "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("belongs to executor", result.stdout)

        result = self._ght("takeover", "10", "--evidence",
                           "only the execution lease expired",
                           env_extra={"GHT_EXECUTOR_ID": "worker-2",
                                      "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 5, result.stdout + result.stderr)
        self.assertIn("lease is not expired past takeover grace", result.stdout)

    def test_discover_reports_owned_parked_delivery_as_awaiting_review(self):
        self._delivered_parked(10, 76)
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])

        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "stop")
        self.assertEqual(payload["awaiting_review"][0]["issue"], 10)
        self.assertEqual(payload["awaiting_review"][0]["pr"], 76)
        self.assertIn("awaits A", payload["awaiting_review"][0]["reason"])
        self.assertNotIn("stops", payload,
                         "ordinary parked review wait is not an A-facing blocker")

    def test_discover_fails_closed_when_review_surface_unreadable(self):
        # #98 AC4/AC5(c): an unreadable review surface is an explicit
        # fail-closed — never silently degraded into "no REQUEST_CHANGES"
        # or a no-work answer.
        self._fabricate_resumable_attempt(10, 60)
        self._expire_attempt_lease(10)
        result = self._ght("discover", env_extra={"GHT_TEST_FAIL_PR_REVIEWS": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unreadable", result.stdout.lower())

    def test_discover_surfaces_foreign_owned_resumable_attempt(self):
        # #98 AC3/AC5(d): a durable resumable continuation owned by ANOTHER
        # executor is surfaced as an explicit ownership/takeover diagnostic
        # — never folded into a bare no-work answer, never auto-taken-over.
        self._fabricate_resumable_attempt(10, 60,
                                          env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "stop",
                         "the foreign continuation must surface, not no-work")
        foreign = payload.get("foreign_resumable") or []
        self.assertTrue(any(item["issue"] == 10 for item in foreign))
        rendered = json.dumps(foreign)
        self.assertIn("worker-2", rendered)
        self.assertIn("ght takeover", rendered)
        self.assertIn("ght acquire", rendered)

    def _rewrite_claim_record(self, number, **changes):
        """Test-only durable rewrite of CLAIM.json fields on the claim ref."""
        temp_ref = f"refs/ght-read/rewrite-{number}"
        fetched = self._git(self.repo, "fetch", "-q", "origin",
                            f"+refs/ght/claims/{number}:{temp_ref}")
        self.assertEqual(fetched.returncode, 0, fetched.stderr)
        rec = json.loads(self._git(self.repo, "show",
                                   f"{temp_ref}:CLAIM.json").stdout)
        rec.update(changes)
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(rec, indent=1)).stdout.strip()
        tree = self._git(self.repo, "mktree",
                         input_text=f"100644 blob {blob}\tCLAIM.json\n").stdout.strip()
        commit = self._git(self.repo, "commit-tree", tree, "-p", temp_ref,
                           "-m", "rewrite claim record").stdout.strip()
        pushed = self._git(self.repo, "push", "--force", "origin",
                           f"{commit}:refs/ght/claims/{number}")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        self._git(self.repo, "update-ref", "-d", temp_ref)

    def test_discover_fails_closed_on_malformed_active_claim_record(self):
        self._claim(10)
        self._rewrite_claim_record(10, claim_id="")

        result = self._ght("discover")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("claim lineage is malformed", result.stdout)

    def test_discover_foreign_parked_without_request_changes_is_not_resumable(self):
        # #98 AC5(d): a foreign parked delivered Candidate with NO current
        # authoritative exact-SHA REQUEST_CHANGES is an ownership note — it
        # is never labeled resumable and never offered a takeover path that
        # only reviewable continuations earn.
        self._delivered_parked(10, 60, executor="worker-2")
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload.get("foreign_resumable") or [], [],
                         "no REQUEST_CHANGES ⇒ not resumable")
        ownership = payload.get("foreign_ownership") or []
        entry = next((item for item in ownership if item["issue"] == 10), None)
        self.assertIsNotNone(entry,
                             "the parked foreign attempt still surfaces explicitly")
        self.assertIn("worker-2", json.dumps(entry))
        self.assertIn("parked", json.dumps(entry).lower())

    def test_discover_principal_mismatch_is_explicit_ownership_diagnostic(self):
        # #98 AC5(d): ownership lineage is dual — the same executor_id under
        # a different github_principal is NOT this identity's lineage;
        # discovery surfaces an explicit principal-mismatch diagnostic with
        # the canonical recovery requirement, never auto-resume/takeover.
        self._delivered_parked(10, 60)
        self._rewrite_claim_record(10, github_principal="acct-other")
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload.get("foreign_resumable") or [], [],
                         "a principal-mismatched lineage is not resumable")
        ownership = payload.get("foreign_ownership") or []
        entry = next((item for item in ownership if item["issue"] == 10), None)
        self.assertIsNotNone(entry, "the dual-lineage mismatch must surface")
        rendered = json.dumps(entry).lower()
        self.assertIn("acct-other", rendered)
        self.assertIn("principal", rendered)

    def test_discover_foreign_resumable_fails_closed_when_verdict_unreadable(self):
        # #98 AC5(d): foreign resumability reuses the own-resume predicate,
        # so an unreadable verdict surface on the foreign PR is the same
        # fail-closed — never degraded into a silent skip.
        self._fabricate_resumable_attempt(10, 60,
                                          env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        for number in (11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result = self._ght("discover", env_extra={"GHT_TEST_FAIL_PR_REVIEWS": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unreadable", result.stdout.lower())
    def test_discover_reads_remote_truth_via_one_batched_fetch(self):
        # #93 AC2/AC6/AC7: one discover invocation performs exactly ONE
        # remote fetch — the batched snapshot build — and zero per-ref
        # network reads; all durable-truth predicates resolve locally.
        log = self.tmp / "git-calls.log"
        result, payload = self._ght_json("discover", env_extra={
            "GHT_TEST_GIT_LOG": str(log)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        calls = [line for line in log.read_text().splitlines() if line]
        fetches = [c for c in calls if c.startswith("fetch")]
        ls_remotes = [c for c in calls if c.startswith("ls-remote")]
        self.assertEqual(len(fetches), 1,
                         f"exactly one batched snapshot fetch expected, got: {fetches}")
        self.assertIn("refs/ght-snapshot", fetches[0],
                      "the fetch is the batched wildcard snapshot build")
        self.assertEqual(ls_remotes, [],
                         "in-scope refs resolve locally during discovery")

    def test_discover_snapshot_deletion_semantics_no_stale_reads(self):
        # #93 AC3/AC6: a remotely deleted ref disappears from the NEXT
        # invocation's snapshot — the prune gives deterministic deletion
        # semantics, so no stale residue is ever readable.
        self._fabricate_resumable_attempt(10, 60)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(10, [w["issue"] for w in payload["work"]])
        # A remote deletion between invocations must be reflected.
        pushed = self._git(self.repo, "push", "origin", ":refs/ght/claims/10")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotIn(10, [w["issue"] for w in payload.get("work", [])],
                         "a deleted remote ref must not be read from stale residue")
        residual = self._git(self.repo, "for-each-ref",
                             "refs/ght-snapshot/ght/claims/10").stdout.strip()
        self.assertEqual(residual, "",
                         "the prune removed the deleted ref from the snapshot")

    def test_discover_fails_closed_when_snapshot_fetch_fails(self):
        # #93 AC3/AC6: a failed batched snapshot fetch is fail-closed —
        # discovery never guesses from partial remote truth.
        result = self._ght("discover", env_extra={"GHT_TEST_FAIL_FETCH": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("snapshot", result.stdout.lower())

    def test_discover_snapshot_is_invocation_isolated(self):
        # #93 R2 (AC2/AC3/AC5): each invocation builds its own unique
        # snapshot namespace; overlapping activations never see, move, or
        # prune each other's view, an earlier invocation keeps reading its
        # own consistent view across remote moves, and cleanup deletes only
        # the invocation's own refs.
        from github_task.cli import Context
        self._fabricate_resumable_attempt(10, 60)
        cwd = os.getcwd()
        os.chdir(self.repo)
        try:
            a = Context()
            a.begin_remote_snapshot()
            sha_a = a.snapshot_sha("refs/ght/claims/10")
            self.assertTrue(sha_a)
            # Remote truth MOVES between the two snapshot builds.
            rec_ref = a.snapshot_ref("refs/ght/claims/10")
            rec = json.loads(self._git(self.repo, "show", f"{rec_ref}:CLAIM.json").stdout)
            rec["lease_expires_at"] = "2020-01-01T00:00:00Z"
            blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                             input_text=json.dumps(rec, indent=1)).stdout.strip()
            tree = self._git(self.repo, "mktree", input_text=(
                f"100644 blob {blob}\tCLAIM.json\n")).stdout.strip()
            commit = self._git(self.repo, "commit-tree", tree, "-p", rec_ref,
                               "-m", "move while A reads").stdout.strip()
            pushed = self._git(self.repo, "push", "--force", "origin",
                               f"{commit}:refs/ght/claims/10")
            self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
            b = Context()
            b.begin_remote_snapshot()
            # Disjoint namespaces: B's build cannot touch A's view.
            self.assertNotEqual(a.snapshot_prefix, b.snapshot_prefix)
            self.assertEqual(b.snapshot_sha("refs/ght/claims/10"), commit,
                             "B reads its own fresher snapshot")
            self.assertEqual(a.snapshot_sha("refs/ght/claims/10"), sha_a,
                             "A keeps reading exactly its own invocation view")
            # Cleanup is selective: A ends, B's namespace is untouched.
            a.end_remote_snapshot()
            self.assertIsNone(a.snapshot_sha("refs/ght/claims/10"))
            self.assertEqual(b.snapshot_sha("refs/ght/claims/10"), commit)
            b.end_remote_snapshot()
            self.assertIsNone(b.snapshot_sha("refs/ght/claims/10"))
        finally:
            os.chdir(cwd)
        residual = self._git(self.repo, "for-each-ref",
                             "refs/ght-snapshot/").stdout.strip()
        self.assertEqual(residual, "",
                         "nothing outlives the invocations that built it")

    def test_discover_prefers_request_changes_resume_over_fresh_ready(self):
        # AC4/AC7: same-attempt continuation (exact-SHA REQUEST_CHANGES)
        # outranks fresh direct-ready work.
        self._update_issue(15, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, first = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(len(first["delivered"]), 1)
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        data = json.loads(self.state.read_text())
        data[str(inspected["delivery"]["pr"])].setdefault("pr_comments", []).append({
            "body": "A REVIEW — REQUEST_CHANGES\n\nReviewed exact Candidate:\n"
                    f"`{inspected['delivery']['sha']}`\n\nblocking findings"})
        self.state.write_text(json.dumps(data, indent=2))
        self._update_issue(10, labels=["ready"],
                          body=issue_body(IMPL_CONTRACT))
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # #89 AC3/AC10: the handoff expresses the COMPLETE authorized
        # workset in admission-priority order — the #15 correction resume
        # (rank 0) AND the independent fresh ready #10 (direct-ready) are
        # both represented, neither hidden nor consumed.
        self.assertEqual(payload["action"], "handoff")
        issues = [w["issue"] for w in payload["work"]]
        self.assertIn(15, issues)
        self.assertIn(10, issues, "fresh authorized work stays visible")
        work15 = next(w for w in payload["work"] if w["issue"] == 15)
        self.assertTrue(work15["runnable"])
        self.assertEqual(work15.get("kind"), "resume")
        work10 = next(w for w in payload["work"] if w["issue"] == 10)
        self.assertEqual(work10.get("source"), "direct-ready")
        self.assertTrue(work10["runnable"])
        self.assertLess(issues.index(15), issues.index(10),
                        "continuation outranks fresh work as admission priority")
        self.assertEqual(self._issue(10)["labels"], ["ready"],
                         "discovery never consumes the ready authorization")

    def test_discover_prefers_current_plan_over_direct_ready(self):
        # AC6: a current Execution Plan routes B to the canonical
        # orchestrator — even when a direct-ready Issue also exists.
        self._update_issue(15, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        self.assertEqual(payload["plan_id"], "wave-1")

    def test_discover_no_work_safe_exit(self):
        # AC9: nothing resumable, no Plan, no ready → safe no-work exit.
        for number in (10, 11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "no_work")

    def test_discover_dual_authority_issue_never_auto_claimed(self):
        # AC9: an Issue holding BOTH direct ready and a live Plan
        # authorization is never auto-claimed by discovery. With a current
        # Plan present, discovery routes to the canonical orchestrator whose
        # per-node start-gates refuse that node — and the ready surface is
        # left untouched for A to reconcile. (The claim commands themselves
        # fail closed in both directions: see test_dual_authority_fail_closed.)
        self._update_issue(10, labels=[])
        for number in (11, 12, 13, 14):
            self._update_issue(number, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        self.assertEqual(payload["plan_id"], "wave-1")
        self.assertEqual(self._issue(15)["labels"], ["ready"],
                         "discovery never consumes the ambiguous authorization")

    def test_discover_unreadable_ready_surface_fails_closed(self):
        # AC9: an unreadable durable surface never degrades to no_work.
        for number in (10, 11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        result = self._ght("discover", env_extra={"GHT_TEST_FAIL_ISSUE_LIST": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unreadable", result.stdout)

    def test_deliver_updates_current_candidate_snapshot(self):
        # AC14/AC19: delivery mechanically standardizes the PR body as the
        # Current Candidate Snapshot; correction re-delivery REPLACES the
        # snapshot (previous reviewed Candidate recorded) instead of
        # appending round reports. "Previous reviewed" comes only from
        # durable exact-SHA A review evidence — never from a mere prior
        # delivery — and omitting --snapshot reports snapshot_synced=None
        # (no update attempted is not "synced").
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha1 = self._commit_on_branch("skills/demo.txt", "demo\n")
        self._ght_json("preserve", "10")
        self._open_pr(22, claim["branch"], sha1, body="round-1 long report")
        evidence = self.tmp / "ac-evidence.md"
        evidence.write_text(
            "### AC verification\n\n"
            "- [x] AC1 — CLI runs; Evidence: tests.test_cli_safety\n\n"
            "### Validation\n\n- targeted 1/1 green\n\n"
            "### Known limitations\n\n- none\n")
        result, payload = self._ght_json("deliver", "10", "--pr", "22",
                                         "--note", "round-1",
                                         "--snapshot", str(evidence))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["snapshot_synced"])
        body1 = json.loads(self.state.read_text())["22"]["body"]
        self.assertEqual(body1.count("ght:candidate-snapshot:v1"), 2)
        self.assertIn(f"exact Candidate: `{sha1}`", body1)
        self.assertIn("previous reviewed Candidate: none — no durable exact-SHA review",
                      body1, "an unreviewed prior delivery is not labeled reviewed")
        self.assertIn("- [x] AC1", body1)
        self.assertIn("round-1", body1)
        # No --snapshot on a later delivery: not synced — null, not True.
        self._ght_json("acquire", "10")
        sha2 = self._commit_on_branch("skills/demo.txt", "demo2\n")
        self._ght_json("preserve", "10")
        result, payload = self._ght_json("deliver", "10", "--pr", "22",
                                         "--note", "snapshot-less round")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIsNone(payload["snapshot_synced"],
                          "absence of an update attempt is not 'synced'")
        # Correction round with durable ACCEPT bound to the immediately
        # prior reviewed SHA: the snapshot REPLACES the body and binds that
        # SHA as previously REVIEWED.
        data = json.loads(self.state.read_text())
        data["22"].setdefault("pr_comments", []).append({
            "body": "A REVIEW — ACCEPTED\n\nReviewed exact Candidate:\n"
                    f"`{sha2}`\n\naccepted"})
        self.state.write_text(json.dumps(data, indent=2))
        self._ght_json("acquire", "10")
        sha3 = self._commit_on_branch("skills/demo.txt", "demo3\n")
        self._ght_json("preserve", "10")
        result, payload = self._ght_json("deliver", "10", "--pr", "22",
                                         "--note", "round-2 fixes",
                                         "--snapshot", str(evidence))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        body3 = json.loads(self.state.read_text())["22"]["body"]
        self.assertIn(f"exact Candidate: `{sha3}`", body3)
        self.assertIn(f"previous reviewed Candidate: `{sha2}`", body3,
                      "the ACCEPT-reviewed SHA is the previous reviewed Candidate")
        self.assertEqual(body3.count("ght:candidate-snapshot:v1"), 2)
        self.assertNotIn("round-1 long report", body3,
                         "the round-1 body is replaced, not appended to")
        self.assertIn("round-2 fixes", body3)

    def test_snapshot_envelope_exactly_single_after_repeated_redelivery(self):
        # #63 B2: snapshot envelope markers from the evidence input are
        # stripped at render time; repeated re-delivery leaves exactly one
        # start + one end marker and never carries an old round body.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha1 = self._commit_on_branch("skills/demo.txt", "demo\n")
        self._ght_json("preserve", "10")
        self._open_pr(22, claim["branch"], sha1, body="round-1 long report")
        evidence = self.tmp / "nested-evidence.md"
        evidence.write_text(
            "<!-- ght:candidate-snapshot:v1 -->\n"
            "### AC verification\n\n"
            "- [x] AC1 — CLI runs; Evidence: tests.test_cli_safety\n"
            "<!-- /ght:candidate-snapshot:v1 -->\n")
        result, payload = self._ght_json("deliver", "10", "--pr", "22",
                                         "--note", "round-1",
                                         "--snapshot", str(evidence))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        body1 = json.loads(self.state.read_text())["22"]["body"]
        self.assertEqual(body1.count("ght:candidate-snapshot:v1"), 2,
                         "exactly one start + one end marker")
        self.assertIn(f"exact Candidate: `{sha1}`", body1)
        self.assertNotIn("round-1 long report", body1)
        # Second re-delivery at a new Candidate: still exactly one envelope.
        self._ght_json("acquire", "10")
        sha2 = self._commit_on_branch("skills/demo.txt", "demo2\n")
        self._ght_json("preserve", "10")
        result, payload = self._ght_json("deliver", "10", "--pr", "22",
                                         "--note", "round-2",
                                         "--snapshot", str(evidence))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        body2 = json.loads(self.state.read_text())["22"]["body"]
        self.assertEqual(body2.count("ght:candidate-snapshot:v1"), 2,
                         "re-delivery never nests or duplicates the envelope")
        self.assertIn(f"exact Candidate: `{sha2}`", body2)
        self.assertNotIn("round-1 long report", body2,
                         "no old round body survives re-delivery")

    def test_deliver_retry_repairs_snapshot_after_partial_success(self):
        # #136: the full observable delivery operation is idempotent. A
        # durable delivery whose snapshot update failed (partial success:
        # delivery record durable, PR body NOT the snapshot) is repairable
        # by the exact retry — same PR at the same preserved Candidate SHA,
        # still current — which re-applies the Current Candidate Snapshot
        # for that SAME exact Candidate and reports the actual result,
        # without minting a new delivery record, claim, lease, or review
        # round.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        self._ght_json("preserve", "10")
        self._open_pr(68, claim["branch"], sha, body="stale round body")
        missing = self.tmp / "snapshot-not-written.md"
        result, payload = self._ght_json("deliver", "10", "--pr", "68",
                                         "--snapshot", str(missing))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertFalse(payload["snapshot_synced"])
        self.assertEqual(json.loads(self.state.read_text())["68"]["body"],
                         "stale round body",
                         "the failed snapshot update left the PR body untouched")
        # The exact retry with a valid --snapshot repairs the PR body.
        evidence = self.tmp / "repair-evidence.md"
        evidence.write_text(
            "### AC verification\n\n"
            "- [x] AC1 — CLI runs; Evidence: tests.test_cli_safety\n\n"
            "### Validation\n\n- targeted 1/1 green\n\n"
            "### Known limitations\n\n- none\n")
        result, payload = self._ght_json("deliver", "10", "--pr", "68",
                                         "--note", "snapshot repair",
                                         "--snapshot", str(evidence))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["snapshot_synced"])
        body = json.loads(self.state.read_text())["68"]["body"]
        self.assertEqual(body.count("ght:candidate-snapshot:v1"), 2,
                         "exactly one start + one end marker")
        self.assertIn(f"exact Candidate: `{sha}`", body)
        self.assertIn("- [x] AC1", body)
        self.assertNotIn("stale round body", body,
                         "the repair replaces the stale body, it does not append")
        # Durable identity untouched: same delivery record and attempt, no
        # new execution lease, attempt stays non-terminal.
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["delivery"]["sha"], sha)
        self.assertEqual(inspected["delivery"]["pr"], 68)
        self.assertEqual(inspected["claim_id"], claim["claim_id"])
        self.assertEqual(inspected["status"], "active")
        self.assertIsNone(self._lease_remote_sha(claim["claim_id"]),
                          "snapshot repair must not mint an execution lease")

    def test_deliver_retry_snapshot_repair_leaves_reacquired_lease_alone(self):
        # #136/AC3: snapshot repair never touches temporary capacity. A live
        # execution lease held under a legitimately reacquired fencing
        # identity is left to its holder while the PR snapshot is still
        # repaired for the same exact Candidate.
        claim, sha = self._delivered_parked(number=10, pr=73)
        digest = self._ght_json("inspect", "10")[1]["claim"]["contract_digest"]
        reacquired = {"v": 3, "kind": "execution-lease", "claim_id": claim["claim_id"],
                      "issue": 10, "executor_id": "worker-1", "github_principal": "acct",
                      "branch": claim["branch"], "contract_digest": digest,
                      "fencing_token": "reacquired-token",
                      "acquired_at": "2026-09-19T00:00:00Z",
                      "renewed_at": "2026-09-19T00:00:00Z",
                      "lease_expires_at": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                                        time.gmtime(time.time() + 3600))}
        self._raw_lease_ref(claim["claim_id"], reacquired, "ght: reacquired lease")
        evidence = self.tmp / "repair-evidence.md"
        evidence.write_text(
            "### AC verification\n\n"
            "- [x] AC1 — CLI runs; Evidence: tests.test_cli_safety\n")
        result, payload = self._ght_json("deliver", "10", "--pr", "73",
                                         "--snapshot", str(evidence))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertFalse(payload["execution_lease_released"],
                         "the live lease is left to its legitimate holder")
        self.assertIsNotNone(self._lease_remote_sha(claim["claim_id"]),
                             "the reacquired lease is not stolen by the repair")
        self.assertTrue(payload["snapshot_synced"])
        body = json.loads(self.state.read_text())["73"]["body"]
        self.assertIn(f"exact Candidate: `{sha}`", body)

    def test_deliver_retry_snapshot_with_moved_head_fails_closed(self):
        # #136/AC2: snapshot repair never bypasses the exact-SHA fence. A
        # retry whose checkout HEAD moved past the delivered Candidate fails
        # closed exactly like the no-snapshot retry — the PR body is not
        # touched and no lease is minted.
        claim, sha = self._delivered_parked(number=10, pr=75)
        self._open_pr(75, claim["branch"], sha, body="round body")
        evidence = self.tmp / "stale-evidence.md"
        evidence.write_text(
            "### AC verification\n\n"
            "- [x] AC1 — CLI runs; Evidence: tests.test_cli_safety\n")
        self._commit_on_branch("skills/demo.txt", "moved past the Candidate\n")
        result = self._ght("deliver", "10", "--pr", "75",
                           "--snapshot", str(evidence))
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("must bind the current exact Candidate", result.stdout)
        self.assertEqual(json.loads(self.state.read_text())["75"]["body"],
                         "round body",
                         "the rejected stale repair never rewrites the PR body")
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["delivery"]["sha"], sha)
        self.assertIsNone(self._lease_remote_sha(claim["claim_id"]),
                          "the stale retry must not mint an execution lease")

    def test_deliver_retry_different_pr_follows_ordinary_redelivery_path(self):
        # #136/AC2: a retry naming a DIFFERENT PR is not a snapshot repair of
        # the durable delivery — it follows the existing ordinary (re-)
        # delivery path unchanged, which re-records the delivery bound to
        # that PR's head.
        claim, sha = self._delivered_parked(number=10, pr=76)
        self._ght_json("acquire", "10")
        self._open_pr(77, claim["branch"], sha, body="other PR body")
        evidence = self.tmp / "pr-evidence.md"
        evidence.write_text(
            "### AC verification\n\n"
            "- [x] AC1 — CLI runs; Evidence: tests.test_cli_safety\n")
        result, payload = self._ght_json("deliver", "10", "--pr", "77",
                                         "--snapshot", str(evidence))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["delivery"]["pr"], 77,
                         "the ordinary path re-records the delivery for the named PR")
        self.assertEqual(inspected["delivery"]["sha"], sha)
        self.assertTrue(payload["snapshot_synced"])
        body = json.loads(self.state.read_text())["77"]["body"]
        self.assertIn(f"exact Candidate: `{sha}`", body)

    def test_discover_fails_closed_on_dual_namespace_claims(self):
        # #63 B1: zero-prompt resume discovery inherits the canonical
        # same-logical-claim ambiguity guard — a legacy/current dual
        # presence fails closed instead of auto-preferring either ref.
        self._claim(10)
        sha = self._git(self.repo, "ls-remote", "origin",
                        CLAIM_REF + "10").stdout.split()[0]
        self._git(self.repo, "push", "origin", f"{sha}:{LEGACY_CLAIM_REF}10")
        result = self._ght("discover")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("AMBIGUOUS", result.stdout)
        self.assertIn("auto-prefer", result.stdout)

    def test_downstream_adapter_runs_pinned_runtime_completion(self):
        # #63 B3: the thin repo-local caller consumes ONE pinned Harry Dev
        # runtime (pre-fetched here via the GHT_RUNTIME_DIR seam, standing
        # in for the downloaded pinned distribution artifact) and completes
        # through the canonical glue — no copied runtime source, no PAT.
        # GHT_TEST_FAIL_API_USER models the installation-token condition;
        # the reconciler identity carries completion (accepted #69 surface).
        claim, sha = self._delivered_parked(number=10, pr=62, executor="original-worker")
        self._merge_pr(62)
        result = subprocess.run(
            ["sh", str(SKILL_ROOT / "scripts" / "ght-gha-adapter.sh"), "10", "62"],
            cwd=str(self.repo),
            env={**self._env,
                 "GHT_RUNTIME_REF": "a" * 64,
                 "GHT_RUNTIME_DIR": str(SKILL_ROOT),
                 "GHT_TEST_FAIL_API_USER": "1",
                 "GHT_RECONCILER_ID": "ght-complete-workflow",
                 "GHT_EXECUTOR_ID": "ght-complete-workflow"},
            capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "delivered")
        self.assertEqual(inspected["completed"]["completed_by"],
                         "ght-complete-workflow")
        self.assertEqual(inspected["executor_id"], "original-worker")

    def test_downstream_adapter_refuses_floating_runtime(self):
        # AC10: upgrades are explicit — a floating/latest pin is refused;
        # the same-repo capsule pin is a content digest.
        result = subprocess.run(
            ["sh", str(SKILL_ROOT / "scripts" / "ght-gha-adapter.sh"), "10", "62"],
            env={"PATH": "/usr/bin:/bin", "GHT_RUNTIME_REF": "latest"},
            capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("content digest", result.stderr)

    # ----- runtime capsule: sync / immutable identity / upgrade lifecycle

    def _capsule_source(self, name, release="v1.0.3", content="runtime-one"):
        """A stamped Harry Dev distribution copy whose payload digest is
        controlled by `content` (distinct content → distinct capsule)."""
        src = self.tmp / name
        shutil.copytree(SKILL_ROOT, src,
                        ignore=shutil.ignore_patterns(".git", "__pycache__"))
        (src / "DISTRIBUTION.json").write_text(json.dumps(
            {"product": "harry-dev", "release": release, "source_sha": "f" * 40}))
        (src / "RUNTIME_MARKER").write_text(f"{content}\n")
        return src

    def _sync_runtime_from(self, src):
        return self._ght_json("sync-runtime", env_extra={
            "GHT_SYNC_SOURCE_DIR": str(src)})

    def _assert_capsule_digest_intact(self, digest):
        """The published capsule ref still carries a payload hashing to its
        content-addressed identity (immutability check)."""
        import hashlib
        self._git(self.repo, "fetch", "--force", "origin",
                  f"refs/ght/runtime/{digest}")
        payload_file = self.tmp / f"capsule-{digest[:8]}.zip"
        with open(payload_file, "wb") as handle:
            subprocess.run([REAL_GIT, "cat-file", "blob", "FETCH_HEAD:runtime.zip"],
                           stdout=handle, cwd=self.repo, check=True)
        self.assertEqual(hashlib.sha256(payload_file.read_bytes()).hexdigest(), digest)

    def test_sync_runtime_publishes_immutable_capsule_idempotently(self):
        # First sync CAS-creates the content-addressed capsule; repeated
        # identical sync is idempotent and never overwrites anything.
        src = self._capsule_source("dist-a", content="runtime-one")
        result, payload = self._sync_runtime_from(src)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "created")
        digest = payload["digest"]
        self.assertEqual(payload["ref"], f"refs/ght/runtime/{digest}")
        self.assertEqual(payload["release"], "v1.0.3")
        self.assertTrue(
            self._git(self.repo, "ls-remote", "origin",
                      payload["ref"]).stdout.strip())
        self._assert_capsule_digest_intact(digest)
        result, again = self._sync_runtime_from(src)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(again["status"], "idempotent")
        self.assertEqual(again["digest"], digest)
        self._assert_capsule_digest_intact(digest)

    def test_sync_runtime_refuses_unstamped_source(self):
        # The bootstrap source is the installed/STAMPED distribution; an
        # unstamped tree carries no release identity to bind.
        src = self.tmp / "unstamped"
        shutil.copytree(SKILL_ROOT, src,
                        ignore=shutil.ignore_patterns(".git", "__pycache__"))
        result = self._ght("sync-runtime", env_extra={
            "GHT_SYNC_SOURCE_DIR": str(src)})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("stamped", result.stdout)

    def test_sync_runtime_conflicting_same_identity_fails_closed(self):
        # Same identity (ref = digest) whose payload content diverged →
        # fail closed; the capsule is never overwritten.
        import hashlib
        from github_task import cli as ght_cli
        src = self._capsule_source("dist-a", content="runtime-one")
        result, payload = self._sync_runtime_from(src)
        digest = payload["digest"]
        # Plant a diverged payload under the same identity ref.
        other = self._capsule_source("dist-diverged", content="runtime-OTHER")
        diverged_payload, manifest = ght_cli._runtime_capsule_payload(other)
        manifest["digest"] = digest  # forge the identity, keep diverged content
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(manifest)).stdout.strip()
        payload_file = self.tmp / "diverged.zip"
        payload_file.write_bytes(diverged_payload)
        payload_blob = self._git(self.repo, "hash-object", "-w",
                                 str(payload_file)).stdout.strip()
        tree = self._git(self.repo, "mktree", input_text=(
            f"100644 blob {payload_blob}\truntime.zip\n"
            f"100644 blob {blob}\tMANIFEST.json\n")).stdout.strip()
        identity_env = {**os.environ, "GIT_AUTHOR_NAME": "g",
                        "GIT_AUTHOR_EMAIL": "g@t", "GIT_COMMITTER_NAME": "g",
                        "GIT_COMMITTER_EMAIL": "g@t"}
        commit = self._git(self.repo, "commit-tree", tree, "-m", "diverged",
                           env=identity_env).stdout.strip()
        moved = self._git(self.repo, "push", "--force", "origin",
                          f"{commit}:refs/ght/runtime/{digest}")
        self.assertEqual(moved.returncode, 0, moved.stderr)
        result = self._ght("sync-runtime", env_extra={
            "GHT_SYNC_SOURCE_DIR": str(src)})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("diverged", result.stdout)

    def test_downstream_adapter_consumes_same_repo_capsule(self):
        # The full same-repo consumption model end to end: sync publishes
        # the immutable capsule; the thin adapter fetches it from the
        # TARGET repo (no cross-repo access, no PAT) and completes
        # executor-neutrally under the installation-token condition.
        src = self._capsule_source("dist-final", release="v1.0.3",
                                   content="runtime-final")
        result, capsule = self._sync_runtime_from(src)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        claim, sha = self._delivered_parked(number=10, pr=62, executor="original-worker")
        self._merge_pr(62)
        result = subprocess.run(
            ["sh", str(SKILL_ROOT / "scripts" / "ght-gha-adapter.sh"), "10", "62"],
            cwd=str(self.repo),
            env={**self._env,
                 "GHT_RUNTIME_REF": capsule["digest"],
                 "GHT_TEST_FAIL_API_USER": "1",
                 "GHT_RECONCILER_ID": "ght-complete-workflow",
                 "GHT_EXECUTOR_ID": "ght-complete-workflow"},
            capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "delivered")
        self.assertEqual(inspected["completed"]["completed_by"],
                         "ght-complete-workflow")
        self.assertEqual(inspected["executor_id"], "original-worker")
        # R4-2: the adapter's private temp refs leave no residue — including
        # across the exec hand-off to the completion glue.
        leftover = self._git(self.repo, "for-each-ref",
                             "refs/ght/tmp").stdout.strip()
        self.assertEqual(leftover, "")

    # ----- #178: full-SHA release identity producer/consumer + the bounded
    # v1.1.2 legacy capsule compatibility path (create-only, fail-closed)

    V112_LEGACY_RELEASE = "v1.1.2"
    V112_LEGACY_DIGEST = ("fee4e7022707b4da7ab54651aaedadfc"
                          "b78a21ce489521df6fef78c0f12fe962")
    V112_LEGACY_SHORT_SHA = "cfb522a"
    V112_LEGACY_EXACT_SHA = "cfb522ac701504c12095c1c408bc89a2e033f557"

    def _legacy_v112_capsule(self):
        """Deterministically reconstruct the REAL published v1.1.2 runtime
        capsule from this repository's own frozen tag: the exact-tag
        checkout, that era's stamping semantics (content-binding digest,
        recorded release repo, ABBREVIATED source_sha — the proven producer
        defect), and the production capsule serializer. The digest assertion
        in the fixture test proves these are the historical bytes published
        at refs/ght/runtime/fee4e702… downstream, not a synthetic look-alike."""
        import io
        import tarfile
        from github_task import cli as ght_cli
        archive = subprocess.run(
            [REAL_GIT, "-C", str(SKILL_ROOT.parents[1]), "archive",
             f"{self.V112_LEGACY_RELEASE}:skills/github-task"],
            capture_output=True)
        self.assertEqual(archive.returncode, 0, archive.stderr.decode())
        tree = self.tmp / "v112-release-tree"
        tree.mkdir()
        with tarfile.open(fileobj=io.BytesIO(archive.stdout), mode="r:") as tar:
            for member in tar.getmembers():
                if not member.isfile():
                    continue
                path = tree / member.name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(tar.extractfile(member).read())
                path.chmod(member.mode & 0o777)
        content = ght_cli._distribution_content_digest(tree)
        binding = ght_cli._distribution_identity_binding(
            self.V112_LEGACY_RELEASE, self.V112_LEGACY_SHORT_SHA, content)
        (tree / "DISTRIBUTION.json").write_text(json.dumps(
            {"product": "harry-dev", "release": self.V112_LEGACY_RELEASE,
             "release_repo": "harryhua-ai/harry-dev",
             "source_sha": self.V112_LEGACY_SHORT_SHA, "digest": binding},
            sort_keys=True))
        return ght_cli._runtime_capsule_payload(tree)

    def _plant_runtime_capsule(self, payload, manifest, pin=False):
        """Publish a capsule at its content-addressed ref (and the project
        pin when requested) exactly the way sync/activation leave them."""
        payload_file = self.tmp / f"plant-{manifest['digest'][:8]}.zip"
        payload_file.write_bytes(payload)
        payload_blob = self._git(self.repo, "hash-object", "-w",
                                 str(payload_file)).stdout.strip()
        manifest_blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                                  input_text=json.dumps(
                                      manifest, sort_keys=True)).stdout.strip()
        tree = self._git(self.repo, "mktree", input_text=(
            f"100644 blob {payload_blob}\truntime.zip\n"
            f"100644 blob {manifest_blob}\tMANIFEST.json\n")).stdout.strip()
        identity_env = {**os.environ,
                        "GIT_AUTHOR_NAME": "ght", "GIT_AUTHOR_EMAIL": "ght@harry-dev",
                        "GIT_COMMITTER_NAME": "ght", "GIT_COMMITTER_EMAIL": "ght@harry-dev"}
        commit = self._git(self.repo, "commit-tree", tree, "-m", "planted capsule",
                           env=identity_env).stdout.strip()
        pushed = self._git(self.repo, "push", "-q", "--force", "origin",
                           f"{commit}:refs/ght/runtime/{manifest['digest']}")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        if pin:
            pushed = self._git(self.repo, "push", "-q", "--force", "origin",
                               f"{commit}:refs/ght/runtime/current")
            self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)

    def _remote_sha(self, ref):
        out = self._git(self.repo, "ls-remote", "origin", ref).stdout.strip()
        return out.split()[0] if out else None

    def _run_adapter(self, issue, pr):
        """Run the shipped thin adapter the way the downstream workflow does:
        installation-token condition, executor-neutral reconciler identity,
        full capsule materialization (no GHT_RUNTIME_DIR seam, no pin
        fallback — the attempt's own binding must resolve)."""
        return subprocess.run(
            ["sh", str(SKILL_ROOT / "scripts" / "ght-gha-adapter.sh"),
             str(issue), str(pr)],
            cwd=str(self.repo),
            env={**self._env,
                 "GHT_TEST_FAIL_API_USER": "1",
                 "GHT_RECONCILER_ID": "ght-complete-workflow",
                 "GHT_EXECUTOR_ID": "ght-complete-workflow"},
            capture_output=True, text=True)

    def test_stamped_release_distribution_completes_through_adapter(self):
        # #178 AC2: the REAL new-producer → new-adapter seam, end to end.
        # A genuinely tagged `stamp-distribution` run (exact-tag checkout,
        # full 40-hex HEAD — not the fabricated `_capsule_source` identity
        # the consumption fixtures use) is published as its
        # content-addressed capsule, activated, and bound to a NEW attempt;
        # that SAME artifact is then materialized and completed by the
        # shipped thin adapter through the ordinary completion gates. This
        # is the integration path whose absence let the v1.1.2 defect
        # ship: the producer's output must pass the consumer's validation,
        # and the bounded legacy exception is never entered.
        dist = self._dist_repo()
        self._git(dist, "tag", "v1.0.4")
        tagged_head = self._git(dist, "rev-parse", "HEAD").stdout.strip()
        self.assertRegex(tagged_head, r"^[0-9a-f]{40}$")
        install = self.tmp / "stamped-dist"
        shutil.copytree(SKILL_ROOT, install,
                        ignore=shutil.ignore_patterns(".git", "__pycache__",
                                                      "DISTRIBUTION.json"))
        result, payload = self._ght_json(
            "stamp-distribution", "--release", "v1.0.4",
            "--source", str(dist), "--root", str(install))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["stamped"],
                         {"product": "harry-dev", "release": "v1.0.4",
                          "source_sha": tagged_head})
        # Producer provenance: the stamped manifest IS the artifact the
        # capsule is built from, and it carries the exact tagged HEAD.
        stamped = json.loads((install / "DISTRIBUTION.json").read_text())
        self.assertEqual(stamped["source_sha"], tagged_head)
        # Publish the stamped distribution as its content-addressed capsule
        # and activate it; the ACTUAL capsule manifest must carry the exact
        # tagged full HEAD.
        result, capsule = self._sync_runtime_from(install)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(capsule["release"], "v1.0.4")
        self._git(self.repo, "fetch", "-q", "--force", "origin",
                  f"+{capsule['ref']}:refs/ght-read/capsule")
        manifest = json.loads(self._git(
            self.repo, "show", "refs/ght-read/capsule:MANIFEST.json").stdout)
        self._git(self.repo, "update-ref", "-d", "refs/ght-read/capsule")
        self.assertEqual(manifest["source_sha"], tagged_head,
                         "the capsule manifest must carry the tagged full HEAD")
        result, _payload = self._ght_json("activate-runtime", capsule["digest"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # A NEW attempt binds exactly this artifact...
        claim, _sha = self._delivered_parked(number=10, pr=62,
                                             executor="original-worker")
        binding = self._ght_json("inspect", "10")[1]["claim"]["runtime"]
        self.assertEqual(binding, {"digest": capsule["digest"],
                                   "release": "v1.0.4",
                                   "source_sha": tagged_head})
        # ...and the shipped adapter materializes THAT capsule and completes
        # through the ordinary gates — with no legacy branch in the log.
        self._merge_pr(62)
        result = self._run_adapter(10, 62)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("materialized runtime capsule", result.stderr)
        self.assertNotIn("legacy", result.stderr,
                         "a full-SHA stamped distribution takes the ordinary "
                         "path; the v1.1.2 exception must stay closed")
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "delivered")
        self.assertEqual(inspected["completed"]["completed_by"],
                         "ght-complete-workflow")
        self.assertEqual(inspected["executor_id"], "original-worker")
        self.assertEqual(inspected["runtime"],
                         {"digest": capsule["digest"],
                          "release": "v1.0.4",
                          "source_sha": tagged_head},
                         "the attempt binding is never rewritten")
        leftover = self._git(self.repo, "for-each-ref",
                             "refs/ght/tmp").stdout.strip()
        self.assertEqual(leftover, "")

    def test_legacy_v112_fixture_reconstructs_the_published_capsule(self):
        # The compatibility anchor: rebuilding the frozen v1.1.2 tag with
        # that era's stamping semantics must reproduce the EXACT capsule
        # bytes published at refs/ght/runtime/fee4e702… downstream — the
        # legacy predicate is bounded to the real artifact, never a shape.
        import hashlib
        payload, manifest = self._legacy_v112_capsule()
        self.assertEqual(manifest["release"], self.V112_LEGACY_RELEASE)
        self.assertEqual(manifest["source_sha"], self.V112_LEGACY_SHORT_SHA)
        self.assertEqual(hashlib.sha256(payload).hexdigest(),
                         self.V112_LEGACY_DIGEST)

    def test_legacy_v112_capsule_completes_through_fixed_adapter(self):
        # #178 AC3: a historical attempt still bound to the immutable v1.1.2
        # capsule (release v1.1.2, digest fee4e702…, abbreviated source_sha
        # cfb522a) completes automatically through the FIXED thin adapter:
        # the bounded legacy identity predicate accepts exactly that tuple,
        # materializes the OLD capsule, and every ordinary completion gate
        # still runs. #178 AC4: no old remote data is rewritten — the
        # capsule/pin objects the attempt is bound to are untouched, and the
        # claim's original binding and executor identity survive.
        payload, manifest = self._legacy_v112_capsule()
        self._plant_runtime_capsule(payload, manifest, pin=True)
        claim, _sha = self._delivered_parked(number=10, pr=62,
                                             executor="original-worker")
        binding = self._ght_json("inspect", "10")[1]["claim"]["runtime"]
        self.assertEqual(binding,
                         {"digest": self.V112_LEGACY_DIGEST,
                          "release": self.V112_LEGACY_RELEASE,
                          "source_sha": self.V112_LEGACY_SHORT_SHA})
        self._merge_pr(62)
        before = {ref: self._remote_sha(ref) for ref in
                  (f"refs/ght/runtime/{self.V112_LEGACY_DIGEST}",
                   "refs/ght/runtime/current")}
        result = self._run_adapter(10, 62)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("materialized runtime capsule", result.stderr)
        self.assertIn("legacy", result.stderr,
                      "the legacy acceptance is auditable in the run log")
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "delivered")
        self.assertEqual(inspected["completed"]["completed_by"],
                         "ght-complete-workflow")
        self.assertEqual(inspected["executor_id"], "original-worker")
        self.assertEqual(inspected["runtime"],
                         {"digest": self.V112_LEGACY_DIGEST,
                          "release": self.V112_LEGACY_RELEASE,
                          "source_sha": self.V112_LEGACY_SHORT_SHA},
                         "the historical binding is never rewritten")
        for ref, sha_before in before.items():
            self.assertEqual(self._remote_sha(ref), sha_before,
                             f"{ref} is immutable under legacy completion")
        leftover = self._git(self.repo, "for-each-ref",
                             "refs/ght/tmp").stdout.strip()
        self.assertEqual(leftover, "")

    def test_new_capsule_activation_does_not_rebind_existing_claim(self):
        # #178 AC4: activating a NEW full-SHA capsule is future-only. The
        # historical attempt keeps its v1.1.2 capsule binding (nothing
        # "heals" the old claim's pin), while a NEW attempt binds the newly
        # activated identity.
        payload, manifest = self._legacy_v112_capsule()
        self._plant_runtime_capsule(payload, manifest, pin=True)
        old_claim, _sha = self._delivered_parked(number=10, pr=60)
        old_binding = self._ght_json("inspect", "10")[1]["claim"]["runtime"]
        self.assertEqual(old_binding["digest"], self.V112_LEGACY_DIGEST)
        src = self._capsule_source("dist-fixed", release="v1.1.3",
                                   content="runtime-fixed")
        result, capsule = self._sync_runtime_from(src)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._ght_json("activate-runtime", capsule["digest"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["runtime"]["digest"], self.V112_LEGACY_DIGEST,
                         "activation never re-binds an existing claim's capsule")
        new_claim = self._claim(14)
        new_binding = self._ght_json("inspect", "14")[1]["claim"]["runtime"]
        self.assertEqual(new_binding["digest"], capsule["digest"],
                         "only NEW attempts bind the activated capsule")

    def test_release_activation_readback_requires_exact_source_equality(self):
        # #178 AC1: the release read-back gate is EXACT source equality.
        # The historical v1.1.2 form — an abbreviated manifest source_sha
        # that is merely a PREFIX of the frozen target — must be refused,
        # not accepted through prefix matching.
        from github_task.cli import CommandFailure, Context, \
            _verify_release_runtime_publication
        payload, manifest = self._legacy_v112_capsule()
        self._plant_runtime_capsule(payload, manifest, pin=True)
        cwd = os.getcwd()
        os.chdir(self.repo)
        try:
            with self.assertRaises(CommandFailure):
                _verify_release_runtime_publication(
                    Context(), self.V112_LEGACY_DIGEST,
                    self.V112_LEGACY_RELEASE, self.V112_LEGACY_EXACT_SHA)
        finally:
            os.chdir(cwd)

    def _legacy_style_capsule(self, release, source_sha, marker):
        """An internally consistent capsule (payload digest == manifest
        digest) in the v1.1.2 shape — used to prove the legacy predicate
        rejects every identity that is not the exact published tuple."""
        import hashlib
        from github_task import cli as ght_cli
        tree = self.tmp / f"legacy-style-{marker[:6]}"
        shutil.copytree(SKILL_ROOT, tree,
                        ignore=shutil.ignore_patterns(".git", "__pycache__",
                                                      "DISTRIBUTION.json"))
        (tree / "RUNTIME_MARKER").write_text(f"{marker}\n")
        payload, manifest = ght_cli._runtime_capsule_payload(tree)
        manifest["release"] = release
        manifest["source_sha"] = source_sha
        manifest["digest"] = hashlib.sha256(payload).hexdigest()
        return payload, manifest

    def _assert_legacy_rejected(self, payload, manifest, fragment):
        self._plant_runtime_capsule(payload, manifest, pin=True)
        _claim, _sha = self._delivered_parked(number=10, pr=62)
        binding = self._ght_json("inspect", "10")[1]["claim"]["runtime"]
        self.assertEqual(binding["digest"], manifest["digest"])
        self._merge_pr(62)
        result = self._run_adapter(10, 62)
        self.assertNotEqual(result.returncode, 0,
                            f"adapter accepted {manifest!r}")
        self.assertIn(fragment, result.stderr)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertNotIn("completed", inspected,
                         "a rejected legacy identity never completes")

    def test_legacy_predicate_rejects_arbitrary_short_source_sha(self):
        # Only the exact published abbreviation is legacy proof; any other
        # short SHA fails closed.
        payload, manifest = self._legacy_style_capsule(
            self.V112_LEGACY_RELEASE, "deadbe1", "reject-short-sha")
        self._assert_legacy_rejected(payload, manifest, "exact source SHA")

    def test_legacy_predicate_rejects_truncated_exact_sha(self):
        # A truncation of the real frozen SHA (39 hex) is still not the
        # published abbreviation and is not a full SHA: fail closed.
        payload, manifest = self._legacy_style_capsule(
            self.V112_LEGACY_RELEASE, self.V112_LEGACY_EXACT_SHA[:39],
            "reject-39-hex")
        self._assert_legacy_rejected(payload, manifest, "exact source SHA")

    def test_legacy_predicate_rejects_release_mismatch(self):
        # The right abbreviation under the WRONG release is not the
        # published legacy identity.
        payload, manifest = self._legacy_style_capsule(
            "v1.1.3", self.V112_LEGACY_SHORT_SHA, "reject-release-mismatch")
        self._assert_legacy_rejected(payload, manifest, "exact source SHA")

    def test_legacy_predicate_rejects_unknown_legacy_digest(self):
        # A capsule claiming the legacy release+short source but carrying a
        # different content digest is NOT the published immutable capsule.
        payload, manifest = self._legacy_style_capsule(
            self.V112_LEGACY_RELEASE, self.V112_LEGACY_SHORT_SHA,
            "reject-unknown-digest")
        self.assertNotEqual(manifest["digest"], self.V112_LEGACY_DIGEST)
        self._assert_legacy_rejected(payload, manifest, "exact source SHA")

    def test_adapter_rejects_corrupted_legacy_payload(self):
        # A capsule pinned to the real v1.1.2 digest whose payload bytes
        # diverge from that digest is interleaved corruption: fail closed
        # before any materialization, regardless of manifest claims. (The
        # binding is planted durably WITHOUT running continuation commands
        # against the corrupted runtime — those fail closed on their own.)
        self._delivered_parked(number=10, pr=62)
        self._rewrite_claim_record(10, runtime={
            "digest": self.V112_LEGACY_DIGEST,
            "release": self.V112_LEGACY_RELEASE,
            "source_sha": self.V112_LEGACY_SHORT_SHA})
        corrupt_manifest = {"v": 1, "kind": "runtime-capsule",
                            "product": "harry-dev",
                            "release": self.V112_LEGACY_RELEASE,
                            "source_sha": self.V112_LEGACY_SHORT_SHA,
                            "digest": self.V112_LEGACY_DIGEST}
        self._plant_runtime_capsule(b"corrupted-payload-bytes", corrupt_manifest,
                                    pin=False)
        self._merge_pr(62)
        result = self._run_adapter(10, 62)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("diverges from pinned identity", result.stderr)

    def test_read_runtime_pin_does_not_depend_on_fetch_head(self):
        # R4-2: the project pin read uses a private temp ref — an unrelated
        # concurrent fetch clobbering FETCH_HEAD cannot corrupt it.
        src = self._capsule_source("dist-pin", content="runtime-pin")
        _r, capsule = self._sync_runtime_from(src)
        self._ght("activate-runtime", capsule["digest"])
        self._git(self.repo, "fetch", "origin", "main")  # clobber FETCH_HEAD
        from github_task.cli import Context, _read_runtime_pin
        cwd = os.getcwd()
        os.chdir(self.repo)
        try:
            pin = _read_runtime_pin(Context())
        finally:
            os.chdir(cwd)
        self.assertIsNotNone(pin)
        self.assertEqual(pin["digest"], capsule["digest"])

    def test_activate_runtime_survives_interleaved_fetch(self):
        # R4-2: activation verifies the capsule through a private temp ref,
        # so an unrelated fetch between sync and activation cannot make it
        # activate (or refuse) the wrong object.
        src = self._capsule_source("dist-a", content="runtime-one")
        _r, capsule = self._sync_runtime_from(src)
        self._git(self.repo, "fetch", "origin", "main")  # clobber FETCH_HEAD
        result = self._ght("activate-runtime", capsule["digest"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        from github_task.cli import RUNTIME_PIN_REF
        pin_sha = self._git(self.repo, "ls-remote", "origin",
                            RUNTIME_PIN_REF).stdout.split()[0]
        self._git(self.repo, "fetch", "--force", "origin", pin_sha)
        manifest = json.loads(self._git(
            self.repo, "show", "FETCH_HEAD:MANIFEST.json").stdout)
        self.assertEqual(manifest["digest"], capsule["digest"])

    def test_discover_fails_closed_on_missing_runtime_identity_proof(self):
        # #98 R3 (AC2/AC5(e)): "no pin" is NOT "nothing to enforce". Until
        # the repo durably declares its accepted runtime identity
        # (refs/ght/runtime/current), discovery cannot mechanically prove
        # the effective runtime against it and must FAIL CLOSED with the
        # canonical refresh/activation recovery path — never compile a
        # verdict (least of all a silent no_work) from unproven identity.
        pushed = self._git(self.repo, "push", "origin",
                           ":refs/ght/runtime/current")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        result = self._ght("discover")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotIn('"no_work"', result.stdout,
                         "missing identity proof must not read as no work")
        self.assertIn("runtime", result.stdout.lower())
        self.assertIn("sync-runtime", result.stdout,
                      "the canonical refresh path is named")
        self.assertIn("activate-runtime", result.stdout,
                      "the canonical activation path is named")

    def test_discover_stale_effective_runtime_returns_refresh_required(self):
        # #102 (AC1/AC3): the zero-prompt discovery boundary proves the
        # effective runtime identity against the project-activated runtime
        # capsule BEFORE any verdict. A stale/different effective runtime
        # never compiles a frontier verdict — the machine-readable
        # `refresh_required` decision is the ONLY output, carrying both
        # identities and the canonical local refresh/reload guidance.
        # Matching identity proceeds into the normal frontier.
        from github_task import cli as ght_cli
        installed_a = self._capsule_source("installed-a", content="runtime-one")
        _r, capsule_a = self._sync_runtime_from(installed_a)
        result = self._ght("activate-runtime", capsule_a["digest"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        installed_b = self._capsule_source("installed-b", content="runtime-two")
        result, payload = self._ght_json("discover", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(installed_b)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "refresh_required")
        self.assertEqual(payload["effective_identity"],
                         {"digest": ght_cli._runtime_payload_digest(installed_b)},
                         "the effective (stale) identity is reported")
        self.assertEqual(payload["expected_identity"],
                         {"digest": capsule_a["digest"], "release": "v1.0.3",
                          "source_sha": capsule_a["source_sha"]},
                         "the expected (activated) identity is reported")
        self.assertIn(capsule_a["digest"][:12], result.stdout,
                      "the mismatching identities are both named")
        self.assertNotIn('"no_work"', result.stdout,
                         "a stale runtime must not silently emit a no-work verdict")
        for retired_verdict in ('"action": "handoff"', '"action": "claim"',
                                '"action": "resume"', '"action": "stop"'):
            self.assertNotIn(retired_verdict, result.stdout,
                             "stale discovery returns ONLY refresh_required")
        self.assertNotIn('"work"', result.stdout,
                         "a stale runtime must not compile the durable frontier")
        guidance = " ".join(payload["refresh"])
        self.assertIn("ght discover", guidance,
                      "the guidance routes through re-discovery after refresh")
        self.assertIn("sync-runtime", guidance,
                      "the guidance names the activation surfaces as NOT a "
                      "B freshness action")
        # The canonical local refresh path: reload the local Skill to the
        # activated identity and re-discover — the frontier compiles again.
        result, payload = self._ght_json("discover", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(installed_a)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff",
                         "matching effective runtime discovers normally")

    def test_discover_refresh_required_even_when_frontier_is_empty(self):
        # #102 (AC5): stale + no work is still refresh_required — never a
        # no_work verdict compiled from stale semantics.
        for number in (10, 11, 12, 13, 14, 15):
            self._update_issue(number, labels=[])
        stale = self._capsule_source("installed-stale", content="runtime-stale")
        result, payload = self._ght_json("discover", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(stale)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "refresh_required")
        self.assertNotIn('"no_work"', result.stdout)

    def test_discover_runtime_identity_diagnostics_are_distinguishable(self):
        # #102 (AC1): the canonical-identity failure shapes are mechanically
        # distinct diagnostics — "not yet activated" vs "unreadable/ambiguous"
        # — and both fail closed without compiling any verdict.
        pushed = self._git(self.repo, "push", "origin",
                           ":refs/ght/runtime/current")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        result = self._ght("discover")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("not activated", result.stdout)
        self.assertNotIn("unreadable/ambiguous", result.stdout)
        self.assertIn("activate-runtime", result.stdout,
                      "the canonical activation path is named")
        self.assertNotIn('"no_work"', result.stdout,
                         "missing identity proof must not read as no work")
        # A pin that exists but declares no usable digest is ambiguous.
        self._plant_pin_commit(json.dumps({"v": 1, "kind": "runtime-capsule"}))
        result = self._ght("discover")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unreadable/ambiguous", result.stdout)
        self.assertNotIn("not activated", result.stdout)
        self.assertNotIn('"no_work"', result.stdout)
        # An unreadable pin manifest is the same fail-closed family.
        self._plant_pin_commit("{not json")
        result = self._ght("discover")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unreadable/ambiguous", result.stdout)
        self.assertNotIn("not activated", result.stdout)

    def _plant_pin_commit(self, manifest_text):
        """Force-move refs/ght/runtime/current to a commit carrying exactly
        one MANIFEST.json document with the given raw text."""
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=manifest_text).stdout.strip()
        tree = self._git(self.repo, "mktree", input_text=(
            f"100644 blob {blob}\tMANIFEST.json\n")).stdout.strip()
        identity_env = {**os.environ,
                        "GIT_AUTHOR_NAME": "ght", "GIT_AUTHOR_EMAIL": "ght@harry-dev",
                        "GIT_COMMITTER_NAME": "ght", "GIT_COMMITTER_EMAIL": "ght@harry-dev"}
        commit = self._git(self.repo, "commit-tree", tree, "-m", "fixture pin",
                           env=identity_env).stdout.strip()
        pushed = self._git(self.repo, "push", "--force", "origin",
                           f"{commit}:refs/ght/runtime/current")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)

    def _default_pin_digest(self):
        """The payload digest the fixture pin declares (SKILL_ROOT, the
        runtime under test, serialized exactly as sync-runtime publishes)."""
        from github_task import cli as ght_cli
        return ght_cli._runtime_capsule_payload(SKILL_ROOT)[1]["digest"]

    def test_discover_fails_closed_when_pinned_digest_ref_is_missing(self):
        # #102 R2 (canonical identity is a dual-ref proof): a readable pin
        # MANIFEST alone is NOT canonical proof — the pinned capsule must
        # also exist at its content-addressed ref (exactly what
        # `ght sync-runtime` publishes before activation). With the digest
        # ref deleted, the pin declares an identity the repo cannot
        # materialize: canonical identity is unreadable/ambiguous, fail
        # closed — never proceed (the digest-only trust treated the
        # readable manifest as canonical), never a freshness verdict (an
        # ambiguous identity cannot name an expected one).
        digest = self._default_pin_digest()
        removed = self._git(self.repo, "push", "origin",
                            f":refs/ght/runtime/{digest}")
        self.assertEqual(removed.returncode, 0, removed.stderr)
        self.assertEqual(self._git(self.repo, "ls-remote", "origin",
                                   f"refs/ght/runtime/{digest}").stdout.strip(),
                         "", "fixture: the digest ref must be gone")
        result = self._ght("discover")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unreadable/ambiguous", result.stdout)
        self.assertNotIn("not activated", result.stdout,
                         "the pin exists — this is the ambiguous family, "
                         "not the not-yet-activated one")
        self.assertNotIn('"no_work"', result.stdout,
                         "ambiguous identity must not read as no work")
        self.assertNotIn("refresh_required", result.stdout,
                         "ambiguous identity is not a freshness verdict")

    def test_discover_fails_closed_when_pin_and_digest_ref_diverge(self):
        # #102 R2: `refs/ght/runtime/current` and `refs/ght/runtime/<digest>`
        # must point at the SAME object. A pin force-moved to a different
        # commit that still carries a perfectly readable manifest declaring
        # the pinned digest is a moved/tampered pin: canonical identity is
        # ambiguous — fail closed. The old digest-only trust treated this
        # pin as canonical and proceeded into the frontier.
        digest = self._default_pin_digest()
        self._plant_pin_commit(json.dumps(
            {"v": 1, "kind": "runtime-capsule", "product": "harry-dev",
             "digest": digest}))
        pin_sha = self._git(self.repo, "ls-remote", "origin",
                            "refs/ght/runtime/current").stdout.split()[0]
        digest_sha = self._git(self.repo, "ls-remote", "origin",
                               f"refs/ght/runtime/{digest}").stdout.split()[0]
        self.assertNotEqual(pin_sha, digest_sha,
                            "fixture must plant a genuinely divergent pin")
        result = self._ght("discover")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unreadable/ambiguous", result.stdout)
        self.assertNotIn('"no_work"', result.stdout,
                         "a tampered pin must not read as no work")
        self.assertNotIn("refresh_required", result.stdout,
                         "a tampered pin is not a freshness verdict")
        self.assertIn(pin_sha[:12], result.stdout,
                      "both divergent object identities are named")

    def test_discover_unrelated_main_movement_does_not_trigger_refresh(self):
        # #102 (AC2): accepted-main movement is not a Skill update. The only
        # canonical identity is the activated capsule pin; main commits that
        # do not move it never trigger refresh_required.
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        (self.repo / "UNRELATED.md").write_text("unrelated main movement\n")
        self._git(self.repo, "add", "UNRELATED.md")
        self._git(self.repo, "commit", "-qm", "unrelated main movement")
        pushed = self._git(self.repo, "push", "-q", "origin", "HEAD:main")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        self.assertNotIn("refresh_required", result.stdout)
        # Even a main commit touching the skill distribution is not a
        # canonical identity change: activation is, and only activation is.
        skill_dir = self.repo / "skills" / "github-task"
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "MAIN-MOVED.md").write_text("moved without activation\n")
        self._git(self.repo, "add", "skills/github-task/MAIN-MOVED.md")
        self._git(self.repo, "commit", "-qm", "skill content moved without activation")
        pushed = self._git(self.repo, "push", "-q", "origin", "HEAD:main")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")

    def test_discover_after_refresh_original_work_still_discoverable(self):
        # #102 (AC4/AC5): a local Skill refresh is lifecycle-neutral — no
        # authorization, claim lineage, or lifecycle change — so the work
        # discoverable before the staleness (a continuation and independent
        # direct-ready items) is discoverable again after refreshing the
        # local Skill to the activated identity.
        claim, sha = self._delivered_parked(number=10, pr=62)
        data = json.loads(self.state.read_text())
        data["62"].setdefault("pr_comments", []).append({
            "body": "A REVIEW — REQUEST_CHANGES\n\nReviewed exact Candidate:\n"
                    f"`{sha}`\n\nblocking findings"})
        self.state.write_text(json.dumps(data, indent=2))
        # The project activates a new runtime identity; the locally installed
        # Skill (the stale working tree) no longer matches it.
        installed_a = self._capsule_source("installed-a", content="runtime-one")
        _r, capsule_a = self._sync_runtime_from(installed_a)
        result = self._ght("activate-runtime", capsule_a["digest"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        stale = self._capsule_source("installed-b", content="runtime-two")
        result, payload = self._ght_json("discover", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(stale)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "refresh_required")
        # "Refresh": discover again from the reloaded (activated) Skill.
        result, payload = self._ght_json("discover", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(installed_a)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        resumed = next(item for item in payload["work"] if item["kind"] == "resume")
        self.assertEqual(resumed["issue"], 10,
                         "the pre-staleness continuation survives the refresh")
        self.assertEqual(resumed["claim_id"], claim["claim_id"])
        direct = next(item for item in payload["work"]
                      if item["source"] == "direct-ready" and item["issue"] == 14)
        self.assertTrue(direct["runnable"],
                        "independent direct-ready work survives the refresh")

    def test_discover_after_refresh_plan_work_still_discoverable(self):
        # #102 (AC5): after the refresh, current-Plan work is recompiled from
        # durable truth exactly as before the staleness.
        installed_a = self._capsule_source("installed-a", content="runtime-one")
        _r, capsule_a = self._sync_runtime_from(installed_a)
        result = self._ght("activate-runtime", capsule_a["digest"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._publish_plan(self._plan_doc())
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._update_issue(15, labels=[])  # the Plan authorizes 15; no dual authority
        stale = self._capsule_source("installed-b", content="runtime-two")
        result, payload = self._ght_json("discover", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(stale)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "refresh_required")
        result, payload = self._ght_json("discover", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(installed_a)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        node = next(item for item in payload["work"] if item["issue"] == 15)
        self.assertTrue(node["runnable"],
                        "the Plan node survives the refresh and stays runnable")

    def test_discover_freshness_path_has_no_durable_side_effects(self):
        # #102 (AC3/AC5): the freshness path is strictly read-only — no
        # GitHub durable write, no runtime activation/pin movement, no
        # release, no claim/Plan/ready mutation. Only identity-proof reads.
        stale = self._capsule_source("installed-stale", content="runtime-stale")
        git_log = self.tmp / "git-calls.log"
        refs_before = self._git(self.repo, "ls-remote", "origin").stdout
        state_before = {k: v for k, v in json.loads(self.state.read_text()).items()
                        if k != "__calls"}
        calls_before = len(self._calls())
        result, payload = self._ght_json("discover", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(stale),
            "GHT_TEST_GIT_LOG": str(git_log)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "refresh_required")
        pushes = [line for line in git_log.read_text().splitlines()
                  if line.startswith("push")]
        self.assertEqual(pushes, [], "the freshness path never pushes")
        new_calls = self._calls()[calls_before:]
        for argv in new_calls:
            self.assertIn(argv[:2], (["api", "user"], ["repo", "view"]),
                          f"the freshness path issued a non-read GitHub call: {argv}")
        self.assertEqual({k: v for k, v in json.loads(self.state.read_text()).items()
                          if k != "__calls"}, state_before,
                         "no Issue/label/comment state changed")
        self.assertEqual(self._git(self.repo, "ls-remote", "origin").stdout,
                         refs_before,
                         "no ref moved — discovery never activates or rewrites the pin")

    def test_request_changes_correction_dispatches_to_bound_runtime(self):
        # R4-1: an attempt started under runtime A continues under A even
        # after the installed runtime has "upgraded" to B: every
        # continuation command (acquire / scope-check / preserve / deliver)
        # is dispatched to the attempt-bound capsule, and the durable
        # binding does not move.
        installed_a = self._capsule_source("installed-a", content="runtime-one")
        _r, capsule_a = self._sync_runtime_from(installed_a)
        self._ght("activate-runtime", capsule_a["digest"])
        installed_env_a = {"GHT_INSTALLED_SKILL_DIR": str(installed_a)}
        claim = self._claim(10, env_extra=installed_env_a)
        bound = self._ght_json("inspect", "10", env_extra=installed_env_a)[1]["claim"]["runtime"]
        self.assertEqual(bound["digest"], capsule_a["digest"])
        self._checkout_claim_branch(claim)
        sha1 = self._commit_on_branch("skills/demo.txt", "demo\n")
        result = self._ght("scope-check", "10", env_extra=installed_env_a)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result = self._ght("preserve", "10", env_extra=installed_env_a)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(22, claim["branch"], sha1)
        result, payload = self._ght_json("deliver", "10", "--pr", "22",
                                         "--note", "round-1",
                                         env_extra=installed_env_a)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # The installed runtime "upgrades" to B (a different tree); A's RC
        # lands; the whole correction resumes under the BOUND runtime A.
        installed_b = self._capsule_source("installed-b", content="runtime-two")
        installed_env_b = {"GHT_INSTALLED_SKILL_DIR": str(installed_b)}
        data = json.loads(self.state.read_text())
        data["22"].setdefault("pr_comments", []).append({
            "body": "A REVIEW — REQUEST_CHANGES\n\nReviewed exact Candidate:\n"
                    f"`{sha1}`\n\nblocking findings"})
        self.state.write_text(json.dumps(data, indent=2))
        result = self._ght("acquire", "10", env_extra=installed_env_b)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("dispatching to the attempt-bound runtime capsule", result.stderr)
        self.assertIn(capsule_a["digest"][:12], result.stderr,
                      "the correction dispatches to the BOUND runtime, not the "
                      "installed B")
        sha2 = self._commit_on_branch("skills/demo.txt", "demo2\n")
        result = self._ght("scope-check", "10", env_extra=installed_env_b)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("dispatching", result.stderr)
        result = self._ght("preserve", "10", env_extra=installed_env_b)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("dispatching", result.stderr)
        result, payload = self._ght_json("deliver", "10", "--pr", "22",
                                         "--note", "round-2",
                                         env_extra=installed_env_b)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("dispatching", result.stderr)
        inspected = self._ght_json("inspect", "10", env_extra=installed_env_b)[1]["claim"]
        self.assertEqual(inspected["runtime"]["digest"], capsule_a["digest"],
                         "the binding never moves to the upgraded runtime")
        self.assertEqual(inspected["delivery"]["sha"],
                         inspected["candidate"]["sha"])

    def test_dispatch_guard_respects_dispatched_marker(self):
        # No recursion: once dispatched, the bound runtime that ACTUALLY IS
        # the bound identity (self-digest matches) does not re-dispatch.
        # A forged/mismatched marker is caught by the self-digest check.
        installed_a = self._capsule_source("installed-a", content="runtime-one")
        _r, capsule_a = self._sync_runtime_from(installed_a)
        self._ght("activate-runtime", capsule_a["digest"])
        installed_env_a = {"GHT_INSTALLED_SKILL_DIR": str(installed_a)}
        self._claim(10, env_extra=installed_env_a)
        # The dispatched child runs from the SAME installed-a tree, so its
        # self-digest matches the bound digest. It should proceed without re-dispatch.
        result = self._ght("verify", "10", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(installed_a),
            "GHT_RUNTIME_DISPATCHED": capsule_a["digest"]})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotIn("dispatching", result.stderr,
                         "the actually-bound runtime must not re-dispatch")

    def test_forged_dispatch_marker_fails_closed(self):
        # R6-1: a process running runtime B cannot bypass by merely setting
        # GHT_RUNTIME_DISPATCHED=<A digest>. The self-digest must match.
        installed_a = self._capsule_source("installed-a", content="runtime-one")
        _r, capsule_a = self._sync_runtime_from(installed_a)
        self._ght("activate-runtime", capsule_a["digest"])
        installed_env_a = {"GHT_INSTALLED_SKILL_DIR": str(installed_a)}
        self._claim(10, env_extra=installed_env_a)
        installed_b = self._capsule_source("installed-b", content="runtime-two")
        result = self._ght("verify", "10", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(installed_b),
            "GHT_RUNTIME_DISPATCHED": capsule_a["digest"]})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("diverges from the attempt-bound digest", result.stdout,
                      "forged marker with wrong self-digest must fail closed")

    def test_dispatch_payload_manifest_divergence_fails_closed(self):
        # R6-1: before dispatching, both manifest.digest AND payload SHA-256
        # must equal the bound digest. A capsule with matching manifest but
        # diverging payload must fail closed.
        from github_task import cli as ght_cli
        from github_task.core import contract_digest, parse_contract
        src = self._capsule_source("divergent", content="runtime-divergent")
        _r, capsule = self._sync_runtime_from(src)
        self._ght("activate-runtime", capsule["digest"])
        installed_env = {"GHT_INSTALLED_SKILL_DIR": str(src)}
        self._claim(10, env_extra=installed_env)
        # Tamper: replace capsule payload but keep manifest digest same
        payload, manifest = ght_cli._runtime_capsule_payload(src)
        import hashlib
        wrong_payload = b"wrong-payload"
        wrong_digest = hashlib.sha256(wrong_payload).hexdigest()
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(manifest)).stdout.strip()
        payload_file = self.tmp / "wrong.zip"
        payload_file.write_bytes(wrong_payload)
        payload_blob = self._git(self.repo, "hash-object", "-w",
                                 str(payload_file)).stdout.strip()
        tree = self._git(self.repo, "mktree", input_text=(
            f"100644 blob {payload_blob}\truntime.zip\n"
            f"100644 blob {blob}\tMANIFEST.json\n")).stdout.strip()
        import os
        identity_env = {**os.environ, "GIT_AUTHOR_NAME": "g",
                        "GIT_AUTHOR_EMAIL": "g@t", "GIT_COMMITTER_NAME": "g",
                        "GIT_COMMITTER_EMAIL": "g@t"}
        commit = self._git(self.repo, "commit-tree", tree, "-m", "diverged",
                           env=identity_env).stdout.strip()
        moved = self._git(self.repo, "push", "--force", "origin",
                          f"{commit}:refs/ght/runtime/{capsule['digest']}")
        self.assertEqual(moved.returncode, 0, moved.stderr)
        # Now try to dispatch - should fail on payload digest mismatch
        installed_b = self._capsule_source("installed-b", content="runtime-two")
        result = self._ght("verify", "10", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(installed_b)})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("payload digest", result.stdout,
                      "payload/manifest divergence must fail closed before exec")

    def test_dispatch_fails_closed_when_bound_capsule_missing(self):
        # A missing bound capsule is fail closed with a mechanical recovery
        # path — never a silent continuation under the new runtime.
        installed_a = self._capsule_source("installed-a", content="runtime-one")
        _r, capsule_a = self._sync_runtime_from(installed_a)
        self._ght("activate-runtime", capsule_a["digest"])
        installed_env_a = {"GHT_INSTALLED_SKILL_DIR": str(installed_a)}
        self._claim(10, env_extra=installed_env_a)
        removed = self._git(self.repo, "push", "origin",
                            f":refs/ght/runtime/{capsule_a['digest']}")
        self.assertEqual(removed.returncode, 0, removed.stderr)
        installed_b = self._capsule_source("installed-b", content="runtime-two")
        result = self._ght("acquire", "10", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(installed_b)})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("sync-runtime", result.stdout,
                      "the recovery path is mechanical and explicit")

    def test_activate_runtime_pin_and_new_attempt_binding(self):
        # AC21 downstream model: activation is explicit and mechanically
        # verified; NEW attempts durably bind the activated runtime
        # identity; acquire/resume preserves the binding.
        src = self._capsule_source("dist-a", release="v1.0.3", content="runtime-one")
        _result, capsule = self._sync_runtime_from(src)
        result = self._ght("activate-runtime", capsule["digest"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("activated", result.stdout)
        claim = self._claim(10)
        bound = self._ght_json("inspect", "10")[1]["claim"]["runtime"]
        self.assertEqual(bound["digest"], capsule["digest"])
        self.assertEqual(bound["release"], "v1.0.3")
        # acquire preserves the binding.
        self._ght_json("acquire", "10")
        after = self._ght_json("inspect", "10")[1]["claim"]["runtime"]
        self.assertEqual(after["digest"], capsule["digest"])

    def test_activate_runtime_requires_synced_capsule(self):
        result = self._ght("activate-runtime", "b" * 64)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("sync-runtime", result.stdout)

    def test_project_pin_upgrade_new_attempts_use_new_runtime(self):
        # Upgrade: after activating B, new attempts bind B while the ACTIVE
        # attempt keeps its A binding; the reconciler materializes each
        # attempt's OWN capsule (attempt-bound resolution).
        src_a = self._capsule_source("dist-a", release="v1.0.3", content="runtime-one")
        _r, capsule_a = self._sync_runtime_from(src_a)
        self._ght("activate-runtime", capsule_a["digest"])
        # Attempt 10 starts under A (direct claim).
        self._claim(10)
        bound = self._ght_json("inspect", "10")[1]["claim"]["runtime"]
        self.assertEqual(bound["digest"], capsule_a["digest"])
        # Project upgrades to B; new attempt 11 binds B.
        src_b = self._capsule_source("dist-b", release="v1.0.4", content="runtime-two")
        _r, capsule_b = self._sync_runtime_from(src_b)
        self._ght("activate-runtime", capsule_b["digest"])
        self._update_issue(14, labels=["ready"])
        self._claim(14, env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        bound_b = self._ght_json("inspect", "14")[1]["claim"]["runtime"]
        self.assertEqual(bound_b["digest"], capsule_b["digest"])
        # Attempt 10's binding did not move.
        self.assertEqual(
            self._ght_json("inspect", "10")[1]["claim"]["runtime"]["digest"],
            capsule_a["digest"])

    def test_reconciler_materializes_attempt_bound_capsule(self):
        # Post-merge completion under the Mechanical Reconciler uses the
        # ATTEMPT's bound capsule even after a later project pin upgrade.
        src_a = self._capsule_source("dist-a", release="v1.0.3", content="runtime-one")
        _r, capsule_a = self._sync_runtime_from(src_a)
        self._ght("activate-runtime", capsule_a["digest"])
        claim, sha = self._delivered_parked(number=10, pr=62, executor="original-worker")
        self._merge_pr(62)
        # Project upgrades to B AFTER attempt 10 started under A.
        src_b = self._capsule_source("dist-b", release="v1.0.4", content="runtime-two")
        _r, capsule_b = self._sync_runtime_from(src_b)
        self._ght("activate-runtime", capsule_b["digest"])
        result = subprocess.run(
            ["sh", str(SKILL_ROOT / "scripts" / "ght-gha-adapter.sh"), "10", "62"],
            cwd=str(self.repo),
            env={**self._env,
                 "GHT_RUNTIME_REF": capsule_b["digest"],
                 "GHT_TEST_FAIL_API_USER": "1",
                 "GHT_RECONCILER_ID": "ght-complete-workflow",
                 "GHT_EXECUTOR_ID": "ght-complete-workflow"},
            capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(f"runtime capsule {capsule_a['digest']}", result.stderr,
                      "the reconciler materialized the ATTEMPT-BOUND capsule, "
                      "not the current project pin")
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "delivered")

    def test_adapter_manifest_verification_fails_closed(self):
        # The adapter verifies the capsule MANIFEST identity (digest binding
        # + coherent release/source SHA), not just the payload digest; a
        # tampered or incoherent manifest never executes.
        from github_task import cli as ght_cli
        src = self._capsule_source("dist-tampered", release="v1.0.3",
                                   content="runtime-one")
        payload, manifest = ght_cli._runtime_capsule_payload(src)
        digest = manifest["digest"]
        manifest["release"] = "not-a-release"  # incoherent identity
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(manifest)).stdout.strip()
        payload_file = self.tmp / "payload.zip"
        payload_file.write_bytes(payload)
        payload_blob = self._git(self.repo, "hash-object", "-w",
                                 str(payload_file)).stdout.strip()
        tree = self._git(self.repo, "mktree", input_text=(
            f"100644 blob {payload_blob}\truntime.zip\n"
            f"100644 blob {blob}\tMANIFEST.json\n")).stdout.strip()
        identity_env = {**os.environ, "GIT_AUTHOR_NAME": "g",
                        "GIT_AUTHOR_EMAIL": "g@t", "GIT_COMMITTER_NAME": "g",
                        "GIT_COMMITTER_EMAIL": "g@t"}
        commit = self._git(self.repo, "commit-tree", tree, "-m", "tampered",
                           env=identity_env).stdout.strip()
        moved = self._git(self.repo, "push", "--force", "origin",
                          f"{commit}:refs/ght/runtime/{digest}")
        self.assertEqual(moved.returncode, 0, moved.stderr)
        result = subprocess.run(
            ["sh", str(SKILL_ROOT / "scripts" / "ght-gha-adapter.sh"), "10", "62"],
            env={"PATH": "/usr/bin:/bin", "GHT_RUNTIME_REF": digest},
            cwd=str(self.repo),
            capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("fail closed", result.stderr)

    def test_runtime_capsule_upgrade_keeps_old_capsule_and_attempt_identity(self):
        # Upgrade lifecycle: syncing a second identity publishes it alongside
        # the old one, changes no pin by itself, and an ACTIVE attempt's
        # durable identity does not drift; rollback is trivially the old
        # retained capsule (pin change only).
        src_a = self._capsule_source("dist-a", release="v1.0.3", content="runtime-one")
        result, payload_a = self._sync_runtime_from(src_a)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        digest_a = payload_a["digest"]
        self._claim(10)
        before = self._ght_json("inspect", "10")[1]["claim"]
        src_b = self._capsule_source("dist-b", release="v1.0.4", content="runtime-two")
        result, payload_b = self._sync_runtime_from(src_b)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload_b["status"], "created")
        digest_b = payload_b["digest"]
        self.assertNotEqual(digest_a, digest_b)
        # Old capsule retained and exact; new capsule published.
        self._assert_capsule_digest_intact(digest_a)
        self._assert_capsule_digest_intact(digest_b)
        # The ACTIVE attempt's durable identity does not drift.
        after = self._ght_json("inspect", "10")[1]["claim"]
        for key in ("claim_id", "executor_id", "github_principal", "branch",
                    "execution_base", "status"):
            self.assertEqual(before[key], after[key],
                             f"ACTIVE attempt identity must not drift on {key}")

    def test_status_lists_owned_active_claims(self):
        self._claim(10)
        result, payload = self._ght_json("status")
        self.assertEqual(result.returncode, 0)
        self.assertEqual([entry["issue"] for entry in payload["active_claims"]], [10])

    def test_status_separates_attempt_ownership_from_expired_capacity(self):
        state_dir = "state-status-expired"
        claim = self._claim(10, env_extra={"GHT_STATE_DIR": state_dir})
        self._rewrite_claim_record(10, lease_expires_at="2000-01-01T00:00:00Z")
        lease = self._read_lease_record(claim["claim_id"])
        lease["lease_expires_at"] = "2000-01-01T00:00:00Z"
        self._rewrite_lease_ref(claim["claim_id"], lease)

        result, payload = self._ght_json(
            "status", env_extra={"GHT_STATE_DIR": state_dir,
                                 "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        entry = next(item for item in payload["active_claims"] if item["issue"] == 10)
        self.assertEqual(entry["attempt_state"], "STALE",
                         "the durable active claim remains listed despite stale heartbeat")
        self.assertEqual(entry["execution_capacity"]["state"], "expired_residue")
        self.assertTrue(entry["execution_capacity"]["reacquirable"])

    # -- AC8: one complete v1 flow ----------------------------------------

    def test_v1_full_flow_milestone_to_merge(self):
        # Milestone -> ready -> B execution -> PR -> REQUEST_CHANGES ->
        # corrections on the same task -> APPROVE -> merge, with NO fresh
        # ready anywhere in the flow.
        claim = self._claim(14)
        self._checkout_claim_branch(claim)
        first_sha = self._commit_on_branch("skills/feature.txt", "v1\n")
        result, _payload = self._ght_json("preserve", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(40, claim["branch"], first_sha)
        result, payload = self._ght_json("deliver", "14", "--pr", "40",
                                         "--note", "initial candidate")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "active")
        # Delivery released the temporary execution capacity; the attempt
        # stays non-terminal and its lease is gone.
        self.assertEqual(payload["execution_lease_released"], True)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      f"refs/ght/execution-leases/{claim['claim_id']}").stdout.strip(), "")
        # A: REQUEST_CHANGES on the unchanged Contract. The task continues
        # on the same attempt: B reacquires a fresh execution lease (new
        # fencing identity) with no fresh `ready`.
        result, acquired = self._ght_json("acquire", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(acquired["claim_id"], claim["claim_id"],
                         "ordinary review corrections keep the same attempt identity")
        self.assertTrue(acquired["execution_lease"]["fencing_token"])
        result = self._ght("verify", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        corrected_sha = self._commit_on_branch("skills/feature.txt", "v1 fixed\n")
        result, _payload = self._ght_json("preserve", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        data = json.loads(self.state.read_text())
        data["40"]["headRefOid"] = corrected_sha
        self.state.write_text(json.dumps(data, indent=2))
        # A moving the Milestone is iteration planning only (AC4): it never
        # invalidates the active task or its Contract digest. Verified while
        # the reacquired lease is still live.
        self._update_issue(14, milestone="v1.1.0")
        result = self._ght("verify", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("deliver", "14", "--pr", "40",
                                         "--note", "corrections for review findings")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["candidate_sha"], corrected_sha)
        # A approves and merges the reviewed head; completion is mechanical
        # and needs no execution capacity of its own.
        self._merge_pr(40)
        result, payload = self._ght_json("complete", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "delivered")
        inspected = self._ght_json("inspect", "14")[1]
        self.assertEqual(inspected["claim_state"], "TERMINAL")
        # The flow consumed READY exactly once and never re-added it.
        for call in self._calls():
            if call[:2] == ["issue", "edit"]:
                self.assertNotIn("--add-label", call)
        self.assertEqual(self._issue(14)["labels"], [])

    def test_replan_after_blocked_starts_new_attempt_with_fresh_ready(self):
        first = self._claim(13)
        result, _payload = self._ght_json(
            "release", "13", "--status", "blocked",
            "--note", "A: stop and replan the approach")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self._ght_json("inspect", "13")[1]["claim_state"], "TERMINAL")
        blocked_ref_sha = self._git(self.repo, "ls-remote", "origin",
                                    CLAIM_REF + "13").stdout.split()[0]
        # Without a fresh one-shot READY there is no new attempt...
        self._update_issue(13, labels=[])
        result = self._ght("claim", "13")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        # ...A's explicit stop/replan plus fresh READY authorizes exactly one.
        self._update_issue(13, labels=["ready"])
        second = self._claim(13)
        self.assertNotEqual(second["claim_id"], first["claim_id"])
        self.assertEqual(second["supersedes"]["claim_id"], first["claim_id"],
                         "the new attempt durably records the superseded prior (AC2)")
        self.assertEqual(second["supersedes"]["sha"], blocked_ref_sha,
                         "supersedes points at the exact terminal ref object")
        self.assertEqual(second["supersedes"]["status"], "blocked")
        remote_sha = self._git(
            self.repo, "ls-remote", "origin", CLAIM_REF + "13").stdout.split()[0]
        self.assertEqual(remote_sha, second["ref_sha"])
        self._git(self.repo, "fetch", "-q", "origin",
                  f"+{CLAIM_REF}13:{CLAIM_REF}13")
        subjects = self._git(self.repo, "log", "--format=%s",
                             CLAIM_REF + "13").stdout
        self.assertIn(first["claim_id"][:24], subjects)
        self.assertIn(second["claim_id"][:24], subjects)

    def test_complete_after_merge_survives_head_branch_deletion(self):
        # Repos may enable delete_branch_on_merge: the merged PR's head
        # branch disappearing must not block completing a correctly merged
        # task. Completion relies on durable facts (preserved Candidate SHA
        # + merged PR head identity), not on branch existence.
        claim = self._claim(14)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/feature.txt", "v1\n")
        result, _payload = self._ght_json("preserve", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(41, claim["branch"], sha)
        result, _payload = self._ght_json("deliver", "14", "--pr", "41")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._merge_pr(41)
        deleted = self._git(self.repo, "push", "origin", f":refs/heads/{claim['branch']}")
        self.assertEqual(deleted.returncode, 0, deleted.stderr)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      f"refs/heads/{claim['branch']}").stdout.strip(), "")
        result, payload = self._ght_json("complete", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "delivered")
        self.assertEqual(payload["candidate_sha"], sha)
        inspected = self._ght_json("inspect", "14")[1]
        self.assertEqual(inspected["claim_state"], "TERMINAL")
        self.assertEqual(inspected["claim"]["completed"]["candidate_sha"], sha)

    def test_complete_rejects_unmerged_and_head_sha_mismatch(self):
        claim = self._claim(14)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/feature.txt", "v1\n")
        result, _payload = self._ght_json("preserve", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(42, claim["branch"], sha)
        result, _payload = self._ght_json("deliver", "14", "--pr", "42")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # Not merged: completion is refused and the claim stays ACTIVE.
        result = self._ght("complete", "14")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("not merged", result.stdout)
        # A merged something other than the reviewed Candidate SHA:
        # exact Candidate identity is enforced, fail-closed.
        other = self._commit_on_branch("skills/feature.txt", "unreviewed change\n")
        self._open_pr(42, claim["branch"], other, state="MERGED")
        result = self._ght("complete", "14")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("does not equal the preserved Candidate SHA", result.stdout)
        inspected = self._ght_json("inspect", "14")[1]
        self.assertEqual(inspected["claim"]["status"], "active",
                         "a mismatched merge must not complete the claim")

    def test_delivered_lineage_restart_with_fresh_ready(self):
        # AC1/AC2: a delivered attempt is durable history, not a dead end —
        # a fresh one-shot READY authorizes a genuinely new attempt that
        # CAS-appends and durably records the superseded delivered attempt.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(50, claim["branch"], sha)
        result, _payload = self._ght_json("deliver", "10", "--pr", "50")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._merge_pr(50)
        result, _payload = self._ght_json("complete", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected_prior = self._ght_json("inspect", "10")[1]
        prior = inspected_prior["claim"]
        prior_ref_sha = inspected_prior["claim_sha"]
        self.assertEqual(prior["status"], "delivered")
        # #171: canonical completion converges the Issue itself (CLOSED with
        # state_reason completed); A reopens it to authorize more work — the
        # delivered-lineage restart scenario starts from there.
        self._update_issue(10, state="OPEN", stateReason=None)
        # Without a fresh READY there is no new attempt (AC1)...
        self._update_issue(10, labels=[])
        result = self._ght("claim", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        # ...with one, the new attempt appends by CAS and records lineage.
        self._update_issue(10, labels=["ready"])
        second = self._claim(10, env_extra={"GHT_SPAWN_SUPERVISOR": "1",
                                            "GHT_SUPERVISE_INTERVAL_SECONDS": "5"})
        self.assertNotEqual(second["claim_id"], prior["claim_id"])
        self.assertEqual(second["supersedes"]["claim_id"], prior["claim_id"])
        self.assertEqual(second["supersedes"]["sha"], prior_ref_sha)
        self.assertEqual(second["supersedes"]["status"], "delivered")
        self.assertEqual(second["supervisor"], "spawned",
                         "the new attempt gets automatic lease supervision (AC5 matrix)")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      CLAIM_REF + "10").stdout.split()[0], second["ref_sha"])
        self._git(self.repo, "fetch", "-q", "origin", f"+{CLAIM_REF}10:{CLAIM_REF}10")
        parent = self._git(self.repo, "rev-parse", CLAIM_REF + "10^").stdout.strip()
        self.assertEqual(parent, prior_ref_sha,
                         "the new attempt is a CAS append onto the terminal lineage")
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["supersedes"]["claim_id"], prior["claim_id"])
        self.assertEqual(inspected["supersedes"]["sha"], prior_ref_sha)
        # Prior history immutable: the delivered record is still an ancestor
        # and unchanged.
        subjects = self._git(self.repo, "log", "--format=%s",
                             "refs/ght/claims/10").stdout
        self.assertIn(prior["claim_id"][:24], subjects)

    # -- canonical refs/ght namespace cutover (replanned contract) --------

    def _raw_ref(self, ref, record, message="ght: raw"):
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(record, indent=1)).stdout.strip()
        tree = self._git(self.repo, "mktree",
                         input_text=f"100644 blob {blob}\tCLAIM.json\n").stdout.strip()
        commit = self._git(self.repo, "commit-tree", tree, "-m", message,
                           env=self._env).stdout.strip()
        pushed = self._git(self.repo, "push", "origin", f"{commit}:{ref}")
        self.assertEqual(pushed.returncode, 0, pushed.stderr)
        return commit

    def _legacy_v2_record(self, number, claim_id, status, lease):
        return {"v": 2, "task": number, "claim_id": claim_id, "agent": "legacy-agent",
                "claimed_at": "2026-09-16T00:00:00Z", "lease_expires_at": lease,
                "baseline_commit": "d3313cccbbc55556fa46098391e4ff5a1a140a2a",
                "status": status, "branch": f"agent/{number}/legacy",
                "heartbeat_at": "2026-09-16T00:00:00Z", "note": None,
                "supersedes": None, "mode": "implementation",
                "policy_digest": "0" * 64, "execution_context": "direct",
                "assignment": None, "workflow": None,
                "change_budget": {"expected": [], "conditional": [], "forbidden": []}}

    def test_new_claims_use_refs_ght_namespace(self):
        claim = self._claim(10)
        self.assertTrue(claim["ref"].startswith("refs/ght/claims/"))
        remote = self._git(self.repo, "ls-remote", "origin",
                           CLAIM_REF + "10").stdout.split()[0]
        self.assertEqual(remote, claim["ref_sha"])
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      LEGACY_CLAIM_REF + "*").stdout.strip(), "",
            "new claims must not appear as ordinary branches")

    def test_legacy_active_claim_namespace_is_sticky(self):
        claim = self._claim(10, env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF})
        legacy_sha = self._git(self.repo, "ls-remote", "origin",
                               LEGACY_CLAIM_REF + "10").stdout.split()[0]
        # Ordinary CAS writes renew the lease in place; they never migrate.
        result, payload = self._ght_json("heartbeat", "10", "--force")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["renewed"])
        moved = self._git(self.repo, "ls-remote", "origin",
                          LEGACY_CLAIM_REF + "10").stdout.split()[0]
        self.assertNotEqual(moved, legacy_sha)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      CLAIM_REF + "10").stdout.strip(), "",
            "ACTIVE claims are never lazily migrated (AC2)")
        result = self._ght("verify", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_takeover_keeps_legacy_namespace(self):
        self._claim(10, env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF,
                                   "GHT_LEASE_MINUTES": "0"})
        stale = self._ght_json("inspect", "10")[1]
        deadline = time.time() + 5
        while stale["claim_state"] != "STALE" and time.time() < deadline:
            time.sleep(0.2)
            stale = self._ght_json("inspect", "10")[1]
        result, payload = self._ght_json(
            "takeover", "10", "--evidence", "worker crashed mid-attempt",
            env_extra={"GHT_TAKEOVER_GRACE_MINUTES": "0", "GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        recovered = self._git(self.repo, "ls-remote", "origin",
                              LEGACY_CLAIM_REF + "10").stdout.split()[0]
        self.assertEqual(recovered, payload["ref_sha"],
                         "same-attempt recovery stays in the lineage's own namespace")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      CLAIM_REF + "10").stdout.strip(), "")

    def test_claim_after_terminal_legacy_migrates_and_appends(self):
        self._claim(10, env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF})
        result, _payload = self._ght_json(
            "release", "10", "--status", "blocked", "--note", "A: replan",
            env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        old_sha = self._git(self.repo, "ls-remote", "origin",
                            LEGACY_CLAIM_REF + "10").stdout.split()[0]
        self._update_issue(10, labels=["ready"])
        second = self._claim(10)
        self.assertTrue(second["ref"].startswith("refs/ght/claims/"))
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      LEGACY_CLAIM_REF + "10").stdout.strip(), "",
            "the terminal legacy ref is migrated away (AC5)")
        self._git(self.repo, "fetch", "-q", "origin",
                  f"+{CLAIM_REF}10:{CLAIM_REF}10")
        parent = self._git(self.repo, "rev-parse", CLAIM_REF + "10^").stdout.strip()
        self.assertEqual(parent, old_sha, "lineage identity is preserved (AC5)")
        inspected = self._ght_json("inspect", "10")[1]
        self.assertEqual(inspected["claim"]["claim_id"], second["claim_id"])

    def test_dual_presence_fails_closed_everywhere(self):
        self._claim(10)
        sha = self._git(self.repo, "ls-remote", "origin",
                        CLAIM_REF + "10").stdout.split()[0]
        self._git(self.repo, "push", "origin", f"{sha}:{LEGACY_CLAIM_REF}10")
        for command in (("verify", "10"), ("heartbeat", "10", "--force"),
                        ("inspect", "10")):
            result = self._ght(*command)
            self.assertNotEqual(result.returncode, 0, f"{command} must fail closed")
            self.assertIn("AMBIGUOUS", result.stdout)
        # Claim intake also refuses; its READY gate may fire first, but the
        # attempt must never succeed against ambiguous ownership.
        result = self._ght("claim", "10")
        self.assertNotEqual(result.returncode, 0)
        # #89: an unrelated Issue by another executor is unaffected by the
        # dual presence on #10 — issue-scoped commands fail closed, while
        # independent claims proceed (issue-scoped ambiguity is not a
        # global lock).
        result, claimed = self._ght_json("claim", "13",
                                         env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("migrate-claims")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        skipped = {entry["ref"]: entry.get("state") for entry in payload["skipped"]}
        self.assertEqual(skipped.get(LEGACY_CLAIM_REF + "10"), "ACTIVE",
                         "batch migration must not touch a live dual (AC4/AC5)")

    def test_pre_existing_identical_terminal_dual_preserved_and_fails(self):
        # A dual that existed BEFORE the migration invocation is ambiguous
        # even when both SHAs are identical: both refs are preserved and the
        # command fails closed (AC4/AC5 — provenance, not sha equality).
        self._claim(10)
        result, _payload = self._ght_json("release", "10", "--status", "blocked",
                                          "--note", "A: replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        sha = self._git(self.repo, "ls-remote", "origin",
                        CLAIM_REF + "10").stdout.split()[0]
        self._git(self.repo, "push", "origin", f"{sha}:{LEGACY_CLAIM_REF}10")
        result = self._ght("migrate-claims")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("AMBIGUOUS", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      CLAIM_REF + "10").stdout.split()[0], sha)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      LEGACY_CLAIM_REF + "10").stdout.split()[0], sha)

    def test_divergent_terminal_dual_preserved_and_fails(self):
        self._claim(10)
        result, _payload = self._ght_json("release", "10", "--status", "blocked",
                                          "--note", "A: replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        current_sha = self._git(self.repo, "ls-remote", "origin",
                                CLAIM_REF + "10").stdout.split()[0]
        self._raw_ref(LEGACY_CLAIM_REF + "10",
                      self._legacy_v2_record(10, "x-10-legacy", "delivered",
                                             "2026-09-16T00:45:00Z"),
                      "ght: divergent x-10")
        result = self._ght("migrate-claims")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("AMBIGUOUS", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      CLAIM_REF + "10").stdout.split()[0], current_sha)
        self.assertTrue(
            self._git(self.repo, "ls-remote", "origin",
                      LEGACY_CLAIM_REF + "10").stdout.strip())

    def test_unconfirmed_legacy_delete_fails_the_command(self):
        # If the leased delete does not land (here: the ref is moved under
        # us mid-migration, so the delete is unconfirmed), the command must
        # FAIL rather than report ok:true with the ambiguity left behind.
        self._claim(10, env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF})
        result, _payload = self._ght_json(
            "release", "10", "--status", "blocked", "--note", "A: replan",
            env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        blocked_sha = self._git(self.repo, "ls-remote", "origin",
                                LEGACY_CLAIM_REF + "10").stdout.split()[0]
        replacement = self._raw_ref(
            LEGACY_CLAIM_REF + "99",
            self._legacy_v2_record(99, "x-99", "delivered", "2026-09-16T00:45:00Z"),
            "ght: other terminal legacy claim")
        result = self._ght("migrate-claims", env_extra={
            "GHT_TEST_REPLACE_ON_DELETE": f"{LEGACY_CLAIM_REF}10|{replacement}"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unconfirmed", result.stdout)
        moved = self._git(self.repo, "ls-remote", "origin",
                          LEGACY_CLAIM_REF + "10").stdout.split()[0]
        self.assertEqual(moved, replacement,
                         "the moved/replaced ref must survive; nothing is best-effort deleted")
        # The copied object stays (proven create), the ambiguity remains,
        # and later refs were never touched because the command stopped.
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      CLAIM_REF + "10").stdout.split()[0], blocked_sha)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      LEGACY_CLAIM_REF + "99").stdout.split()[0], replacement)

    def test_migrate_claims_moves_terminal_only(self):
        self._claim(10, env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF})
        result, _payload = self._ght_json(
            "release", "10", "--status", "blocked", "--note", "A: replan",
            env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        blocked_sha = self._git(self.repo, "ls-remote", "origin",
                                LEGACY_CLAIM_REF + "10").stdout.split()[0]
        v2_sha = self._raw_ref(
            LEGACY_CLAIM_REF + "12",
            self._legacy_v2_record(12, "legacy-agent-20260916T000000-legacy12",
                                   "delivered", "2026-09-16T00:45:00Z"))
        result, _payload = self._ght_json(
            "claim", "13", env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF,
                                      "GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        active_sha = self._git(self.repo, "ls-remote", "origin",
                               LEGACY_CLAIM_REF + "13").stdout.split()[0]
        result, payload = self._ght_json("migrate-claims")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        moved_refs = {entry["legacy_ref"] for entry in payload["moved"]}
        skipped_refs = {entry["ref"]: entry.get("state") for entry in payload["skipped"]}
        self.assertIn(LEGACY_CLAIM_REF + "10", moved_refs)
        self.assertIn(LEGACY_CLAIM_REF + "12", moved_refs)
        self.assertEqual(skipped_refs.get(LEGACY_CLAIM_REF + "13"), "ACTIVE")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      CLAIM_REF + "10").stdout.split()[0], blocked_sha)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      CLAIM_REF + "12").stdout.split()[0], v2_sha)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      LEGACY_CLAIM_REF + "13").stdout.split()[0], active_sha)

    def test_multi_active_across_namespaces(self):
        # #89: independent Issues under the legacy and canonical namespaces
        # both belong to the same coordination identity without
        # serializing; namespace ambiguity stays a separate fail-closed.
        result, _payload = self._ght_json(
            "claim", "13", env_extra={"GHT_CLAIMS_PREFIX": LEGACY_CLAIM_REF})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result = self._ght("claim", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_reservation_cleanup_is_exact_and_never_unleased_fallback(self):
        import hashlib
        legacy_lock = ("refs/heads/claims-by-executor/"
                       + hashlib.sha256(b"worker-1").hexdigest()[:32])
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(80, claim["branch"], sha)
        result, _payload = self._ght_json("deliver", "10", "--pr", "80")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._merge_pr(80)
        result, payload = self._ght_json("complete", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "delivered")
        # The live-namespace reservation is gone with the finished task.
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "")
        # A stale legacy lock planted afterwards is NOT removed by any
        # unleased fallback (AC6): completion only ever deletes the
        # exact-identity reservation it owns.
        stale_reservation = {
            "v": 3, "kind": "executor-reservation",
            "claim_id": "worker-1-20260916T000000-oldlock",
            "executor_id": "worker-1", "github_principal": "acct", "issue": 9,
            "claimed_at": "2026-09-16T00:00:00Z",
            "lease_expires_at": "2026-09-16T00:45:00Z",
        }
        self._raw_ref(legacy_lock, stale_reservation, "ght: reservation oldlock")
        self.assertTrue(self._git(self.repo, "ls-remote", "origin", legacy_lock).stdout.strip())
        # ...only the batch migration removes it, under an exact lease.
        result, payload = self._ght_json("migrate-claims")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(legacy_lock, {entry["legacy_ref"] for entry in payload["moved"]})
        self.assertEqual(self._git(self.repo, "ls-remote", "origin", legacy_lock).stdout.strip(), "")

    def test_expired_dual_reservation_preserved_and_fails(self):
        import hashlib
        key = hashlib.sha256(b"worker-1").hexdigest()[:32]
        reservation = {
            "v": 3, "kind": "executor-reservation",
            "claim_id": "worker-1-20260916T000000-oldlock",
            "executor_id": "worker-1", "github_principal": "acct", "issue": 9,
            "claimed_at": "2026-09-16T00:00:00Z",
            "lease_expires_at": "2026-09-16T00:45:00Z",
        }
        self._raw_ref(f"refs/ght/claims-by-executor/{key}", reservation, "ght: dual lock")
        self._raw_ref(f"refs/heads/claims-by-executor/{key}", reservation, "ght: dual lock")
        result = self._ght("migrate-claims")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("AMBIGUOUS", result.stdout)
        for prefix in ("refs/ght/claims-by-executor/", "refs/heads/claims-by-executor/"):
            self.assertTrue(
                self._git(self.repo, "ls-remote", "origin",
                          prefix + key).stdout.strip(),
                f"{prefix}<key> must be preserved on ambiguous dual (AC4/AC6)")

    def test_replaced_reservation_ref_is_never_deleted(self):
        import hashlib
        key = hashlib.sha256(b"worker-1").hexdigest()[:32]
        legacy_lock = f"refs/heads/claims-by-executor/{key}"
        self._raw_ref(legacy_lock, {
            "v": 3, "kind": "executor-reservation",
            "claim_id": "worker-1-20260916T000000-oldlock",
            "executor_id": "worker-1", "github_principal": "acct", "issue": 9,
            "claimed_at": "2026-09-16T00:00:00Z",
            "lease_expires_at": "2026-09-16T00:45:00Z",
        }, "ght: reservation oldlock")
        replacement = self._raw_ref(
            LEGACY_CLAIM_REF + "98",
            self._legacy_v2_record(98, "x-98", "delivered", "2026-09-16T00:45:00Z"),
            "ght: replacement payload")
        result = self._ght("migrate-claims", env_extra={
            "GHT_TEST_REPLACE_ON_DELETE": f"{legacy_lock}|{replacement}"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unconfirmed", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      legacy_lock).stdout.split()[0], replacement,
            "a ref replaced under us must never be deleted (AC6)")

    def test_reservation_dual_presence_fails_closed(self):
        import hashlib
        key = hashlib.sha256(b"worker-1").hexdigest()[:32]
        reservation = {
            "v": 3, "kind": "executor-reservation",
            "claim_id": "worker-1-20260917T000000-duallock",
            "executor_id": "worker-1", "github_principal": "acct", "issue": 9,
            "claimed_at": "2026-09-17T00:00:00Z",
            "lease_expires_at": "2026-09-17T00:45:00Z",
        }
        self._raw_ref(f"refs/ght/claims-by-executor/{key}", reservation, "ght: dual lock")
        self._raw_ref(f"refs/heads/claims-by-executor/{key}", reservation, "ght: dual lock")
        result = self._ght("claim", "10")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("AMBIGUOUS", result.stdout)

    # -- automatic lease supervision (Issue #5) ---------------------------

    def _read_supervise_status(self, issue):
        path = self.repo / ".ght" / "executors" / (
            __import__("hashlib").sha256(b"worker-1").hexdigest()[:32]
        ) / f"supervise-{issue}.json"
        if not path.exists():
            return None
        return json.loads(path.read_text())

    def _wait_exit(self, process, timeout=8.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            code = process.poll()
            if code is not None:
                return code
            time.sleep(0.1)
        process.kill()
        return process.wait()

    def test_spawn_failure_blocks_execution_and_offers_no_heartbeat_fallback(self):
        # AC3/AC4: without established supervision the attempt is not a
        # normally usable ACTIVE worker — the claim command fails loudly
        # (after its CAS), and every gated command stays blocked until
        # supervision is re-established. Manual heartbeat is not offered.
        result = self._ght("claim", "10", env_extra={
            "GHT_SPAWN_SUPERVISOR": "1",
            "GHT_SUPERVISE_FORCE_SPAWN_FAILURE": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("cannot establish automatic lease supervision", result.stdout)
        self.assertNotIn("ght heartbeat", result.stdout,
                         "manual heartbeat must not be advertised as the recovery path")
        # Ownership truth exists, but the worker is blocked fail-closed.
        self.assertTrue(self._git(self.repo, "ls-remote", "origin",
                                  CLAIM_REF + "10").stdout.strip())
        for command in (("verify", "10"), ("heartbeat", "10", "--force"),
                        ("scope-check", "10")):
            blocked = self._ght(*command)
            self.assertEqual(blocked.returncode, 2, f"{command}: {blocked.stdout}")
            self.assertIn("supervision is not established", blocked.stdout)
        # Re-establishing supervision (starting the supervisor once) is the
        # reconciliation path — it clears the block; manual heartbeat does not.
        env = {**self._env, "GHT_SUPERVISE_INTERVAL_SECONDS": "5"}
        process = subprocess.Popen(
            [sys.executable, str(CLI), "--json", "supervise", "10"],
            cwd=str(self.repo), env=env, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL)
        deadline = time.time() + 5
        unblocked = False
        while time.time() < deadline:
            if self._ght("verify", "10").returncode == 0:
                unblocked = True
                break
            time.sleep(0.2)
        process.terminate()
        self._wait_exit(process)
        self.assertTrue(unblocked, "supervise start must be the reconciliation path")

    def test_spawn_success_keeps_claim_normally_executable(self):
        claim = self._claim(10, env_extra={"GHT_SPAWN_SUPERVISOR": "1",
                                           "GHT_SUPERVISE_INTERVAL_SECONDS": "5"})
        self.assertEqual(claim["supervisor"], "spawned")
        result = self._ght("verify", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_persistent_supervision_failure_gate_and_reconciliation(self):
        # A supervisor that reached state="failed" (persistent unconfirmable
        # renewal) keeps mutation authority blocked even after remote
        # ownership reads look healthy again (AC3). `degraded` never blocks;
        # successful `ght supervise` re-establishment clears the gate.
        import hashlib
        self._claim(10)
        status_path = (self.repo / ".ght" / "executors"
                       / hashlib.sha256(b"worker-1").hexdigest()[:32]
                       / "supervise-10.json")

        def write_status(state):
            status_path.parent.mkdir(parents=True, exist_ok=True)
            status_path.write_text(json.dumps({
                "issue": 10, "pid": 0, "state": state,
                "updated_at": "2026-09-17T00:00:00Z",
                "error": "lease renewal could not be confirmed",
            }, indent=2) + "\n")

        def assert_blocked():
            for command in (("verify", "10"), ("scope-check", "10"),
                            ("preserve", "10"), ("deliver", "10", "--pr", "90")):
                blocked = self._ght(*command)
                self.assertEqual(blocked.returncode, 2, f"{command}: {blocked.stdout}")
                self.assertIn("supervision is not established", blocked.stdout)

        # Persistent supervisor failure: remote ownership is healthy (the
        # claim just succeeded), but the failed state keeps every gated
        # command blocked.
        write_status("failed")
        assert_blocked()
        # Transient degraded cycles do not block execution.
        write_status("degraded")
        result = self._ght("verify", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # A successful `ght supervise` re-establishment clears the gate.
        write_status("failed")
        assert_blocked()
        env = {**self._env, "GHT_SUPERVISE_INTERVAL_SECONDS": "5"}
        process = subprocess.Popen(
            [sys.executable, str(CLI), "--json", "supervise", "10"],
            cwd=str(self.repo), env=env, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL)
        deadline = time.time() + 5
        unblocked = False
        while time.time() < deadline:
            if self._ght("verify", "10").returncode == 0:
                unblocked = True
                break
            time.sleep(0.2)
        process.terminate()
        self._wait_exit(process)
        self.assertTrue(unblocked, "supervise reconciliation must clear the failed gate")

    def test_supervise_renews_and_actually_extends_expiry(self):
        # AC1/AC2: a supervised healthy worker keeps the lease ACTIVE and
        # the expiry genuinely extends each cycle — the v2 failure class
        # (renewal no-op leaving a fixed original expiry) cannot return.
        self._claim(10, env_extra={"GHT_LEASE_MINUTES": "1"})
        original = self._ght_json("inspect", "10")[1]["claim"]["lease_expires_at"]
        env = {**self._env, "GHT_SUPERVISE_INTERVAL_SECONDS": "1"}
        process = subprocess.Popen(
            [sys.executable, str(CLI), "--json", "supervise", "10"],
            cwd=str(self.repo), env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
        deadline = time.time() + 8
        first = None
        while time.time() < deadline:
            first = self._read_supervise_status(10)
            if first and first.get("last_renewal"):
                break
            time.sleep(0.2)
        time.sleep(2.5)
        second = self._read_supervise_status(10)
        process.terminate()
        code = self._wait_exit(process)
        self.assertIsNotNone(first, "supervisor must write its status file")
        self.assertEqual(first["state"], "running")
        self.assertIsNotNone(first.get("last_renewal"))
        self.assertIsNotNone(second)
        self.assertNotEqual(first.get("last_renewal"), second.get("last_renewal"),
                            "renewal must repeat, not no-op into a fixed expiry")
        self.assertGreater(second["lease_expires_at"], original)
        inspected = self._ght_json("inspect", "10")[1]
        self.assertEqual(inspected["claim_state"], "ACTIVE")
        # SIGTERM teardown by the test itself is not a supervision failure;
        # clean exits (terminal claim / max window) are covered elsewhere.
        self.assertIn(code, (0, -15))

    def test_supervisor_stops_renewing_after_executor_host_exits(self):
        # AC1: the engineering executor owns the parent process lifetime. Its
        # automatic supervisor renews while that host is alive, then stops
        # without delivering or terminalizing the ACTIVE attempt when the host
        # exits. Recovery remains lease-expiry/grace driven.
        host_script = """
import subprocess, sys
cli, repo = sys.argv[1:]
result = subprocess.run([sys.executable, cli, "--json", "claim", "10"],
                        cwd=repo, capture_output=True, text=True)
if result.returncode:
    sys.stderr.write(result.stderr or result.stdout)
    raise SystemExit(result.returncode)
print("CLAIM_OK", flush=True)
sys.stdin.readline()
raise SystemExit(2)
"""
        env = {**self._env, "GHT_SPAWN_SUPERVISOR": "1",
               "GHT_SUPERVISE_INTERVAL_SECONDS": "0.05",
               "GHT_LEASE_MINUTES": "1"}
        executor = subprocess.Popen(
            [sys.executable, "-c", host_script, str(CLI), str(self.repo)],
            cwd=str(self.repo), env=env, stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        status = None
        try:
            claim_line = executor.stdout.readline()
            if claim_line != "CLAIM_OK\n":
                self.fail(f"executor host failed: {claim_line!r}; {executor.stderr.read()}")

            deadline = time.time() + 4
            while time.time() < deadline:
                status = self._read_supervise_status(10)
                if status and status.get("last_renewal"):
                    break
                time.sleep(0.02)
            self.assertIsNotNone(status)
            self.assertEqual(status["state"], "running")
            self.assertIsNotNone(status.get("last_renewal"))
            result, inspected = self._ght_json("inspect", "10")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("claim", inspected, inspected)
            before_exit = inspected["claim"]
            self.assertEqual(before_exit["status"], "active")
            self.assertIsNone(before_exit.get("candidate"))
            self.assertFalse(before_exit.get("delivery"))

            executor.stdin.close()
            self.assertEqual(executor.wait(timeout=3), 2)

            deadline = time.time() + 3
            while time.time() < deadline:
                status = self._read_supervise_status(10)
                if status and status.get("state") == "stopped":
                    break
                time.sleep(0.02)
            self.assertEqual(status["state"], "stopped", status)
            self.assertEqual(status.get("reason"), "execution host exited")

            result, inspected = self._ght_json("inspect", "10")
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("claim", inspected, inspected)
            after_exit = inspected["claim"]
            self.assertEqual(after_exit["status"], "active")
            self.assertEqual(after_exit["lease_expires_at"],
                             before_exit["lease_expires_at"])
            self.assertIsNone(after_exit.get("candidate"))
            self.assertFalse(after_exit.get("delivery"))
        finally:
            if executor.poll() is None:
                if executor.stdin:
                    executor.stdin.close()
                self._wait_exit(executor)
            status = self._read_supervise_status(10)
            if status and status.get("pid") and status.get("state") != "stopped":
                try:
                    os.kill(status["pid"], 15)
                except ProcessLookupError:
                    pass
            for stream in (executor.stdin, executor.stdout, executor.stderr):
                if stream and not stream.closed:
                    stream.close()

    def test_supervise_fails_loud_on_ownership_loss(self):
        # AC3: renewal that cannot be confirmed against remote truth stops
        # the supervisor loudly and non-zero.
        self._claim(10)
        env = {**self._env, "GHT_SUPERVISE_INTERVAL_SECONDS": "0.3"}
        process = subprocess.Popen(
            [sys.executable, str(CLI), "--json", "supervise", "10"],
            cwd=str(self.repo), env=env, stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE, text=True)
        hijacker = self.tmp / "hijacker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(hijacker))
        sha = self._git(hijacker, "ls-remote", "origin",
                        CLAIM_REF + "10").stdout.split()[0]
        self._git(hijacker, "fetch", "-q", "origin", f"{CLAIM_REF}10")
        record = json.loads(self._git(hijacker, "show", f"{sha}:CLAIM.json").stdout)
        record["claim_id"] = "hijacker-20260917T000000-loseit"
        blob = self._git(hijacker, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(record, indent=1)).stdout.strip()
        tree = self._git(hijacker, "mktree",
                         input_text=f"100644 blob {blob}\tCLAIM.json\n").stdout.strip()
        hijack = self._git(hijacker, "commit-tree", tree, "-p", sha, "-m", "hijack",
                           env=self._env).stdout.strip()
        moved = self._git(hijacker, "push",
                          f"--force-with-lease={CLAIM_REF}10:{sha}",
                          "origin", f"{hijack}:{CLAIM_REF}10")
        self.assertEqual(moved.returncode, 0, moved.stderr)
        code = self._wait_exit(process)
        self.assertNotEqual(code, 0, "ownership loss must fail loudly, not silently")
        status = self._read_supervise_status(10)
        self.assertEqual(status["state"], "failed")
        self.assertIn("ownership", (status.get("error") or "").lower())

    def test_supervise_stops_when_claim_terminalizes(self):
        self._claim(10)
        env = {**self._env, "GHT_SUPERVISE_INTERVAL_SECONDS": "0.4"}
        process = subprocess.Popen(
            [sys.executable, str(CLI), "--json", "supervise", "10"],
            cwd=str(self.repo), env=env, stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE, text=True)
        result, _payload = self._ght_json("release", "10", "--status", "blocked",
                                          "--note", "A: replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        code = self._wait_exit(process)
        if code != 0:
            self.fail(f"supervise exit={code} stderr={process.stderr.read()}")
        self.assertEqual(code, 0, "terminal claim ends supervision cleanly")
        status = self._read_supervise_status(10)
        self.assertEqual(status["state"], "stopped")

    def test_claim_spawns_supervisor_and_long_run_stays_active(self):
        # AC4: the runtime owns renewal from claim time; no manual
        # heartbeat is needed while the worker executes long phases.
        claim = self._claim(10, env_extra={
            "GHT_LEASE_MINUTES": "1", "GHT_SUPERVISE_INTERVAL_SECONDS": "1",
            "GHT_SPAWN_SUPERVISOR": "1"})
        self.assertEqual(claim["supervisor"], "spawned")
        original = self._ght_json("inspect", "10")[1]["claim"]["lease_expires_at"]
        time.sleep(2.4)
        status = self._read_supervise_status(10)
        self.assertIsNotNone(status)
        self.assertEqual(status["state"], "running")
        self.assertGreater(status["lease_expires_at"], original,
                           "supervised long-running execution stays ACTIVE")
        result, _payload = self._ght_json("release", "10", "--status", "investigated",
                                          "--note", "done")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        deadline = time.time() + 6
        while time.time() < deadline:
            status = self._read_supervise_status(10)
            if status and status["state"] == "stopped":
                break
            time.sleep(0.2)
        self.assertEqual(status["state"], "stopped",
                         "terminalization ends the supervisor without any manual stop")

    def test_failed_terminal_record_restart_with_fresh_ready(self):
        # AC5 covers `failed` too: a failed attempt is durable history that a
        # fresh one-shot READY may follow, with lineage recorded.
        failed_record = {
            "v": 3, "task": 15, "claim_id": "worker-x-20260916T000000-fail15",
            "github_principal": "old", "executor_id": "worker-x",
            "claimed_at": "2026-09-16T00:00:00Z",
            "lease_expires_at": "2026-09-16T00:45:00Z",
            "execution_base": "d3313cccbbc55556fa46098391e4ff5a1a140a2a",
            "status": "failed", "branch": "agent/15/legacy",
            "heartbeat_at": "2026-09-16T00:00:00Z",
            "supersedes": None, "contract_digest": "f" * 64, "candidate": None,
        }
        failed_sha = self._raw_ref(CLAIM_REF + "15", failed_record, "ght: failed fail15")
        second = self._claim(15)
        self.assertEqual(second["supersedes"]["claim_id"], failed_record["claim_id"])
        self.assertEqual(second["supersedes"]["sha"], failed_sha)
        self.assertEqual(second["supersedes"]["status"], "failed")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      CLAIM_REF + "15").stdout.split()[0], second["ref_sha"])
        self._git(self.repo, "fetch", "-q", "origin", f"+{CLAIM_REF}15:{CLAIM_REF}15")
        self.assertEqual(self._git(self.repo, "rev-parse",
                                   CLAIM_REF + "15^").stdout.strip(), failed_sha,
                         "prior failed history remains immutable in the lineage chain")

    def test_terminal_restart_cas_race_has_exactly_one_winner(self):
        # AC3: two contenders starting from the same terminal state cannot
        # both become ACTIVE — exactly one CAS transition wins and the loser
        # stands down fail-closed.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(60, claim["branch"], sha)
        result, _payload = self._ght_json("deliver", "10", "--pr", "60")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._merge_pr(60)
        result, _payload = self._ght_json("complete", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        prior_sha = self._ght_json("inspect", "10")[1]["claim_sha"]
        # Contender A is the runtime under test; contender B is a racer whose
        # append lands between A's read and A's push (injected overwrite).
        racer = self.tmp / "racer3"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(racer))
        racer_record = {
            "v": 3, "task": 10, "claim_id": "racer-20260917T000000-winner",
            "github_principal": "acct", "executor_id": "racer",
            "claimed_at": "2026-09-17T00:00:00Z",
            "lease_expires_at": "2999-01-01T00:00:00Z",
            "execution_base": "d3313cccbbc55556fa46098391e4ff5a1a140a2a",
            "status": "active", "branch": "agent/10/racer",
            "heartbeat_at": "2026-09-17T00:00:00Z",
            "supersedes": {"claim_id": "prior", "sha": prior_sha},
            "contract_digest": "e" * 64, "candidate": None,
        }
        blob = self._git(racer, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(racer_record, indent=1)).stdout.strip()
        tree = self._git(racer, "mktree",
                         input_text=f"100644 blob {blob}\tCLAIM.json\n").stdout.strip()
        racer_commit = self._git(racer, "commit-tree", tree, "-p", prior_sha,
                                 "-m", "ght: active racer-20260917T000000-wi",
                                 env=self._env).stdout.strip()
        # #171: canonical completion converges the Issue itself (CLOSED with
        # state_reason completed); A reopens it to authorize more work — the
        # terminal-restart race scenario starts from there.
        self._update_issue(10, state="OPEN", stateReason=None, labels=["ready"])
        result = self._ght("claim", "10", env_extra={
            "GHT_TEST_RACER_DIR": str(racer),
            "GHT_TEST_RACE_OVERWRITE": racer_commit,
            "GHT_TEST_RACE_REF": CLAIM_REF + "10",
            "GHT_TEST_FAIL_PUSH_RESPONSE": "1",
        })
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("could not be reconciled", result.stdout)
        # Exactly one ACTIVE owner exists: the racer's append, with the
        # terminal prior still immutable in its ancestry.
        final_sha = self._git(self.repo, "ls-remote", "origin",
                              CLAIM_REF + "10").stdout.split()[0]
        self.assertEqual(final_sha, racer_commit)
        self._git(self.repo, "fetch", "-q", "origin", f"+{CLAIM_REF}10:{CLAIM_REF}10")
        self.assertEqual(self._git(self.repo, "rev-parse",
                                   CLAIM_REF + "10^").stdout.strip(), prior_sha)
        record = json.loads(self._git(self.repo, "show",
                                      f"{CLAIM_REF}10:CLAIM.json").stdout)
        self.assertEqual(record["status"], "active")
        self.assertEqual(record["claim_id"], racer_record["claim_id"])
        # The loser holds no ownership and cannot claim again while the
        # winner is ACTIVE.
        self._update_issue(10, labels=["ready"])
        result = self._ght("claim", "10")
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)
        self.assertIn("ACTIVE", result.stdout)

    def test_reservation_integrity_across_lineage_restart(self):
        # Reservation invariants: exactly one live lock for the executor
        # across a lineage restart; an orphan lock of a race loser never
        # authorizes a second owner and is cleaned by batch migration.
        self._claim(13)
        import hashlib
        key = hashlib.sha256(b"worker-1").hexdigest()[:32]
        result, _payload = self._ght_json("release", "13", "--status", "blocked",
                                          "--note", "A: replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "")
        self._update_issue(13, labels=["ready"])
        second = self._claim(13)
        lock_lines = self._git(self.repo, "ls-remote", "origin",
                               "refs/ght/claims-by-executor/*").stdout.strip().splitlines()
        locks = [line.split("\t", 1)[1] for line in lock_lines if line.strip()]
        self.assertEqual(len(locks), 1,
                         "exactly one live reservation after the restart")
        self.assertTrue(locks[0].startswith("refs/ght/claims-by-executor/"))
        result, _payload = self._ght_json("release", "13", "--status", "blocked",
                                          "--note", "A: stop again")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "")

    def test_manual_claim_ref_deletion_is_not_a_runtime_path(self):
        # AC4: the runtime never deletes a current-namespace claim ref; the
        # only deletions are object-preserving legacy migrations.
        sources = "\n".join(
            path.read_text()
            for path in sorted((SKILL_ROOT / "github_task").glob("*.py")))
        self.assertNotIn('"--delete"', sources)
        self.assertNotIn(":refs/ght/claims/", sources.replace(" ", ""))

    # -- pre-READY mechanical validation (read-only, executor-neutral) ----

    def _check(self, payload, check_id):
        return next(check for check in payload["checks"] if check["id"] == check_id)

    def test_validate_ready_passes_prepared_issue_and_reports_ready_state(self):
        # Pre-READY: a prepared Issue without `ready` is mechanically
        # eligible; PASS must not require or imply authorization (AC7/AC10).
        self._update_issue(15, labels=[])
        result, payload = self._ght_json("validate-ready", "15")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["ok"])
        self.assertTrue(payload["eligible"])
        self.assertTrue(payload["read_only"])
        self.assertEqual(payload["ready"], "absent")
        self.assertEqual([check["id"] for check in payload["checks"] if not check["ok"]], [])
        self.assertIn("mechanical eligibility", payload["note"])
        self.assertIn("never replaces", payload["note"])
        # With `ready` present the Issue is also eligible; the report shows
        # the authorization state without consuming it.
        self._update_issue(15, labels=["ready"])
        result, payload = self._ght_json("validate-ready", "15")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["ready"], "present")
        self.assertEqual(self._issue(15)["labels"], ["ready"],
                         "validate-ready must not consume ready")

    def test_validate_ready_is_strictly_read_only(self):
        # Prove at both surfaces that validation mutates nothing: the remote
        # ref dump (claims, reservations, branches) is byte-identical, the
        # Issue mirror (labels/comments) is untouched, and the only GitHub
        # calls are reads (AC7/AC9).
        self._update_issue(10, labels=["ready"])
        before_refs = self._git(self.repo, "ls-remote", "origin").stdout
        before_issue10, before_issue12 = self._issue(10), self._issue(12)
        calls_before = len(self._calls())
        results = [self._ght("validate-ready", number) for number in ("10", "2", "12")]
        self.assertEqual([result.returncode for result in results], [0, 2, 2],
                         [result.stdout + result.stderr for result in results])
        self.assertEqual(self._git(self.repo, "ls-remote", "origin").stdout, before_refs,
                         "validate-ready changed remote refs (claim/reservation/ready/ownership)")
        self.assertEqual(self._issue(10), before_issue10)
        self.assertEqual(self._issue(12), before_issue12)
        for call in self._calls()[calls_before:]:
            self.assertTrue(call[:2] in (["api", "user"], ["issue", "view"]),
                            f"validate-ready performed a non-read GitHub call: {call}")
        # The same holds while an ACTIVE claim and a live reservation exist:
        # the validator must not create, consume, repair, or delete anything.
        self._claim(14)
        settled_refs = self._git(self.repo, "ls-remote", "origin").stdout
        before_issue14 = self._issue(14)
        calls_before = len(self._calls())
        result, payload = self._ght_json("validate-ready", "14")
        self.assertEqual(result.returncode, 2)
        self.assertFalse(self._check(payload, "ownership")["ok"])
        # An unrelated live claim/reservation does not touch Issue 10's
        # eligibility: the verdict is issue-intrinsic, not worker-relative.
        result, payload = self._ght_json("validate-ready", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["ok"])
        self.assertEqual(self._git(self.repo, "ls-remote", "origin").stdout, settled_refs)
        self.assertEqual(self._issue(14), before_issue14)
        self.assertEqual(self._issue(10)["labels"], ["ready"])
        for call in self._calls()[calls_before:]:
            self.assertTrue(call[:2] in (["api", "user"], ["issue", "view"]),
                            f"validate-ready performed a non-read GitHub call: {call}")

    def test_validate_ready_is_executor_neutral(self):
        # AC7: the verdict depends only on the Issue's durable state, never
        # on GHT_EXECUTOR_ID — another worker's unrelated ACTIVE claim and
        # live reservation must not change this Issue's pre-READY eligibility.
        self._claim(14, env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        previous_checks = None
        for executor in ("worker-1", "worker-2", "worker-3"):
            result, payload = self._ght_json("validate-ready", "15",
                                             env_extra={"GHT_EXECUTOR_ID": executor})
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["ready"], "present")
            if previous_checks is not None:
                self.assertEqual(payload["checks"], previous_checks,
                                 "verdict changed with GHT_EXECUTOR_ID")
            previous_checks = payload["checks"]
        # Worker-identity safety stays a claim-time concern: the validator
        # surface has no executor or reservation checks at all.
        _result, payload = self._ght_json("validate-ready", "15")
        self.assertNotIn("executor", {check["id"] for check in payload["checks"]})
        self.assertNotIn("reservation", {check["id"] for check in payload["checks"]})

    def test_validate_ready_fails_invalid_target_contract_and_dependency(self):
        # PR target.
        result = self._ght("validate-ready", "2")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("Pull Request", result.stdout)
        # Closed Issue target.
        result = self._ght("validate-ready", "4")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("not open", result.stdout)
        # Open hard dependency.
        result = self._ght("validate-ready", "12")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("hard dependency #5", result.stdout)
        # Contract integrity: missing, duplicated, and invalid-authority.
        for body in ("no contract here",
                     issue_body(IMPL_CONTRACT + IMPL_CONTRACT),
                     issue_body(IMPL_CONTRACT.replace(
                         "implementation: allowed", "implementation: sometimes"))):
            self._update_issue(15, body=body)
            result = self._ght("validate-ready", "15")
            self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
            self.assertIn("not claimable", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "15").stdout.strip(), "",
            "failed validation must not create claim state")

    def test_validate_ready_fails_on_conflicting_active_stale_and_incoherent_ready(self):
        self._claim(10)
        result, payload = self._ght_json("validate-ready", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertFalse(payload["ok"])
        self.assertIn("ACTIVE", self._check(payload, "ownership")["detail"])
        # READY-absent alongside an ACTIVE claim is the normal consumed state.
        self.assertTrue(self._check(payload, "ready")["ok"])
        # A stale ready label coexisting with the ACTIVE claim is incoherent
        # (failed mirror repair) and fails closed.
        self._update_issue(10, labels=["ready"])
        result, payload = self._ght_json("validate-ready", "10")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        ready = self._check(payload, "ready")
        self.assertFalse(ready["ok"])
        self.assertIn("incoherent", ready["detail"])
        # A STALE lineage is not fresh-claim eligible; recovery is takeover.
        # A second executor holds it so the one-ACTIVE invariant stays clean.
        self._claim(14, env_extra={"GHT_LEASE_MINUTES": "0",
                                   "GHT_EXECUTOR_ID": "worker-2"})
        stale = self._ght_json("inspect", "14")[1]
        deadline = time.time() + 5
        while stale["claim_state"] != "STALE" and time.time() < deadline:
            time.sleep(0.2)
            stale = self._ght_json("inspect", "14")[1]
        result, payload = self._ght_json("validate-ready", "14",
                                         env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        ownership = self._check(payload, "ownership")
        self.assertFalse(ownership["ok"])
        self.assertIn("STALE", ownership["detail"])
        self.assertIn("takeover", ownership["detail"])

    def test_validate_ready_fails_closed_on_ambiguous_namespace(self):
        self._claim(10)
        sha = self._git(self.repo, "ls-remote", "origin",
                        CLAIM_REF + "10").stdout.split()[0]
        self._git(self.repo, "push", "origin", f"{sha}:{LEGACY_CLAIM_REF}10")
        result, payload = self._ght_json("validate-ready", "10")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertTrue(payload["ambiguous"])
        namespace = self._check(payload, "namespace")
        self.assertFalse(namespace["ok"])
        self.assertIn("AMBIGUOUS", namespace["detail"])
        # Fail-closed means read-only even under ambiguity: both copies stay.
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "10").stdout.split()[0], sha)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      LEGACY_CLAIM_REF + "10").stdout.split()[0], sha)

    def test_validate_ready_over_terminal_lineage(self):
        self._claim(10)
        result, _payload = self._ght_json("release", "10", "--status", "blocked",
                                          "--note", "A: replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("validate-ready", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        ownership = self._check(payload, "ownership")
        self.assertTrue(ownership["ok"])
        self.assertIn("terminal", ownership["detail"])
        self.assertIn("supersedes", ownership["detail"])
        # An investigated report answered its Contract and is final.
        self._claim(11, mode="investigate")
        result, _payload = self._ght_json("release", "11", "--status", "investigated",
                                          "--note", "findings recorded")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("validate-ready", "11")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        ownership = self._check(payload, "ownership")
        self.assertFalse(ownership["ok"])
        self.assertIn("final", ownership["detail"])

    def test_validate_ready_checks_referenced_design_anchors(self):
        self._update_issue(15, body=issue_body(IMPL_CONTRACT.replace(
            "authority:", "design_refs:\n  - README.md\n\nauthority:")))
        result, payload = self._ght_json("validate-ready", "15")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(self._check(payload, "design_refs")["ok"])
        self._update_issue(15, body=issue_body(IMPL_CONTRACT.replace(
            "authority:", "design_refs:\n  - docs/missing-anchor.md\n\nauthority:")))
        result, payload = self._ght_json("validate-ready", "15")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        design_refs = self._check(payload, "design_refs")
        self.assertFalse(design_refs["ok"])
        self.assertIn("docs/missing-anchor.md", design_refs["detail"])

    def test_validate_ready_reuses_canonical_intake_primitives(self):
        # No second validation model: the validator must go through the
        # canonical claim-intake and claim-state primitives, and must not
        # carry its own Contract parser. Executor-neutrality is structural:
        # no worker-identity or reservation lookup may gate the verdict.
        import inspect

        from github_task import cli as cli_module

        source = inspect.getsource(cli_module._cmd_validate_ready)
        self.assertIn("_validate_issue_intake", source)
        self.assertIn("claim_state", source)
        self.assertNotIn("_parse_yaml_subset", source)
        self.assertNotIn("re.findall", source)
        self.assertNotIn("_active_executor_claim", source)
        self.assertNotIn("_remote_executor_reservation", source)
        self.assertNotIn("executor_id", source)

    # -- Harry Dev distribution identity ---------------------------------

    def _dist_repo(self, name="dist-src"):
        """A throwaway git source tree used as the distribution root."""
        dist = self.tmp / name
        self._git(self.tmp, "init", "-q", str(dist), "-b", "main")
        (dist / "f.txt").write_text("one\n")
        self._git(dist, "add", ".")
        self._git(dist, "-c", "user.email=t@t", "-c", "user.name=t",
                  "commit", "-qm", "one")
        return dist

    def test_version_reports_harry_dev_distribution_identity(self):
        # AC2: `ght version` reports only the Harry Dev distribution
        # identity. A source checkout sitting exactly on a `v*` tag is a
        # release install and reports that tag; development source must
        # never impersonate the nearest release; missing git provenance
        # fails honest. AC1: no independent github-task product version
        # appears on the version surface.
        dist = self._dist_repo()
        env = {"GHT_DISTRIBUTION_ROOT": str(dist)}
        self._git(dist, "tag", "v9.9.9")
        result, payload = self._ght_json("version", env_extra=env)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload, {"product": "harry-dev", "status": "released",
                                   "release": "v9.9.9",
                                   "source_sha": self._git(dist, "rev-parse",
                                                           "--short", "HEAD").stdout.strip()})
        self.assertNotIn("github-task v", result.stdout)
        # The argparse --version path reports the same identity.
        human = self._ght("--version", env_extra=env)
        self.assertEqual(human.returncode, 0, human.stdout + human.stderr)
        self.assertIn("harry-dev v9.9.9", human.stdout)
        # identity/status carry the same distribution identity instead of
        # an independent product version.
        _result, identity = self._ght_json("identity", env_extra=env)
        self.assertEqual(identity["distribution"]["release"], "v9.9.9")
        self.assertNotIn("version", identity)
        _result, status = self._ght_json("status", env_extra=env)
        self.assertEqual(status["distribution"]["status"], "released")
        self.assertNotIn("version", status)
        # Development source one commit past the release tag: unreleased,
        # with locatable source provenance, never the release tag.
        (dist / "f.txt").write_text("two\n")
        self._git(dist, "add", ".")
        self._git(dist, "-c", "user.email=t@t", "-c", "user.name=t",
                  "commit", "-qm", "two")
        result, payload = self._ght_json("version", env_extra=env)
        self.assertEqual(payload["product"], "harry-dev")
        self.assertEqual(payload["status"], "unreleased")
        self.assertIsNone(payload["release"])
        self.assertTrue(payload["source_sha"])
        self.assertNotIn("v9.9.9", result.stdout)
        # A source tree without any git provenance fails honest.
        bare = self.tmp / "no-provenance"
        bare.mkdir()
        result, payload = self._ght_json("version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(bare)})
        self.assertEqual(payload, {"product": "harry-dev", "status": "unreleased",
                                   "release": None, "source_sha": None})
        self.assertIn("unreleased", self._ght("--version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(bare)}).stdout)

    def test_version_release_identity_survives_copy_without_git(self):
        # AC2: a formal Harry Dev release install keeps reporting its
        # `harry-dev vX.Y.Z` identity even when the installation form
        # (copied skill directory, extracted release archive) carries no
        # `.git` at all. The release identity therefore travels with the
        # distribution itself as DISTRIBUTION.json, written at release
        # packaging time; git exact-tag stays the dev-source provenance
        # path, and a manifest that does not carry a well-formed Harry Dev
        # release never claims released status.
        dist = self._dist_repo()
        self._git(dist, "tag", "v9.9.9")
        release_sha = self._git(dist, "rev-parse", "--short", "HEAD").stdout.strip()
        copied = self.tmp / "release-copy"
        shutil.copytree(dist, copied, ignore=shutil.ignore_patterns(".git"))
        (copied / "DISTRIBUTION.json").write_text(json.dumps(
            {"product": "harry-dev", "release": "v1.0.3", "source_sha": release_sha}))
        result, payload = self._ght_json("version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(copied)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload, {"product": "harry-dev", "status": "released",
                                   "release": "v1.0.3", "source_sha": release_sha})
        self.assertIn("harry-dev v1.0.3", self._ght("--version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(copied)}).stdout)
        self.assertNotIn("github-task v", result.stdout)
        # The carried manifest is authoritative even for a git checkout
        # (release packaging knows the shipped identity).
        (dist / "DISTRIBUTION.json").write_text(json.dumps(
            {"product": "harry-dev", "release": "v1.0.3", "source_sha": release_sha}))
        result, payload = self._ght_json("version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(dist)})
        self.assertEqual(payload["status"], "released")
        self.assertEqual(payload["release"], "v1.0.3")
        # A manifest without a well-formed release value never claims
        # released: the identity falls back to the git path — the tagged
        # tree keeps its tag identity, and a dev tree reports unreleased.
        for bad in ("banana", "", None):
            (dist / "DISTRIBUTION.json").write_text(json.dumps(
                {"product": "harry-dev", "release": bad}))
            result, payload = self._ght_json("version", env_extra={
                "GHT_DISTRIBUTION_ROOT": str(dist)})
            self.assertEqual(payload["status"], "released", f"release={bad!r}")
            self.assertEqual(payload["release"], "v9.9.9", f"release={bad!r}")
            dev_tree = self._dist_repo("dist-dev")
            (dev_tree / "DISTRIBUTION.json").write_text(json.dumps(
                {"product": "harry-dev", "release": bad}))
            result, payload = self._ght_json("version", env_extra={
                "GHT_DISTRIBUTION_ROOT": str(dev_tree)})
            self.assertEqual(payload["status"], "unreleased", f"release={bad!r}")
            self.assertIsNone(payload["release"], f"release={bad!r}")
            self.assertTrue(payload["source_sha"])
        # A manifest naming a different product is rejected as well, and
        # unreadable manifest content cannot claim a release either — on a
        # dev tree both fall back to honest unreleased.
        (dev_tree / "DISTRIBUTION.json").write_text(json.dumps(
            {"product": "other-tool", "release": "v1.0.3"}))
        result, payload = self._ght_json("version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(dev_tree)})
        self.assertEqual(payload["status"], "unreleased")
        (dev_tree / "DISTRIBUTION.json").write_text("{not json")
        result, payload = self._ght_json("version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(dev_tree)})
        self.assertEqual(payload["status"], "unreleased")
        # And without any git behind it, a bad manifest fails honest.
        (copied / "DISTRIBUTION.json").write_text(json.dumps(
            {"product": "harry-dev", "release": "banana"}))
        result, payload = self._ght_json("version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(copied)})
        self.assertEqual(payload, {"product": "harry-dev", "status": "unreleased",
                                   "release": None, "source_sha": None})

    def test_stamp_distribution_requires_matching_release_source(self):
        # AC2 end-to-end: the producer may only establish released truth
        # when the actual release source proves the requested identity —
        # the source checkout must sit exactly on the requested `v*` tag.
        # A dev checkout, a checkout on a different tag, or a malformed
        # request all fail closed without writing or clobbering anything;
        # a matching exact-tag checkout stamps the manifest, and the
        # stamped skill keeps reporting that exact release after landing
        # on a host with no `.git` at all.
        dist = self._dist_repo()
        install = self.tmp / "release-archive"
        shutil.copytree(SKILL_ROOT, install,
                        ignore=shutil.ignore_patterns(".git", "__pycache__",
                                                      "DISTRIBUTION.json"))

        def stamp(release):
            return self._ght_json("stamp-distribution", "--release", release,
                                  "--source", str(dist), "--root", str(install))

        # A dev checkout on no tag at all may not claim a release.
        result, _payload = stamp("v1.0.3")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertFalse((install / "DISTRIBUTION.json").exists(),
                         "a refused stamp must not write a manifest")
        # A checkout sitting on a different tag may not claim another
        # release, and the failure must not write anything either.
        self._git(dist, "tag", "v9.9.9")
        result, _payload = stamp("v1.0.3")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertFalse((install / "DISTRIBUTION.json").exists())
        # Development source one commit past the release tag stays refused.
        (dist / "f.txt").write_text("two\n")
        self._git(dist, "add", ".")
        self._git(dist, "-c", "user.email=t@t", "-c", "user.name=t",
                  "commit", "-qm", "two")
        result, _payload = stamp("v1.0.3")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertFalse((install / "DISTRIBUTION.json").exists())
        # The checkout whose HEAD exactly matches the requested tag stamps:
        # the manifest carries the release plus the source SHA provenance.
        # #178 AC1: the producer writes the FULL exact 40-hex tagged HEAD —
        # the abbreviated form is the proven v1.1.2 producer defect that the
        # shipped thin consumer refuses — and never a non-exact identity.
        self._git(dist, "tag", "v1.0.3")
        source_sha = self._git(dist, "rev-parse", "HEAD").stdout.strip()
        self.assertRegex(source_sha, r"^[0-9a-f]{40}$",
                         "the stamped provenance must be the exact commit SHA")
        result, payload = stamp("v1.0.3")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["stamped"],
                         {"product": "harry-dev", "release": "v1.0.3",
                          "source_sha": source_sha})
        self.assertEqual(payload["identity"]["status"], "released")
        # Simulate the distributed copy landing on a host: no `.git`
        # anywhere, `ght version` still reports the exact release.
        deployed = self.tmp / "deployed-skill"
        shutil.copytree(install, deployed,
                        ignore=shutil.ignore_patterns(".git", "__pycache__"))
        result, payload = self._ght_json("version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(deployed)})
        self.assertEqual(payload, {"product": "harry-dev", "status": "released",
                                   "release": "v1.0.3", "source_sha": source_sha})
        self.assertIn("harry-dev v1.0.3", self._ght("--version", env_extra={
            "GHT_DISTRIBUTION_ROOT": str(deployed)}).stdout)
        self.assertNotIn("github-task v", result.stdout)
        # Refusals never clobber an existing stamped manifest: dev source,
        # a mismatched tag request, and malformed values are all inert.
        before = (install / "DISTRIBUTION.json").read_text()
        (dist / "f.txt").write_text("three\n")
        self._git(dist, "add", ".")
        self._git(dist, "-c", "user.email=t@t", "-c", "user.name=t",
                  "commit", "-qm", "three")
        for bad_release in ("v1.0.3", "v9.9.9", "banana", ""):
            result, _payload = stamp(bad_release)
            self.assertNotEqual(result.returncode, 0,
                                f"stamp accepted {bad_release!r}")
            self.assertEqual((install / "DISTRIBUTION.json").read_text(), before,
                             f"refused stamp must not touch the manifest: {bad_release!r}")

    # -- execution leases: durable attempt vs temporary capacity (#42) ----

    LEASE_REF_FMT = "refs/ght/execution-leases/%s"

    def _read_lease_record(self, claim_id):
        ref = self.LEASE_REF_FMT % claim_id
        temp_ref = f"refs/ght-read/lease-{claim_id}"
        fetched = self._git(self.repo, "fetch", "-q", "origin", f"+{ref}:{temp_ref}")
        self.assertEqual(fetched.returncode, 0, fetched.stderr)
        try:
            result = self._git(self.repo, "show", f"{temp_ref}:LEASE.json")
            self.assertEqual(result.returncode, 0, result.stderr)
            return json.loads(result.stdout)
        finally:
            self._git(self.repo, "update-ref", "-d", temp_ref)

    def _rewrite_lease_ref(self, claim_id, record, message="ght: rewrite lease fixture"):
        ref = self.LEASE_REF_FMT % claim_id
        temp_ref = f"refs/ght-read/lease-parent-{claim_id}"
        fetched = self._git(self.repo, "fetch", "-q", "origin", f"+{ref}:{temp_ref}")
        self.assertEqual(fetched.returncode, 0, fetched.stderr)
        try:
            parent = self._git(self.repo, "rev-parse", temp_ref).stdout.strip()
            blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                             input_text=json.dumps(record, indent=1)).stdout.strip()
            tree = self._git(self.repo, "mktree",
                             input_text=f"100644 blob {blob}\tLEASE.json\n").stdout.strip()
            commit = self._git(self.repo, "commit-tree", tree, "-p", parent,
                               "-m", message, env=self._env).stdout.strip()
            pushed = self._git(self.repo, "push", f"--force-with-lease={ref}:{parent}",
                               "origin", f"{commit}:{ref}")
            self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
            return commit
        finally:
            self._git(self.repo, "update-ref", "-d", temp_ref)

    def _expire_execution_lease(self, claim_id):
        record = self._read_lease_record(claim_id)
        record["lease_expires_at"] = "2000-01-01T00:00:00Z"
        self._rewrite_lease_ref(claim_id, record, "ght: expired execution lease fixture")
        return record

    def _raw_lease_ref(self, claim_id, record, message="ght: raw lease"):
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(record, indent=1)).stdout.strip()
        tree = self._git(self.repo, "mktree",
                         input_text=f"100644 blob {blob}\tLEASE.json\n").stdout.strip()
        commit = self._git(self.repo, "commit-tree", tree, "-m", message,
                           env=self._env).stdout.strip()
        pushed = self._git(self.repo, "push", "origin",
                           f"{commit}:refs/ght/execution-leases/{claim_id}")
        self.assertEqual(pushed.returncode, 0, pushed.stderr)
        return commit

    def _lease_remote_sha(self, claim_id):
        return self._git(self.repo, "ls-remote", "origin",
                         self.LEASE_REF_FMT % claim_id).stdout.strip().split()[0] \
            if self._git(self.repo, "ls-remote", "origin",
                         self.LEASE_REF_FMT % claim_id).stdout.strip() else None

    def _delivered_parked(self, number=10, pr=60, executor="worker-1"):
        """Drive one attempt to the parked condition: durable Candidate
        delivery, capacity released, attempt still non-terminal."""
        env = {"GHT_EXECUTOR_ID": executor} if executor != "worker-1" else None
        claim = self._claim(number, env_extra=env)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", str(number), env_extra=env)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(pr, claim["branch"], sha)
        result, payload = self._ght_json("deliver", str(number), "--pr", str(pr),
                                         env_extra=env)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return claim, sha

    def test_execution_lease_lifecycle_claim_deliver_reacquire(self):
        # AC1/AC2/AC4/AC5: the claim creates a live lease bound to the
        # durable claim_id; delivery releases the capacity while the attempt
        # stays non-terminal (parked, derived from durable facts only); the
        # review-correction path reacquires a NEW fencing identity for the
        # SAME attempt.
        claim = self._claim(10)
        token = claim["execution_lease"]["fencing_token"]
        self.assertEqual(claim["execution_lease"]["ref"], self.LEASE_REF_FMT % claim["claim_id"])
        self.assertEqual(self._lease_remote_sha(claim["claim_id"]) is not None, True)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(60, claim["branch"], sha)
        result, payload = self._ght_json("deliver", "10", "--pr", "60")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["execution_lease_released"])
        self.assertIsNone(self._lease_remote_sha(claim["claim_id"]),
                          "delivery releases the temporary execution lease")
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "active",
                         "the durable attempt is NOT terminal after delivery")
        self.assertEqual(inspected["delivery"]["sha"], sha)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "",
            "the executor reservation is released with the lease (AC16)")
        # Parked derives from durable facts; no lifecycle label appears.
        self.assertEqual(self._issue(10)["labels"], [])
        # Ordinary REQUEST_CHANGES resume: same attempt, new lease identity.
        result, acquired = self._ght_json("acquire", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(acquired["claim_id"], claim["claim_id"])
        self.assertNotEqual(acquired["execution_lease"]["fencing_token"], token)
        self.assertIsNotNone(self._lease_remote_sha(claim["claim_id"]))
        result, payload = self._ght_json("verify", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["execution_lease"]["fencing_token"],
                         acquired["execution_lease"]["fencing_token"])
        # Idempotent re-delivery of the same PR/Candidate releases again.
        result, payload = self._ght_json("deliver", "10", "--pr", "60")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIsNone(self._lease_remote_sha(claim["claim_id"]))

    def test_acquire_recovers_expired_residue_with_exact_remote_readback(self):
        state_dir = "state-recover-expired"
        claim = self._claim(10, env_extra={"GHT_STATE_DIR": state_dir})
        self._rewrite_claim_record(10, lease_expires_at="2000-01-01T00:00:00Z")
        old_lease = self._expire_execution_lease(claim["claim_id"])

        result, payload = self._ght_json(
            "acquire", "10", env_extra={"GHT_STATE_DIR": state_dir,
                                        "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["claim_id"], claim["claim_id"])
        self.assertNotEqual(payload["execution_lease"]["fencing_token"],
                            old_lease["fencing_token"])

        inspected = self._ght_json("inspect", "10")[1]["claim"]
        new_lease = self._read_lease_record(claim["claim_id"])
        self.assertEqual(inspected["status"], "active")
        self.assertEqual(inspected["claim_id"], claim["claim_id"])
        self.assertEqual(inspected["branch"], claim["branch"])
        self.assertEqual(new_lease["claim_id"], claim["claim_id"])
        self.assertEqual(new_lease["issue"], 10)
        self.assertEqual(new_lease["executor_id"], inspected["executor_id"])
        self.assertEqual(new_lease["github_principal"], inspected["github_principal"])
        self.assertEqual(new_lease["branch"], inspected["branch"])
        self.assertEqual(new_lease["contract_digest"], inspected["contract_digest"])
        self.assertEqual(new_lease["fencing_token"], payload["execution_lease"]["fencing_token"])
        self.assertGreater(new_lease["lease_expires_at"], "2000-01-01T00:00:00Z")

    def test_release_can_terminalize_owned_delivery_with_expired_lease_residue(self):
        claim = self._claim(10)
        old_lease = self._read_lease_record(claim["claim_id"])
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(75, claim["branch"], sha)
        result, _payload = self._ght_json("deliver", "10", "--pr", "75")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        old_lease["lease_expires_at"] = "2000-01-01T00:00:00Z"
        self._raw_lease_ref(claim["claim_id"], old_lease)

        result, payload = self._ght_json("release", "10", "--status", "blocked",
                                         "--note", "A: stop and replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "blocked")
        self.assertEqual(self._ght_json("inspect", "10")[1]["claim"]["claim_id"],
                         claim["claim_id"])
        self.assertIsNone(self._lease_remote_sha(claim["claim_id"]))

    def test_status_fails_closed_on_mismatched_or_malformed_lease(self):
        claim = self._claim(10)
        mismatched = self._read_lease_record(claim["claim_id"])
        mismatched["executor_id"] = "worker-2"
        self._rewrite_lease_ref(claim["claim_id"], mismatched,
                                "ght: mismatched execution lease fixture")
        result = self._ght("status")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("does not back-prove", result.stdout)

        malformed = self._read_lease_record(claim["claim_id"])
        malformed["executor_id"] = self._ght_json("inspect", "10")[1]["claim"]["executor_id"]
        malformed["lease_expires_at"] = "not-a-date"
        self._rewrite_lease_ref(claim["claim_id"], malformed,
                                "ght: malformed execution lease fixture")
        result = self._ght("status")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("execution lease is malformed", result.stdout)
        result = self._ght("discover")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("execution lease is malformed", result.stdout)

    def test_stale_holder_fencing_across_sessions(self):
        # AC3: a holder proves the CURRENT fencing identity, never just the
        # claim_id. A cache-less (or superseded) holder fails closed even
        # while the lease is live; the same-attempt reacquire replaces an
        # identity-proven residue only after expiry past grace.
        claim = self._claim(10, env_extra={"GHT_LEASE_MINUTES": "0",
                                           "GHT_STATE_DIR": "state-A"})
        # A cache-less holder fails closed before it can prove anything.
        result = self._ght("verify", "10", env_extra={"GHT_STATE_DIR": "state-B"})
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        result = self._ght("verify", "10", env_extra={"GHT_STATE_DIR": "state-A"})
        self.assertEqual(result.returncode, 5, result.stdout + result.stderr)
        # Expire the lease: even the holding session fails closed instead of
        # renewing in place; reacquire mints a fresh identity.
        stale = self._ght_json("inspect", "10")[1]
        deadline = time.time() + 5
        while stale["claim_state"] != "STALE" and time.time() < deadline:
            time.sleep(0.2)
            stale = self._ght_json("inspect", "10")[1]
        result = self._ght("heartbeat", "10", "--force",
                           env_extra={"GHT_STATE_DIR": "state-A"})
        self.assertEqual(result.returncode, 5, result.stdout + result.stderr)
        result, reacquired = self._ght_json(
            "acquire", "10", env_extra={"GHT_STATE_DIR": "state-B",
                                        "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertNotEqual(reacquired["execution_lease"]["fencing_token"],
                            claim["execution_lease"]["fencing_token"])
        # The stale state-A holder can neither verify nor renew: its fencing
        # identity was replaced by the reacquire.
        result = self._ght("verify", "10", env_extra={"GHT_STATE_DIR": "state-A"})
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("different fencing identity", result.stdout)
        result = self._ght("heartbeat", "10", "--force",
                           env_extra={"GHT_STATE_DIR": "state-A"})
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("different fencing identity", result.stdout)
        # The reacquiring session holds the live identity.
        result, payload = self._ght_json("heartbeat", "10", "--force",
                                         env_extra={"GHT_STATE_DIR": "state-B"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertTrue(payload["renewed"])

    def test_acquire_conflicts_with_live_lease_and_residue_grace(self):
        # AC3: a second concurrent holder is refused while the lease is live,
        # and an expired residue inside the stale-holder grace window too.
        self._claim(10, env_extra={"GHT_STATE_DIR": "state-A"})
        result = self._ght("acquire", "10", env_extra={"GHT_STATE_DIR": "state-B"})
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)
        self.assertIn("live execution lease", result.stdout)
        # Expired residue within the stale-holder grace window: refused.
        self._claim(15, env_extra={"GHT_LEASE_MINUTES": "0", "GHT_STATE_DIR": "state-A",
                                   "GHT_EXECUTOR_ID": "worker-2"})
        stale = self._ght_json("inspect", "15")[1]
        deadline = time.time() + 5
        while stale["claim_state"] != "STALE" and time.time() < deadline:
            time.sleep(0.2)
            stale = self._ght_json("inspect", "15")[1]
        result = self._ght("acquire", "15",
                           env_extra={"GHT_STATE_DIR": "state-B",
                                      "GHT_TAKEOVER_GRACE_MINUTES": "30",
                                      "GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)
        self.assertIn("grace", result.stdout)
        # Past the grace window the same-attempt reacquire succeeds.
        result, _payload = self._ght_json(
            "acquire", "15", env_extra={"GHT_STATE_DIR": "state-B",
                                        "GHT_TAKEOVER_GRACE_MINUTES": "0",
                                        "GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_deliver_failure_keeps_execution_capacity(self):
        # AC4: capacity is released only after the delivery became durable
        # remote truth; a refused delivery keeps the lease and reservation.
        claim = self._claim(10)
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # A PR whose head lives on a different branch (its recorded sha can
        # never equal the preserved Candidate).
        self._open_pr(61, "agent/10/wrong-head", "f" * 40)
        result, _payload = self._ght_json("deliver", "10", "--pr", "61")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIsNotNone(self._lease_remote_sha(claim["claim_id"]),
                             "a refused delivery must not release the lease")
        self.assertTrue(self._git(self.repo, "ls-remote", "origin",
                                  "refs/ght/claims-by-executor/*").stdout.strip())
        self._open_pr(61, claim["branch"], sha)
        result, _payload = self._ght_json("deliver", "10", "--pr", "61")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIsNone(self._lease_remote_sha(claim["claim_id"]))

    def test_executor_neutral_complete_without_original_session(self):
        # AC10: completion reconciles from durable remote truth — the caller
        # needs neither the original executor identity, nor a local claim
        # cache, worktree, or live lease. The original execution identity
        # stays intact; the reconciler is audit metadata only.
        claim, sha = self._delivered_parked(number=10, pr=62, executor="original-worker")
        self._merge_pr(62)
        result, payload = self._ght_json("complete", "10", env_extra={
            "GHT_EXECUTOR_ID": "reconciler-9",
            "GHT_STATE_DIR": "reconciler-state"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "delivered")
        self.assertEqual(payload["candidate_sha"], sha)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["executor_id"], "original-worker",
                         "the original execution identity is preserved (AC10)")
        self.assertEqual(inspected["completed"]["completed_by"], "acct",
                         "the reconciling actor is recorded as audit information only")
        # Idempotent retry after an uncertain response: same truth, success.
        result, payload = self._ght_json("complete", "10", env_extra={
            "GHT_EXECUTOR_ID": "reconciler-9",
            "GHT_STATE_DIR": "reconciler-state"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "delivered")

    def test_complete_runs_under_installation_token_with_reconciler_identity(self):
        # AC1/AC2/AC5: a GitHub App installation token cannot answer
        # `gh api user`, but an explicit machine/reconciler identity carries
        # executor-neutral completion: completed_by is the reconciler, the
        # durable attempt's original identity stays untouched, and every
        # exact Candidate / acceptance / merged-head predicate is still
        # verified by the same primitive.
        claim, sha = self._delivered_parked(number=10, pr=62, executor="original-worker")
        self._merge_pr(62)
        result, payload = self._ght_json("complete", "10", env_extra={
            "GHT_TEST_FAIL_API_USER": "1",
            "GHT_RECONCILER_ID": "ght-complete-workflow",
            "GHT_EXECUTOR_ID": "ght-complete-workflow"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "delivered")
        self.assertEqual(payload["candidate_sha"], sha)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["executor_id"], "original-worker",
                         "the original execution identity is preserved")
        self.assertEqual(inspected["status"], "delivered")
        self.assertEqual(inspected["completed"]["completed_by"],
                         "ght-complete-workflow",
                         "the machine caller is recorded as audit metadata only")

    def test_complete_without_principal_or_reconciler_fails_closed(self):
        # AC4: an unusable credential with no explicit machine identity must
        # fail closed — never silently empty, random, or the original
        # executor's identity — and must not terminalize the attempt.
        claim, sha = self._delivered_parked(number=10, pr=62, executor="original-worker")
        self._merge_pr(62)
        result = self._ght("complete", "10", env_extra={"GHT_TEST_FAIL_API_USER": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("fail closed", result.stdout)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "active",
                         "the attempt is not terminalized without a caller identity")

    def test_reconciler_identity_is_completion_only(self):
        # AC3: the machine identity never reaches an ownership-sensitive
        # path — the commands refuse it even when a real principal exists.
        for command, args in (("claim", ["10"]), ("deliver", ["10", "--pr", "62"]),
                              ("heartbeat", ["10"]), ("orchestrate", [])):
            result = self._ght(command, *args, env_extra={
                "GHT_RECONCILER_ID": "ght-complete-workflow"})
            self.assertNotEqual(result.returncode, 0,
                                f"{command} must refuse the completion-only identity")
            self.assertIn("completion-only", result.stdout)

    def test_release_publisher_identity_is_publication_only(self):
        # #130: the dedicated release-publisher machine identity reaches ONLY
        # the canonical release-publication surface (plus the side-effect-free
        # `version`); every other command mechanically refuses it — it is
        # never a general principal substitute and never release authority.
        for command, args in (("claim", ["10"]), ("deliver", ["10", "--pr", "62"]),
                              ("heartbeat", ["10"]), ("complete", ["10"]),
                              ("plan-publish", ["-"])):
            result = self._ght(command, *args, env_extra={
                "GHT_RELEASE_PUBLISHER_ID": "ght-formal-release-workflow"})
            self.assertNotEqual(result.returncode, 0,
                                f"{command} must refuse the publication-only identity")
            self.assertIn("publication-only", result.stdout)
        result = self._ght("version", env_extra={
            "GHT_RELEASE_PUBLISHER_ID": "ght-formal-release-workflow"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_complete_fail_closed_predicates(self):
        # AC11: every missing/conflicting durable fact blocks reconciliation.
        claim, sha = self._delivered_parked(number=14, pr=63)
        # Candidate without a delivery record cannot complete.
        data = json.loads(self.state.read_text())
        data["63"]["state"] = "OPEN"
        self.state.write_text(json.dumps(data, indent=2))
        result = self._ght("complete", "14")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("not merged", result.stdout)
        # Merged at a different head than the preserved Candidate. The
        # mock resolves headRefOid to the live branch tip like real GitHub,
        # so model the stale-head state with a head branch that no longer
        # exists (GitHub keeps the last known head SHA after deletion).
        self._open_pr(63, "agent/14/deleted-head", "e" * 40, state="MERGED")
        result = self._ght("complete", "14")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("does not equal the preserved Candidate SHA", result.stdout)
        # Merged exactly, but no durable A acceptance on the PR.
        self._open_pr(63, claim["branch"], sha, state="MERGED")
        result = self._ght("complete", "14")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no durable A acceptance", result.stdout)
        # An APPROVED review bound to a different SHA without the canonical
        # structured fallback is not acceptance either.
        self._open_pr(63, claim["branch"], sha, state="MERGED",
                      reviews=[{"state": "APPROVED", "commit_id": "d" * 40}])
        result = self._ght("complete", "14")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no durable A acceptance", result.stdout)
        # Unreadable acceptance surface fails closed.
        self._open_pr(63, claim["branch"], sha, state="MERGED")
        result = self._ght("complete", "14",
                           env_extra={"GHT_TEST_FAIL_PR_REVIEWS": "1"})
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("unreadable", result.stdout)
        # A changed Contract blocks reconciliation.
        self._merge_pr(63)
        self._update_issue(14, body=issue_body(IMPL_CONTRACT.replace(
            "intent: >\n  A small runnable baseline.", "intent: >\n  A changed baseline.")))
        result = self._ght("complete", "14")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("Contract changed", result.stdout)

    def test_complete_refuses_ambiguous_lease_residue(self):
        # AC18: only an identity-proven lease of THIS attempt is cleaned; a
        # residue that does not back-prove the lineage blocks completion.
        claim, sha = self._delivered_parked(number=10, pr=64)
        residue = {"v": 3, "kind": "execution-lease", "claim_id": claim["claim_id"],
                   "issue": 999, "executor_id": "ghost", "github_principal": "acct",
                   "branch": claim["branch"], "contract_digest": "a" * 64,
                   "fencing_token": "ghost-token", "acquired_at": "2026-09-19T00:00:00Z",
                   "renewed_at": "2026-09-19T00:00:00Z",
                   "lease_expires_at": "2026-09-19T00:45:00Z"}
        self._raw_lease_ref(claim["claim_id"], residue, "ght: ghost residue")
        self._merge_pr(64)
        result = self._ght("complete", "10")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("does not back-prove", result.stdout)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "active",
                         "ambiguous residue must not terminalize the attempt")

    def test_parked_attempts_do_not_serialize_executor_capacity(self):
        # AC9: one LIVE lease per direct executor; parked delivered attempts
        # hold none and never block new attempts.
        self._delivered_parked(number=10, pr=65)
        self._update_issue(14, labels=["ready"])
        result, payload = self._ght_json("claim", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # A second LIVE attempt on an independent Issue runs concurrently
        # under the same coordination identity (#89).
        self._update_issue(15, labels=["ready"])
        result, third = self._ght_json("claim", "15")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # Resuming the parked attempt while other live leases are held
        # also proceeds: corrections never serialize against independent
        # authorized work (#89 AC5).
        result = self._ght("acquire", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_takeover_replaces_stale_lease_with_fresh_identity(self):
        # AC3/AC6/AC15: cross-executor recovery replaces the execution
        # holder and fencing identity on the SAME lease ref (keyed by the
        # unchanged claim_id); the durable attempt identity and branch are
        # preserved, and the stale holder is fenced out.
        self._claim(10, env_extra={"GHT_LEASE_MINUTES": "0",
                                   "GHT_STATE_DIR": "state-A"})
        stale = self._ght_json("inspect", "10")[1]
        deadline = time.time() + 5
        while stale["claim_state"] != "STALE" and time.time() < deadline:
            time.sleep(0.2)
            stale = self._ght_json("inspect", "10")[1]
        old_claim_id = stale["claim"]["claim_id"]
        import hashlib
        old_token = json.loads((self.repo / "state-A" / "executors" /
                                hashlib.sha256(b"worker-1").hexdigest()[:32] /
                                "claim-10.json").read_text())["_lease"]["token"]
        result, payload = self._ght_json(
            "takeover", "10", "--evidence", "worker crashed mid-attempt",
            env_extra={"GHT_TAKEOVER_GRACE_MINUTES": "0", "GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["claim_id"], old_claim_id)
        self.assertEqual(payload["branch"], stale["claim"]["branch"])
        self.assertNotEqual(payload["execution_lease"]["fencing_token"], old_token)
        self.assertIsNotNone(self._lease_remote_sha(old_claim_id))
        # The stale predecessor (old cache, old identity) is fenced out of
        # every live-ownership mutation; the new holder proceeds.
        result = self._ght("verify", "10", env_extra={"GHT_EXECUTOR_ID": "worker-1",
                                                      "GHT_STATE_DIR": "state-A"})
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        # The stale holder is fenced out at the durable-attempt identity
        # layer (the record's executor changed) — fail closed either way.
        result = self._ght("verify", "10", env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_deliver_retry_reconciles_cleanup_without_acquire(self):
        # AC4: after the exact delivery is durable (lease already released),
        # a crashed session's retry reconciles the remaining capacity
        # cleanup from remote truth — without fencing, without minting a new
        # execution lease, and without re-delivering the Candidate.
        claim, sha = self._delivered_parked(number=10, pr=68)
        # Crash window: the reservation release never landed.
        import hashlib
        key = hashlib.sha256(b"worker-1").hexdigest()[:32]
        residue = {"v": 3, "kind": "executor-reservation", "claim_id": claim["claim_id"],
                   "executor_id": "worker-1", "github_principal": "acct", "issue": 10,
                   "claimed_at": "2026-09-19T00:00:00Z",
                   "lease_expires_at": "2026-09-19T00:45:00Z"}
        self._raw_ref(f"refs/ght/claims-by-executor/{key}", residue, "ght: crash residue")
        result, payload = self._ght_json("deliver", "10", "--pr", "68")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIsNone(self._lease_remote_sha(claim["claim_id"]),
                          "the retry must not mint a new execution lease")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "",
            "the residue reservation is reconciled from remote truth")
        self.assertEqual(payload["candidate_sha"], sha)

    def test_complete_rejects_undelivered_corrected_candidate(self):
        # AC10/AC11: the durable delivery must bind the exact Candidate
        # being completed — a re-preserved correction that was never
        # re-delivered cannot ride an older delivery record to completion.
        claim = self._claim(14)
        self._checkout_claim_branch(claim)
        first_sha = self._commit_on_branch("skills/feature.txt", "v1\n")
        result, _payload = self._ght_json("preserve", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(69, claim["branch"], first_sha)
        result, _payload = self._ght_json("deliver", "14", "--pr", "69")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._ght_json("acquire", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        corrected_sha = self._commit_on_branch("skills/feature.txt", "v1 fixed\n")
        result, _payload = self._ght_json("preserve", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(69, claim["branch"], corrected_sha)
        self._merge_pr(69)
        result = self._ght("complete", "14")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("never durably delivered", result.stdout)
        inspected = self._ght_json("inspect", "14")[1]["claim"]
        self.assertEqual(inspected["status"], "active")
        # The corrected Candidate becomes completion-eligible only through
        # its own durable delivery.
        result, _payload = self._ght_json("deliver", "14", "--pr", "69")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("complete", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["candidate_sha"], corrected_sha)

    def test_complete_cleans_original_executor_reservation_residue(self):
        # AC10/AC11/AC18: completion inspects the reservation slot derived
        # from the ATTEMPT's executor identity, cleans exact residue, and
        # fails closed on conflicting residue while capacity is present.
        claim, sha = self._delivered_parked(number=10, pr=70, executor="legacy-worker")
        import hashlib
        key = hashlib.sha256(b"legacy-worker").hexdigest()[:32]
        residue = {"v": 3, "kind": "executor-reservation", "claim_id": claim["claim_id"],
                   "executor_id": "legacy-worker", "github_principal": "acct", "issue": 10,
                   "claimed_at": "2026-09-19T00:00:00Z",
                   "lease_expires_at": "2026-09-19T00:45:00Z"}
        self._raw_ref(f"refs/ght/claims-by-executor/{key}", residue, "ght: crash residue")
        self._merge_pr(70)
        result, payload = self._ght_json("complete", "10", env_extra={
            "GHT_EXECUTOR_ID": "reconciler-9", "GHT_STATE_DIR": "reconciler-state"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["status"], "delivered")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      f"refs/ght/claims-by-executor/{key}").stdout.strip(), "",
            "the ORIGINAL executor's residue slot is cleaned, not the caller's")

    def test_release_is_fenced_for_live_execution(self):
        # AC3/AC13: terminalizing a live attempt requires the current
        # execution lease identity; a stale holder superseded by a reacquire
        # cannot BLOCK shared state.
        self._claim(10, env_extra={"GHT_LEASE_MINUTES": "0", "GHT_STATE_DIR": "state-A"})
        stale = self._ght_json("inspect", "10")[1]
        deadline = time.time() + 5
        while stale["claim_state"] != "STALE" and time.time() < deadline:
            time.sleep(0.2)
            stale = self._ght_json("inspect", "10")[1]
        result, _payload = self._ght_json(
            "acquire", "10", env_extra={"GHT_STATE_DIR": "state-B",
                                        "GHT_TAKEOVER_GRACE_MINUTES": "0"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result = self._ght("release", "10", "--status", "blocked",
                           "--note", "A: replan", env_extra={"GHT_STATE_DIR": "state-A"})
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("different fencing identity", result.stdout)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "active",
                         "a fenced-out holder must not terminalize the attempt")
        result, _payload = self._ght_json("release", "10", "--status", "blocked",
                                          "--note", "A: replan",
                                          env_extra={"GHT_STATE_DIR": "state-B"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_release_fenced_in_delivery_live_lease_crash_window(self):
        # AC3/AC5/AC13: delivery-present + live execution lease is NOT
        # parked — release must prove the current fencing identity. A stale
        # holder cannot BLOCK the attempt in the cleanup crash window; the
        # session holding the superseding identity may, and the no-live-
        # lease parked path stays durable-identity based.
        claim, sha = self._delivered_parked(number=10, pr=74)
        digest = self._ght_json("inspect", "10")[1]["claim"]["contract_digest"]
        crash_lease = {"v": 3, "kind": "execution-lease", "claim_id": claim["claim_id"],
                       "issue": 10, "executor_id": "worker-1", "github_principal": "acct",
                       "branch": claim["branch"], "contract_digest": digest,
                       "fencing_token": "crash-window-token",
                       "acquired_at": "2026-09-19T00:00:00Z",
                       "renewed_at": "2026-09-19T00:00:00Z",
                       "lease_expires_at": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                                         time.gmtime(time.time() + 3600))}
        self._raw_lease_ref(claim["claim_id"], crash_lease, "ght: crash-window lease")
        # The stale holder's cache still carries the pre-release token:
        # fenced out even though a durable delivery exists.
        result = self._ght("release", "10", "--status", "blocked",
                           "--note", "A: replan")
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("different fencing identity", result.stdout)
        inspected = self._ght_json("inspect", "10")[1]["claim"]
        self.assertEqual(inspected["status"], "active",
                         "a stale holder must not BLOCK the crash-window attempt")
        # The session holding the superseding fencing identity may stop it.
        import hashlib
        key = hashlib.sha256(b"worker-1").hexdigest()[:32]
        state_b = str(self.tmp / "state-B")
        current_dir = Path(state_b) / "executors" / key
        current_dir.mkdir(parents=True, exist_ok=True)
        cache = json.loads((self.repo / ".ght" / "executors" / key /
                            "claim-10.json").read_text())
        cache["_lease"]["token"] = "crash-window-token"
        (current_dir / "claim-10.json").write_text(json.dumps(cache, indent=2))
        result, _payload = self._ght_json("release", "10", "--status", "blocked",
                                          "--note", "A: replan",
                                          env_extra={"GHT_STATE_DIR": state_b})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self._ght_json("inspect", "10")[1]["claim"]["status"], "blocked")
        # The no-live-lease parked path (exact capacity cleanup done) stops
        # on durable-attempt identity alone.
        claim15, _sha15 = self._delivered_parked(number=15, pr=75)
        result, _payload = self._ght_json("release", "15", "--status", "blocked",
                                          "--note", "A: replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_delivery_with_live_lease_is_not_parked(self):
        # AC5/AC9/AC16: parked requires NO live execution lease. A crash
        # window with delivery durable but capacity residue present is not
        # parked and still serializes the executor's capacity.
        claim, sha = self._delivered_parked(number=10, pr=71)
        live_residue = {"v": 3, "kind": "execution-lease", "claim_id": claim["claim_id"],
                        "issue": 10, "executor_id": "worker-1", "github_principal": "acct",
                        "branch": claim["branch"],
                        "contract_digest": self._ght_json("inspect", "10")[1]["claim"]["contract_digest"],
                        "fencing_token": "crash-window-token",
                        "acquired_at": "2026-09-19T00:00:00Z",
                        "renewed_at": "2026-09-19T00:00:00Z",
                        "lease_expires_at": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                                          time.gmtime(time.time() + 3600))}
        self._raw_lease_ref(claim["claim_id"], live_residue, "ght: crash-window lease")
        self._update_issue(14, labels=["ready"])
        result = self._ght("validate-ready", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # #89: a live residue lease on one attempt never blocks another
        # independent authorized start; the marker is audit state only.
        result, payload = self._ght_json("claim", "14")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # The parked attempt with the residue lease stays unclaimable.
        result = self._ght("validate-ready", "10")
        self.assertNotEqual(result.returncode, 0)
        # Once the residue lease is gone, the attempt is parked again.
        self._git(self.repo, "push", "origin",
                  f":refs/ght/execution-leases/{claim['claim_id']}")

    def test_supervisor_stops_cleanly_when_capacity_released(self):
        # AC2/AC4: after delivery releases the lease, the supervisor ends
        # without noise — the parked attempt needs no live capacity.
        claim = self._claim(10, env_extra={"GHT_SPAWN_SUPERVISOR": "1",
                                           "GHT_SUPERVISE_INTERVAL_SECONDS": "1"})
        self._checkout_claim_branch(claim)
        sha = self._commit_on_branch("skills/demo.txt", "demo\n")
        result, _payload = self._ght_json("preserve", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self._open_pr(66, claim["branch"], sha)
        result, _payload = self._ght_json("deliver", "10", "--pr", "66")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        deadline = time.time() + 8
        status = None
        while time.time() < deadline:
            status = self._read_supervise_status(10)
            if status and status["state"] == "stopped":
                break
            time.sleep(0.2)
        self.assertIsNotNone(status)
        self.assertEqual(status["state"], "stopped")
        self.assertIn("released", status.get("reason", ""))

    def test_execute_after_review_needs_no_fresh_ready(self):
        # AC6/AC8: the direct/JIT workflow survives the lease introduction —
        # a delivered Candidate is resumable on the same attempt/branch/PR
        # with no ready label and no new Plan authorization, and the resume
        # keeps the durable lineage append-free.
        claim, sha = self._delivered_parked(number=15, pr=67)
        ready_before = self._issue(15)["labels"]
        self.assertNotIn("ready", ready_before)
        result, acquired = self._ght_json("acquire", "15")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(acquired["claim_id"], claim["claim_id"])
        inspected = self._ght_json("inspect", "15")[1]
        self.assertEqual(inspected["claim"]["branch"], claim["branch"])
        self.assertEqual(inspected["claim_state"], "ACTIVE")
        self.assertEqual(self._issue(15)["labels"], [],
                         "resume never touches the one-shot authorization surface")

    # -- B orchestrator runtime (#43) --------------------------------------

    def _orchestration_plan(self, nodes, plan_id="wave-1", **overrides):
        from github_task.core import contract_digest, parse_contract
        digest = contract_digest(parse_contract(issue_body(IMPL_CONTRACT)))
        fixed = []
        for node in nodes:
            fixed.append({"issue": node["issue"], "contract_digest": digest,
                          "authorization_id": node.get("authorization_id",
                                                       f"wave-1-{node['issue']}-a"),
                          "priority": node.get("priority", 1),
                          **({"after": node["after"]} if "after" in node else {})})
        doc = {"version": 1, "plan_id": plan_id, "nodes": fixed}
        doc.update(overrides)
        return doc

    def _orchestrate(self, extra_env=None, max_parallel=None):
        env = {"GHT_ORCHESTRATOR_RUN_DIR": str(self.tmp / "orchestrator-runs"),
               "GHT_ORCHESTRATOR_TASK_COMMAND": (
                   "mkdir -p skills && printf 'orchestrated\\n' >> "
                   "skills/orchestrated.txt && git add skills && "
                   "git -c user.email=d@ght -c user.name=drv commit -qm orchestrated")}
        if max_parallel is not None:
            env["GHT_ORCHESTRATOR_MAX_PARALLEL"] = str(max_parallel)
        return self._ght_json("orchestrate", "--execute",
                              env_extra={**env, **(extra_env or {})})


    def test_handoff_keeps_independent_nodes_runnable_under_live_lease(self):
        # #89 review AC2/AC3: one Issue of the stable coordination identity
        # holding a live execution lease must NOT gate an independent
        # authorized Plan node — the handoff workset keeps it runnable
        # (cross-Issue capacity is B/host HOW); the same-Issue duplicate
        # start stays fenced.
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        result, _payload = self._publish_plan(self._orchestration_plan(
            [{"issue": 15, "authorization_id": "wave-1-15-a", "priority": 2},
             {"issue": 14, "authorization_id": "wave-1-14-b", "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # Issue 15 is claimed by this coordination identity (live lease).
        result, claimed = self._ght_json(
            "claim", "15", "--plan-authorization", "wave-1-15-a")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        by_issue = {w["issue"]: w for w in payload["work"]}
        self.assertFalse(by_issue[15]["runnable"],
                         "same-Issue duplicate start stays fenced")
        self.assertTrue(by_issue[14]["runnable"],
                        "the independent authorized node stays runnable while "
                        "the identity holds a live lease on #15")

    def test_discover_plan_handoff_bundle_is_read_only(self):
        # #75 AC2/AC3: with a current Plan, discovery hands the mechanically
        # eligible work (issue, authorization, exact plan revision, contract
        # digest) to the already-online primary B as an ephemeral bundle —
        # no claim, no candidate, no driver launch; authorization consumption
        # stays at canonical claim time.
        self._update_issue(15, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        self.assertEqual(payload["plan_id"], "wave-1")
        self.assertTrue(payload["plan_revision"])
        work = payload["work"]
        # #89 AC3/AC10: the bundle is the COMPLETE authorized workset — the
        # Plan node first (admission priority), every direct-ready Issue
        # visible as its own entry (discovery consumes nothing).
        self.assertEqual([w["issue"] for w in work][0], 15)
        self.assertTrue(work[0]["runnable"], work)
        self.assertTrue(work[0]["authorization_id"], work)
        self.assertTrue(work[0]["contract_digest"], work)
        self.assertEqual(work[0].get("source"), "plan")
        for w in work[1:]:
            self.assertEqual(w.get("source"), "direct-ready", w)
        # Read-only: no durable attempt was created for the handed-off node.
        _result, inspected = self._ght_json("inspect", "15")
        self.assertIn(inspected.get("claim"), (None, "none"),
                      "handoff must not create a claim lineage")

    def test_bare_orchestrate_is_handoff_never_launch(self):
        # #75 AC4/AC9: bare `ght orchestrate` (no explicit --execute fixture)
        # evaluates and hands off — it must NOT launch the reference driver,
        # must not create a synthetic Candidate, and must not consume the
        # authorization.
        self._update_issue(15, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        env = {"GHT_ORCHESTRATOR_RUN_DIR": str(self.tmp / "orchestrator-runs"),
               "GHT_ORCHESTRATOR_TASK_COMMAND": (
                   "mkdir -p skills && printf 'orchestrated\\n' >> "
                   "skills/orchestrated.txt && git add skills && "
                   "git -c user.email=d@ght -c user.name=drv commit -qm orchestrated")}
        result, payload = self._ght_json("orchestrate", env_extra=env)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["action"], "handoff")
        self.assertTrue(any(w["issue"] == 15 and w["runnable"]
                            for w in payload["work"]))
        _result, inspected = self._ght_json("inspect", "15")
        self.assertIn(inspected.get("claim"), (None, "none"),
                      "bare orchestrate must not start the node")

    def test_reference_driver_is_explicit_fixture_only(self):
        # #75 AC4: `--execute --driver reference` remains available as the
        # explicit test/dev fixture — it still runs the legacy launch
        # pipeline (synthetic task command), proving the fixture surface
        # was not removed, only taken off the production path.
        self._update_issue(15, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(15, payload["started"],
                      "the explicit fixture still launches the trace")

    def test_orchestrator_dual_acquire_race_stands_down(self):
        # AC1/AC2: one active orchestrator per Plan — a second acquire while
        # a live lease is held stands down; after release, acquisition works.
        self._update_issue(15, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        plan_id = payload["plan_id"]
        self.assertEqual(payload["orchestrator"]["ref"],
                         "refs/ght/orchestrators/"
                         + hashlib.sha256(plan_id.encode()).hexdigest()[:32])
        # The invocation released the slot at its safe exit; verify by
        # direct dual-acquire on the ref the first cycle would have held.
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      payload["orchestrator"]["ref"]).stdout.strip(), "")
        # Hold the slot from "another invocation" (raw ref), then orchestrate
        # again: it must stand down instead of forming a second pool.
        held = {"v": 3, "kind": "orchestrator-lease", "plan_id": plan_id,
                "plan_revision": "0" * 40, "orchestrator_id": "worker-2",
                "github_principal": "acct", "fencing_token": "live-token",
                "acquired_at": "2026-09-19T00:00:00Z", "renewed_at": "2026-09-19T00:00:00Z",
                "lease_expires_at": time.strftime(
                    "%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() + 3600))}
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(held, indent=1)).stdout.strip()
        tree = self._git(self.repo, "mktree",
                         input_text=f"100644 blob {blob}\tORCHESTRATOR.json\n").stdout.strip()
        commit = self._git(self.repo, "commit-tree", tree, "-m", "ght: held slot",
                           env=self._env).stdout.strip()
        self._git(self.repo, "push", "origin",
                  f"{commit}:refs/ght/orchestrators/"
                  + hashlib.sha256(plan_id.encode()).hexdigest()[:32])
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)
        self.assertIn("stands down", result.stdout)

    def test_orchestrator_stale_holder_cannot_release_or_renew(self):
        # AC2: an orchestrator whose fencing identity was replaced by a
        # takeover can neither renew nor release the Plan slot; only the
        # current holder can.
        import hashlib
        plan_id = "wave-1"
        self._update_issue(15, labels=[])
        result, _payload = self._publish_plan(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        expired = time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                time.gmtime(time.time() - 7200))
        residue = {"v": 3, "kind": "orchestrator-lease", "plan_id": plan_id,
                   "plan_revision": "0" * 40, "orchestrator_id": "worker-1",
                   "github_principal": "acct", "fencing_token": "stale-token",
                   "acquired_at": expired, "renewed_at": expired,
                   "lease_expires_at": expired}
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(residue, indent=1)).stdout.strip()
        tree = self._git(self.repo, "mktree",
                         input_text=f"100644 blob {blob}\tORCHESTRATOR.json\n").stdout.strip()
        commit = self._git(self.repo, "commit-tree", tree, "-m", "ght: stale slot",
                           env=self._env).stdout.strip()
        ref = ("refs/ght/orchestrators/"
               + hashlib.sha256(plan_id.encode()).hexdigest()[:32])
        self._git(self.repo, "push", "origin", f"{commit}:{ref}")

        from github_task.cli import CommandFailure, Context
        from github_task.orchestrator import acquire_orchestrator, renew_orchestrator, \
            release_orchestrator
        saved_env = {key: os.environ.get(key) for key in
                     ("GHT_TEST_STATE", "GHT_TEST_REAL_GIT", "GHT_EXECUTOR_ID")}
        previous_cwd = os.getcwd()
        os.environ.update(self._env)
        os.chdir(self.repo)
        try:
            ctx = Context("origin")
            takeover = acquire_orchestrator(ctx, plan_id, "0" * 40)
            self.assertNotEqual(takeover["fencing_token"], "stale-token")
            for operation in (renew_orchestrator, release_orchestrator):
                with self.assertRaises(CommandFailure) as caught:
                    operation(ctx, plan_id, {"fencing_token": "stale-token"})
                self.assertIn("fencing LOST", str(caught.exception))
            renewed = renew_orchestrator(ctx, plan_id, takeover)
            self.assertEqual(renewed["fencing_token"], takeover["fencing_token"])
            self.assertTrue(release_orchestrator(ctx, plan_id, renewed))
        finally:
            os.chdir(previous_cwd)
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def test_orchestrator_deterministic_order_and_delivery(self):
        # AC4/AC5/AC9/AC16: the runnable set is evaluated from durable truth
        # and started priority DESC / issue ASC; each admitted trace runs a
        # REAL driver execution (ephemeral worktree, actual engineering
        # commit), is preserved and delivered, and its execution capacity is
        # released with the attempt left non-terminal (parked).
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        doc = self._orchestration_plan([
            {"issue": 15, "priority": 1}, {"issue": 14, "priority": 10}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        started = payload["started"]
        self.assertEqual(sorted(started), [14, 15])
        self.assertEqual(started, [14, 15],
                         "priority DESC: issue 14 (priority 10) starts first")
        for entry in payload["delivered"]:
            self.assertTrue(entry["pr"])
            candidate = entry["candidate_sha"]
            self.assertTrue(candidate)
            inspected = self._ght_json("inspect", str(entry["issue"]))[1]["claim"]
            self.assertEqual(inspected["status"], "active",
                             "delivered orchestrated attempts stay non-terminal")
            self.assertEqual(inspected["delivery"]["sha"], candidate)
            self.assertIsNone(self._lease_remote_sha(inspected["claim_id"]),
                              "orchestrated delivery releases the trace lease")
        # The driver actually launched an engineering execution: the
        # delivered Candidate commits the orchestrated file.
        for entry in payload["delivered"]:
            comments = self._issue(entry["issue"])["comments"]
            self.assertTrue(any("Candidate ready for review" in c["body"]
                                for c in comments))

    def test_retired_envelope_never_gates_operator_ceiling(self):
        # #89 AC1/AC6: a legacy max_concurrency field (even the old 0 pause)
        # in a revision that already exists in the wild is ignored — the
        # operator --max-parallel is the only fixture ceiling, and
        # deterministic order holds.
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        doc = self._orchestration_plan([
            {"issue": 15, "priority": 10}, {"issue": 14, "priority": 5}],
            max_concurrency=0)
        self._force_publish_plan(doc)
        result, payload = self._orchestrate(max_parallel=1)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertFalse(payload["paused"])
        self.assertEqual(payload["started"], [15, 14],
                         "the retired field gates nothing; the operator "
                         "ceiling (1) serializes deterministically")

    def test_orchestrator_admission_failure_defers_and_recovers(self):
        # AC15/AC17: semantic runnable but operationally inadmissible work is
        # deferred (ephemeral runtime fact, no durable state); independent
        # admitted nodes continue; a later invocation admits the deferred
        # node once the runtime condition clears.
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        doc = self._orchestration_plan([
            {"issue": 15, "priority": 10}, {"issue": 14, "priority": 5}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate(
            extra_env={"GHT_TEST_DRIVER_ADMIT_FAIL_ISSUES": "15"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["started"], [14],
                         "the inadmissible node defers; the independent node continues")
        deferred = [item for item in payload["deferred"] if item["issue"] == 15]
        self.assertTrue(deferred and "admission" in deferred[0]["reason"])
        inspected = self._ght_json("inspect", "15")[1]["claim_state"]
        self.assertEqual(inspected, "NONE",
                         "deferral creates no durable claim or lifecycle state")
        # Capacity/runtime recovered: the next invocation admits it.
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["started"], [15])

    def test_orchestrator_descendant_blocked_independent_branch_continues(self):
        # AC10: an unsatisfied upstream barrier blocks only its descendants;
        # independent branches continue in the same invocation.
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        self._update_issue(10, labels=[])
        doc = self._orchestration_plan([
            {"issue": 15, "priority": 10,
             "after": [{"gate": "merged", "issue": 99}]},
            {"issue": 14, "priority": 5},
            {"issue": 10, "priority": 3, "after": [{"gate": "issue_done", "issue": 15}]}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        runnable_issues = {item["issue"] for item in payload["runnable"] if item["runnable"]}
        self.assertEqual(runnable_issues, {14},
                         "15 blocked by an unsatisfied barrier; its descendant 10 too")
        self.assertEqual(payload["started"], [14])
        # The blocked descendants stay not-runnable in later cycles.
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        runnable_issues = {item["issue"] for item in payload["runnable"] if item["runnable"]}
        self.assertEqual(runnable_issues, set())

    def test_orchestrator_restarts_reconstruct_from_durable_truth(self):
        # AC3/AC11: an invocation that stops with work remaining is followed
        # by a fresh invocation that reconstructs everything from GitHub
        # durable truth and continues safely — no private scheduler state.
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        doc = self._orchestration_plan([
            {"issue": 15, "priority": 10}, {"issue": 14, "priority": 5}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, first = self._orchestrate(
            extra_env={"GHT_TEST_DRIVER_ADMIT_FAIL": "1"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(first["started"], [])
        result, second = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(sorted(second["started"]), [14, 15])

    def test_orchestrator_skips_direct_ready_and_consumed_nodes(self):
        # AC13/AC4/AC8(direct compatibility): nodes whose authorization was
        # consumed, whose Contract changed, or whose Issue carries the
        # direct `ready` surface are not runnable; the orchestrator never
        # touches the ready surface.
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        doc = self._orchestration_plan([
            {"issue": 15, "authorization_id": "wave-1-15-a", "priority": 10},
            {"issue": 14, "authorization_id": "wave-1-14-a", "priority": 5}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # Start 15 interactively (consumes wave-1-15-a and holds a live
        # execution attempt), then orchestrate: 15 is not runnable anymore
        # (one authorization starts at most one attempt) while the
        # independent 14 stays runnable and starts under its derived trace
        # identity — one coordination identity holds 0..N ACTIVE
        # executions (#89).
        result, _payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        by_issue = {item["issue"]: item for item in payload["runnable"]}
        self.assertFalse(by_issue[15]["runnable"])
        self.assertTrue(by_issue[14]["runnable"],
                        f"independent node stays runnable: {by_issue[14]['reason']}")
        self.assertEqual(payload["started"], [14])
        # A's explicit stop terminalizes 15; the next cycle has no runnable
        # work — 15's authorization is consumed and 14's is consumed by its
        # own started attempt.
        result, _payload = self._ght_json("release", "15", "--status", "blocked",
                                          "--note", "A: replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        by_issue = {item["issue"]: item for item in payload["runnable"]}
        self.assertFalse(by_issue[15]["runnable"])
        self.assertFalse(by_issue[14]["runnable"],
                         "14's authorization was consumed by its own started "
                         "attempt in the previous cycle")
        self.assertEqual(payload["started"], [])
        # A direct `ready` label plus a fresh Plan node stays unstarted, and
        # the orchestrator never consumes or removes the label.
        self._update_issue(14, labels=["ready"])
        current = self._git(self.repo, "ls-remote", "origin", self.PLAN_REF
                            ).stdout.split()[0]
        doc = self._orchestration_plan([
            {"issue": 15, "authorization_id": "wave-1-15-a", "priority": 10},
            {"issue": 14, "authorization_id": "wave-1-14-b", "priority": 5}])
        result, _payload = self._publish_plan(doc, replace=current)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        by_issue = {item["issue"]: item for item in payload["runnable"]}
        self.assertFalse(by_issue[14]["runnable"])
        self.assertEqual(payload["started"], [])
        self.assertEqual(self._issue(14)["labels"], ["ready"],
                         "the orchestrator never touches the ready surface")

    def test_orchestrator_preserves_durable_identity_after_review_resume(self):
        # AC9: after the orchestrator parks a delivered Candidate, ordinary
        # REQUEST_CHANGES resumes the SAME attempt via ght acquire (no fresh
        # authorization), and the orchestrator's next cycle does not
        # re-start it (authorization consumed).
        self._update_issue(15, labels=[])
        doc = self._orchestration_plan([{"issue": 15, "priority": 1}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(len(payload["delivered"]), 1)
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        claim_id = inspected["claim_id"]
        result, acquired = self._ght_json("acquire", "15")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(acquired["claim_id"], claim_id)
        result, payload = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["started"], [])
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        self.assertEqual(inspected["claim_id"], claim_id,
                         "resume keeps the durable attempt identity")

    def test_takeover_during_trace_fences_stale_orchestrator(self):
        # AC2/AC12: the trace is bound to the launching orchestrator's
        # fencing identity. When the Plan slot is replaced mid-trace, the
        # stale orchestrator's fenced mutations fail, the running Driver is
        # STOPPED (not awaited), nothing is preserved/delivered, and the
        # replacement slot is left untouched.
        self._update_issue(15, labels=[])
        doc = self._orchestration_plan([{"issue": 15, "priority": 1}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        long_task = ("sleep 30 && mkdir -p skills && printf x > "
                     "skills/orchestrated.txt && git add skills && "
                     "git -c user.email=d@ght -c user.name=drv commit -qm late")
        env = {**self._env,
               "GHT_ORCHESTRATOR_RUN_DIR": str(self.tmp / "orchestrator-runs"),
               "GHT_ORCHESTRATOR_TASK_COMMAND": long_task}
        process = subprocess.Popen(
            [sys.executable, str(CLI), "--json", "orchestrate", "--execute"],
            cwd=str(self.repo),
            env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            deadline = time.time() + 30
            claimed = None
            while time.time() < deadline:
                claimed = self._git(self.repo, "ls-remote", "origin",
                                    CLAIM_REF + "15").stdout.strip()
                if claimed:
                    break
                time.sleep(0.2)
            self.assertTrue(claimed, "the orchestrated trace never claimed")
            # Canonical takeover state: the Plan slot is replaced (new
            # fencing identity, live expiry) while the trace runs.
            import hashlib
            plan_id = "wave-1"
            replacement = {"v": 3, "kind": "orchestrator-lease", "plan_id": plan_id,
                           "plan_revision": "0" * 40, "orchestrator_id": "worker-2",
                           "github_principal": "acct", "fencing_token": "replacement-token",
                           "acquired_at": "2026-09-19T00:00:00Z",
                           "renewed_at": "2026-09-19T00:00:00Z",
                           "lease_expires_at": time.strftime(
                               "%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() + 3600))}
            blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                             input_text=json.dumps(replacement, indent=1)).stdout.strip()
            tree = self._git(self.repo, "mktree",
                             input_text=f"100644 blob {blob}\tORCHESTRATOR.json\n"
                             ).stdout.strip()
            commit = self._git(self.repo, "commit-tree", tree, "-m", "ght: takeover slot",
                               env=self._env).stdout.strip()
            ref = ("refs/ght/orchestrators/"
                   + hashlib.sha256(plan_id.encode()).hexdigest()[:32])
            moved = self._git(self.repo, "push", "--force", "origin", f"{commit}:{ref}")
            self.assertEqual(moved.returncode, 0, moved.stderr)
            stdout, stderr = process.communicate(timeout=60)
            self.assertEqual(process.returncode, 0, stdout + stderr)
            payload = json.loads(stdout)
            self.assertEqual(payload["started"], [15])
            failed = [item for item in payload["failed"] if item["issue"] == 15]
            self.assertTrue(failed and failed[0].get("error"))
            self.assertIn("fencing", failed[0]["error"].lower())
            self.assertEqual([item for item in payload["delivered"] if item["issue"] == 15],
                             [], "a fenced-out trace must not deliver")
            inspected = self._ght_json("inspect", "15")[1]["claim"]
            self.assertIsNone(inspected.get("candidate"),
                              "a fenced-out trace must not preserve")
            self.assertEqual(inspected["status"], "active",
                             "fencing loss never invents an A terminal decision")
            # AC2: the stale invocation's fencing loss is positively
            # classified — it must NOT release (or otherwise mutate) the
            # trace's execution capacity. The lease stays for the current
            # holder / natural expiry to reconcile.
            self.assertIsNotNone(
                self._lease_remote_sha(inspected["claim_id"]),
                "a stale invocation must not release the trace's capacity")
            # ... and it must not emit the shared failure-evidence comment
            # either — that mutation belongs to a genuinely failed trace.
            self.assertNotIn("ORCHESTRATED TRACE FAILED",
                             json.dumps(self._issue(15).get("comments", [])))
            self.assertNotIn("ORCHESTRATED TRACE FAILED",
                             json.dumps(self._issue(15).get("pr_comments", [])))
            # The replacement slot survives: the stale orchestrator did not
            # release what it no longer holds.
            self.assertEqual(
                self._git(self.repo, "ls-remote", "origin", ref).stdout.split()[0],
                self._git(self.repo, "rev-parse", commit).stdout.strip())
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()

    def test_orchestrator_drives_request_changes_resume_end_to_end(self):
        # AC9/AC12: the orchestrator itself reconstructs the correction
        # resume from durable truth — same attempt/branch/PR, fresh
        # execution lease identity, re-delivery at a new exact Candidate —
        # with no fresh authorization/ready and no manual ght acquire.
        self._update_issue(15, labels=[])
        doc = self._orchestration_plan([{"issue": 15, "priority": 1}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, first = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(len(first["delivered"]), 1)
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        claim_id = inspected["claim_id"]
        old_candidate = inspected["delivery"]["sha"]
        pr_number = inspected["delivery"]["pr"]
        # A's durable REQUEST_CHANGES outcome lands on the PR (canonical
        # structured comment bound to the reviewed exact Candidate).
        data = json.loads(self.state.read_text())
        data[str(pr_number)].setdefault("pr_comments", []).append({
            "body": "A REVIEW — REQUEST_CHANGES\n\nReviewed exact Candidate:\n"
                    f"`{old_candidate}`\n\nblocking findings\n\n"
                    "Re-review required after corrections."})
        self.state.write_text(json.dumps(data, indent=2))
        # The next orchestration cycle drives the correction itself.
        result, second = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(second["started"], [15])
        resumed = [item for item in second["delivered"] if item["issue"] == 15]
        self.assertEqual(len(resumed), 1)
        self.assertEqual(resumed[0]["pr"], pr_number,
                         "the correction re-delivers the SAME PR")
        self.assertNotEqual(resumed[0]["candidate_sha"], old_candidate,
                            "the correction produced a new exact Candidate")
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        self.assertEqual(inspected["claim_id"], claim_id,
                         "resume keeps the durable attempt identity")
        self.assertEqual(inspected["delivery"]["sha"], resumed[0]["candidate_sha"])
        self.assertEqual(inspected["authorization"]["authorization_id"],
                         "wave-1-15-a",
                         "resume consumes no fresh Plan authorization")
        self.assertEqual(self._issue(15)["labels"], [])

    def test_request_changes_resume_from_fresh_clone(self):
        # AC3/AC9/AC12: correction resume is restart/takeover-safe — a fresh
        # clone / fresh worker (no local attempt branch, no local claim
        # cache) reconstructs everything from GitHub durable truth: same
        # attempt / same PR / no fresh authorization, rehydrated at the
        # exact durable Candidate SHA fetched from the remote.
        self._update_issue(15, labels=[])
        doc = self._orchestration_plan([{"issue": 15, "priority": 1}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, first = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(len(first["delivered"]), 1)
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        claim_id = inspected["claim_id"]
        old_candidate = inspected["delivery"]["sha"]
        pr_number = inspected["delivery"]["pr"]
        data = json.loads(self.state.read_text())
        data[str(pr_number)].setdefault("pr_comments", []).append({
            "body": "A REVIEW — REQUEST_CHANGES\n\nReviewed exact Candidate:\n"
                    f"`{old_candidate}`\n\nblocking findings\n\n"
                    "Re-review required after corrections."})
        self.state.write_text(json.dumps(data, indent=2))
        # A brand-new worker: fresh clone (only origin/* refs, no local
        # attempt branch) and no shared local claim cache.
        fresh = self.tmp / "fresh-worker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(fresh))
        self.assertIsNone(
            self._git(fresh, "rev-parse", "--verify", "--quiet",
                      inspected["branch"]).stdout.strip() or None,
            "the fresh clone must not have the attempt branch locally")
        # And no usable remote-tracking ref either ("only the remote
        # object" worker state): the resume must explicitly fetch durable
        # truth instead of resolving a bare branch name (DWIM or local).
        self.assertEqual(self._git(fresh, "branch", "-d", "-r",
                                   f"origin/{inspected['branch']}").returncode, 0)
        env = {"GHT_ORCHESTRATOR_RUN_DIR": str(self.tmp / "fresh-runs"),
               "GHT_ORCHESTRATOR_TASK_COMMAND": (
                   "mkdir -p skills && printf 'corrected\\n' >> "
                   "skills/orchestrated.txt && git add skills && "
                   "git -c user.email=d@ght -c user.name=drv commit -qm corrected")}
        result, second = self._ght_json("orchestrate", "--execute",
                                        cwd=fresh, env_extra=env)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(second["started"], [15])
        resumed = [item for item in second["delivered"] if item["issue"] == 15]
        self.assertEqual(len(resumed), 1,
                         "the fresh worker drives the correction resume from durable truth")
        self.assertEqual(resumed[0]["pr"], pr_number, "same PR, no fresh authorization")
        new_candidate = resumed[0]["candidate_sha"]
        self.assertNotEqual(new_candidate, old_candidate)
        inspected = self._ght_json("inspect", "15", cwd=fresh)[1]["claim"]
        self.assertEqual(inspected["claim_id"], claim_id,
                         "resume keeps the durable attempt identity")
        # The correction was rehydrated at the durable Candidate SHA: the
        # rejected candidate is contained in the new candidate's history and
        # the leg-1 work content survived into the new tree.
        self.assertEqual(self._git(fresh, "merge-base", "--is-ancestor",
                                   old_candidate, new_candidate).returncode, 0,
                         "the correction builds on the fetched durable Candidate")
        self.assertIn("orchestrated", self._git(
            fresh, "show", f"{new_candidate}:skills/orchestrated.txt").stdout)
        self.assertIn("corrected", self._git(
            fresh, "show", f"{new_candidate}:skills/orchestrated.txt").stdout)

    def test_plan_nodes_execute_in_parallel_within_envelope(self):
        # AC5: two independent semantic-runnable nodes execute CONCURRENTLY
        # within the envelope (operator cap 2 × Plan cap 2), each under its
        # own derived executor identity; delivered Candidates release their
        # execution capacity; the downstream merged gate starts only once
        # the upstream PR is MERGED at the exact Candidate SHA with durable
        # A acceptance — and never depends on post-merge completion.
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        self._update_issue(10, labels=[])
        doc = self._orchestration_plan(
            [{"issue": 15, "priority": 5},
             {"issue": 14, "priority": 4},
             {"issue": 10, "priority": 1,
              "after": [{"gate": "merged", "issue": 14}]}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        flags = self.tmp / "parallel-flags"
        flags.mkdir()
        # Rendezvous: each trace commits only after the other's flag exists.
        # Under serial execution the wait times out and the trace fails, so
        # this test can only pass with genuinely concurrent traces.
        task = (
            "mkdir -p skills && printf orchestrated\\n >> skills/orchestrated.txt && "
            "git add skills && git -c user.email=d@ght -c user.name=drv commit -qm ok && "
            'if [ "$GHT_ORCHESTRATOR_ISSUE" = "15" ]; then '
            f"touch {flags}/15; i=0; while [ ! -f {flags}/14 ] && [ $i -lt 150 ]; do "
            'sleep 0.2; i=$((i+1)); done; fi; '
            'if [ "$GHT_ORCHESTRATOR_ISSUE" = "14" ]; then '
            f"touch {flags}/14; i=0; while [ ! -f {flags}/15 ] && [ $i -lt 150 ]; do "
            'sleep 0.2; i=$((i+1)); done; fi')
        result, payload = self._orchestrate(extra_env={
            "GHT_ORCHESTRATOR_TASK_COMMAND": task}, max_parallel=2)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["started"], [15, 14],
                         "both independent nodes start in the same round")
        self.assertEqual(sorted(item["issue"] for item in payload["delivered"]), [14, 15])
        self.assertTrue((flags / "15").exists() and (flags / "14").exists(),
                        "the rendezvous proves genuinely concurrent execution")
        # Per-trace derived executor identities; every delivered Candidate
        # released its temporary capacity.
        for issue in (15, 14):
            claim = self._ght_json("inspect", str(issue))[1]["claim"]
            self.assertTrue(claim["executor_id"].startswith("worker-1/orch-"),
                            f"trace ran under a derived identity: {claim['executor_id']}")
            self.assertIsNone(self._lease_remote_sha(claim["claim_id"]),
                              "delivered Candidates release execution capacity")
        # The downstream node stayed gated: no merged upstream yet.
        self.assertNotIn(10, payload["started"])
        gated = [item for item in payload["runnable"] if item["issue"] == 10]
        self.assertTrue(gated and not gated[-1]["runnable"],
                        "the merged gate blocks the descendant until A merges")
        # A merges the upstream Candidate with durable exact-SHA ACCEPT.
        # Completion has NOT run — the merged gate must not depend on it.
        delivered = [item for item in payload["delivered"] if item["issue"] == 14][0]
        data = json.loads(self.state.read_text())
        data[str(delivered["pr"])].setdefault("pr_comments", []).append({
            "body": "A REVIEW — ACCEPTED\n\nReviewed exact Candidate:\n"
                    f"`{delivered['candidate_sha']}`\n\naccepted"})
        data[str(delivered["pr"])]["state"] = "MERGED"
        self.state.write_text(json.dumps(data, indent=2))
        inspected = self._ght_json("inspect", "14")[1]["claim"]
        self.assertEqual(inspected["status"], "active",
                         "post-merge completion is a separate transition")
        result, second = self._orchestrate(max_parallel=2)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(second["started"], [10])
        self.assertEqual([item["issue"] for item in second["delivered"]], [10])

    def test_dual_authority_fail_closed(self):
        # AC4: direct READY and a live Plan authorization are XOR paths —
        # when both grants exist for the same new attempt, both claim
        # directions fail closed for A reconciliation instead of
        # auto-preferring either surface.
        doc = self._orchestration_plan([{"issue": 15, "priority": 1}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # Issue 15 keeps its direct `ready` label while the Plan
        # authorization is live and unconsumed.
        result = self._ght("claim", "15")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("dual authority", result.stdout)
        result = self._ght("claim", "15", "--plan-authorization", "wave-1-15-a")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("READY", result.stdout)
        # A reconciles by removing the direct grant; the Plan path works.
        self._update_issue(15, labels=[])
        result, payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["authorization"]["authorization_id"], "wave-1-15-a")

    def test_retired_envelope_field_is_ignored_not_reinterpreted(self):
        # #89 AC1/AC6: a legacy Plan carrying max_concurrency (including the
        # old 0 pause) that already exists in the wild is readable and
        # auditable, but the runtime never reinterprets it as a concurrency
        # semantic — a legacy 0 does NOT pause fixture starts. (New
        # authoring of the field is refused outright: see
        # test_plan_publish_rejects_retired_max_concurrency.)
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        self._update_issue(10, labels=[])
        doc = self._orchestration_plan(
            [{"issue": 15, "priority": 5}, {"issue": 14, "priority": 4},
             {"issue": 10, "priority": 1}], max_concurrency=0)
        self._force_publish_plan(doc)
        result, payload = self._orchestrate(max_parallel=2)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["started"], [15, 14, 10],
                         "all authorized nodes run; the retired envelope "
                         "field never gates anything")
        self.assertFalse(payload.get("paused"),
                         "the retired field is never reinterpreted as a pause")
        self.assertEqual(sorted(item["issue"] for item in payload["delivered"]),
                         [10, 14, 15], "all authorized nodes completed")

    def test_direct_ready_plan_authority_race_revokes_fail_closed(self):
        # AC4: a Plan authorization CAS-published between the direct path's
        # final pre-push check and the claim landing leaves BOTH one-shot
        # authorities on the same new attempt — the post-acquisition
        # recheck revokes the just-acquired start fail-closed (lineage
        # preserved, lease/reservation residue released).
        racer = self.tmp / "plan-racer"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(racer))
        racer_commit = self._racer_plan_commit(
            self._orchestration_plan([{"issue": 15, "priority": 1}]))
        # Issue 15 keeps its direct `ready` label.
        result = self._ght("claim", "15", env_extra={
            "GHT_TEST_RACER_DIR": str(racer),
            "GHT_TEST_RACE_OVERWRITE": racer_commit,
            "GHT_TEST_RACE_REF": self.PLAN_REF})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("revoked", result.stdout)
        inspected = self._ght_json("inspect", "15")[1]
        self.assertEqual(inspected["claim_state"], "TERMINAL")
        self.assertEqual(inspected["claim"]["status"], "failed")
        self.assertIn("revoked", inspected["claim"]["note"])
        self.assertEqual(self._issue(15)["labels"], [],
                         "the direct one-shot grant was consumed by the revoked start")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "",
            "the reservation of a revoked start is released")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/execution-leases/*").stdout.strip(), "",
            "the execution lease of a revoked start is released")

    def test_unexpected_trace_failure_keeps_identity_and_releases_capacity(self):
        # AC5/AC7: a non-CommandFailure failure AFTER a successful claim
        # (PR creation fails here) must keep the trace's durable identity,
        # release its temporary capacity exactly through the fenced path,
        # leave durable evidence, and never block the independent sibling.
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        result, _payload = self._publish_plan(self._orchestration_plan(
            [{"issue": 15, "priority": 5}, {"issue": 14, "priority": 4}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate(extra_env={
            "GHT_TEST_FAIL_PR_CREATE_ISSUES": "15"}, max_parallel=2)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["started"], [15, 14])
        self.assertEqual([item["issue"] for item in payload["delivered"]], [14],
                         "the independent sibling completes")
        failed = [item for item in payload["failed"] if item["issue"] == 15]
        self.assertTrue(failed and "unexpected trace failure" in failed[0]["error"])
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        self.assertEqual(inspected["status"], "active",
                         "the failed attempt stays durable and non-terminal")
        self.assertIsNotNone(inspected.get("candidate"),
                             "the failure happened after a successful preserve")
        self.assertIsNone(inspected.get("delivery"))
        self.assertIsNone(self._lease_remote_sha(inspected["claim_id"]),
                          "the stranded-lease window is closed: capacity is released")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "",
            "the reservation is released by exact identity")
        self.assertIn("ORCHESTRATED TRACE FAILED",
                      json.dumps(self._issue(15).get("comments", [])),
                      "durable failure evidence is recorded")

    def test_resume_acquire_failure_keeps_claim_and_releases_capacity(self):
        # AC5/AC7 (REQUEST_CHANGES resume path): after a successful
        # `ght acquire`, the trace record carries the SAME durable claim id
        # plus the fresh fencing token, so a later preserve failure flows
        # through the fenced exact-identity capacity release: the same
        # non-terminal claim, zero lease/reservation residue, durable
        # evidence, and no fresh authorization anywhere.
        self._update_issue(15, labels=[])
        result, _payload = self._publish_plan(self._orchestration_plan(
            [{"issue": 15, "priority": 1}]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, first = self._orchestrate()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(len(first["delivered"]), 1)
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        claim_id = inspected["claim_id"]
        old_candidate = inspected["delivery"]["sha"]
        pr_number = inspected["delivery"]["pr"]
        data = json.loads(self.state.read_text())
        data[str(pr_number)].setdefault("pr_comments", []).append({
            "body": "A REVIEW — REQUEST_CHANGES\n\nReviewed exact Candidate:\n"
                    f"`{old_candidate}`\n\nblocking findings\n\n"
                    "Re-review required after corrections."})
        self.state.write_text(json.dumps(data, indent=2))
        # The resumed trace fails at preserve (its branch push is forced to
        # fail) AFTER the correction acquire succeeded.
        result, second = self._orchestrate(extra_env={
            "GHT_TEST_FAIL_PUSH_REFSPEC": f"refs/heads/{inspected['branch']}"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(second["started"], [15])
        self.assertEqual([item for item in second["delivered"]], [])
        failed = [item for item in second["failed"] if item["issue"] == 15]
        self.assertTrue(failed and "preserve failed" in failed[0]["error"])
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        self.assertEqual(inspected["claim_id"], claim_id,
                         "the failed correction keeps the SAME durable claim")
        self.assertEqual(inspected["status"], "active",
                         "the attempt stays durable and non-terminal")
        self.assertIsNone(self._lease_remote_sha(claim_id),
                          "the resumed trace's capacity is released exactly")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "",
            "the reservation is released by exact identity")
        self.assertIn("ORCHESTRATED TRACE FAILED",
                      json.dumps(self._issue(15).get("comments", [])),
                      "durable failure evidence is recorded")
        self.assertEqual(self._issue(15)["labels"], [],
                         "no fresh authorization is involved in the resume")

    def test_driver_failure_releases_capacity_independent_branch_continues(self):
        # AC10/AC12: a real Driver failure after start releases the failed
        # trace's temporary capacity (attempt preserved, no invented A
        # decision) so an independent admitted branch continues in the SAME
        # invocation; the failed node's descendants stay blocked.
        self._update_issue(15, labels=[])
        self._update_issue(14, labels=[])
        self._update_issue(10, labels=[])
        doc = self._orchestration_plan([
            {"issue": 15, "priority": 10},
            {"issue": 14, "priority": 5},
            {"issue": 10, "priority": 1,
             "after": [{"gate": "issue_done", "issue": 15}]}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._orchestrate(extra_env={
            "GHT_ORCHESTRATOR_TASK_COMMAND":
                'if [ "$GHT_ORCHESTRATOR_ISSUE" = "15" ]; then exit 1; fi; '
                "mkdir -p skills && printf ok >> skills/orchestrated.txt && "
                "git add skills && git -c user.email=d@ght -c user.name=drv "
                "commit -qm ok"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        failed = [item for item in payload["failed"] if item["issue"] == 15]
        self.assertTrue(failed and "failed" in failed[0]["error"])
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        self.assertEqual(inspected["status"], "active",
                         "a driver failure never invents an A terminal decision")
        self.assertIsNone(self._lease_remote_sha(inspected["claim_id"]),
                          "the failed trace's temporary capacity is released")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "")
        # The independent branch continues in the SAME invocation.
        delivered = [item for item in payload["delivered"] if item["issue"] == 14]
        self.assertEqual(len(delivered), 1)
        # The failed node's descendant stays blocked (issue_done gate):
        # take each issue's LAST evaluation (the report accumulates rounds).
        # Issue 15 is filtered out of later rounds once started, so its last
        # recorded evaluation is the pre-start one; its post-failure durable
        # state is asserted above via inspect/lease.
        final_runnable = {}
        for item in payload["runnable"]:
            final_runnable[item["issue"]] = item["runnable"]
        self.assertIs(final_runnable.get(10), False,
                      "the failed node's descendant never becomes runnable")

    def test_reconstruct_fail_closed_when_leases_unreadable(self):
        # AC3/AC4: an unreadable execution-lease namespace is never misread
        # as "no live capacity" — reconstruction fails closed and nothing
        # is claimed or started.
        self._update_issue(15, labels=[])
        doc = self._orchestration_plan([{"issue": 15, "priority": 1}])
        result, _payload = self._publish_plan(doc)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._orchestrate(
            extra_env={"GHT_TEST_FAIL_LS_REMOTE": "1"})
        self.assertEqual(result.returncode, 4, result.stdout + result.stderr)
        self.assertIn("simulated ls-remote transport failure", result.stdout,
                      "the unreadable durable truth surfaces as the failure")
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "15").stdout.strip(),
            "", "no claim may be created when durable truth is unreadable")

    def test_reference_driver_launch_stop_cleanup(self):
        # AC16: the Execution Driver exposes a real provider-neutral stop
        # path — launch a long-running engineering execution, stop it, and
        # verify the process is terminated and the workspace cleaned up.
        import hashlib
        self._update_issue(15, labels=[])
        saved_env = {key: os.environ.get(key) for key in
                     ("GHT_TEST_STATE", "GHT_TEST_REAL_GIT", "GHT_EXECUTOR_ID",
                      "GHT_ORCHESTRATOR_TASK_COMMAND", "GHT_ORCHESTRATOR_RUN_DIR")}
        previous_cwd = os.getcwd()
        os.environ.update(self._env)
        os.environ["GHT_ORCHESTRATOR_TASK_COMMAND"] = (
            "sleep 30 && mkdir -p skills && printf x > skills/never.txt")
        os.environ["GHT_ORCHESTRATOR_RUN_DIR"] = str(self.tmp / "driver-runs")
        os.chdir(self.repo)
        try:
            from github_task.cli import Context
            from github_task.orchestrator import ReferenceDriver
            ctx = Context("origin")
            driver = ReferenceDriver(ctx)
            spec = {"issue": 99, "branch": "driver-stop-demo",
                    "execution_base": self._git(self.repo, "rev-parse",
                                                "HEAD").stdout.strip()}
            worktree = driver.prepare(spec, spec)
            handle = driver.launch(spec, spec, worktree)
            time.sleep(0.5)
            self.assertFalse(driver.poll(handle), "the execution should be running")
            result = driver.stop(handle)
            self.assertTrue(result["stopped"])
            self.assertFalse((Path(handle["worktree"]) / "skills" / "never.txt").exists(),
                             "a stopped execution must not have produced its change")
            driver.cleanup(spec, spec, worktree)
            self.assertFalse(worktree.exists(), "cleanup removes the workspace")
        finally:
            os.chdir(previous_cwd)
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def previous_cwd(self):
        raise NotImplementedError

    # -- Execution Plan revisions and Plan authorization ------------------

    PLAN_REF = "refs/ght/plans/current"

    def _plan_doc(self, nodes=None, **overrides):
        from github_task.core import contract_digest, parse_contract

        digest = contract_digest(parse_contract(issue_body(IMPL_CONTRACT)))
        doc = {"version": 1, "plan_id": "wave-1", "nodes": [
            {"issue": 15, "contract_digest": digest,
             "authorization_id": "wave-1-15-a", "priority": 10}]}
        if nodes is not None:
            doc["nodes"] = nodes
        doc.update(overrides)
        return doc

    def _write_plan(self, doc):
        path = self.tmp / "plan.json"
        path.write_text(json.dumps(doc))
        return str(path)

    def _publish_plan(self, doc, replace=None, **kwargs):
        args = ["plan-publish", self._write_plan(doc)]
        if replace:
            args += ["--replace", replace]
        return self._ght_json(*args, **kwargs)

    def _force_publish_plan(self, doc):
        # Simulate a revision that already exists in the wild — published
        # before the current-authoring gate existed — by committing
        # PLAN.json and moving the ref directly, bypassing `ght
        # plan-publish` (which now refuses retired authoring).
        blob = self._git(self.repo, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(doc)).stdout.strip()
        tree = self._git(self.repo, "mktree",
                         input_text=f"100644 blob {blob}\tPLAN.json\n").stdout.strip()
        commit = self._git(self.repo, "commit-tree", tree,
                           "-m", "legacy revision").stdout.strip()
        pushed = self._git(self.repo, "push",
                           f"--force-with-lease={self.PLAN_REF}:",
                           "origin", f"{commit}:{self.PLAN_REF}")
        self.assertEqual(pushed.returncode, 0, pushed.stdout + pushed.stderr)
        return commit

    def _plan_claim(self, number, authorization_id, **kwargs):
        return self._ght_json("claim", str(number), "--plan-authorization", authorization_id,
                              **kwargs)

    def _racer_plan_commit(self, doc):
        """Build a replacement plan revision object inside a racer clone."""
        racer = self.tmp / "plan-racer"
        if not racer.exists():
            self._git(self.tmp, "clone", "-q", str(self.origin), str(racer))
        blob = self._git(racer, "hash-object", "-w", "--stdin",
                         input_text=json.dumps(doc)).stdout.strip()
        tree = self._git(racer, "mktree",
                         input_text=f"100644 blob {blob}\tPLAN.json").stdout.strip()
        return self._git(racer, "commit-tree", tree, "-m", "ght: racing plan revision",
                         env=self._env).stdout.strip()

    def _delivered_upstream(self, number, candidate_sha, pr_number, *, with_completion=False,
                            pr_state="MERGED", pr_head=None, reviews=None, pr_comments=None):
        """Push a durable delivered upstream claim + its merged PR fact."""
        record = {"v": 3, "task": number, "claim_id": f"x-{number}-delivered",
                  "github_principal": "acct", "executor_id": "prior-worker",
                  "claimed_at": "2026-09-18T00:00:00Z",
                  "lease_expires_at": "2026-09-18T01:00:00Z",
                  "execution_base": "0" * 40, "status": "delivered",
                  "branch": f"agent/{number}/prior", "heartbeat_at": "2026-09-18T00:00:00Z",
                  "supersedes": None, "contract_digest": "a" * 64, "candidate": None}
        if candidate_sha:
            record["candidate"] = {"branch": f"agent/{number}/prior", "sha": candidate_sha,
                                   "scope": {"pass": True, "paths": {}, "violations": [],
                                             "counts": {"ALLOWED": 1, "FORBIDDEN": 0}},
                                   "preserved_at": "2026-09-18T00:10:00Z"}
            record["delivery"] = {"pr": pr_number, "sha": candidate_sha, "note": "",
                                  "delivered_at": "2026-09-18T00:20:00Z"}
            if with_completion:
                record["completed"] = {"pr": pr_number,
                                       "merge_commit": "m" * 40,
                                       "candidate_sha": candidate_sha,
                                       "completed_at": "2026-09-18T00:30:00Z"}
        self._raw_ref(CLAIM_REF + str(number), record)
        if candidate_sha:
            self._open_pr(pr_number, f"agent/{number}/prior", pr_head or candidate_sha,
                          state=pr_state, reviews=reviews, pr_comments=pr_comments)

    def test_plan_publish_cas_lineage_and_history(self):
        result, payload = self._publish_plan(self._plan_doc())
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        first = payload["revision"]
        self.assertEqual(self._git(self.repo, "ls-remote", "origin",
                                   self.PLAN_REF).stdout.split()[0], first)
        # A second fresh publish fails closed: revisions are created by CAS.
        result, _payload = self._publish_plan(self._plan_doc(plan_id="wave-2"))
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)
        self.assertIn("already exists", result.stdout)
        # A stale --replace fails closed with the CAS error, regardless of
        # the new document's plan identity.
        result, _payload = self._publish_plan(self._plan_doc(plan_id="wave-2"),
                                              replace="f" * 40)
        self.assertEqual(result.returncode, 3, result.stdout + result.stderr)
        self.assertIn("CAS mismatch", result.stdout)
        # One repository execution context has one long-lived stable plan_id:
        # a revision that changes the Plan identity is refused fail-closed
        # and leaves the current pointer untouched.
        result, _payload = self._publish_plan(self._plan_doc(plan_id="wave-2"),
                                              replace=first)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("plan_id must stay stable", result.stdout)
        self.assertEqual(self._git(self.repo, "ls-remote", "origin",
                                   self.PLAN_REF).stdout.split()[0], first)
        # The same plan_id with different scheduling content is a legal
        # immutable revision chained onto the exact prior.
        revised = self._plan_doc(plan_id="wave-1")
        revised["nodes"] = [{**revised["nodes"][0], "priority": 9}]
        result, payload = self._publish_plan(revised, replace=first)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        second = payload["revision"]
        self.assertNotEqual(first, second)
        self.assertEqual(payload["nodes"], 1)
        # History is reconstructable from the Git object graph, never rewritten.
        _result, old = self._ght_json("plan-view", "--revision", first)
        self.assertEqual(old["plan"]["plan_id"], "wave-1")
        _result, current = self._ght_json("plan-view")
        self.assertEqual(current["revision"], second)
        self.assertEqual(current["plan"]["plan_id"], "wave-1")
        # An exact SHA outside the reconstructable chain is refused.
        foreign = self._racer_plan_commit(self._plan_doc(plan_id="rogue"))
        result = self._ght("plan-view", "--revision", foreign)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_plan_schema_rejects_invalid_documents(self):
        digest = self._plan_doc()["nodes"][0]["contract_digest"]
        node = {"issue": 15, "contract_digest": digest,
                "authorization_id": "w15", "priority": 1}
        bad_docs = [
            self._plan_doc(version=2), self._plan_doc(version=True),
            self._plan_doc(plan_id=""), self._plan_doc(plan_id=None),
            self._plan_doc(max_concurrency=-1), self._plan_doc(max_concurrency="2"),
            self._plan_doc(max_concurrency=True),
            self._plan_doc(nodes=[]), self._plan_doc(nodes=[node, dict(node)]),
            {**self._plan_doc(), "scheduler_note": "runtime state"},
            {**self._plan_doc(), "nodes": [{**node, "worker": "worker-2"}]},
            {**self._plan_doc(), "nodes": [{**node, "started_at": "now"}]},
            {**self._plan_doc(), "nodes": [{**node, "retry_count": 1}]},
            {**self._plan_doc(), "nodes": [{**node, "authorization_id": "dup"},
                                           {**node, "issue": 14,
                                            "authorization_id": "dup"}]},
            {**self._plan_doc(), "nodes": [{**node, "contract_digest": "nothex"}]},
            {**self._plan_doc(),
             "nodes": [{**node, "after": [{"gate": "candidate", "issue": 4}]}]},
            {**self._plan_doc(), "nodes": [{**node, "after": [{"gate": "merged"}]}]},
        ]
        for doc in bad_docs:
            result = self._ght("plan-publish", self._write_plan(doc))
            self.assertNotEqual(result.returncode, 0, f"schema accepted: {doc}")
            self.assertIn("invalid Execution Plan", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", self.PLAN_REF).stdout.strip(), "",
            "rejected documents must not leave a current pointer")

    def test_plan_publish_rejects_cyclic_barrier_graphs(self):
        # Plan v1 publication is where an invalid barrier graph fails closed:
        # self-edges and Plan-internal cycles are mechanically rejected, not
        # deferred to a later start as ordinary "no runnable work". Barriers
        # to Issues outside the Plan remain legal external dependencies.
        digest = self._plan_doc()["nodes"][0]["contract_digest"]

        def node(issue, after=None, auth=None):
            entry = {"issue": issue, "contract_digest": digest,
                     "authorization_id": auth or f"auth-{issue}", "priority": 1}
            if after is not None:
                entry["after"] = after
            return entry

        cyclic = [
            # self-edge
            self._plan_doc(nodes=[node(15, [{"gate": "merged", "issue": 15}])]),
            # two-node cycle
            self._plan_doc(nodes=[node(15, [{"gate": "merged", "issue": 14}]),
                                  node(14, [{"gate": "issue_done", "issue": 15}])]),
            # three-node cycle
            self._plan_doc(nodes=[node(15, [{"gate": "merged", "issue": 14}]),
                                  node(14, [{"gate": "merged", "issue": 12}]),
                                  node(12, [{"gate": "issue_done", "issue": 15}])]),
        ]
        for doc in cyclic:
            result = self._ght("plan-publish", self._write_plan(doc))
            self.assertNotEqual(result.returncode, 0, f"cyclic graph accepted: {doc}")
            self.assertIn("invalid Execution Plan", result.stdout)
            self.assertIn("DAG", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", self.PLAN_REF).stdout.strip(), "",
            "rejected graphs must not leave a current pointer")
        # A valid Plan-internal DAG publishes: 15 is blocked by 14, which is
        # blocked only by the external Issue 12.
        result, payload = self._publish_plan(
            self._plan_doc(nodes=[node(15, [{"gate": "merged", "issue": 14}],
                                       auth="wave-1-15-a"),
                                  node(14, [{"gate": "merged", "issue": 12}],
                                       auth="wave-1-14-a")]))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["nodes"], 2)
        # Barriers to Issues outside the current Plan never form a cycle.
        result, _payload = self._publish_plan(
            self._plan_doc(nodes=[node(15, [{"gate": "merged", "issue": 99},
                                            {"gate": "issue_done", "issue": 4}],
                                       auth="wave-1-15-a")]),
            replace=payload["revision"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_plan_authorized_claim_records_durable_authority(self):
        # AC7: the claim durably records source/type, exact authorization_id,
        # exact Plan revision SHA, and exact contract_digest.
        from github_task.core import contract_digest, parse_contract

        self._update_issue(15, labels=[])
        expected_digest = contract_digest(parse_contract(issue_body(IMPL_CONTRACT)))
        _result, published = self._publish_plan(self._plan_doc())
        revision = published["revision"]
        result, payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(payload["authorization"], {
            "type": "plan", "plan_id": "wave-1", "authorization_id": "wave-1-15-a",
            "plan_revision": revision, "contract_digest": expected_digest})
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        self.assertEqual(inspected["authorization"]["plan_revision"], revision)
        self.assertEqual(inspected["authorization"]["contract_digest"], expected_digest)
        self.assertEqual(inspected["status"], "active")
        # The independent ready surface is untouched by a Plan-authorized start.
        self.assertEqual(self._issue(15)["labels"], [])

    def test_plan_claim_fail_closed_conditions(self):
        digest = self._plan_doc()["nodes"][0]["contract_digest"]
        # No current Plan pointer at all.
        result, _payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no current Execution Plan", result.stdout)
        # Node missing, identity mismatch, digest mismatch, ready presence.
        self._publish_plan(self._plan_doc())
        self._update_issue(15, labels=["ready"])
        result, _payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("independent", result.stdout)
        self._update_issue(15, labels=[])
        result, _payload = self._plan_claim(15, "wrong-id")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("authorizes", result.stdout)
        result, _payload = self._plan_claim(14, "wave-1-15-a")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no node", result.stdout)
        result, _payload = self._publish_plan(
            self._plan_doc(nodes=[{"issue": 15, "contract_digest": "b" * 64,
                                   "authorization_id": "wave-1-15-a", "priority": 1}]),
            replace=self._git(self.repo, "ls-remote", "origin",
                              self.PLAN_REF).stdout.split()[0])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("contract_digest does not match", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "15").stdout.strip(), "",
            "failed plan gates must not create ownership state")

    def test_plan_authorization_is_one_shot(self):
        # AC7: one authorization starts at most one new attempt; ordinary
        # review corrections never consume a new authorization (no new
        # claim is involved), while AC8: a post-BLOCK new attempt requires
        # a fresh authorization id under the current revision.
        self._update_issue(15, labels=[])
        _result, first = self._publish_plan(self._plan_doc())
        result, _payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._ght_json("release", "15", "--status", "blocked",
                                          "--note", "A: replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("already consumed", result.stdout)
        # A fresh authorization id in the current revision authorizes the
        # new attempt, which CAS-appends and records supersedes.
        current = self._git(self.repo, "ls-remote", "origin",
                            self.PLAN_REF).stdout.split()[0]
        _result, republished = self._publish_plan(
            self._plan_doc(nodes=[{"issue": 15, "contract_digest":
                                   self._plan_doc()["nodes"][0]["contract_digest"],
                                   "authorization_id": "wave-1-15-b", "priority": 10}]),
            replace=current)
        self.assertNotEqual(republished["revision"], first["revision"])
        result, payload = self._plan_claim(15, "wave-1-15-b")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIsNotNone(payload["supersedes"]["claim_id"])

    def test_plan_barriers_merged_and_issue_done(self):
        # AC3/AC4: the merged gate binds the upstream Issue's delivered
        # Candidate SHA, a PR MERGED at that exact head, and a durable A
        # acceptance on the PR bound to the same exact SHA — a native
        # APPROVED review or the structured exact-SHA ACCEPT comment
        # fallback. The execution-attempt completion record is NOT part of
        # the predicate. issue_done requires the stronger Issue-level DONE
        # fact — CLOSED with closure reason completed — and is never derived
        # from a merge.
        self._update_issue(15, labels=[])
        digest = self._plan_doc()["nodes"][0]["contract_digest"]

        def barrier_doc(after, authorization_id):
            return self._plan_doc(nodes=[{"issue": 15, "contract_digest": digest,
                                          "authorization_id": authorization_id,
                                          "priority": 1, "after": after}])

        auth_ids = iter(f"wave-1-15-bar{i}" for i in range(1, 30))

        def republish(after):
            remote = self._git(self.repo, "ls-remote", "origin",
                               self.PLAN_REF).stdout.strip()
            prior = remote.split()[0] if remote else None
            auth_id = next(auth_ids)
            result, payload = self._publish_plan(barrier_doc(after, auth_id), replace=prior)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            return auth_id

        def try_claim(auth_id):
            return self._plan_claim(15, auth_id)[0]

        # merged: unsatisfied while no upstream attempt has the durable facts.
        auth_id = republish([{"gate": "merged", "issue": 12}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("merged:#12", result.stdout)
        # No delivery/PR record is not enough, and completed bookkeeping is
        # deliberately absent here: it is not part of the predicate.
        self._delivered_upstream(12, "c" * 40, 21)
        self._open_pr(21, "agent/12/prior", "c" * 40, state="MERGED")
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no APPROVED review", result.stdout)
        # A MERGED PR whose head is not the delivered Candidate SHA is refused.
        self._delivered_upstream(13, "d" * 40, 22, pr_head="e" * 40,
                                 reviews=[{"state": "APPROVED", "commit_id": "d" * 40}])
        auth_id = republish([{"gate": "merged", "issue": 13}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("not MERGED at the delivered Candidate", result.stdout)
        # Exact head but no durable acceptance in either canonical surface.
        self._open_pr(22, "agent/13/prior", "d" * 40, state="MERGED")
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no APPROVED review", result.stdout)
        # An APPROVED review bound to a different SHA without the fallback
        # comment is refused.
        self._open_pr(22, "agent/13/prior", "d" * 40, state="MERGED",
                      reviews=[{"state": "APPROVED", "commit_id": "e" * 40}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("bind", result.stdout)
        self.assertIn("not the delivered Candidate SHA", result.stdout)
        # The native exact-SHA APPROVED review satisfies the gate.
        self._open_pr(22, "agent/13/prior", "d" * 40, state="MERGED",
                      reviews=[{"state": "APPROVED", "commit_id": "d" * 40}])
        auth_id = republish([{"gate": "merged", "issue": 13}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._ght_json("release", "15", "--status", "blocked",
                                          "--note", "reset for review cases")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # The structured exact-SHA ACCEPT comment fallback also satisfies
        # the gate when no native APPROVED review exists (same-account
        # platforms refuse native self-approval).
        fallback_body = ("A REVIEW — ACCEPTED\n\nReviewed exact Candidate:\n"
                         f"{'f' * 40}\n\nacceptance conclusion\n\nMerge authorization "
                         "applies only while PR head remains this exact SHA.")
        self._delivered_upstream(14, "f" * 40, 23, reviews=[],
                                 pr_comments=[{"body": fallback_body}])
        auth_id = republish([{"gate": "merged", "issue": 14}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._ght_json("release", "15", "--status", "blocked",
                                          "--note", "reset for review cases")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # A fallback ACCEPT comment bound to a different SHA is refused.
        old_sha_body = fallback_body.replace("f" * 40, "e" * 40)
        self._delivered_upstream(10, "a" * 40, 24, reviews=[],
                                 pr_comments=[{"body": old_sha_body}])
        auth_id = republish([{"gate": "merged", "issue": 10}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no APPROVED review", result.stdout)
        # A generic comment without the structured ACCEPT marker is not an
        # acceptance even when it mentions the exact SHA.
        generic = f"looks good, accepting candidate {('a' * 40)} in spirit"
        self._open_pr(24, "agent/10/prior", "a" * 40, state="MERGED",
                      pr_comments=[{"body": generic}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no APPROVED review", result.stdout)
        # A quoted copy of the canonical structure documents it without
        # being a review header; it must not count as acceptance.
        quoted = ("\n> A REVIEW — ACCEPTED\n>\n> Reviewed exact Candidate:\n> "
                  f"`{('a' * 40)}`\n")
        self._open_pr(24, "agent/10/prior", "a" * 40, state="MERGED",
                      pr_comments=[{"body": quoted}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no APPROVED review", result.stdout)
        # A negated/explanatory mention of the header below other body text
        # is incidental prose, not a review header.
        negated = ("This comment deliberately does NOT accept anything.\n"
                   "A REVIEW — ACCEPTED\n\nReviewed exact Candidate:\n"
                   f"`{('a' * 40)}`\n")
        self._open_pr(24, "agent/10/prior", "a" * 40, state="MERGED",
                      pr_comments=[{"body": negated}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no APPROVED review", result.stdout)
        # The header without the exact-SHA field binds nothing.
        header_only = f"A REVIEW — ACCEPTED\n\nship it — candidate {('a' * 40)}\n"
        self._open_pr(24, "agent/10/prior", "a" * 40, state="MERGED",
                      pr_comments=[{"body": header_only}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no APPROVED review", result.stdout)
        # Only the SHA bound by the field counts: a candidate SHA mentioned
        # elsewhere in the body (as a superseded reference here) never binds.
        prose_sha = ("A REVIEW — ACCEPTED\n\nReviewed exact Candidate:\n"
                     f"`{('e' * 40)}`\n\nsupersedes the earlier candidate "
                     f"{('a' * 40)}\n")
        self._open_pr(24, "agent/10/prior", "a" * 40, state="MERGED",
                      pr_comments=[{"body": prose_sha}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("no APPROVED review", result.stdout)
        # The canonical structured fallback (header as the review header +
        # field bound to the exact delivered SHA) satisfies the gate.
        self._open_pr(24, "agent/10/prior", "a" * 40, state="MERGED",
                      pr_comments=[{"body": fallback_body.replace("f" * 40, "a" * 40)}])
        auth_id = republish([{"gate": "merged", "issue": 10}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._ght_json("release", "15", "--status", "blocked",
                                          "--note", "reset for surface cases")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # An unreadable review surface fails closed even with a fallback.
        auth_id = republish([{"gate": "merged", "issue": 10}])
        result = self._ght("claim", "15", "--plan-authorization", auth_id,
                           env_extra={"GHT_TEST_FAIL_PR_REVIEWS": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unreadable", result.stdout)
        result = self._ght("claim", "15", "--plan-authorization", auth_id,
                           env_extra={"GHT_TEST_FAIL_PR_COMMENTS": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("unreadable", result.stdout)
        # issue_done is not derived from the merge: issue 13 merged above but
        # the Issue itself is still OPEN.
        auth_id = republish([{"gate": "issue_done", "issue": 13}])
        result, _payload = self._plan_claim(15, auth_id)
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("issue_done:#13", result.stdout)
        self.assertIn("never derives", result.stdout)
        # Issue 4 is CLOSED with closure reason completed: the durable
        # Issue-level DONE fact satisfies the gate.
        auth_id = republish([{"gate": "issue_done", "issue": 4}])
        result = try_claim(auth_id)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._ght_json("release", "15", "--status", "blocked",
                                          "--note", "reset for closure-reason cases")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # A CLOSED Issue whose closure reason is not completed is not DONE:
        # not_planned/duplicate closures never unblock downstream work, and
        # a missing/unreadable reason fails closed too.
        for reason in ("NOT_PLANNED", "DUPLICATE", None):
            self._update_issue(4, stateReason=reason)
            auth_id = republish([{"gate": "issue_done", "issue": 4}])
            result = try_claim(auth_id)
            self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
            self.assertIn("closure reason", result.stdout)

    def test_plan_update_governs_future_starts_only(self):
        # AC8: an attempt already started under a valid authorization is not
        # silently revoked by a later Plan edit; stopping it still requires
        # the ordinary BLOCK/REPLAN semantics.
        self._update_issue(15, labels=[])
        self._publish_plan(self._plan_doc())
        result, _payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        current = self._git(self.repo, "ls-remote", "origin", self.PLAN_REF).stdout.split()[0]
        result, _payload = self._publish_plan(
            self._plan_doc(plan_id="wave-1",
                           nodes=[{"issue": 15,
                                   "contract_digest":
                                   self._plan_doc()["nodes"][0]["contract_digest"],
                                   "authorization_id": "wave-1-15-a", "priority": -5}]),
            replace=current)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, payload = self._ght_json("verify", "15")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._ght_json("heartbeat", "15", "--force")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_plan_start_recheck_race_revokes_fail_closed(self):
        # AC9: if the Plan gate breaks between CAS acquisition and the
        # post-acquisition recheck (node deleted here), the ownership state
        # must not survive as a seemingly valid start.
        self._update_issue(15, labels=[])
        self._publish_plan(self._plan_doc())
        racer = self.tmp / "plan-racer"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(racer))
        broken = self._racer_plan_commit(self._plan_doc(nodes=[
            {"issue": 14, "contract_digest": self._plan_doc()["nodes"][0]["contract_digest"],
             "authorization_id": "wave-1-14-a", "priority": 1}]))
        result, _payload = self._plan_claim(15, "wave-1-15-a", env_extra={
            "GHT_TEST_RACER_DIR": str(racer),
            "GHT_TEST_RACE_OVERWRITE": broken,
            "GHT_TEST_RACE_REF": self.PLAN_REF,
        })
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("revoked", result.stdout)
        inspected = self._ght_json("inspect", "15")[1]
        self.assertEqual(inspected["claim_state"], "TERMINAL")
        self.assertEqual(inspected["claim"]["status"], "failed")
        self.assertIn("revoked", inspected["claim"]["note"])
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "",
            "the reservation of a revoked start is released")
        # The failed record is a durable CAS append onto the started claim,
        # not a rewrite of it.
        self._git(self.repo, "fetch", "-q", "origin", f"+{CLAIM_REF}15:{CLAIM_REF}15")
        started_sha = self._git(self.repo, "rev-parse",
                                f"{CLAIM_REF}15^").stdout.strip()
        self.assertTrue(started_sha)
        started_record = json.loads(self._git(
            self.repo, "show", f"{started_sha}:CLAIM.json").stdout)
        self.assertEqual(started_record["status"], "active")
        self.assertEqual(started_record["authorization"]["authorization_id"],
                         "wave-1-15-a")
        self.assertNotEqual(
            started_sha,
            self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "15").stdout.split()[0])

    def test_plan_start_recheck_semantics_preserving_change_continues(self):
        # AC9: a revision change that keeps the same authorization semantics
        # (same node, identity, digest, barriers) does not revoke the start.
        self._update_issue(15, labels=[])
        self._publish_plan(self._plan_doc())
        same_semantics = self._racer_plan_commit(self._plan_doc(
            plan_id="wave-1", max_concurrency=5,
            nodes=[{"issue": 15, "contract_digest":
                    self._plan_doc()["nodes"][0]["contract_digest"],
                    "authorization_id": "wave-1-15-a", "priority": 99}]))
        result, payload = self._plan_claim(15, "wave-1-15-a", env_extra={
            "GHT_TEST_RACER_DIR": str(self.tmp / "plan-racer"),
            "GHT_TEST_RACE_OVERWRITE": same_semantics,
            "GHT_TEST_RACE_REF": self.PLAN_REF,
        })
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        self.assertEqual(inspected["status"], "active")
        self.assertEqual(inspected["authorization"]["authorization_id"], "wave-1-15-a")

    def test_direct_ready_path_unaffected_by_plan_surface(self):
        # AC5: the direct/JIT ready path keeps its exact existing behavior
        # whether or not an Execution Plan exists.
        result, payload = self._ght_json("claim", "10")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIsNone(payload["authorization"])
        self.assertEqual(payload["ready_mirror"]["consumed"], True)
        self.assertEqual(self._issue(10)["labels"], [])
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", self.PLAN_REF).stdout.strip(), "")

    def test_plan_authorization_replay_checks_durable_ancestry(self):
        # AC7/AC11: the replay predicate covers the claim lineage's durable
        # ancestry, not just its current tip record — an authorization that
        # started a superseded attempt can never start a second one even
        # after later attempts carry a different identity. Ordinary review
        # corrections consume no new authorization.
        self._update_issue(15, labels=[])
        digest = self._plan_doc()["nodes"][0]["contract_digest"]

        def node_with(auth_id):
            return [{"issue": 15, "contract_digest": digest,
                     "authorization_id": auth_id, "priority": 10}]

        def republish(auth_id):
            remote = self._git(self.repo, "ls-remote", "origin",
                               self.PLAN_REF).stdout.strip()
            prior = remote.split()[0] if remote else None
            result, payload = self._publish_plan(self._plan_doc(nodes=node_with(auth_id)),
                                                 replace=prior)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

        # Authorization A starts and terminalizes an attempt.
        republish("wave-1-15-a")
        result, _payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # While A's attempt is ACTIVE, ordinary review activity consumes
        # nothing: verify stays green and no second authorization appears.
        self.assertEqual(self._ght_json("verify", "15")[0].returncode, 0)
        result, _payload = self._ght_json("heartbeat", "15", "--force")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        inspected = self._ght_json("inspect", "15")[1]["claim"]
        self.assertEqual(inspected["authorization"]["authorization_id"], "wave-1-15-a")
        result, _payload = self._ght_json("release", "15", "--status", "blocked",
                                          "--note", "A: replan")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # Fresh authorization B supersedes A: the lineage tip now carries
        # only B's authorization block.
        republish("wave-1-15-b")
        result, _payload = self._plan_claim(15, "wave-1-15-b")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        result, _payload = self._ght_json("release", "15", "--status", "blocked",
                                          "--note", "A: replan again")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        # A revives in a later revision: the tip record carries only B, but
        # A lives in the durable ancestry — the second start fails closed.
        republish("wave-1-15-a")
        result, payload = self._plan_claim(15, "wave-1-15-a")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("already consumed", result.stdout)
        self.assertIn("wave-1-15-a", result.stdout)
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin", CLAIM_REF + "15").stdout.split()[0],
            self._ght_json("inspect", "15")[1]["claim_sha"],
            "the replayed start left no ownership state")


class DistributionIdentityLazinessTests(unittest.TestCase):
    """The --version surface must not tax commands that never report it.

    #66 profiling: ``main()`` resolved the distribution identity (several
    git subprocesses) eagerly at parser-construction time — once for the
    argparse version string on EVERY invocation, and once more inside
    ``ght version``. These in-process tests pin the lazy contract: only
    the surfaces that actually report a version pay for it, and each pays
    exactly once.
    """

    def setUp(self):
        import contextlib
        import io
        from github_task import cli
        self.cli = cli
        self.calls = []
        original = cli.distribution_identity

        def counting():
            self.calls.append(1)
            return original()

        cli.distribution_identity = counting
        self.addCleanup(setattr, cli, "distribution_identity", original)
        self._contextlib = contextlib
        self._io = io

    def test_help_never_resolves_the_distribution_identity(self):
        buffer = self._io.StringIO()
        with self._contextlib.redirect_stdout(buffer):
            with self.assertRaises(SystemExit) as exited:
                self.cli.main(["--help"])
        self.assertEqual(exited.exception.code, 0)
        self.assertEqual(self.calls, [],
                         "--help resolved the distribution identity eagerly")

    def test_version_flag_resolves_the_identity_exactly_once(self):
        buffer = self._io.StringIO()
        with self._contextlib.redirect_stdout(buffer):
            with self.assertRaises(SystemExit) as exited:
                self.cli.main(["--version"])
        self.assertEqual(exited.exception.code, 0)
        self.assertIn("harry-dev", buffer.getvalue())
        self.assertEqual(len(self.calls), 1)

    def test_version_command_resolves_the_identity_exactly_once(self):
        buffer = self._io.StringIO()
        with self._contextlib.redirect_stdout(buffer):
            self.cli.main(["version"])
        payload = json.loads(buffer.getvalue())
        self.assertEqual(payload["product"], "harry-dev")
        self.assertEqual(len(self.calls), 1,
                         "ght version resolved the identity more than once")


if __name__ == "__main__":
    unittest.main()
