"""Consumer-side conformance for the canonical `ght discover` verdict (#121).

The canonical discovery result is a typed contract: it must be consumed as
complete structured output — the whole JSON document, the documented schema,
and the complete `work[]` surface (admission-priority ordered: continuations
first, direct-ready entries ride the array tail). The observed failure class
this pins: a consumer read a nonexistent alternate key (`candidates` /
`items`) with an empty default, and another truncated the raw JSON text and
dropped the array tail — both silently misreported a non-empty frontier as
0 runnable. ``consume_discovery_verdict`` is the repository-owned reference
consumer: every drift mode fails closed with an explicit diagnostic, and
canonical verdict semantics stay distinct — only the canonical ``no_work``
verdict is authoritative no-work (SKILL.md), never an empty ``work[]``
surface, a ``stop``, or a ``refresh_required`` decision.
"""

import dataclasses
import json
import unittest

WORKSET_JSON = json.dumps({
    "action": "handoff",
    "work": [
        {"issue": 119, "source": "resume", "kind": "resume",
         "runnable": True, "reason": "resume with `ght acquire`"},
        {"issue": 130, "source": "plan", "kind": "new", "priority": 5,
         "runnable": True, "reason": "plan node"},
        # direct-ready entries sort at the array tail (#121): a consumer
        # that truncates the text drops exactly these.
        {"issue": 120, "source": "direct-ready", "kind": "new",
         "runnable": True, "reason": "direct-ready"},
    ],
    "executing_elsewhere": [123],
})


class DiscoveryConsumerError(Exception):
    """Fail-closed diagnostic — never degrades into an empty frontier."""


@dataclasses.dataclass(frozen=True)
class DiscoveryVerdict:
    """Typed canonical discover verdict.

    ``work`` is the complete runnable work surface for the verdict;
    ``no_work`` is an explicit property of the canonical verdict type,
    never inferred from an empty work surface.
    """

    action: str
    work: tuple

    @property
    def is_no_work(self) -> bool:
        # SKILL.md: only the canonical `no_work` verdict is authoritative
        # no-work. An empty handoff bundle, `stop`, and `refresh_required`
        # each keep their own distinct semantics — never folded into [].
        return self.action == "no_work"


def consume_discovery_verdict(text: str) -> DiscoveryVerdict:
    """Reference consumer of the canonical `ght discover` output.

    Returns a typed ``DiscoveryVerdict``. ``verdict.work`` is the runnable
    work surface (the complete `work[]` for a handoff — possibly empty,
    which is still a handoff, not no-work — and the single-item surface for
    `claim`/`resume`). Only the canonical ``no_work`` verdict is
    authoritative no-work (``verdict.is_no_work``); ``stop`` and
    ``refresh_required`` keep their distinct verdict tags with an empty
    work surface, never the same answer as no-work. Any schema mismatch,
    missing/unrecognized required work surface, or malformed/truncated
    output raises ``DiscoveryConsumerError`` — it is never reported as
    no work.
    """
    try:
        decision = json.loads(text)
    except json.JSONDecodeError as exc:
        raise DiscoveryConsumerError(
            f"discover output is not parseable JSON (malformed or "
            f"truncated): {exc}") from exc
    if not isinstance(decision, dict):
        raise DiscoveryConsumerError(
            "discover verdict is not a JSON object")
    action = decision.get("action")
    if action == "no_work":
        return DiscoveryVerdict(action=action, work=())
    if action == "handoff":
        if not isinstance(decision.get("work"), list):
            raise DiscoveryConsumerError(
                "handoff verdict is missing its required `work[]` surface; "
                "never substitute an alternate key or an empty default")
        # An empty bundle is still a handoff verdict with its own
        # semantics — never authoritative no-work (only `no_work` is).
        return DiscoveryVerdict(action=action, work=tuple(decision["work"]))
    if action in ("claim", "resume"):
        if "issue" not in decision:
            raise DiscoveryConsumerError(
                f"{action} verdict is missing its required `issue` surface")
        return DiscoveryVerdict(action=action, work=(decision,))
    if action in ("stop", "refresh_required"):
        # Explicit canonical decisions with their own semantics — kept
        # distinct from `no_work` by their verdict tag, never folded into
        # a silent empty-work answer.
        return DiscoveryVerdict(action=action, work=())
    raise DiscoveryConsumerError(
        f"unrecognized discover action {action!r}; schema mismatch fails "
        "closed instead of degrading to 0 runnable")


class DiscoverConsumerConformanceTests(unittest.TestCase):
    def test_nonempty_workset_is_consumed_completely(self):
        # The complete `work[]` surface is the admission input: resume,
        # plan, and array-tail direct-ready entries all survive.
        verdict = consume_discovery_verdict(WORKSET_JSON)
        self.assertEqual(verdict.action, "handoff")
        self.assertFalse(verdict.is_no_work)
        work = verdict.work
        self.assertEqual([item["issue"] for item in work], [119, 130, 120])
        self.assertTrue(all(item["runnable"] for item in work))
        tail = work[-1]
        self.assertEqual(tail["source"], "direct-ready")
        self.assertTrue(tail["runnable"],
                        "the array-tail direct-ready entry must survive")

    def test_alternate_key_drift_fails_closed_not_zero_runnable(self):
        # The observed drift: reading `candidates` / `items` with an empty
        # default instead of the documented `work` key must fail closed.
        drifted = json.dumps({"action": "handoff",
                              "candidates": [{"issue": 119}],
                              "items": [{"issue": 120}]})
        with self.assertRaises(DiscoveryConsumerError) as caught:
            consume_discovery_verdict(drifted)
        self.assertIn("work[]", str(caught.exception))
        self.assertNotIn("0 runnable", str(caught.exception))

    def test_truncated_output_fails_closed_not_zero_runnable(self):
        # `tail`-style text truncation drops the array tail; a truncated
        # document is unparseable and must fail closed, never report an
        # empty frontier.
        truncated = WORKSET_JSON[: len(WORKSET_JSON) // 2]
        with self.assertRaises(DiscoveryConsumerError) as caught:
            consume_discovery_verdict(truncated)
        self.assertIn("truncated", str(caught.exception))

    def test_malformed_output_fails_closed_not_zero_runnable(self):
        with self.assertRaises(DiscoveryConsumerError):
            consume_discovery_verdict("ght: discover — 2 runnable items")
        with self.assertRaises(DiscoveryConsumerError):
            consume_discovery_verdict("[1, 2, 3]")

    def test_missing_work_surface_fails_closed(self):
        with self.assertRaises(DiscoveryConsumerError):
            consume_discovery_verdict(json.dumps({"action": "handoff"}))

    def test_only_canonical_no_work_is_authoritative_no_work(self):
        # A canonical `no_work` verdict — and only it — is authoritative
        # no-work: typed, diagnostic-free, and marked `is_no_work`.
        verdict = consume_discovery_verdict(
            json.dumps({"action": "no_work",
                        "reason": "no resumable attempt, no current Plan, "
                                  "no direct-ready work"}))
        self.assertEqual(verdict.action, "no_work")
        self.assertTrue(verdict.is_no_work)
        self.assertEqual(verdict.work, ())

    def test_stop_verdict_is_distinct_from_authoritative_no_work(self):
        # `stop` is an explicit canonical decision with its own semantics:
        # it keeps its verdict tag and must never be folded into the same
        # empty answer as authoritative no-work.
        verdict = consume_discovery_verdict(
            json.dumps({"action": "stop",
                        "reason": "ambiguous authority needs A "
                                  "reconciliation"}))
        self.assertEqual(verdict.action, "stop")
        self.assertFalse(verdict.is_no_work,
                         "stop must never be interpretable as no-work")
        self.assertEqual(verdict.work, ())

    def test_refresh_required_verdict_is_distinct_from_no_work(self):
        # `refresh_required` is an explicit decision (reload the local
        # Skill/distribution, then re-run discover) — its own verdict tag,
        # never folded into authoritative no-work.
        verdict = consume_discovery_verdict(
            json.dumps({"action": "refresh_required",
                        "reason": "reload the local Skill to the activated "
                                  "identity"}))
        self.assertEqual(verdict.action, "refresh_required")
        self.assertFalse(verdict.is_no_work,
                         "refresh_required must never be interpretable "
                         "as no-work")
        self.assertEqual(verdict.work, ())

    def test_empty_handoff_bundle_is_not_authoritative_no_work(self):
        # A handoff with an empty `work[]` is a legal canonical shape but a
        # different verdict type: it keeps the handoff semantics (an empty
        # deterministic bundle) and is never folded into no-work.
        verdict = consume_discovery_verdict(
            json.dumps({"action": "handoff", "work": []}))
        self.assertEqual(verdict.action, "handoff")
        self.assertEqual(verdict.work, ())
        self.assertFalse(verdict.is_no_work,
                         "an empty bundle is not the `no_work` verdict")

    def test_empty_work_surface_never_implies_authoritative_no_work(self):
        # The semantic collapse #121 prevents: emptiness of the work
        # surface alone must never read as no-work — only the `no_work`
        # verdict type is authoritative.
        for payload in ({"action": "stop"},
                        {"action": "refresh_required"},
                        {"action": "handoff", "work": []}):
            verdict = consume_discovery_verdict(json.dumps(payload))
            self.assertEqual(verdict.work, ())
            self.assertFalse(verdict.is_no_work,
                             f"{verdict!r} must not read as no-work")

    def test_single_item_verdicts_are_work_surfaces_not_no_work(self):
        claim = consume_discovery_verdict(
            json.dumps({"action": "claim", "issue": 120}))
        self.assertEqual(claim.action, "claim")
        self.assertFalse(claim.is_no_work)
        self.assertEqual(len(claim.work), 1)
        self.assertEqual(claim.work[0]["issue"], 120)
        resume = consume_discovery_verdict(json.dumps(
            {"action": "resume", "issue": 119, "claim_id": "c1",
             "resumable": [119]}))
        self.assertEqual(resume.action, "resume")
        self.assertFalse(resume.is_no_work)
        self.assertEqual(len(resume.work), 1)


if __name__ == "__main__":
    unittest.main()
