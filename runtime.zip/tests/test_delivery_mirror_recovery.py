"""Issue #203 / #210 regression matrix for the delivery comment mirror.

The base fix (a120ca2f) recovers the Issue ``ght:deliver`` mirror on the
exact re-delivery branch. This file closes the AC5 matrix cases the base
tests did not construct — each test builds the actual mismatched, foreign,
or unavailable condition and checks durable state and the Issue surface,
never a diagnostic message alone:

- a readable PR whose head no longer binds the delivered Candidate fails
  closed with no marker republished (AC3, distinct from the vanished-PR
  fence and from the branch/checkout-HEAD fences of #104);
- a foreign executor (or GitHub principal) retrying the exact delivery
  never publishes the mirror — ownership is proven before the mirror, and
  the durable record is untouched (AC3);
- a retry naming a different PR whose head is not the preserved Candidate
  fails closed on the ordinary delivery fence and never rewrites the
  durable delivery record or mints a second marker (AC3);
- a retry whose comment republication fails — write surface down, or the
  evidence read itself unreadable — stays a green durable-delivery report
  with ``comment_mirror_synced=false`` and an explicit warning, keeps the
  delivery record and capacity cleanup intact, and remains repairable
  (AC4);
- a normal retry with the legal marker already present has no side
  effects: no duplicate or rewritten comment, no claim/delivery/label/lease
  movement, and ``comment_mirror_synced`` proven by the marker read-back
  even with the write surface down (AC2).

First-comment-failure recovery, moved branch/checkout heads, the vanished
PR, snapshot retry, and the execution-resource cleanup semantics are
covered by the existing tests (``test_cli_safety`` a120ca2f/#136/#104),
which run individually.
"""

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
CLI = SKILL_ROOT / "scripts" / "ght.py"
REAL_GIT = shutil.which("git")
sys.path.insert(0, str(SKILL_ROOT))
sys.path.insert(0, str(SKILL_ROOT / "tests"))

from test_cli_safety import MOCK_GH, GIT_WRAPPER, IMPL_CONTRACT, issue_body  # noqa: E402

LEASE_REF_FMT = "refs/ght/execution-leases/%s"


class DeliveryMirrorRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ght-mirror-recovery-"))
        self.origin = self.tmp / "origin.git"
        self.state = self.tmp / "issues.json"
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        self._write_executable(self.bin / "gh", MOCK_GH)
        self._write_executable(self.bin / "git", GIT_WRAPPER)
        self._git(self.tmp, "init", "--bare", str(self.origin), "-b", "main")
        seed = self.tmp / "seed"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(seed))
        (seed / "README.md").write_text("seed\n")
        self._git(seed, "add", ".")
        self._git(seed, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "seed")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        self.repo = self.tmp / "worker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(self.repo))
        self._git(self.repo, "config", "user.email", "w@t")
        self._git(self.repo, "config", "user.name", "w")
        self.state.write_text(json.dumps({
            "10": {"number": 10, "title": "Task ten", "state": "OPEN",
                   "stateReason": None,
                   "url": "https://github.com/example/repo/issues/10",
                   "body": issue_body(IMPL_CONTRACT), "labels": ["ready"], "comments": []},
        }, indent=2))
        self._env = {
            "PATH": f"{self.bin}:{os.environ['PATH']}",
            "GHT_TEST_STATE": str(self.state),
            "GHT_TEST_REAL_GIT": REAL_GIT,
            "GHT_EXECUTOR_ID": "worker-1",
            "GHT_LEASE_MINUTES": "45",
            "GHT_SPAWN_SUPERVISOR": "0",
            "GIT_AUTHOR_NAME": "w", "GIT_AUTHOR_EMAIL": "w@t",
            "GIT_COMMITTER_NAME": "w", "GIT_COMMITTER_EMAIL": "w@t",
        }

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    # -- harness --------------------------------------------------------

    def _write_executable(self, path, content):
        path.write_text(content)
        path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    def _git(self, cwd, *args, input_text=None):
        return subprocess.run([REAL_GIT, *args], cwd=cwd, capture_output=True, text=True,
                              env={**os.environ}, input=input_text)

    def _ght(self, *args, env_extra=None):
        env = {**self._env, **(env_extra or {})}
        return subprocess.run([sys.executable, str(CLI), "--json", *args],
                              cwd=str(self.repo), capture_output=True, text=True, env=env)

    def _ght_ok(self, *args, env_extra=None):
        result = self._ght(*args, env_extra=env_extra)
        self.assertEqual(result.returncode, 0, f"unexpected failure: {result.stdout} {result.stderr}")
        return json.loads(result.stdout)

    def _ght_fail(self, *args, env_extra=None):
        result = self._ght(*args, env_extra=env_extra)
        self.assertNotEqual(result.returncode, 0,
                            f"expected failure, got: {result.stdout} {result.stderr}")
        return result.stdout + result.stderr

    def _issue(self, number=10):
        return json.loads(self.state.read_text())[str(number)]

    def _update_issue(self, number, **changes):
        data = json.loads(self.state.read_text())
        data[str(number)].update(changes)
        self.state.write_text(json.dumps(data, indent=2))

    def _markers(self, number=10):
        return [c["body"] for c in self._issue(number)["comments"]
                if "ght:deliver:" in c["body"]]

    def _delete_mirror(self, number=10):
        data = json.loads(self.state.read_text())
        data[str(number)]["comments"] = [c for c in data[str(number)]["comments"]
                                         if "ght:deliver:" not in c["body"]]
        self.state.write_text(json.dumps(data, indent=2))

    def _lease_sha(self, claim_id):
        out = self._git(self.repo, "ls-remote", "origin",
                        LEASE_REF_FMT % claim_id).stdout.strip()
        return out.split()[0] if out else None

    def _parked(self, number=10, pr=60):
        """Drive one attempt to the parked condition: durable Candidate
        delivery with the Issue mirror published, capacity released, attempt
        still non-terminal."""
        claim = self._ght_ok("claim", str(number))
        self._git(self.repo, "checkout", "-q", "-b", claim["branch"], "origin/main")
        path = self.repo / "skills" / "demo.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("demo\n")
        self._git(self.repo, "add", "skills/demo.txt")
        self._git(self.repo, "commit", "-qm", "add demo")
        sha = self._git(self.repo, "rev-parse", "HEAD").stdout.strip()
        self._ght_ok("preserve", str(number))
        data = json.loads(self.state.read_text())
        data[str(pr)] = {"number": pr, "is_pr": True, "state": "OPEN",
                         "url": f"https://github.com/example/repo/pull/{pr}",
                         "headRefName": claim["branch"], "headRefOid": sha,
                         "mergeCommit": None, "reviews": [], "pr_comments": []}
        self.state.write_text(json.dumps(data, indent=2))
        self._ght_ok("deliver", str(number), "--pr", str(pr))
        return claim, sha

    # -- AC3: identity mismatches fail closed ----------------------------

    def test_readable_pr_with_moved_head_fails_closed_without_republish(self):
        # The PR re-proof is distinct from the #104 branch/checkout-HEAD
        # fences: the PR is readable and the branch and checkout still bind
        # the delivered Candidate exactly, but the PR itself now reports a
        # different head. That must fail closed — never reconcile as
        # "delivery already durable" and never republish the marker.
        claim, sha = self._parked(pr=60)
        self._delete_mirror(10)
        self.assertEqual(self._markers(10), [], "fixture: no mirror present")
        self._update_issue(60, headRefName="main")
        output = self._ght_fail("deliver", "10", "--pr", "60")
        self.assertIn("must never reconcile as 'delivery already durable'", output)
        self.assertEqual(self._markers(10), [],
                         "no marker is republished for an unproven PR head")
        inspected = self._ght_ok("inspect", "10")["claim"]
        self.assertEqual(inspected["delivery"]["sha"], sha,
                         "the durable delivery record is untouched")
        self.assertEqual(inspected["delivery"]["pr"], 60)
        self.assertIsNone(self._lease_sha(claim["claim_id"]),
                          "the failed retry mints no execution lease")

    def test_foreign_executor_cannot_repair_the_mirror(self):
        # Ownership is proven BEFORE the mirror is published: a foreign
        # executor (or a foreign GitHub principal) retrying the exact
        # delivery fails closed and must never write the Issue surface of
        # an attempt it does not own.
        claim, sha = self._parked(pr=60)
        self._delete_mirror(10)
        output = self._ght_fail("deliver", "10", "--pr", "60",
                                env_extra={"GHT_EXECUTOR_ID": "worker-2"})
        self.assertIn("not this caller's to reconcile", output)
        self.assertEqual(self._markers(10), [],
                         "a foreign executor must never publish the mirror")
        output = self._ght_fail("deliver", "10", "--pr", "60",
                                env_extra={"GHT_TEST_GITHUB_PRINCIPAL": "other-acct"})
        self.assertIn("not this caller's to reconcile", output)
        self.assertEqual(self._markers(10), [])
        inspected = self._ght_ok("inspect", "10")["claim"]
        self.assertEqual(inspected["delivery"]["sha"], sha)
        self.assertEqual(inspected["delivery"]["pr"], 60)
        self.assertEqual(inspected["claim_id"], claim["claim_id"])
        self.assertIsNone(self._lease_sha(claim["claim_id"]))

    def test_wrong_pr_retry_fails_closed_and_preserves_durable_delivery(self):
        # A retry naming a DIFFERENT PR whose head is not the preserved
        # Candidate is not a mirror repair and not a legal new delivery:
        # the ordinary delivery fence refuses it and the durable record
        # keeps binding the original PR.
        claim, sha = self._parked(pr=60)
        data = json.loads(self.state.read_text())
        data["61"] = {"number": 61, "is_pr": True, "state": "OPEN",
                      "url": "https://github.com/example/repo/pull/61",
                      "headRefName": "main", "headRefOid": "0" * 40,
                      "mergeCommit": None, "reviews": [], "pr_comments": []}
        self.state.write_text(json.dumps(data, indent=2))
        self._ght_ok("acquire", "10")
        output = self._ght_fail("deliver", "10", "--pr", "61")
        self.assertIn("PR head does not equal the preserved Candidate SHA", output)
        inspected = self._ght_ok("inspect", "10")["claim"]
        self.assertEqual(inspected["delivery"]["pr"], 60,
                         "the durable delivery still binds the original PR")
        self.assertEqual(inspected["delivery"]["sha"], sha)
        markers = self._markers(10)
        self.assertEqual(len(markers), 1, "no second delivery marker appears")
        self.assertIn("- pr: #60", markers[0])
        self.assertNotIn("- pr: #61", markers[0])

    # -- AC4: republication failures are explicit, never fake success ----

    def test_retry_comment_write_failure_reports_false_and_stays_repairable(self):
        claim, sha = self._parked(pr=60)
        self._delete_mirror(10)
        result = self._ght("deliver", "10", "--pr", "60",
                           env_extra={"GHT_TEST_FAIL_ISSUE_COMMENT": "1"})
        self.assertEqual(result.returncode, 0,
                         f"the delivery stays durable: {result.stdout} {result.stderr}")
        payload = json.loads(result.stdout)
        self.assertFalse(payload["comment_mirror_synced"])
        self.assertIn("comment_mirror_synced=false", result.stderr)
        self.assertIn("WARNING", result.stderr)
        self.assertEqual(self._markers(10), [])
        inspected = self._ght_ok("inspect", "10")["claim"]
        self.assertEqual(inspected["delivery"]["sha"], sha,
                         "the failed mirror repair never moves the durable record")
        self.assertEqual(inspected["delivery"]["pr"], 60)
        self.assertEqual(inspected["status"], "active")
        self.assertIsNone(self._lease_sha(claim["claim_id"]),
                          "capacity cleanup still reconciles without a new lease")
        # Safely idempotent: a later clean retry repairs the mirror.
        payload = self._ght_ok("deliver", "10", "--pr", "60")
        self.assertTrue(payload["comment_mirror_synced"])
        markers = self._markers(10)
        self.assertEqual(len(markers), 1)
        self.assertIn(f"ght:deliver:{claim['claim_id']}:{sha} -->", markers[0])

    def test_retry_comment_read_failure_reports_false_and_stays_repairable(self):
        # The evidence read inside the mirror publication is itself
        # unreadable while the PR surface stays readable — the repair
        # reports the mirror as not recovered instead of guessing.
        claim, sha = self._parked(pr=60)
        self._delete_mirror(10)
        result = self._ght("deliver", "10", "--pr", "60",
                           env_extra={"GHT_TEST_FAIL_ISSUE_VIEW_ONLY": "1"})
        self.assertEqual(result.returncode, 0,
                         f"the delivery stays durable: {result.stdout} {result.stderr}")
        payload = json.loads(result.stdout)
        self.assertFalse(payload["comment_mirror_synced"])
        self.assertIn("comment_mirror_synced=false", result.stderr)
        self.assertEqual(self._markers(10), [])
        inspected = self._ght_ok("inspect", "10")["claim"]
        self.assertEqual(inspected["delivery"]["sha"], sha)
        self.assertEqual(inspected["delivery"]["pr"], 60)
        payload = self._ght_ok("deliver", "10", "--pr", "60")
        self.assertTrue(payload["comment_mirror_synced"])
        self.assertEqual(len(self._markers(10)), 1)

    # -- AC2: an existing legal marker makes the retry a pure no-op ------

    def test_existing_marker_retry_is_side_effect_free(self):
        claim, sha = self._parked(pr=60)
        before_markers = self._markers(10)
        self.assertEqual(len(before_markers), 1)
        before_comments = self._issue(10)["comments"]
        before_labels = self._issue(10)["labels"]
        before = self._ght_ok("inspect", "10")["claim"]

        payload = self._ght_ok("deliver", "10", "--pr", "60")
        self.assertTrue(payload["comment_mirror_synced"])
        self.assertEqual(self._markers(10), before_markers,
                         "the existing marker is neither rewritten nor duplicated")
        self.assertEqual(self._issue(10)["comments"], before_comments,
                         "no comment of any kind is appended")
        self.assertEqual(self._issue(10)["labels"], before_labels,
                         "no lifecycle label appears")
        after = self._ght_ok("inspect", "10")["claim"]
        self.assertEqual(after["claim_id"], before["claim_id"])
        self.assertEqual(after["status"], before["status"])
        self.assertEqual(after["delivery"], before["delivery"],
                         "the delivery record is byte-identical after the retry")
        self.assertIsNone(self._lease_sha(claim["claim_id"]))
        self.assertEqual(
            self._git(self.repo, "ls-remote", "origin",
                      "refs/ght/claims-by-executor/*").stdout.strip(), "",
            "no executor reservation is minted")

        # The dedup truth is the marker read-back, not a write: with the
        # comment write surface down the retry still proves the existing
        # marker and reports synced without posting anything.
        payload = self._ght_ok("deliver", "10", "--pr", "60",
                               env_extra={"GHT_TEST_FAIL_ISSUE_COMMENT": "1"})
        self.assertTrue(payload["comment_mirror_synced"])
        self.assertEqual(self._markers(10), before_markers)


if __name__ == "__main__":
    unittest.main()
