"""#165: downstream bootstrap — the canonical installable release, host
preflight, and the one-time mechanical repository bootstrap.

The accepted model under test:

- **AC1** — every formal Harry Dev release exposes ONE canonical install
  surface: the release's pre-stamped ``github-task-<version>.zip``
  distribution asset. Installing it (download + extract) yields a
  deterministic B-side ``ght`` entrypoint whose ``ght version`` proves the
  release/source identity — with NO Harry Dev source checkout, NO
  release-tag checkout, and NO consumer-side ``stamp-distribution``.
- **AC2** — the supported-host contract is explicit (user-space POSIX,
  no root); ``ght preflight`` ESTABLISHES the non-secret local tooling in
  ONE pass over the standard host surfaces: missing ``gh`` on a supported
  platform is provisioned user-space from the official ``cli/cli`` release
  (never half-installed), missing executables degrade to probe-failure
  entries — never a crash — and the ONE remaining User-owned blocker is
  authentication consent (``gh auth login``). It uses ONLY standard
  host/GitHub credential surfaces (``gh --version``, ``gh api user``, the
  read-only collaborator permission probe) and never reads, prints, or
  persists raw credentials.
- **AC3** — for a provably uninitialized repository (NO ``refs/ght/runtime/*``),
  ``ght bootstrap`` is the pre-governance root-of-trust for the EXACT
  installed released identity only: publish THIS capsule → activate THIS
  identity → read back capsule immutability + the current ref — reusing
  the existing sync/activate/CAS internals, creating no new lifecycle
  state and granting no Issue authority. The transition is fenced against
  concurrency: any runtime ref that races into existence between the
  empty-namespace check and the activation fails bootstrap closed with
  the foreign project state untouched (activation itself is create-only).
- **AC4** — bootstrap never becomes an implicit upgrade: any pre-existing
  activated runtime identity is preserved; a different local identity
  stops through the existing freshness/upgrade authority boundary.
- **AC5** — successful bootstrap flows directly into ordinary B operation
  in the SAME activation: the bootstrap output IS a fresh discover
  verdict, and the canonical claim admission (``ght claim``) proceeds on
  the discovered direct-ready Issue with no second A/User permission
  round — the one-shot ``ready`` remains the only consumed authority.

All boundaries (gh, network, credentials) are faked offline, exactly like
the existing release-publication tests.
"""

import argparse
import hashlib
import io
import json
import os
import platform
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import unittest
import zipfile
from contextlib import contextmanager, redirect_stdout
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
CLI = SKILL_ROOT / "scripts" / "ght.py"
REAL_GIT = "/usr/bin/git"

VERSION = "v9.9.9"
ASSET_NAME = f"github-task-{VERSION}.zip"

# A real direct-ready test Issue on the synthetic target repository: open,
# `ready`-labeled, carrying one valid v1 Task Contract with implementation
# authority. This is the AC5 fixture — the only authorization that exists.
ISSUE_BODY = """# Ship the greeting endpoint

Planning notes that are NOT part of the Contract.

```ght-contract
version: 1
intent: >
  Serve a greeting over HTTP so the product demo works.
acceptance:
  - id: AC1
    requirement: GET /greeting returns 200 and a non-empty body.
authority:
  implementation: allowed
depends_on: []
scope:
  forbidden:
    - secrets/**
```"""

# Mock gh: the ONLY GitHub boundary the runtime may touch during install,
# preflight, bootstrap, discovery, and claim admission. It records every
# invocation (argv) so tests can prove which credential surfaces were used,
# it stores uploaded release assets on disk like the real CLI does, and —
# review R2 finding 2 — it VALIDATES argv shape like the real CLI does:
# `--repo` is accepted only before a repo-scoped subcommand (issue/pr/
# release/repo); `gh api` refuses it ("unknown flag: --repo"), so a mock
# can never hide invalid real-CLI argv from the tests.
MOCK_GH = r'''#!/usr/bin/env python3
import json, os, shutil, sys
args = sys.argv[1:]
state_path = os.environ["GHT_RELEASE_STATE"]
state = json.load(open(state_path)) if os.path.exists(state_path) else {
    "releases": {}, "issues": {}, "calls": []}
def save():
    json.dump(state, open(state_path, "w"))
state["calls"].append(args)
save()
REPO_SCOPED_COMMANDS = ("issue", "pr", "release", "repo")
if args[:1] == ["--repo"]:
    command = args[2] if len(args) > 2 else None
    if command not in REPO_SCOPED_COMMANDS:
        print("unknown flag: --repo", file=sys.stderr)
        raise SystemExit(2)
    args = args[2:]
def issue(number):
    return state["issues"].get(str(number))
if args[:1] == ["api"]:
    if "--repo" in args or "-R" in args:
        print("unknown flag: --repo", file=sys.stderr)
        raise SystemExit(2)
if args[:2] == ["api", "user"]:
    if os.environ.get("GHT_TEST_FAIL_API_USER") == "1":
        print("GET /user: OAuth token authentication failed", file=sys.stderr)
        raise SystemExit(1)
    print(os.environ.get("GHT_TEST_PRINCIPAL", "acct"))
    raise SystemExit(0)
if args[:2] == ["repo", "view"]:
    # The slug a real gh infers from the checkout's own remote — the cwd,
    # never the explicit --repo flag.
    print(os.environ.get("GHT_TEST_INFERRED_SLUG", "acme/target"))
    raise SystemExit(0)
if (args[:1] == ["api"] and len(args) > 1
        and "/collaborators/" in args[1] and args[1].endswith("/permission")):
    print(json.dumps({"permission":
                      os.environ.get("GHT_TEST_WRITE_PERMISSION", "admin")}))
    raise SystemExit(0)
if args[:2] == ["--version"]:
    print("gh version 2.0.0 (test)")
    raise SystemExit(0)
if args[:3] == ["api", "-X", "POST"] and len(args) > 3 and args[3].endswith("/releases"):
    body = json.loads(sys.stdin.read())
    tag = body["tag_name"]
    if tag in state["releases"]:
        print(json.dumps(state["releases"][tag]["release"]))
        raise SystemExit(0)
    rel = {"tag_name": tag, "name": body.get("name", tag),
           "draft": bool(body.get("draft")), "prerelease": bool(body.get("prerelease")),
           "body": body.get("body", ""), "id": 1, "assets": []}
    state["releases"][tag] = {"release": rel, "assets": {}}
    save()
    print(json.dumps(rel))
    raise SystemExit(0)
if args[:1] == ["api"] and len(args) > 1 and "/releases/tags/" in args[1]:
    tag = args[1].rsplit("/", 1)[-1]
    if tag in state["releases"]:
        rel = dict(state["releases"][tag]["release"])
        rel["assets"] = [{"name": name, "size": 1}
                         for name in sorted(state["releases"][tag]["assets"])]
        print(json.dumps(rel))
        raise SystemExit(0)
    print("Not Found", file=sys.stderr)
    raise SystemExit(1)
if args[:2] == ["release", "upload"]:
    # gh release upload <tag> <file...> [--clobber] — exactly like the real
    # CLI: an existing same-name asset FAILS unless --clobber is passed,
    # and the recorded argv proves whether the destructive flag was used.
    tag = args[2]
    clobber = "--clobber" in args
    files = [a for a in args[3:] if not a.startswith("-")]
    if tag not in state["releases"]:
        print("release not found", file=sys.stderr)
        raise SystemExit(1)
    for path in files:
        name = os.path.basename(path)
        dest = os.path.join(os.environ["GHT_ASSET_DIR"], name)
        if os.path.exists(dest) and not clobber:
            print("asset with name %r already exists; use --clobber to "
                  "overwrite" % name, file=sys.stderr)
            raise SystemExit(1)
        shutil.copyfile(path, dest)
        state["releases"][tag]["assets"][name] = {"size": os.path.getsize(path)}
    save()
    raise SystemExit(0)
if args[:2] == ["release", "download"]:
    # gh release download <tag> --pattern <name> --dir <dir> — serves the
    # stored asset bytes like the real CLI (the asset-reconciliation
    # read-back that must precede any idempotent re-publication).
    tag = args[2]
    pattern = args[args.index("--pattern") + 1]
    outdir = args[args.index("--dir") + 1]
    if tag not in state["releases"] or pattern not in \
            state["releases"][tag].get("assets", {}):
        print("no assets match the pattern %r" % pattern, file=sys.stderr)
        raise SystemExit(1)
    src = os.path.join(os.environ["GHT_ASSET_DIR"], pattern)
    os.makedirs(outdir, exist_ok=True)
    shutil.copyfile(src, os.path.join(outdir, pattern))
    raise SystemExit(0)
if args[:2] == ["issue", "list"]:
    ready = [n for n, i in state["issues"].items()
             if "ready" in [l.get("name") for l in i.get("labels", [])]]
    print(json.dumps([{"number": int(n)} for n in sorted(ready)]))
    raise SystemExit(0)
if args[:2] == ["issue", "view"]:
    data = issue(args[2])
    if data is None:
        print("not found", file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps(data))
    raise SystemExit(0)
if args[:2] == ["issue", "edit"]:
    number = args[2]
    data = issue(number)
    if data is None:
        print("not found", file=sys.stderr)
        raise SystemExit(1)
    if "--remove-label" in args:
        label = args[args.index("--remove-label") + 1]
        data["labels"] = [l for l in data.get("labels", [])
                          if l.get("name") != label]
    save()
    raise SystemExit(0)
if args[:2] == ["issue", "comment"]:
    if issue(args[2]) is None:
        print("not found", file=sys.stderr)
        raise SystemExit(1)
    raise SystemExit(0)
print("unsupported mock gh command: %s" % " ".join(args[:4]), file=sys.stderr)
raise SystemExit(1)
'''


class DownstreamBootstrapTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ght-bootstrap-"))
        # TWO independent repositories, exactly like the real downstream
        # topology: the Harry Dev SOURCE repository (where formal releases
        # are published) and the TARGET business repository (where B runs).
        self.origin = self.tmp / "harry-dev-origin.git"
        self.target_origin = self.tmp / "acme-origin.git"
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        (self.bin / "gh").write_text(MOCK_GH)
        (self.bin / "gh").chmod(os.stat(self.bin / "gh").st_mode | stat.S_IXUSR)
        self.state = self.tmp / "state.json"
        self.assets = self.tmp / "assets"
        self.assets.mkdir()
        self.state.write_text(json.dumps(
            {"releases": {}, "issues": {}, "calls": []}))
        self._git(self.tmp, "init", "--bare", str(self.origin), "-b", "main")
        seed = self.tmp / "seed"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(seed))
        (seed / "skills" / "github-task" / "scripts").mkdir(parents=True)
        (seed / "skills" / "github-task" / "scripts" / "ght.py").write_text(
            "# minimal ght runtime stub\n")
        (seed / "skills" / "github-task" / "SKILL.md").write_text("# skill\n")
        (seed / "README.md").write_text("seed\n")
        self._git(seed, "add", "-A")
        self._git(seed, "-c", "user.email=t@t", "-c", "user.name=t",
                  "commit", "-qm", "seed main")
        self._git(seed, "push", "-q", "origin", "HEAD:main")
        self.target = self._git(seed, "rev-parse", "HEAD").stdout.strip()
        self.notes = self.tmp / "notes.md"
        self.notes.write_text(f"# {VERSION}\n\nRelease notes body.\n")
        # The release machinery runs from a clone of the SOURCE repository.
        self.src_worker = self.tmp / "release-worker"
        self._git(self.tmp, "clone", "-q", str(self.origin), str(self.src_worker))
        # The synthetic target business repository: B's checkout, holding
        # no Harry Dev runtime refs and no Harry Dev source tree.
        self._git(self.tmp, "init", "--bare", str(self.target_origin), "-b", "main")
        biz = self.tmp / "biz-seed"
        self._git(self.tmp, "clone", "-q", str(self.target_origin), str(biz))
        (biz / "README.md").write_text("# ACME business repo\n")
        self._git(biz, "add", "-A")
        self._git(biz, "-c", "user.email=t@t", "-c", "user.name=t",
                  "commit", "-qm", "initial")
        self._git(biz, "push", "-q", "origin", "HEAD:main")
        self.worker = self.tmp / "acme-target"
        self._git(self.tmp, "clone", "-q", str(self.target_origin), str(self.worker))
        self._publish()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    # -- harness ---------------------------------------------------------

    def _git(self, cwd, *args, input_text=None):
        return subprocess.run(
            [REAL_GIT, *args], cwd=str(cwd), capture_output=True, text=True,
            input=input_text,
            env={**os.environ,
                 "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
                 "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t"})

    def _base_env(self):
        env = {
            "PATH": f"{self.bin}:{os.environ['PATH']}",
            "GHT_RELEASE_STATE": str(self.state),
            "GHT_ASSET_DIR": str(self.assets),
            "GHT_TEST_PRINCIPAL": "b-operator",
            "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
            "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t",
            "GHT_SPAWN_SUPERVISOR": "0",
            # The offline download seam is ALWAYS active for this suite: an
            # accidental provisioning attempt fails honestly against an
            # empty local dir instead of touching the network. Tests that
            # exercise provisioning override it with a fixture archive.
            "GHT_TEST_DOWNLOAD_DIR": str(self.tmp / "offline-downloads"),
        }
        if getattr(self, "installed", None):
            # The installed Skill distribution this B resolves its own ght
            # identity and runtime source from (the extracted release asset).
            env["GHT_INSTALLED_SKILL_DIR"] = str(self.installed)
            env["GHT_DISTRIBUTION_ROOT"] = str(self.installed)
        return env

    def _ght(self, *args, cwd=None, env_extra=None):
        env = self._base_env()
        env.update(env_extra or {})
        return subprocess.run([sys.executable, str(CLI), "--json", *args],
                              cwd=str(cwd or self.worker),
                              capture_output=True, text=True, env=env)

    # -- in-process harness (for concurrency-simulation fixtures) ---------

    def _inprocess_env(self, install=True):
        env = {
            "PATH": f"{self.bin}:{os.environ['PATH']}",
            "GHT_RELEASE_STATE": str(self.state),
            "GHT_ASSET_DIR": str(self.assets),
            "GHT_TEST_PRINCIPAL": "b-operator",
            "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t",
            "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t",
            "GHT_SPAWN_SUPERVISOR": "0",
        }
        if install and getattr(self, "installed", None):
            env["GHT_INSTALLED_SKILL_DIR"] = str(self.installed)
            env["GHT_DISTRIBUTION_ROOT"] = str(self.installed)
        return env

    @contextmanager
    def _in_process(self, env_extra=None, cwd=None, install=True):
        import github_task.cli as _cli  # noqa: F401 — the module under test
        env = self._inprocess_env(install=install)
        env.update(env_extra or {})
        old_cwd = os.getcwd()
        saved = {key: os.environ.get(key) for key in env}
        try:
            os.environ.update(env)
            os.chdir(str(cwd or self.worker))
            yield
        finally:
            for key, value in saved.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            os.chdir(old_cwd)

    def _bootstrap_inprocess(self, env_extra=None):
        """Run `ght bootstrap` in-process so a fixture can interleave a
        concurrent writer between its internal steps. Returns
        (code, stdout, CommandFailure | None)."""
        import github_task.cli as cli
        out = io.StringIO()
        with self._in_process(env_extra=env_extra):
            try:
                with redirect_stdout(out):
                    cli._cmd_bootstrap(argparse.Namespace(remote="origin",
                                                          repo=None))
                return 0, out.getvalue(), None
            except cli.CommandFailure as failure:
                return failure.code, out.getvalue(), failure

    def _publish_inprocess(self, env_extra=None):
        """Run `ght release-publish` in-process (same interleaving power)."""
        import github_task.cli as cli
        out = io.StringIO()
        with self._in_process(env_extra=env_extra, cwd=self.src_worker,
                              install=False):
            try:
                with redirect_stdout(out):
                    cli._cmd_release_publish(argparse.Namespace(
                        version=VERSION, target=self.target,
                        notes_file=str(self.notes), checkout=None,
                        remote="origin", repo=None))
                return 0, out.getvalue(), None
            except cli.CommandFailure as failure:
                return failure.code, out.getvalue(), failure

    def _foreign_runtime_commit(self, name="race-skill"):
        """A commit that stands for a foreign (non-bootstrap) runtime
        capsule object, created locally and NOT published."""
        tree = self._git(self.worker, "mktree", input_text="").stdout.strip()
        self.assertTrue(tree, "the empty foreign tree must exist")
        return self._git(self.worker, "commit-tree", tree,
                         "-m", f"foreign runtime {name}").stdout.strip()

    def _push_ref(self, sha, ref):
        pushed = self._git(self.worker, "push", "-q", "origin",
                           f"{sha}:{ref}")
        self.assertEqual(pushed.returncode, 0, pushed.stderr)


    def _publish(self):
        result = self._ght("release-publish", "--version", VERSION,
                           "--target", self.target,
                           "--notes-file", str(self.notes),
                           cwd=self.src_worker)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return json.loads(result.stdout)

    def _install_release_asset(self):
        """The downstream install act: download the release's distribution
        asset and extract it into the host's skill directory — nothing else
        (no source checkout, no stamp-distribution)."""
        dist_dir = self.tmp / "installed" / "github-task"
        asset = self.assets / ASSET_NAME
        self.assertTrue(asset.is_file(),
                        "the release must carry its distribution asset")
        with zipfile.ZipFile(asset) as archive:
            archive.extractall(dist_dir)
        self.installed = dist_dir
        return dist_dir

    def _seed_issue(self, number=42):
        self.state.write_text(json.dumps({
            "releases": json.loads(self.state.read_text())["releases"],
            "issues": {str(number): {
                "number": number,
                "title": "Ship the greeting endpoint",
                "body": ISSUE_BODY,
                "state": "open",
                "url": f"https://github.com/acme/target/issues/{number}",
                "labels": [{"name": "ready"}],
                "comments": [],
            }},
            "calls": json.loads(self.state.read_text())["calls"],
        }))

    def _pin(self):
        pin_sha = self._git(self.worker, "ls-remote", "origin",
                            "refs/ght/runtime/current").stdout.split()
        if not pin_sha:
            return None, None
        self._git(self.worker, "fetch", "-q", "origin",
                  "+refs/ght/runtime/current:refs/ght-read/pin")
        manifest = json.loads(self._git(
            self.worker, "show", "refs/ght-read/pin:MANIFEST.json").stdout)
        self._git(self.worker, "update-ref", "-d", "refs/ght-read/pin")
        return manifest, pin_sha[0]

    def _remote_runtime_refs(self):
        out = self._git(self.worker, "ls-remote", "origin",
                        "refs/ght/runtime/*").stdout
        return {line.split()[1]: line.split()[0]
                for line in out.splitlines() if line.strip()}

    def _stamp_tree(self, root, release, sha):
        """Fixture-only identity write (the producer-side manifest the
        reader enforces); used to synthesize *other* installed identities
        for refusal tests."""
        from github_task.cli import _write_distribution_manifest
        root.mkdir(parents=True, exist_ok=True)
        (root / "scripts").mkdir(exist_ok=True)
        (root / "scripts" / "ght.py").write_text("# other identity\n")
        (root / "SKILL.md").write_text("# other\n")
        _write_distribution_manifest(root, release, sha)
        return root

    def _other_capsule(self, release="v1.0.0"):
        """Publish + activate a DIFFERENT runtime identity in the target
        repo (simulating an already-initialized project)."""
        from github_task.cli import _write_distribution_manifest
        other = self.tmp / "other-skill"
        self._stamp_tree(other, release, "abc1234")
        result = self._ght("sync-runtime", "--source", str(other))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        digest = json.loads(result.stdout)["digest"]
        result = self._ght("activate-runtime", digest)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return digest

    # -- AC1: one canonical, pre-stamped install surface -----------------

    def test_release_asset_is_the_pre_stamped_install_surface(self):
        payload = self._publish()
        asset = payload.get("distribution_asset")
        self.assertIsNotNone(asset,
                             "the release must expose its install surface")
        self.assertEqual(asset["name"], ASSET_NAME)
        self.assertEqual(asset["digest"], payload["runtime"]["digest"],
                         "the install asset IS the runtime capsule payload")
        release = json.loads(self.state.read_text())["releases"][VERSION]
        self.assertIn(ASSET_NAME, release["assets"],
                      "the asset read-back must prove it is on the Release")
        # R1: the uploaded asset bytes are PROVEN identical to the published
        # capsule digest — the install surface IS the capsule, byte for byte.
        stored = (self.assets / ASSET_NAME).read_bytes()
        self.assertEqual(hashlib.sha256(stored).hexdigest(),
                         payload["runtime"]["digest"],
                         "the uploaded asset bytes are the published capsule")

        # The downstream install: download + extract. Nothing else.
        dist = self._install_release_asset()
        self.assertTrue((dist / "DISTRIBUTION.json").is_file(),
                        "the released distribution carries its identity")
        # `ght version` mechanically proves the release/source identity of
        # the installed tree — no source checkout, no consumer-side stamp.
        result = self._ght("version", cwd=self.worker)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        identity = json.loads(result.stdout)
        self.assertEqual(identity["status"], "released")
        self.assertEqual(identity["release"], VERSION)
        self.assertTrue(self.target.startswith(identity["source_sha"] or ""),
                        "the installed identity proves the released source")

    def test_republication_keeps_one_idempotent_asset(self):
        first = self._publish()
        again = self._publish()
        self.assertEqual(again["distribution_asset"]["digest"],
                         first["distribution_asset"]["digest"],
                         "the same stamped tree yields the same asset bytes")
        release = json.loads(self.state.read_text())["releases"][VERSION]
        self.assertEqual(sorted(release["assets"]), [ASSET_NAME],
                         "the asset is replaced, never duplicated")

    def test_release_asset_upload_honors_the_selected_repo(self):
        # R1: the distribution asset upload targets the explicitly selected
        # --repo, not whatever the cwd's remote happens to infer. R2
        # finding 4: the upload is NOT destructive — no --clobber — and it
        # happens only when the asset is ABSENT (an existing asset is
        # reconciled in place), so this retry starts from an absent asset.
        self._publish()
        state = json.loads(self.state.read_text())
        del state["releases"][VERSION]["assets"][ASSET_NAME]
        self.state.write_text(json.dumps(state))
        (self.assets / ASSET_NAME).unlink()
        before = len(state["calls"])
        result = self._ght("--repo", "acme/target", "release-publish",
                           "--version", VERSION,
                           "--target", self.target,
                           "--notes-file", str(self.notes),
                           cwd=self.src_worker,
                           env_extra={"GHT_TEST_INFERRED_SLUG":
                                      "harryhua-ai/harry-dev"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        calls = json.loads(self.state.read_text())["calls"][before:]
        uploads = [call for call in calls
                   if call[:5] == ["--repo", "acme/target", "release",
                                   "upload", VERSION]]
        self.assertTrue(uploads, f"the asset upload must happen: {calls}")
        for call in uploads:
            self.assertNotIn("--clobber", call,
                             f"the reconciliation never uploads destructively: {call}")

    def test_release_asset_bytes_are_proven_to_be_the_published_capsule(self):
        # R1: the asset bytes are never silently re-serialized — the exact
        # uploaded payload must hash to the published capsule digest, and
        # any divergence fails the release closed BEFORE the upload.
        self._publish()
        import github_task.cli as cli
        real_payload = cli._runtime_capsule_payload
        serializations = {"n": 0}

        def tampered_payload(source):
            payload, manifest = real_payload(source)
            serializations["n"] += 1
            if serializations["n"] == 2:  # the second pass is the asset
                payload = payload + b"tampered"
            return payload, manifest

        cli._runtime_capsule_payload = tampered_payload
        try:
            code, out, failure = self._publish_inprocess()
        finally:
            cli._runtime_capsule_payload = real_payload
        self.assertIsNotNone(
            failure,
            "asset bytes that diverge from the published capsule digest "
            "must fail the release closed")
        self.assertIn("digest", str(failure))
        release = json.loads(self.state.read_text())["releases"][VERSION]
        self.assertEqual(sorted(release["assets"]), [ASSET_NAME],
                         "the earlier honest upload is not replaced by "
                         "divergent bytes")
        stored = (self.assets / ASSET_NAME).read_bytes()
        self.assertNotIn(b"tampered", stored,
                         "the tampered serialization never reached the "
                         "release")

    def test_release_asset_reconciliation_reuses_an_already_correct_asset(self):
        # R2 finding 4: a retry over a Release that already carries the
        # canonical asset must NOT re-upload destructively — the existing
        # asset is read back and digest-verified in place; only a missing
        # asset is uploaded.
        self._publish()
        stored = (self.assets / ASSET_NAME).read_bytes()
        before = len(json.loads(self.state.read_text())["calls"])
        again_result = self._ght("release-publish", "--version", VERSION,
                                 "--target", self.target,
                                 "--notes-file", str(self.notes),
                                 cwd=self.src_worker)
        self.assertEqual(again_result.returncode, 0,
                         again_result.stdout + again_result.stderr)
        again = json.loads(again_result.stdout)
        calls = json.loads(self.state.read_text())["calls"][before:]
        uploads = [call for call in calls if "upload" in call]
        self.assertFalse(
            uploads,
            f"an already-correct install asset is verified in place, never "
            f"re-uploaded: {calls}")
        self.assertEqual((self.assets / ASSET_NAME).read_bytes(), stored,
                         "the completed install surface is untouched")
        self.assertEqual(again["distribution_asset"]["state"], "reconciled",
                         "the retry reports reconciliation, not an upload")
        release = json.loads(self.state.read_text())["releases"][VERSION]
        self.assertEqual(sorted(release["assets"]), [ASSET_NAME])

    def test_release_asset_reconciliation_fails_closed_on_a_divergent_asset(self):
        # R2 finding 4: a Release already carrying the canonical asset NAME
        # over divergent bytes (prior partial write / human error) is a
        # completed install surface — reconciliation must fail closed with
        # an actionable message and NEVER issue a destructive overwrite.
        self._publish()
        divergent = b"divergent prior install surface"
        (self.assets / ASSET_NAME).write_bytes(divergent)
        before = len(json.loads(self.state.read_text())["calls"])
        result = self._ght("release-publish", "--version", VERSION,
                           "--target", self.target,
                           "--notes-file", str(self.notes),
                           cwd=self.src_worker)
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("never overwritten", result.stdout,
                      "the refusal must name the never-overwrite guarantee")
        calls = json.loads(self.state.read_text())["calls"][before:]
        self.assertFalse([call for call in calls if "upload" in call],
                         f"no destructive upload may happen: {calls}")
        self.assertEqual((self.assets / ASSET_NAME).read_bytes(), divergent,
                         "the previously completed install surface survives")

    # -- AC2: supported-host preflight ------------------------------------

    def _fake_gh_archive(self, downloads: Path):
        """The offline stand-in for the official cli/cli release archive,
        served for THIS test host's platform (see _build_gh_archive)."""
        import github_task.cli as cli
        return self._build_gh_archive(downloads, platform.system())

    def _build_gh_archive(self, downloads: Path, system: str):
        """Build the offline stand-in for the official cli/cli release
        archive in the REAL upstream layout (review R2 finding 1; R3
        finding 5a): verified against the actual cli/cli release assets
        (e.g. v2.63.0), BOTH the macOS zip and the linux tar.gz carry ONE
        versioned top-level directory ``gh_<version>_<platform>_<arch>/``
        whose ``bin/gh`` is the binary alongside the real accompanying
        members (``LICENSE`` and the ``share/man`` man pages) — the
        fixture must model that real root shape, not a permissive
        self-confirming one-member skeleton. Served from a local directory
        through the offline download seam under the SAME canonical URL
        pattern production resolves. The archived binary reports the
        pinned version and delegates every real command to the suite's
        mock gh. Returns (archive_path, archive_name)."""
        import github_task.cli as cli
        machine = {"Darwin": "arm64", "Linux": "amd64"}[system]
        url = cli._gh_download_url(cli.GH_PROVISION_VERSION, system, machine)
        name = url.rsplit("/", 1)[-1]
        version = cli.GH_PROVISION_VERSION
        top = name[:-4]  # gh_<v>_<os>_<arch> — the REAL upstream root
        shim = (
            f"#!{sys.executable}\n"
            "import os, sys\n"
            "args = sys.argv[1:]\n"
            "if args[:1] == ['--version']:\n"
            f"    print('gh version {version} (test-provisioned)')\n"
            "    raise SystemExit(0)\n"
            "mock = os.environ['GHT_MOCK_GH_PATH']\n"
            "os.execv(sys.executable, [sys.executable, mock] + args)\n")
        members = {
            f"{top}/bin/gh": shim,
            f"{top}/LICENSE": "MIT License\n",
            f"{top}/share/man/man1/gh.1.gz": "man page payload\n",
        }
        archive_path = downloads / name
        if name.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "w") as archive:
                for member, content in members.items():
                    archive.writestr(member, content)
        else:
            with tarfile.open(archive_path, "w:gz") as archive:
                for member, content in members.items():
                    data = content.encode()
                    info = tarfile.TarInfo(member)
                    info.size = len(data)
                    info.mode = 0o755 if member.endswith("/gh") else 0o644
                    archive.addfile(info, io.BytesIO(data))
        return archive_path, name

    def _assert_real_gh_archive_layout(self, archive_path: Path):
        """R3 finding 5a: the fixture must ITSELF match the documented real
        upstream layout — exactly one versioned top-level directory whose
        name matches the canonical asset name, carrying bin/gh, LICENSE,
        and the share/man pages — so a fixture drift can never re-enable a
        permissive extraction."""
        import github_task.cli as cli
        name = archive_path.name
        top = name[:-4]
        expected = {f"{top}/bin/gh", f"{top}/LICENSE",
                    f"{top}/share/man/man1/gh.1.gz"}
        if name.endswith(".zip"):
            with zipfile.ZipFile(archive_path) as archive:
                names = set(archive.namelist())
                binary = archive.read(f"{top}/bin/gh")
        else:
            with tarfile.open(archive_path, "r:gz") as archive:
                names = {m.name for m in archive.getmembers() if m.isfile()}
                binary = archive.extractfile(f"{top}/bin/gh").read()
        self.assertEqual(names, expected,
                         f"the fixture must model the real upstream archive "
                         f"root exactly: {sorted(names)}")
        self.assertIn("gh version", binary.decode(),
                      "bin/gh inside the real layout must be the gh binary")
        # And the runtime's member locator must pick bin/gh out of the
        # full real member set — not merely tolerate a one-member archive.
        self.assertEqual(cli._gh_archive_member(sorted(names)), f"{top}/bin/gh")

    def test_preflight_reports_supported_host_state(self):
        result = self._ght("preflight")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(result.stdout)
        self.assertTrue(report["ok"], report)
        self.assertEqual(report["auth"]["principal"], "b-operator")
        self.assertTrue(report["tools"]["git"]["ok"])
        self.assertTrue(report["tools"]["gh"]["ok"])
        self.assertEqual(report["repo"], "acme/target")
        self.assertFalse(report["runtime"]["initialized"],
                         "an uninitialized repo is reported as such")
        self.assertEqual(report["blockers"], [])
        # The proven repository write permission (the mutating bootstrap
        # phase must never be entered on an unproven credential).
        self.assertTrue(report["write_access"]["ok"], report)
        self.assertFalse(report["provision"]["attempted"],
                         "an already-resolvable gh is never re-provisioned")

    def test_preflight_collects_every_blocker_in_one_failure(self):
        # R1/review: GENUINE executable removal — PATH contains ONLY an
        # empty controlled directory, so neither git nor gh can resolve
        # from any host fallback. Both probes degrade to blocker entries
        # inside the ONE report (never an unhandled crash), the offline
        # provisioning attempt fails honestly with the precise manual
        # fallback, and nothing half-installs.
        empty_bin = self.tmp / "empty-bin"
        empty_bin.mkdir()
        downloads = self.tmp / "empty-downloads"
        downloads.mkdir()
        tool_bin = self.tmp / "empty-toolbin"
        result = self._ght("preflight", env_extra={
            "PATH": str(empty_bin),
            "GHT_TOOL_BIN_DIR": str(tool_bin),
            "GHT_TEST_DOWNLOAD_DIR": str(downloads)})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        combined = result.stdout + result.stderr
        self.assertNotIn("Traceback", combined,
                         "a missing executable must degrade, never crash")
        self.assertNotIn("FileNotFoundError", combined)
        self.assertIn("git", result.stdout)
        self.assertIn("gh", result.stdout)
        self.assertIn("cli.github.com", result.stdout,
                      "the manual fallback stays precise and actionable")
        self.assertFalse((tool_bin / "gh").exists(),
                         "a failed provisioning never half-installs")
        self.assertFalse(json.loads(result.stdout)["provision"]["installed"])

    def test_preflight_provisions_missing_gh_user_space_official_upstream(self):
        # AC2 (R1): a supported host without gh is ESTABLISHED by preflight
        # itself — the official cli/cli release archive (served offline by
        # the fixture) is installed into the canonical user-space tool dir,
        # verified, and the preflight continues on the provisioned binary,
        # so the ONE remaining User-owned step is authentication consent.
        tool_bin = self.tmp / "toolbin"
        downloads = self.tmp / "downloads"
        downloads.mkdir()
        self._fake_gh_archive(downloads)
        import github_task.cli as cli
        git_dir = self.tmp / "gitonly-bin"
        git_dir.mkdir()
        (git_dir / "git").symlink_to(shutil.which("git"))
        # Genuinely no gh on PATH: PATH is ONLY the git-only directory.
        result = self._ght("preflight", env_extra={
            "PATH": str(git_dir),
            "GHT_TOOL_BIN_DIR": str(tool_bin),
            "GHT_TEST_DOWNLOAD_DIR": str(downloads),
            "GHT_MOCK_GH_PATH": str(self.bin / "gh")})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(result.stdout)
        self.assertTrue(report["ok"], report)
        self.assertTrue(report["tools"]["gh"]["ok"])
        self.assertTrue(report["provision"]["installed"], report)
        self.assertEqual(report["provision"]["path"], str(tool_bin / "gh"))
        self.assertEqual(report["provision"]["version"],
                         cli.GH_PROVISION_VERSION,
                         "the installed version is recorded")
        self.assertTrue(report["provision"]["source_url"].startswith(
            "https://github.com/cli/cli/releases/download/"),
            report["provision"])
        self.assertTrue((tool_bin / "gh").is_file())
        self.assertEqual(report["auth"]["principal"], "b-operator",
                         "post-provisioning the standard credential surface "
                         "is used; only auth consent stays User-owned")
        self.assertEqual(report["blockers"], [])
        marker = json.loads((tool_bin / "gh-provision.json").read_text())
        self.assertEqual(marker["version"], report["provision"]["version"])
        self.assertEqual(marker["source_url"],
                         report["provision"]["source_url"])
        # R2 finding 3: on the EXACT fresh-host path (gh exists only at the
        # provisioned user-space location, and the credential probe fails),
        # the auth blocker must hand the User the executable, copy-pasteable
        # command — the absolute path of the provisioned gh — with no PATH
        # editing and no binary discovery.
        result = self._ght("preflight", env_extra={
            "PATH": str(git_dir),
            "GHT_TOOL_BIN_DIR": str(tool_bin),
            "GHT_TEST_DOWNLOAD_DIR": str(downloads),
            "GHT_MOCK_GH_PATH": str(self.bin / "gh"),
            "GHT_TEST_FAIL_API_USER": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(result.stdout)
        self.assertTrue(report["provision"]["installed"] or
                        (tool_bin / "gh").is_file())
        exact = f"{tool_bin / 'gh'} auth login"
        self.assertIn(exact, result.stdout,
                      "the auth blocker must carry the executable command "
                      "for the provisioned gh")
        self.assertEqual(report["auth"]["login_command"], exact)

    def test_provisioned_tool_dir_is_preferred_on_later_invocations(self):
        # The binary-resolution seam prefers the provisioned location over
        # PATH: with a PATH that resolves gh NOWHERE, a pre-provisioned
        # tool dir still yields a fully working gh surface.
        tool_bin = self.tmp / "resolved-toolbin"
        tool_bin.mkdir(parents=True)
        (tool_bin / "gh").write_text(MOCK_GH)
        (tool_bin / "gh").chmod(os.stat(tool_bin / "gh").st_mode | stat.S_IXUSR)
        # PATH resolves python3 (the mock's interpreter) and git, but
        # never gh.
        py_bin = self.tmp / "pyonly-bin"
        py_bin.mkdir()
        (py_bin / "python3").symlink_to(sys.executable)
        (py_bin / "git").symlink_to(shutil.which("git"))
        result = self._ght("preflight", env_extra={
            "PATH": str(py_bin),
            "GHT_TOOL_BIN_DIR": str(tool_bin)})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(result.stdout)
        self.assertTrue(report["tools"]["gh"]["ok"], report)
        self.assertTrue(report["tools"]["git"]["ok"])
        self.assertFalse(report["provision"]["attempted"],
                         "an already-resolvable gh is never re-provisioned")

    def test_provisioning_fails_closed_when_the_archive_lacks_the_gh_binary(self):
        # R2 finding 1 (fail-closed leg): an archive that looks like an
        # official release asset but does not carry the REAL upstream
        # binary path gh_<version>_<platform>_<arch>/bin/gh must fail
        # provisioning closed — nothing is installed, never a half-install.
        tool_bin = self.tmp / "no-binary-toolbin"
        downloads = self.tmp / "no-binary-downloads"
        downloads.mkdir()
        import github_task.cli as cli
        system, machine = platform.system(), platform.machine()
        url = cli._gh_download_url(cli.GH_PROVISION_VERSION, system, machine)
        name = url.rsplit("/", 1)[-1]
        archive_path = downloads / name
        filler = b"not the gh binary"
        if name.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr(name[:-4] + "/LICENSE", filler)
        else:
            with tarfile.open(archive_path, "w:gz") as archive:
                import io as _io
                info = tarfile.TarInfo(name[:-4] + "/LICENSE")
                info.size = len(filler)
                archive.addfile(info, _io.BytesIO(filler))
        git_dir = self.tmp / "gitonly-nobin"
        git_dir.mkdir()
        (git_dir / "git").symlink_to(shutil.which("git"))
        result = self._ght("preflight", env_extra={
            "PATH": str(git_dir),
            "GHT_TOOL_BIN_DIR": str(tool_bin),
            "GHT_TEST_DOWNLOAD_DIR": str(downloads),
            "GHT_MOCK_GH_PATH": str(self.bin / "gh")})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(result.stdout)
        self.assertFalse(report["provision"]["installed"], report["provision"])
        self.assertFalse((tool_bin / "gh").exists(), "never a half-install")
        self.assertIn("bin/gh", report["provision"]["declined"],
                      "the refusal names the real upstream binary path")

    def test_explicit_repo_keeps_repo_independent_gh_calls_valid(self):
        # R2 finding 2: `gh api user` is a GLOBAL-scope command — the real
        # CLI refuses `gh --repo X api user` ("unknown flag: --repo"), so
        # the explicit repository selection may ride only repo-scoped
        # subcommands. The strengthened mock enforces that argv shape, so
        # this test can no longer be satisfied by invalid real-CLI argv.
        # (R3 finding 4: the remote carries a GitHub-shaped URL through
        # the offline mirror so the same-repository proof is resolvable.)
        self._point_remote_at_github_mirror("origin", "acme/target")
        self._seed_issue(42)
        result = self._ght("--repo", "acme/target", "preflight",
                           env_extra={"GHT_TEST_INFERRED_SLUG": "acme/target"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        calls = json.loads(self.state.read_text())["calls"]
        principal_calls = [call for call in calls if call[:2] == ["api", "user"]]
        self.assertTrue(principal_calls, "the principal read must happen")
        for argv in principal_calls:
            self.assertEqual(argv, ["api", "user", "--jq", ".login"],
                             "the repo-independent principal read carries "
                             f"exactly the global argv: {argv}")
        probes = [call for call in calls
                  if call[:1] == ["api"] and "/collaborators/" in (call[1] if len(call) > 1 else "")]
        self.assertTrue(probes)
        for argv in probes:
            self.assertNotIn("--repo", argv,
                             "repo-scoped API calls carry the slug in the "
                             f"path, never the flag: {argv}")
            self.assertEqual(argv[1],
                             "repos/acme/target/collaborators/"
                             "b-operator/permission")
        # Repo-scoped subcommands DO carry the explicit repo (an
        # initialized runtime so discovery actually reads its surfaces).
        self._install_release_asset()
        self._ght("bootstrap")
        result = self._ght("--repo", "acme/target", "discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        calls = json.loads(self.state.read_text())["calls"]
        listings = [call for call in calls
                    if len(call) > 2 and call[2] == "issue"]
        self.assertTrue(listings, "discovery must read the issue surface")
        for argv in listings:
            self.assertEqual(argv[:3], ["--repo", "acme/target", "issue"],
                             f"repo-scoped subcommands carry the selection: {argv}")

    def test_preflight_honors_explicit_repo_and_refuses_a_mismatch(self):
        # R1: the explicit --repo is never dropped by preflight — the report
        # names the selected repository, and a checkout whose inferred
        # origin differs fails closed instead of probing the wrong repo.
        # (R3 finding 4: the remote carries a GitHub-shaped URL through
        # the offline mirror so the same-repository proof is resolvable.)
        self._point_remote_at_github_mirror("origin", "acme/target")
        result = self._ght("--repo", "acme/other", "preflight",
                           env_extra={"GHT_TEST_INFERRED_SLUG": "acme/target"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["repo"], "acme/other")
        self.assertTrue(any("acme/other" in blocker
                            and "acme/target" in blocker
                            for blocker in payload["blockers"]),
                        payload["blockers"])
        # And the matching explicit repo is honored end to end.
        result = self._ght("--repo", "acme/target", "preflight")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(json.loads(result.stdout)["repo"], "acme/target")

    def test_preflight_uses_only_standard_credential_surfaces(self):
        before = len(json.loads(self.state.read_text())["calls"])
        self._ght("preflight")
        calls = json.loads(self.state.read_text())["calls"][before:]
        self.assertTrue(calls, "preflight must exercise the gh boundary")
        for argv in calls:
            head = tuple(argv[:2])
            if head == ("--version",) or head == ("repo", "view"):
                continue
            if head == ("api", "user"):
                continue
            self.assertEqual(head[0], "api", f"non-standard credential "
                             f"surface used: {argv}")
            self.assertIn("/collaborators/", head[1],
                          f"non-standard credential surface used: {argv}")
            self.assertNotIn("token", " ".join(argv),
                             "ght never reads or relays raw credential material")

    def test_auth_blocker_names_the_exact_executable_login_command(self):
        # R2 finding 3: when gh resolves but the credential probe fails,
        # the ONE User-owned blocker must hand over the executable,
        # copy-pasteable `auth login` command — the resolved absolute gh
        # path — so the User never discovers a binary or edits PATH.
        result = self._ght("preflight",
                           env_extra={"GHT_TEST_FAIL_API_USER": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(result.stdout)
        self.assertTrue(report["tools"]["gh"]["ok"], report)
        self.assertIsNone(report["auth"]["principal"])
        resolved = shutil.which("gh", path=self._base_env()["PATH"])
        exact = f"{resolved} auth login"
        self.assertIn(exact, result.stdout,
                      "the blocker must carry the executable, copy-pasteable "
                      "command")
        self.assertEqual(report["auth"]["login_command"], exact)
        self.assertNotIn("export PATH", result.stdout,
                         "the User is never asked to edit PATH")

    def test_preflight_fails_closed_on_unsupported_platform(self):
        # R1: the declared support boundary is macOS/Linux user-space POSIX.
        # Outside it, preflight fails closed with the precise blocker and
        # provisioning DECLINES — it never half-installs on an unsupported
        # platform.
        import github_task.cli as cli
        empty_bin = self.tmp / "noplat-bin"
        empty_bin.mkdir()
        downloads = self.tmp / "noplat-downloads"
        downloads.mkdir()
        tool_bin = self.tmp / "noplat-toolbin"
        with self._in_process(env_extra={
                "PATH": str(empty_bin),
                "GHT_TOOL_BIN_DIR": str(tool_bin),
                "GHT_TEST_DOWNLOAD_DIR": str(downloads)},
                cwd=self.tmp):
            real_system = platform.system
            platform.system = lambda: "Windows"
            try:
                report = cli._host_preflight_report("origin")
            finally:
                platform.system = real_system
        self.assertFalse(report["ok"])
        self.assertTrue(any("Windows" in blocker or "unsupported" in
                            blocker.lower() for blocker in report["blockers"]),
                        report["blockers"])
        self.assertFalse(report["provision"]["attempted"],
                         "provisioning declines on unsupported platforms")
        self.assertFalse((tool_bin / "gh").exists(), "never a half-install")

    def test_preflight_and_bootstrap_share_one_initialized_definition(self):
        # R1: preflight and bootstrap answer 'is the runtime namespace
        # initialized?' from ONE shared predicate. An orphan capsule (a
        # refs/ght/runtime/<digest> without the pin) IS initialized for
        # both surfaces — preflight reports it as such and bootstrap
        # refuses it with the same never-touch guarantee.
        from github_task.cli import _write_distribution_manifest
        orphan = self.tmp / "orphan-skill"
        orphan.mkdir()
        (orphan / "scripts").mkdir()
        (orphan / "scripts" / "ght.py").write_text("# orphan\n")
        _write_distribution_manifest(orphan, "v0.7.0", "beefcafe")
        result = self._ght("sync-runtime", "--source", str(orphan))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(self._ght("preflight").stdout)
        self.assertTrue(report["runtime"]["initialized"],
                        "an orphan runtime namespace IS initialized — the "
                        "same answer bootstrap gives")
        self.assertIsNone(report["runtime"]["pin"],
                          "an orphan namespace carries no pin")
        self._install_release_asset()
        result = self._ght("bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("initialized", result.stdout)
        self.assertEqual(len(self._remote_runtime_refs()), 1,
                         "bootstrap never touches the orphan namespace")

    def test_bootstrap_requires_proven_write_access_before_mutation(self):
        # R1: preflight proves the authenticated principal can actually
        # write the target repository BEFORE the mutating bootstrap phase;
        # a read-only credential yields the ONE actionable blocker and
        # zero partial mutation.
        self._install_release_asset()
        self._seed_issue(42)
        result = self._ght("bootstrap",
                           env_extra={"GHT_TEST_WRITE_PERMISSION": "read"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("write access", result.stdout)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "no runtime ref is published without proven write "
                         "access")

    def test_preflight_proves_the_mutation_transport_not_just_the_api_probe(self):
        # R2 finding 5: a `gh` API permission check alone does NOT prove
        # that `git push` through the configured remote can write. With the
        # push URL broken while the fetch URL (and the gh API leg) stay
        # intact, preflight must fail closed on the unproven mutation
        # transport instead of claiming end-to-end write access.
        self._git(self.worker, "remote", "set-url", "--push", "origin",
                  str(self.tmp / "broken-push-remote.git"))
        result = self._ght("preflight")
        self.assertNotEqual(result.returncode, 0,
                            "a passing gh API permission probe must not be "
                            "reported as proven repository write access")
        report = json.loads(result.stdout)
        self.assertFalse(report["write_access"]["ok"])
        self.assertTrue(report["write_access"]["api_permission_probe"]["ok"],
                        "the gh API leg passed — preflight must word its "
                        "claim so the API probe alone is never the write "
                        "proof")
        self.assertFalse(report["write_access"]["push_transport"]["ok"])
        self.assertTrue(any("push" in blocker.lower()
                            for blocker in report["blockers"]),
                        report["blockers"])
        self.assertEqual(self._remote_runtime_refs(), {})

    def test_bootstrap_requires_the_mutation_transport_before_publishing(self):
        # R2 finding 5 (bootstrap leg): the bootstrap preamble proves the
        # actual mutation transport (`git push --dry-run` — read-only to
        # refs) BEFORE any mutation; a credential that answers the gh API
        # but cannot push fails closed with the precise blocker and
        # publishes nothing.
        self._install_release_asset()
        self._seed_issue(42)
        self._git(self.worker, "remote", "set-url", "--push", "origin",
                  str(self.tmp / "broken-push-remote.git"))
        result = self._ght("bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("mutation transport", result.stdout)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "nothing is published over an unproven transport")
        # Once the transport is restored, the identical invocation succeeds.
        self._git(self.worker, "remote", "set-url", "--push", "origin",
                  str(self.target_origin))
        result = self._ght("bootstrap")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(json.loads(result.stdout)["action"], "claim")

    def test_preflight_reports_installed_release_provenance(self):
        # R2 provenance disposition: preflight reports the installed
        # distribution's release provenance facts (content verified against
        # the digest recorded at stamp time) — honestly, as facts; the
        # bootstrap gate is where an unprovable identity refuses.
        self._install_release_asset()
        report = json.loads(self._ght("preflight").stdout)
        provenance = report["installed_provenance"]
        self.assertTrue(provenance["verified"], provenance)
        self.assertEqual(provenance["release"], VERSION)
        # A drifted installed tree is reported honestly.
        (self.installed / "SKILL.md").write_text("# drifted after install\n")
        report = json.loads(self._ght("preflight").stdout)
        self.assertFalse(report["installed_provenance"]["verified"],
                         report["installed_provenance"])

    # -- AC3: one-time mechanical bootstrap -------------------------------

    def test_bootstrap_publishes_activates_reads_back_and_flows_into_discover(self):
        self._install_release_asset()
        self._seed_issue(42)
        result = self._ght("bootstrap")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        decision = json.loads(result.stdout)

        # The bootstrap facts prove the exact installed release identity.
        boot = decision["bootstrap"]
        self.assertEqual(boot["status"], "bootstrapped")
        self.assertEqual(boot["release"], VERSION)
        self.assertTrue(self.target.startswith(boot["source_sha"]))

        # Remote read-back: capsule + current ref are the SAME object and
        # the manifest proves the installed identity.
        refs = self._remote_runtime_refs()
        pin_manifest, pin_sha = self._pin()
        self.assertIsNotNone(pin_manifest)
        self.assertEqual(refs.get("refs/ght/runtime/current"), pin_sha)
        self.assertEqual(refs.get(f"refs/ght/runtime/{boot['digest']}"), pin_sha,
                         "pin and capsule are one published object")
        self.assertEqual(pin_manifest["release"], VERSION)
        self.assertEqual(pin_manifest["digest"], boot["digest"])

        # AC5: the SAME activation already carries the fresh discovery
        # verdict — here the one eligible direct-ready Issue.
        self.assertEqual(decision["action"], "claim")
        self.assertEqual(decision["issue"], 42)

    # -- #166: first adoption applies the project AGENTS contract --------

    def test_bootstrap_applies_the_project_agents_contract_on_first_adoption(self):
        from github_task.agents_contract import MANAGED_BLOCK
        self._install_release_asset()
        self.assertFalse((self.worker / "AGENTS.md").exists())
        result = self._ght("bootstrap")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        decision = json.loads(result.stdout)
        # The SAME activation carries the AGENTS reconciliation facts.
        self.assertEqual(decision["agents"]["status"], "created")
        self.assertEqual(decision["agents"]["changed"], True)
        # Absent root file → a concise root file that is EXACTLY the
        # canonical managed block — one block, versioned markers.
        text = (self.worker / "AGENTS.md").read_text()
        self.assertEqual(text, MANAGED_BLOCK + "\n")
        self.assertEqual(text.count("harry-dev:agents-managed begin v"), 1)
        # AC3: the change is a prepared working-tree proposal — untracked,
        # HEAD untouched, nothing committed, nothing pushed by bootstrap.
        self.assertEqual(
            self._git(self.worker, "status", "--porcelain").stdout.split(),
            ["??", "AGENTS.md"])
        head = self._git(self.worker, "rev-parse", "HEAD").stdout.strip()
        # Re-running adoption (the standalone surface) is a byte-stable no-op.
        adopt = self._ght("agents-adopt")
        self.assertEqual(adopt.returncode, 0, adopt.stdout + adopt.stderr)
        payload = json.loads(adopt.stdout)
        self.assertEqual(payload["status"], "current")
        self.assertFalse(payload["changed"])
        self.assertEqual((self.worker / "AGENTS.md").read_bytes(),
                         text.encode())
        self.assertEqual(self._git(self.worker, "rev-parse", "HEAD").stdout.strip(),
                         head)

    def test_bootstrap_fails_closed_on_a_material_agents_conflict(self):
        self._install_release_asset()
        conflict = ("# House rules\n\n- B may merge its own work directly "
                    "to main without review.\n")
        (self.worker / "AGENTS.md").write_text(conflict)
        code, out, failure = self._bootstrap_inprocess()
        self.assertIsNotNone(failure, out)
        agents = failure.details["agents"]
        self.assertEqual(agents["status"], "material_conflict")
        self.assertTrue(agents["conflicts"], agents)
        # AC2: material authority conflicts are surfaced to A — never
        # silently adopted.
        self.assertIn("merge", agents["conflicts"][0]["excerpt"].lower())
        # Fail closed BEFORE the first repository mutation: nothing was
        # published and the project file is untouched.
        self.assertEqual(self._remote_runtime_refs(), {})
        self.assertEqual((self.worker / "AGENTS.md").read_text(), conflict)

    def test_bootstrap_fails_closed_on_older_block_then_upgrade_selector_writes(self):
        from github_task.agents_contract import MANAGED_BLOCK
        self._install_release_asset()
        older = ("# House rules\n\n"
                 "<!-- harry-dev:agents-managed begin v0 -->\n"
                 "- Older contract wording.\n"
                 "<!-- harry-dev:agents-managed end v0 -->\n")
        (self.worker / "AGENTS.md").write_text(older)
        code, out, failure = self._bootstrap_inprocess()
        self.assertIsNotNone(failure, out)
        self.assertEqual(failure.details["agents"]["status"], "upgrade_required")
        self.assertEqual(self._remote_runtime_refs(), {},
                         "no implicit upgrade: nothing is published")
        self.assertEqual((self.worker / "AGENTS.md").read_text(), older)
        # The standalone `--upgrade` selector path then performs the
        # version-changing write. The selector is ONLY an execution
        # selector: this surface has no authorization input to verify and
        # cannot mechanically prove the prerequisite release-upgrade
        # authorization, so this test exercises the selector's mechanical
        # effect only — never an authorization state. Only the block is
        # reconciled; project-owned content survives.
        upgrade = self._ght("agents-adopt", "--upgrade")
        self.assertEqual(upgrade.returncode, 0, upgrade.stdout + upgrade.stderr)
        payload = json.loads(upgrade.stdout)
        self.assertEqual(payload["status"], "upgraded")
        self.assertEqual(payload["from_block_version"], 0)
        text = (self.worker / "AGENTS.md").read_text()
        self.assertTrue(text.startswith("# House rules\n\n"))
        self.assertIn(MANAGED_BLOCK, text)
        self.assertEqual(text.count("harry-dev:agents-managed begin v"), 1)
        # ... and the SAME one bootstrap path then completes first adoption.
        self._seed_issue(42)
        result = self._ght("bootstrap")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        decision = json.loads(result.stdout)
        self.assertEqual(decision["bootstrap"]["status"], "bootstrapped")
        self.assertEqual(decision["agents"]["status"], "current")

    def test_bootstrap_claim_admission_consumes_only_the_ready_authority(self):
        self._install_release_asset()
        self._seed_issue(42)
        decision = json.loads(self._ght("bootstrap").stdout)
        self.assertEqual(decision["action"], "claim")

        # The canonical claim admission runs with no second permission
        # round: the durable one-shot `ready` is the only authority.
        result = self._ght("claim", "42")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        claim = json.loads(result.stdout)
        self.assertEqual(claim["issue"], 42)
        issue = json.loads(self.state.read_text())["issues"]["42"]
        self.assertEqual([l["name"] for l in issue["labels"]], [],
                         "the one-shot ready was consumed by the claim")
        # The attempt durably binds the bootstrapped runtime identity —
        # the existing binding semantics, unchanged (read from the durable
        # claim ref, not the command's stdout summary).
        self._git(self.worker, "fetch", "-q", "origin",
                  f"+{claim['ref']}:refs/ght-read/claim42")
        record = json.loads(self._git(
            self.worker, "show", "refs/ght-read/claim42:CLAIM.json").stdout)
        self._git(self.worker, "update-ref", "-d", "refs/ght-read/claim42")
        self.assertEqual(record.get("runtime", {}).get("digest"),
                         decision["bootstrap"]["digest"])

    def test_bootstrap_requires_a_released_installed_identity(self):
        # An unstamped/dev installation never bootstraps: the pre-governance
        # root transition materializes ONLY an exact released identity.
        dev_dist = self.tmp / "dev-dist"
        dev_dist.mkdir()
        (dev_dist / "scripts").mkdir()
        (dev_dist / "scripts" / "ght.py").write_text("# dev\n")
        result = self._ght("bootstrap", env_extra={
            "GHT_INSTALLED_SKILL_DIR": str(dev_dist),
            "GHT_DISTRIBUTION_ROOT": str(dev_dist)})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("released", result.stdout)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "nothing is published from an unreleased install")

    def test_bootstrap_refuses_a_tampered_installed_tree(self):
        # R2 provenance disposition: a locally modified tree that RETAINS
        # its DISTRIBUTION.json must never bootstrap — the released
        # determination derives from the installed tree verifying against
        # the release digest recorded at stamp time (the existing
        # formal-release provenance fact), not from the manifest's claim
        # alone.
        self._install_release_asset()
        ght_script = self.installed / "scripts" / "ght.py"
        ght_script.write_text(ght_script.read_text() + "\n# tampered\n")
        result = self._ght("bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("does not match its stamped", result.stdout)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "a tampered tree is never materialized")

    def test_bootstrap_refuses_a_forged_release_claim(self):
        # R2 provenance disposition (manifest-side tamper): editing the
        # claimed release in DISTRIBUTION.json breaks the recorded identity
        # binding — bootstrap refuses instead of materializing the forged
        # identity.
        self._install_release_asset()
        manifest_path = self.installed / "DISTRIBUTION.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["release"] = "v0.0.1"
        manifest_path.write_text(json.dumps(manifest))
        result = self._ght("bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("does not verify", result.stdout)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "a forged identity claim is never materialized")

    def test_bootstrap_requires_an_uninitialized_runtime_namespace(self):
        # Any pre-existing refs/ght/runtime/* means this is NOT the
        # pre-governance transition — bootstrap refuses before publishing.
        from github_task.cli import _write_distribution_manifest
        orphan = self.tmp / "orphan-skill"
        orphan.mkdir()
        (orphan / "scripts").mkdir()
        (orphan / "scripts" / "ght.py").write_text("# orphan\n")
        _write_distribution_manifest(orphan, "v0.9.0", "deadbee")
        result = self._ght("sync-runtime", "--source", str(orphan))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        before = self._remote_runtime_refs()
        self._install_release_asset()
        result = self._ght("bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self._remote_runtime_refs(), before,
                         "bootstrap never touches an existing runtime namespace")

    # -- R1: the bootstrap transition is fenced against concurrency --------

    def test_bootstrap_fences_a_runtime_pin_that_races_in_during_publish(self):
        # A foreign runtime pin that appears between bootstrap's initial
        # empty-namespace check and its activation fails the whole
        # bootstrap closed: the activation never runs, the foreign pin is
        # untouched, and nothing is deleted or overwritten.
        self._install_release_asset()
        foreign_sha = self._foreign_runtime_commit()
        activated = {"called": False}
        import github_task.cli as cli
        real_sync = cli._cmd_sync_runtime
        real_activate = cli._cmd_activate_runtime

        def racing_sync(args):
            # The concurrent writer lands after the capsule publish, before
            # the fence re-lists the namespace.
            real_sync(args)
            self._push_ref(foreign_sha, cli.RUNTIME_PIN_REF)

        def spy_activate(args):
            activated["called"] = True
            return real_activate(args)

        cli._cmd_sync_runtime = racing_sync
        cli._cmd_activate_runtime = spy_activate
        try:
            code, out, failure = self._bootstrap_inprocess()
        finally:
            cli._cmd_sync_runtime = real_sync
            cli._cmd_activate_runtime = real_activate
        self.assertIsNotNone(failure,
                             "bootstrap must fail closed on the racing pin")
        self.assertEqual(failure.code, cli.OWNERSHIP_LOST)
        self.assertFalse(activated["called"],
                         "the activation must never run past the fence")
        self.assertEqual(
            self._git(self.worker, "ls-remote", "origin",
                      cli.RUNTIME_PIN_REF).stdout.split()[:1] or [None],
            [foreign_sha],
            "the foreign pin is untouched — never moved, never deleted")

    def test_bootstrap_activation_is_create_only_against_a_racing_pin(self):
        # The residual window: the fence read a clean namespace, then the
        # foreign writer lands right before the pin push. Bootstrap's
        # activation is CREATE-ONLY — it refuses and leaves the foreign
        # pin exactly as the concurrent writer left it.
        self._install_release_asset()
        foreign_sha = self._foreign_runtime_commit()
        import github_task.cli as cli
        real_refs = cli._remote_runtime_refs
        real_activate = cli._cmd_activate_runtime
        fence_calls = {"n": 0}

        def fenced_refs(ctx):
            fence_calls["n"] += 1
            refs = real_refs(ctx)
            if fence_calls["n"] == 2:
                # fence #1 reads BEFORE the concurrent writer's push lands
                return {ref: sha for ref, sha in refs.items()
                        if ref != cli.RUNTIME_PIN_REF}
            return refs

        def racing_activate(args):
            self._push_ref(foreign_sha, cli.RUNTIME_PIN_REF)
            return real_activate(args)

        cli._remote_runtime_refs = fenced_refs
        cli._cmd_activate_runtime = racing_activate
        try:
            code, out, failure = self._bootstrap_inprocess()
        finally:
            cli._remote_runtime_refs = real_refs
            cli._cmd_activate_runtime = real_activate
        self.assertIsNotNone(failure,
                             "create-only activation must refuse a pin that "
                             "raced in")
        self.assertEqual(failure.code, cli.OWNERSHIP_LOST)
        self.assertEqual(
            self._git(self.worker, "ls-remote", "origin",
                      cli.RUNTIME_PIN_REF).stdout.split()[:1] or [None],
            [foreign_sha],
            "the racing foreign pin is untouched")
        # Our own capsule was published before the fence — the refusal
        # deleted nothing.
        refs = self._remote_runtime_refs()
        self.assertEqual(len(refs), 2, refs)
        self.assertIn(cli.RUNTIME_PIN_REF, refs)

    # -- AC4: bootstrap never becomes an implicit upgrade ------------------

    def test_bootstrap_never_moves_an_activated_project_pin(self):
        other_digest = self._other_capsule()
        before_manifest, before_sha = self._pin()
        self._install_release_asset()
        result = self._ght("bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("refresh", result.stdout.lower(),
                      "the mismatch stops through the freshness boundary")
        after_manifest, after_sha = self._pin()
        self.assertEqual(after_sha, before_sha,
                         "the project pin is never moved by bootstrap")
        self.assertEqual(after_manifest["digest"], other_digest)
        # And the existing freshness authority still applies to discover:
        result = self._ght("discover")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(json.loads(result.stdout)["action"], "refresh_required")

    def test_bootstrap_stops_when_the_installed_identity_is_already_current(self):
        self._install_release_asset()
        first = self._ght("bootstrap")
        self.assertEqual(first.returncode, 0, first.stdout + first.stderr)
        again = self._ght("bootstrap")
        self.assertNotEqual(again.returncode, 0, again.stdout + again.stderr)
        self.assertIn("discover", again.stdout,
                      "an initialized, current repo routes to ordinary discovery")

    # -- R3 finding 5a: the fixture IS the real upstream archive shape ----

    def test_fake_gh_archive_fixture_models_the_real_upstream_archive(self):
        # The offline fixture must model/assert the REAL upstream archive
        # root — one versioned top-level dir carrying bin/gh, LICENSE, and
        # the share/man pages — for BOTH the macOS zip and the linux
        # tar.gz forms, and the runtime's member locator must pick bin/gh
        # out of the full member set (not merely tolerate a one-member
        # skeleton that would confirm any shape).
        for system in ("Darwin", "Linux"):
            downloads = self.tmp / f"layout-downloads-{system}"
            downloads.mkdir()
            archive_path, name = self._build_gh_archive(downloads, system)
            self.assertTrue(archive_path.is_file(), name)
            self._assert_real_gh_archive_layout(archive_path)

    def test_a_permissive_wrong_layout_archive_is_refused(self):
        # The realistic permissive shapes an older/looser extractor would
        # accept — a binary at the archive root's bin/gh (no versioned
        # top-level dir) — must fail closed.
        import github_task.cli as cli
        for names in (["bin/gh", "LICENSE"],
                      [f"gh_{cli.GH_PROVISION_VERSION}_linux_amd64/bin/gh/gh"],
                      [f"gh_{cli.GH_PROVISION_VERSION}_linux_amd64/LICENSE"]):
            with self.assertRaises(cli.CommandFailure):
                cli._gh_archive_member(names)

    # -- R3 finding 5b: the auth command is shell-quoted ------------------

    def test_auth_login_command_is_shell_quoted(self):
        # The copy-pasteable auth command must survive a tool dir whose
        # path carries a space: it must parse back as exactly one command
        # (the resolved gh path) plus the `auth login` subcommand.
        tool_bin = self.tmp / "tool bin"
        downloads = self.tmp / "quoted-downloads"
        downloads.mkdir()
        self._fake_gh_archive(downloads)
        git_dir = self.tmp / "quoted-git-bin"
        git_dir.mkdir()
        (git_dir / "git").symlink_to(shutil.which("git"))
        result = self._ght("preflight", env_extra={
            "PATH": str(git_dir),
            "GHT_TOOL_BIN_DIR": str(tool_bin),
            "GHT_TEST_DOWNLOAD_DIR": str(downloads),
            "GHT_MOCK_GH_PATH": str(self.bin / "gh"),
            "GHT_TEST_FAIL_API_USER": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(result.stdout)
        login = report["auth"]["login_command"]
        parts = shlex.split(login)
        self.assertEqual(parts[1:], ["auth", "login"],
                         f"the command must parse as one command + auth login: {login!r}")
        self.assertEqual(parts[0], str(tool_bin / "gh"), login)
        self.assertIn(shlex.quote(str(tool_bin / "gh")) + " auth login",
                      result.stdout,
                      "the blocker must carry the shell-quoted copy-pasteable command")

    # -- R3 finding 2: the fresh-host first entry reaches bootstrap --------

    def test_fresh_host_discover_reaches_the_bootstrap_preflight_path(self):
        # The documented first entry (`ght discover`) must reach the
        # supported-host bootstrap/preflight path on a fresh host — no gh
        # on PATH, uninitialized repository, unauthenticated credential —
        # instead of dying in principal-dependent Context construction:
        # gh is provisioned user-space, the ONE remaining blocker is the
        # exact auth consent command, `ght bootstrap` is named, and the
        # exit fails closed without any runtime mutation.
        tool_bin = self.tmp / "fresh tool bin"
        downloads = self.tmp / "fresh-downloads"
        downloads.mkdir()
        self._fake_gh_archive(downloads)
        git_dir = self.tmp / "fresh-git-bin"
        git_dir.mkdir()
        (git_dir / "git").symlink_to(shutil.which("git"))
        result = self._ght("discover", env_extra={
            "PATH": str(git_dir),
            "GHT_TOOL_BIN_DIR": str(tool_bin),
            "GHT_TEST_DOWNLOAD_DIR": str(downloads),
            "GHT_MOCK_GH_PATH": str(self.bin / "gh"),
            "GHT_TEST_FAIL_API_USER": "1"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        combined = result.stdout + result.stderr
        self.assertNotIn("Traceback", combined, "the first entry never crashes")
        self.assertIn("ght preflight", combined)
        self.assertIn("ght bootstrap", combined,
                      "the first entry must name the bootstrap path")
        payload = json.loads(result.stdout)
        self.assertTrue(payload["preflight"]["provision"]["installed"],
                        payload.get("preflight", {}).get("provision"))
        self.assertTrue((tool_bin / "gh").is_file(),
                        "the first entry establishes the missing tooling")
        blockers = payload["preflight"]["blockers"]
        self.assertEqual(len(blockers), 1, blockers)
        self.assertIn(shlex.quote(str(tool_bin / "gh")) + " auth login",
                      blockers[0], blockers)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "the first entry mutates no runtime state")

    def test_discover_initialized_repo_with_missing_gh_keeps_existing_semantics(self):
        # With an INITIALIZED runtime the entry ordering must not reroute:
        # missing gh keeps the existing principal-refusal behavior, and no
        # provisioning side effect happens (this is entry-order only).
        self._install_release_asset()
        self._seed_issue(42)
        self._ght("bootstrap")
        before = self._remote_runtime_refs()
        empty_tool = self.tmp / "empty-initialized-tool"
        git_dir = self.tmp / "initialized-git-bin"
        git_dir.mkdir()
        (git_dir / "git").symlink_to(shutil.which("git"))
        result = self._ght("discover", env_extra={
            "PATH": str(git_dir),
            "GHT_TOOL_BIN_DIR": str(empty_tool)})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        combined = result.stdout + result.stderr
        self.assertNotIn("Traceback", combined)
        self.assertIn("principal", combined,
                      "the existing no-principal failure class is unchanged")
        self.assertNotIn("ght preflight", combined,
                         "an initialized repository is not rerouted into preflight")
        self.assertFalse((empty_tool / "gh").exists(),
                         "the initialized path never provisions")
        self.assertEqual(self._remote_runtime_refs(), before)

    # -- R3 finding 3: the push probe claims only what it proves -----------

    def test_push_probe_claim_states_exactly_what_was_proven(self):
        # `git push --dry-run` does NOT send an update and can succeed where
        # the real update is rejected (server hooks/rules/update-time
        # authorization). The write_access facts must state exactly what
        # was proven — transport reachable + authenticated at probe time —
        # and must explicitly disclaim update authorization.
        report = json.loads(self._ght("preflight").stdout)
        push = report["write_access"]["push_transport"]
        self.assertIn("reachable", push["proves"], push)
        self.assertIn("authenticated", push["proves"], push)
        self.assertNotIn("authoriz", push["proves"].lower(),
                         "the proves-claim must never claim authorization")
        self.assertIn("authorization", push["does_not_prove"].lower(), push)

    def test_real_update_rejection_fails_closed_reconcilable_and_honest(self):
        # The realistic rejection fixture the review asked for: a
        # server-side update policy (modeled by a pre-receive hook on the
        # bare remote) REJECTS the real update while the dry-run succeeds —
        # proving the probe cannot prove update authorization. Bootstrap
        # must fail closed on the real rejection, surface the server's
        # rejection (actionable), leave the durable state unchanged, and
        # be reconcilable once the policy is lifted.
        hook = self.target_origin / "hooks" / "pre-receive"
        hook.parent.mkdir(exist_ok=True)
        hook.write_text("#!/bin/sh\n"
                        "echo 'policy: runtime ref updates rejected' >&2\n"
                        "exit 1\n")
        hook.chmod(0o755)
        # Fixture shape proof: dry-run succeeds while updates are rejected.
        dry = self._git(self.worker, "push", "--dry-run", "origin",
                        "HEAD:refs/ght/runtime/write-probe")
        self.assertEqual(dry.returncode, 0, dry.stdout + dry.stderr)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "the dry-run proved nothing was sent")
        self._install_release_asset()
        self._seed_issue(42)
        result = self._ght("bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        combined = result.stdout + result.stderr
        self.assertIn("reject", combined.lower(),
                      "the server's rejection must be surfaced verbatim")
        self.assertEqual(self._remote_runtime_refs(), {},
                         "nothing is published over a rejected update")
        # Reconcilable: lifting the policy lets the identical invocation
        # complete the same transition.
        hook.unlink()
        result = self._ght("bootstrap")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(json.loads(result.stdout)["action"], "claim")

    # -- R3 finding 1: the producer→consumer provenance chain --------------

    def test_provenance_digest_survives_the_download_extract_round_trip(self):
        # The content-binding digest is the identity of file BYTES + paths.
        # A real install is download + extract, and extraction does not
        # carry unix modes; a digest that varies with the exec bit would
        # refuse every legitimate install of a distribution with
        # executable files — the chain must hold for the real bytes.
        import github_task.cli as cli
        tree = self.tmp / "exec-dist"
        (tree / "scripts").mkdir(parents=True)
        ght = tree / "scripts" / "ght.py"
        ght.write_text("# runtime\n")
        ght.chmod(0o755)
        (tree / "SKILL.md").write_text("# skill\n")
        cli._write_distribution_manifest(tree, "v1.2.3", "abc1234")
        stamped = cli._release_content_provenance(tree)
        self.assertTrue(stamped["verified"], stamped)
        payload, _manifest = cli._runtime_capsule_payload(tree)
        install_dir = self.tmp / "extracted-install"
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            archive.extractall(install_dir)
        provenance = cli._release_content_provenance(install_dir)
        self.assertTrue(provenance["verified"],
                        "the download+extract install must verify: "
                        f"{provenance}")

    def test_bootstrap_refuses_a_self_reauthored_manifest_and_tree(self):
        # Consumer adversarial (finding 1): re-authoring the installed tree
        # AND recomputing the recorded binding is self-consistent — the
        # local manifest verification alone passes it. Bootstrap must
        # corroborate the installed identity against the canonical durable
        # release surface (the published Release asset bytes) and refuse;
        # it must never manufacture release truth from the mutable local
        # manifest alone.
        self._install_release_asset()
        (self.installed / "scripts" / "ght.py").write_text("# re-authored\n")
        from github_task.cli import _write_distribution_manifest
        manifest = json.loads((self.installed / "DISTRIBUTION.json").read_text())
        # The maximally self-consistent forgery keeps every recorded fact
        # (release, source, release repository) and only re-authors the
        # tree + recomputed binding.
        _write_distribution_manifest(self.installed, manifest["release"],
                                     manifest["source_sha"],
                                     release_repo=manifest.get("release_repo"))
        result = self._ght("bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("canonical release asset", result.stdout)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "a self-consistent local forgery never materializes")

    def test_bootstrap_refuses_when_the_recorded_release_is_not_canonical(self):
        # Consumer adversarial (finding 1), release-side: a re-authored
        # manifest claiming a release that does not exist on the recorded
        # release repository must fail the corroboration lookup closed —
        # never publish a capsule for it.
        self._install_release_asset()
        from github_task.cli import _write_distribution_manifest
        manifest = json.loads((self.installed / "DISTRIBUTION.json").read_text())
        _write_distribution_manifest(self.installed, "v8.8.8",
                                     manifest["source_sha"])
        result = self._ght("bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("canonical release", result.stdout)
        self.assertEqual(self._remote_runtime_refs(), {})

    def test_bootstrap_capsule_is_the_canonical_release_asset_byte_for_byte(self):
        # The chain closes on the consumer side too: the capsule bootstrap
        # publishes IS the canonical release asset, byte for byte — the
        # installed tree can only publish what the durable release surface
        # provably carries.
        self._install_release_asset()
        self._seed_issue(42)
        decision = json.loads(self._ght("bootstrap").stdout)
        digest = decision["bootstrap"]["digest"]
        stored = (self.assets / ASSET_NAME).read_bytes()
        self.assertEqual(digest, hashlib.sha256(stored).hexdigest(),
                         "the published capsule is the canonical release asset")

    def _point_remote_at_github_mirror(self, name: str, slug: str) -> None:
        """Model a GitHub-shaped remote URL offline: the remote's URL is
        the canonical github.com form while git insteadOf rewrites the
        transport to a local bare mirror — so the configured URL identity
        (what the same-repo proof must read) and the offline transport
        stay independent."""
        mirror_root = self.tmp / "gh-mirror"
        mirror = mirror_root / f"{slug}.git"
        mirror.parent.mkdir(parents=True, exist_ok=True)
        self._git(self.tmp, "clone", "--bare", "-q", str(self.target_origin),
                  str(mirror))
        exists = self._git(self.worker, "remote").stdout.split()
        if name in exists:
            self._git(self.worker, "remote", "set-url", name,
                      f"https://github.com/{slug}.git")
        else:
            self._git(self.worker, "remote", "add", name,
                      f"https://github.com/{slug}.git")
        self._git(self.worker, "config", f"url.{mirror_root}/.insteadOf",
                  "https://github.com/")

    def test_preflight_refuses_a_push_url_pointing_at_a_different_repository(self):
        # R3 finding 4: the permission probe and the git mutation must
        # target the SAME repository. With explicit --repo acme/target
        # while the selected remote's push URL points at other/repo,
        # preflight fails closed BEFORE any mutation attempt — the API leg
        # passing never licenses a cross-repo push.
        self._git(self.worker, "remote", "set-url", "--push", "origin",
                  "https://github.com/other/repo.git")
        self._seed_issue(42)
        result = self._ght("--repo", "acme/target", "preflight",
                           env_extra={"GHT_TEST_INFERRED_SLUG": "acme/target"})
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(result.stdout)
        self.assertFalse(report["write_access"]["ok"])
        self.assertTrue(report["write_access"]["api_permission_probe"]["ok"],
                        "the API leg passed — the same-repository boundary "
                        "is what refuses")
        same = report["write_access"]["same_repository"]
        self.assertFalse(same["ok"], same)
        self.assertEqual(same["push_slug"], "other/repo", same)
        self.assertEqual(same["expected_slug"], "acme/target", same)
        self.assertTrue(any("same repository" in blocker.lower()
                            for blocker in report["blockers"]),
                        report["blockers"])
        self.assertEqual(self._remote_runtime_refs(), {})
        # The mutating surface inherits the same refusal.
        self._install_release_asset()
        result = self._ght("--repo", "acme/target", "bootstrap")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self._remote_runtime_refs(), {},
                         "no runtime ref is pushed across the authority boundary")

    def test_non_default_remote_is_honored_end_to_end(self):
        # R3 finding 4 (honored leg): with a non-default --remote, the
        # permission probe and the runtime-ref push BOTH go through the
        # selected remote's URL — here "upstream", modeled GitHub-shaped
        # and rewritten offline to a local bare mirror by git insteadOf.
        self._point_remote_at_github_mirror("upstream", "acme/target")
        self._install_release_asset()
        self._seed_issue(42)
        result = self._ght("--remote", "upstream", "--repo", "acme/target",
                           "preflight")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads(result.stdout)
        self.assertTrue(report["write_access"]["ok"], report)
        self.assertEqual(report["write_access"]["push_transport"]["remote"],
                         "upstream")
        self.assertTrue(report["write_access"]["same_repository"]["ok"])
        result = self._ght("--remote", "upstream", "--repo", "acme/target",
                           "bootstrap")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        out = self._git(self.worker, "ls-remote", "upstream",
                        "refs/ght/runtime/*").stdout
        self.assertIn("refs/ght/runtime/current", out,
                      "the runtime refs are published through the selected remote")

    # -- the not-activated discovery failure names the mechanical path -----

    def test_discover_without_runtime_names_the_bootstrap_path(self):
        result = self._ght("discover")
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("ght bootstrap", result.stdout)


if __name__ == "__main__":
    unittest.main()
