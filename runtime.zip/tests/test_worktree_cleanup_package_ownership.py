"""Package-ownership conformance for #155: the canonical fenced worktree
cleanup implementation (``worktree_cleanup.py``, #147/#154 semantics) is
owned by the complete standalone ``github-task`` Skill package — the B-side
execution-resource lifecycle — not by the Harry Dev source root.

Failure class pinned here: an isolated installed Skill (a temp copy of
``skills/github-task/``, no Harry Dev source tree, beside an unrelated
fresh git repository) cannot perform canonical fenced cleanup because the
implementation still lives at the repository root
(``scripts/worktree_cleanup.py``). The installed package must carry the
cleanup entrypoint itself, and the repository root must keep no duplicate
canonical copy.

The behavioral proof reuses the #147/#154 fencing semantics end to end
through the installed CLI: dry-run is the default and never deletes; a
reclaimable worktree is removed only after the atomic
``ght reclaim-execution-resource`` authorization and confirmed afterward;
a refused authorization fences fail-closed; a canonically ACTIVE resource
with live capacity stays non-deletable and is never even authorized.
ght is faked hermetically at its CLI boundary (network/gh not required);
the run happens in a clean environment with cwd inside the unrelated
target repository, and a Python audit hook proves the isolated package
never opens the Harry Dev source tree.

R1 failure class (default-invocation package ownership): the normal
cleanup invocation — no explicit ``--ght`` — must resolve canonical ght
from the installed Skill itself (the ``ght.py`` packaged beside the
cleanup helper), never from the target repository. The retired resolver
assumed ``<target-repo>/skills/github-task/scripts/ght.py``; a downstream
business repo carries no Skill copy, so that assumption degraded every
normal invocation to unreadable truth — fail-closed, but unable to clean.
The R0 isolated evidence always passed ``--ght`` explicitly and therefore
never exercised the default resolver; the tests below close exactly that
gap (a decoy planted at the retired target-repo path must stay unrun).
"""

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).parents[1]
SOURCE_ROOT = Path(__file__).parents[3]
PKG_HELPER = SKILL_ROOT / "scripts" / "worktree_cleanup.py"
REPO_ROOT_HELPER = SOURCE_ROOT / "scripts" / "worktree_cleanup.py"


def _clean_env(home: str) -> dict[str, str]:
    """A host shell without any pointer into the Harry Dev source tree."""
    return {"PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "HOME": home,
            "PYTHONPATH": "",
            "GHT_DISTRIBUTION_ROOT": "",
            "LC_ALL": "C"}


def _fake_ght_script(claim_marker: str = "a") -> str:
    """Source of the hermetic fake ght CLI (see :func:`_fake_ght`).

    ``claim_marker`` names the claim_sha the fake reports, so two fake
    installations are distinguishable at the authorization boundary —
    used to prove an explicit ``--ght`` override really wins.
    """
    return (
        "import json, os, sys\n"
        "args = sys.argv[1:]\n"
        "log = os.environ.get('FAKE_GHT_LOG')\n"
        "if log:\n"
        "    with open(log, 'a') as fh:\n"
        "        fh.write(json.dumps(args) + chr(10))\n"
        "if args and args[0] == 'status':\n"
        "    if os.environ.get('FAKE_GHT_MODE') == 'protect':\n"
        "        print(json.dumps({'executor_id': 'worker-1',"
        " 'active_claims': [{'issue': 555, 'attempt_state': 'ACTIVE',"
        " 'execution_capacity': {'state': 'live'}}]}))\n"
        "    else:\n"
        "        print(json.dumps({'executor_id': 'worker-1',"
        " 'active_claims': []}))\n"
        "elif args and args[0] == 'inspect':\n"
        "    if os.environ.get('FAKE_GHT_MODE') == 'protect':\n"
        "        print(json.dumps({'issue': 555,\n"
        "            'claim': {'status': 'active',"
        " 'executor_id': 'worker-1', 'candidate': None},\n"
        "            'claim_state': 'ACTIVE',\n"
        f"            'claim_sha': '{claim_marker}' * 40}}))\n"
        "    else:\n"
        "        print(json.dumps({'issue': 555,\n"
        "            'claim': {'status': 'delivered',"
        " 'executor_id': 'worker-1',\n"
        "                      'candidate': 'abc123def456'},\n"
        "            'claim_state': 'TERMINAL',\n"
        f"            'claim_sha': '{claim_marker}' * 40}}))\n"
        "elif args and args[0] == 'reclaim-execution-resource':\n"
        "    if '--confirm-removal' in args:\n"
        "        print(json.dumps({'ok': True}))\n"
        "    elif os.environ.get('FAKE_GHT_MODE') == 'authorize':\n"
        "        print(json.dumps({'marker_sha': 'm' * 40}))\n"
        "    else:\n"
        "        print(json.dumps({'error': 'reclaim authorization "
        "refused by fixture'}))\n"
        "        sys.exit(2)\n"
        "else:\n"
        "    sys.exit(3)\n")


def _fake_ght(tmp, mode):
    """Hermetic fake ght CLI for the installed-package exercise.

    Modes: ``authorize`` — readable canonical truth (TERMINAL claim with a
    claim_sha) whose reclaim authorization succeeds and confirms;
    ``refuse`` — same truth, refused authorization;
    ``protect`` — the Issue is canonically ACTIVE with live execution
    capacity (PROTECTED), so no authorization may even be attempted.
    Every invocation is appended to ``FAKE_GHT_LOG`` as JSON argv.
    """
    script = Path(tmp) / f"fake-ght-{mode}.py"
    script.write_text(_fake_ght_script())
    script.chmod(script.stat().st_mode | stat.S_IXUSR)
    return script


def _fresh_target_repo(tmp: Path) -> tuple[Path, Path]:
    """An unrelated fresh business repository with a registered
    Issue-executor worktree and none of the Harry Dev source surfaces."""
    target = tmp / "acme-business-repo"
    target.mkdir()

    def git(*args):
        subprocess.run(["git", "-C", str(target), *args],
                       check=True, capture_output=True)

    for args in (["init", "-q"],
                 ["config", "user.name", "acme"],
                 ["config", "user.email", "dev@acme.example"],
                 ["config", "commit.gpgsign", "false"]):
        git(*args)
    (target / "README.md").write_text("# ACME business repo\n")
    git("add", ".")
    git("commit", "-qm", "initial")
    git("worktree", "add", ".worktree/555", "-b", "agent/555/x")
    return target, target / ".worktree" / "555"


def _decoy_target_repo_ght(target: Path, log: Path) -> Path:
    """A decoy Skill copy planted in the TARGET repository at the exact
    path the retired default resolver assumed. It records any consultation
    and fails loudly: corrected default resolution must never run it."""
    decoy = target / "skills" / "github-task" / "scripts" / "ght.py"
    decoy.parent.mkdir(parents=True)
    decoy.write_text(
        "import json, sys\n"
        f"log = {str(log)!r}\n"
        "with open(log, 'a') as fh:\n"
        "    fh.write(json.dumps(sys.argv[1:]) + chr(10))\n"
        "sys.stderr.write('DECOY target-repo ght must never be "
        "consulted')\n"
        "sys.exit(9)\n")
    return decoy


def _report_or_none(result):
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        raise AssertionError(f"cleanup CLI emitted no report: "
                             f"{result.stdout!r} {result.stderr!r}")


class PackageOwnershipTests(unittest.TestCase):
    """AC1: exactly one canonical cleanup implementation, owned by the
    Skill package; the repository root keeps no duplicate copy."""

    def test_canonical_cleanup_module_lives_in_the_package(self):
        self.assertTrue(PKG_HELPER.exists(),
                        "skills/github-task/scripts/worktree_cleanup.py is "
                        "missing — the canonical cleanup implementation "
                        "must be package-owned")
        self.assertFalse(REPO_ROOT_HELPER.exists(),
                         "repository-root scripts/worktree_cleanup.py must "
                         "be gone — no duplicate canonical cleanup truth")

    def test_package_helper_still_carries_the_fenced_semantics(self):
        # The moved module must be the #147/#154 implementation, not a
        # stripped copy: the fenced sequence and its proof gate are intact.
        source = PKG_HELPER.read_text()
        for anchor in ("def execute_cleanup", "class RemovalAuthorization",
                       "def _remove_worktree", "ReclaimRefused",
                       "reclaim-execution-resource", "classify_ownership"):
            self.assertIn(anchor, source, f"fenced semantic missing: {anchor}")


class IsolatedInstalledCleanupTests(unittest.TestCase):
    """AC4: an isolated installed github-task Skill beside an unrelated
    target repository exercises the canonical fenced cleanup path with no
    Harry Dev source checkout."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory(prefix="ght155-")
        tmp = Path(self._tmp.name)
        # 1) The "installed" Skill package: a complete copy of
        #    skills/github-task/ standing alone (no Harry Dev tree).
        self.dist = tmp / "installed" / "github-task"
        shutil.copytree(
            SKILL_ROOT, self.dist,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git*"))
        # 2) The unrelated target repository: a fresh business repo with a
        #    registered Issue-executor worktree, holding none of the Harry
        #    Dev source surfaces.
        self.target, self.wt = _fresh_target_repo(tmp)
        # Isolation preconditions.
        self.assertFalse((self.target / "skills").exists())
        self.assertFalse((self.target / "prompts").exists())
        self.assertFalse((self.dist.parent / "prompts").exists())
        self.installed_helper = self.dist / "scripts" / "worktree_cleanup.py"
        self.env = _clean_env(str(tmp))

    def tearDown(self):
        self._tmp.cleanup()

    def _run_cleanup(self, mode, extra_args=()):
        log = Path(self._tmp.name) / "fake-ght-calls.log"
        result = subprocess.run(
            [sys.executable, str(self.installed_helper),
             "--repo-root", str(self.target),
             "--ght", str(_fake_ght(Path(self._tmp.name), mode)),
             *extra_args],
            cwd=str(self.target), env={**self.env, "FAKE_GHT_MODE": mode,
                                       "FAKE_GHT_LOG": str(log)},
            capture_output=True, text=True, timeout=120)
        calls = [json.loads(line) for line in log.read_text().splitlines()] \
            if log.exists() else []
        return result, _report_or_none(result), calls

    def test_installed_package_carries_the_cleanup_entrypoint(self):
        # The complete installed Skill alone is the cleanup distribution.
        self.assertTrue(self.installed_helper.exists(),
                        "installed package is incomplete: "
                        "scripts/worktree_cleanup.py missing")

    def test_dry_run_default_reports_and_never_deletes(self):
        result, report, calls = self._run_cleanup("authorize")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(report["mode"], "dry-run")
        self.assertEqual(report["removed"], [])
        self.assertTrue(self.wt.exists())
        reclaims = [call for call in calls
                    if call and call[0] == "reclaim-execution-resource"]
        self.assertEqual(reclaims, [],
                         "dry-run must never approach the authorization")

    def test_reclaimable_worktree_is_removed_through_the_full_fenced_sequence(self):
        result, report, calls = self._run_cleanup("authorize",
                                                  extra_args=("--execute",))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(report["removed"], ["555"])
        self.assertEqual(report["post_removal_alerts"], [])
        self.assertFalse(self.wt.exists())
        reclaims = [call for call in calls
                    if call and call[0] == "reclaim-execution-resource"]
        # authorize → remove → confirm: the authorization anchors on the
        # eligibility read's claim_sha, the confirm on the minted marker,
        # and nothing is confirmed before the authorization succeeded.
        self.assertEqual(len(reclaims), 2)
        self.assertNotIn("--confirm-removal", reclaims[0])
        self.assertIn("a" * 40, reclaims[0])
        self.assertIn("--confirm-removal", reclaims[1])
        self.assertIn("m" * 40, reclaims[1])

    def test_refused_authorization_fences_fail_closed(self):
        result, report, calls = self._run_cleanup("refuse",
                                                  extra_args=("--execute",))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(report["removed"], [])
        self.assertEqual(len(report["fenced"]), 1)
        self.assertEqual(report["fenced"][0]["verdict"], "FAIL_CLOSED")
        self.assertIn("refused", report["fenced"][0]["detail"])
        self.assertTrue(self.wt.exists(),
                        "a refused removal must leave the worktree in place")
        reclaims = [call for call in calls
                    if call and call[0] == "reclaim-execution-resource"]
        self.assertTrue(reclaims)
        self.assertNotIn("--confirm-removal",
                         [flag for call in reclaims for flag in call])

    def test_active_protected_resource_is_not_deletable_and_never_authorized(self):
        result, report, calls = self._run_cleanup("protect",
                                                  extra_args=("--execute",))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(report["removed"], [])
        fenced = {item["worktree"]: item["verdict"]
                  for item in report["fenced"]}
        self.assertEqual(fenced, {"555": "PROTECTED"})
        self.assertTrue(self.wt.exists(),
                        "the canonically ACTIVE resource must survive")
        self.assertNotIn(
            "reclaim-execution-resource",
            [call[0] for call in calls if call],
            "a protected resource must never reach the authorization")

    def test_module_surface_imports_from_the_installed_copy_with_no_source_reach_back(self):
        # The importable fenced surface works from the installed copy alone;
        # an audit hook proves the run never opens the Harry Dev source tree
        # (which exists on this host) — behavioral, not grep, proof.
        code = (
            "import importlib.util, json, sys\n"
            "opened = []\n"
            "def _audit(event, args):\n"
            "    if event == 'open':\n"
            "        opened.append(str(args[0]))\n"
            "sys.addaudithook(_audit)\n"
            f"spec = importlib.util.spec_from_file_location('worktree_cleanup',"
            f" {str(self.installed_helper)!r})\n"
            "module = importlib.util.module_from_spec(spec)\n"
            "sys.modules[spec.name] = module\n"
            "spec.loader.exec_module(module)\n"
            "live = module.IssueOwnership(issue=555, readability='readable',"
            " claim_state='ACTIVE', executor_id='worker-1', candidate=None,"
            " capacity_live=True, identity_executor_id='worker-1',"
            " fencing_token=None)\n"
            "orphan = module.IssueOwnership(issue=555, readability='readable',"
            " claim_state='NONE')\n"
            "print(json.dumps({'active': module.classify_ownership(live),\n"
            "                  'orphan': module.classify_ownership(orphan),\n"
            "                  'opened': opened}))\n"
        )
        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=str(self.target), env=self.env,
            capture_output=True, text=True, timeout=120)
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(payload["active"], "PROTECTED")
        self.assertEqual(payload["orphan"], "RECLAIMABLE")
        reached = [path for path in payload["opened"]
                   if path.startswith(str(SOURCE_ROOT))]
        self.assertEqual(reached, [],
                         "isolated package read into the Harry Dev source tree")


class InstalledDefaultGhtResolutionTests(unittest.TestCase):
    """AC4 (R1): the normal cleanup invocation — no explicit ``--ght`` —
    resolves canonical ght from the installed Skill itself and walks the
    full fenced canonical path beside an unrelated target repository.

    Failure class pinned here: the retired default resolver assumed
    ``<target-repo>/skills/github-task/scripts/ght.py``. A downstream
    business repo carries no Skill copy, so a genuine standalone
    installation degraded to unreadable truth — fail-closed (safe), but
    unable to complete a normal cleanup. The R0 isolated evidence always
    injected ``--ght`` and never exercised this default path.

    The fake ght is installed at the distribution's own canonical location
    (``<installed Skill>/scripts/ght.py`` — package-complete by
    construction), and a decoy is planted in the target repo at the
    retired path: corrected default resolution must complete the canonical
    sequence through the installed Skill while the decoy stays unrun.
    Explicit ``--ght`` stays the test/host seam and must still win.
    """

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory(prefix="ght155def-")
        tmp = Path(self._tmp.name)
        # 1) The "installed" Skill package, complete and alone.
        self.dist = tmp / "installed" / "github-task"
        shutil.copytree(
            SKILL_ROOT, self.dist,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git*"))
        #    Its OWN canonical ght is the hermetic fake: the default
        #    resolver must find ght exactly there, or not at all.
        (self.dist / "scripts" / "ght.py").write_text(_fake_ght_script())
        # 2) The unrelated target repository — deliberately carrying a
        #    decoy Skill copy at the retired default path, which must
        #    never be consulted.
        self.target, self.wt = _fresh_target_repo(tmp)
        self.decoy_log = tmp / "decoy-ght-calls.log"
        _decoy_target_repo_ght(self.target, self.decoy_log)
        self.assertFalse((self.target / "prompts").exists())
        self.installed_helper = self.dist / "scripts" / "worktree_cleanup.py"
        self.env = _clean_env(str(tmp))

    def tearDown(self):
        self._tmp.cleanup()

    def _run_default(self, mode, extra_args=()):
        """Run the installed helper WITHOUT ``--ght``: the default
        resolver is the whole subject under test."""
        log = Path(self._tmp.name) / "installed-ght-calls.log"
        result = subprocess.run(
            [sys.executable, str(self.installed_helper),
             "--repo-root", str(self.target), *extra_args],
            cwd=str(self.target), env={**self.env, "FAKE_GHT_MODE": mode,
                                       "FAKE_GHT_LOG": str(log)},
            capture_output=True, text=True, timeout=120)
        calls = [json.loads(line) for line in log.read_text().splitlines()] \
            if log.exists() else []
        return result, _report_or_none(result), calls

    def _assert_decoy_never_consulted(self):
        self.assertFalse(
            self.decoy_log.exists(),
            "the default resolver consulted the target repository's Skill "
            "copy — normal-invocation package ownership regression (#155)")

    def test_default_dry_run_reads_canonical_truth_from_the_installed_skill(self):
        # The retired wiring degraded a no-``--ght`` run beside a target
        # repo without a Skill copy to unreadable truth (FAIL_CLOSED
        # everywhere). Default resolution must instead read the installed
        # Skill's ght: verdicts are real classifications, not fence noise.
        result, report, calls = self._run_default("authorize")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(report["mode"], "dry-run")
        self.assertEqual(report["removed"], [])
        self.assertTrue(self.wt.exists())
        self.assertEqual(
            [(item["worktree"], item["verdict"]) for item in report["plan"]],
            [("555", "RECLAIMABLE")],
            "default resolution did not produce canonical verdicts from "
            "the installed Skill's ght")
        self.assertTrue(calls, "default resolution never invoked the "
                               "installed Skill's ght")
        self._assert_decoy_never_consulted()

    def test_default_execute_walks_the_full_fenced_canonical_path(self):
        # The standalone-conformance core proof: one installed-package
        # invocation with NO explicit ``--ght`` completes the safe reclaim
        # end to end — eligibility read, atomic authorization, removal,
        # confirm — exactly as the explicit-``--ght`` runs do.
        result, report, calls = self._run_default("authorize",
                                                  extra_args=("--execute",))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(report["mode"], "execute")
        self.assertEqual(report["removed"], ["555"])
        self.assertEqual(report["post_removal_alerts"], [])
        self.assertFalse(self.wt.exists())
        reclaims = [call for call in calls
                    if call and call[0] == "reclaim-execution-resource"]
        self.assertEqual(len(reclaims), 2,
                         "expected exactly authorize → confirm")
        self.assertNotIn("--confirm-removal", reclaims[0])
        self.assertIn("a" * 40, reclaims[0],
                      "authorization must anchor on the eligibility read's "
                      "claim_sha")
        self.assertIn("--confirm-removal", reclaims[1])
        self.assertIn("m" * 40, reclaims[1],
                      "confirm must anchor on the minted marker")
        self._assert_decoy_never_consulted()

    def test_explicit_ght_override_still_wins_over_default_resolution(self):
        # The test/host seam stays: an explicit ``--ght`` is used verbatim.
        # Its fake reports a distinct claim_sha ('b'), so a resolver that
        # wrongly fell back to the installed Skill's ght ('a') fails here.
        override = Path(self._tmp.name) / "fake-ght-override.py"
        override.write_text(_fake_ght_script(claim_marker="b"))
        log = Path(self._tmp.name) / "override-ght-calls.log"
        result = subprocess.run(
            [sys.executable, str(self.installed_helper),
             "--repo-root", str(self.target),
             "--ght", str(override), "--execute"],
            cwd=str(self.target), env={**self.env, "FAKE_GHT_MODE": "authorize",
                                       "FAKE_GHT_LOG": str(log)},
            capture_output=True, text=True, timeout=120)
        report = _report_or_none(result)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(report["removed"], ["555"])
        reclaims = [json.loads(line) for line in log.read_text().splitlines()
                    if line and json.loads(line)[0] == "reclaim-execution-resource"]
        self.assertEqual(len(reclaims), 2)
        self.assertIn("b" * 40, reclaims[0],
                      "the explicit --ght override was not used verbatim")
        self._assert_decoy_never_consulted()


if __name__ == "__main__":
    unittest.main()
