"""Executable source-free adoption fixture for the review check caller."""

import contextlib
import hashlib
import importlib.util
import io
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

TEST_ROOT = Path(__file__).parent
SKILL_ROOT = TEST_ROOT.parents[0]
SCRIPTS_ROOT = SKILL_ROOT / "scripts"
RUNTIME_PACKAGE = SKILL_ROOT / "github_task"
CANDIDATE_SHA = "445704cd33804d109b695e59263573f4a9c1a7df"
OTHER_SHA = "a" * 40
CLAIM_ID = "executor-20261010T095505-34cc423c"
BRANCH = "agent/45/3a8140af"
EXECUTION_BASE = "1563a21bdc0d9ff465464e338938904d16d909ab"
DELIVERED_AT = "2026-10-10T09:55:12Z"
DEFAULT_COMMENTS = object()


def load_script(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise AssertionError(f"fixture script is missing: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def runtime_capsule():
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(RUNTIME_PACKAGE.rglob("*.py")):
            archive.writestr(path.relative_to(SKILL_ROOT).as_posix(), path.read_bytes())
    payload = buffer.getvalue()
    digest = hashlib.sha256(payload).hexdigest()
    identity = {"digest": digest, "release": "v1.1.3", "source_sha": "d" * 40}
    manifest = json.dumps(identity, sort_keys=True).encode("utf-8")
    return payload, manifest, identity


def current_observation(runtime, *, head_sha, reviews, comments=DEFAULT_COMMENTS):
    snapshot = (
        "<!-- ght:candidate-snapshot:v1 -->\n"
        "## Current Candidate Snapshot — #45 / PR #65\n"
        f"- exact Candidate: `{CANDIDATE_SHA}`\n"
        f"- claim: `{CLAIM_ID}` · branch: `{BRANCH}` · "
        f"execution_base: `{EXECUTION_BASE}`\n"
        f"- authority: direct `ready` · delivered: {DELIVERED_AT}\n"
        "<!-- /ght:candidate-snapshot:v1 -->\n"
    )
    return {
        "repository": "owner/repo",
        "requested_pr": 65,
        "issue": 45,
        "pr": {
            "number": 65,
            "state": "open",
            "head": {"sha": head_sha, "ref": BRANCH,
                     "repo": {"full_name": "owner/repo"}},
            "body": snapshot,
        },
        "claim_sha": "b" * 40,
        "claim": {
            "v": 3,
            "task": 45,
            "claim_id": CLAIM_ID,
            "status": "active",
            "branch": BRANCH,
            "execution_base": EXECUTION_BASE,
            "candidate": {"sha": CANDIDATE_SHA},
            "delivery": {"pr": 65, "sha": CANDIDATE_SHA,
                         "delivered_at": DELIVERED_AT},
            "runtime": runtime,
        },
        "runtime": runtime,
        "runtime_ref_sha": "e" * 40,
        "reviews": reviews,
        "comments": [] if comments is DEFAULT_COMMENTS else comments,
    }


class GhaReviewDownstreamTests(unittest.TestCase):
    def test_runtime_review_launcher_dispatches_fresh_verdict_to_check_run(self):
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary)
            installed = target / ".github/scripts"
            installed.mkdir(parents=True)
            for name in ("ght-gha-review-trigger.py", "ght-gha-review-verdict.py"):
                shutil.copy2(SCRIPTS_ROOT / name, installed / name)
                self.assertEqual((installed / name).read_bytes(),
                                 (SCRIPTS_ROOT / name).read_bytes())
            trigger = load_script("downstream_review_trigger",
                                  installed / "ght-gha-review-trigger.py")
            verifier = load_script("downstream_review_verifier",
                                   installed / "ght-gha-review-verdict.py")
            runtime_payload, runtime_manifest, runtime = runtime_capsule()
            accepted = {
                "id": 901,
                "updated_at": DELIVERED_AT,
                "body": ("A REVIEW — ACCEPTED\n\nReviewed exact Candidate:\n"
                         f"{CANDIDATE_SHA}\n\nReviewed by A."),
            }
            scenarios = (
                {"name": "fallback approval", "event_name": "issue_comment",
                 "action": "created", "reviews": [], "comments": [accepted],
                 "head": CANDIDATE_SHA, "expected": "PASS"},
                {"name": "native approval", "event_name": "pull_request_review",
                 "action": "submitted", "reviews": [{"id": 44, "state": "APPROVED",
                                                            "commit_id": CANDIDATE_SHA}],
                 "comments": [], "head": CANDIDATE_SHA, "expected": "PASS"},
                {"name": "fallback edit revokes approval", "event_name": "issue_comment",
                 "action": "edited", "reviews": [], "comments": [{**accepted,
                    "body": "A REVIEW — REQUEST_CHANGES\nrevised after review"}],
                 "head": CANDIDATE_SHA, "expected": "FAIL"},
                {"name": "fallback comment deletion", "event_name": "issue_comment",
                 "action": "deleted", "reviews": [], "comments": [],
                 "head": CANDIDATE_SHA, "expected": "FAIL"},
                {"name": "wrong SHA", "event_name": "issue_comment",
                 "action": "created", "reviews": [], "comments": [{**accepted,
                    "body": accepted["body"].replace(CANDIDATE_SHA, OTHER_SHA)}],
                 "head": CANDIDATE_SHA, "expected": "FAIL"},
                {"name": "native review dismissal", "event_name": "pull_request_review",
                 "action": "dismissed", "reviews": [{"id": 44, "state": "DISMISSED",
                                                          "commit_id": CANDIDATE_SHA}],
                 "comments": [], "head": CANDIDATE_SHA, "expected": "FAIL"},
                {"name": "unreadable reviews", "event_name": "pull_request_review",
                 "action": "submitted", "reviews": None, "comments": [accepted],
                 "head": CANDIDATE_SHA, "expected": "UNKNOWN"},
                {"name": "unreadable comments", "event_name": "issue_comment",
                 "action": "created", "reviews": [], "comments": None,
                 "head": CANDIDATE_SHA, "expected": "UNKNOWN"},
                {"name": "comment edited during verification", "event_name": "issue_comment",
                 "action": "edited", "reviews": [], "comments": [accepted],
                 "head": CANDIDATE_SHA, "expected": "UNKNOWN", "edit_after_read": True},
                {"name": "stale candidate head", "event_name": "pull_request_review",
                 "action": "submitted", "reviews": [{"id": 44, "state": "APPROVED",
                                                            "commit_id": CANDIDATE_SHA}],
                 "comments": [], "head": OTHER_SHA, "expected": "UNKNOWN"},
                {"name": "check permission failure", "event_name": "issue_comment",
                 "action": "created", "reviews": [], "comments": [accepted],
                 "head": CANDIDATE_SHA, "expected": "UNKNOWN", "deny_check": True},
            )
            for scenario in scenarios:
                with self.subTest(scenario=scenario["name"]):
                    if scenario["event_name"] == "pull_request_review":
                        event = {"action": scenario["action"],
                                 "pull_request": {"number": 65},
                                 "review": {"id": 44, "state": "APPROVED",
                                            "commit_id": OTHER_SHA}}
                    else:
                        event = {"action": scenario["action"],
                                 "issue": {"number": 65,
                                           "pull_request": {"url": "https://api.example/pr/65"}},
                                 "comment": accepted,
                                 "changes": {"body": {"from": accepted["body"]}}}
                    event_path = target / "event.json"
                    event_path.write_text(json.dumps(event), encoding="utf-8")
                    current = current_observation(
                        runtime, head_sha=scenario["head"],
                        reviews=scenario["reviews"], comments=scenario["comments"])
                    read_observation = patch.object(
                        verifier, "_read_observation", return_value=(current, 45))
                    if scenario.get("edit_after_read"):
                        changed = current_observation(
                            runtime, head_sha=scenario["head"], reviews=scenario["reviews"],
                            comments=[{**accepted, "updated_at": "2026-10-10T10:00:00Z",
                                       "body": "A REVIEW — REQUEST_CHANGES\nedited while checking"}])
                        read_observation = patch.object(
                            verifier, "_read_observation",
                            side_effect=[(current, 45), (current, 45), (changed, 45)])
                    check_payloads = []
                    dispatches = []
                    helper_results = []
                    loaded_runtimes = []

                    def dispatch(command, *, check):
                        dispatches.append(command)
                        real_load_runtime = verifier._load_runtime

                        def load_runtime(claim):
                            runtime_state = real_load_runtime(claim)
                            loaded_runtimes.append(runtime_state[0])
                            return runtime_state

                        def publish(path, **kwargs):
                            self.assertEqual(path, "repos/owner/repo/check-runs")
                            check_payloads.append(kwargs["payload"])
                            if scenario.get("deny_check"):
                                raise PermissionError("checks:write denied")
                            return {"id": 733}

                        with patch.object(verifier, "_read_ref_files",
                                          return_value=({"runtime.zip": runtime_payload,
                                                         "MANIFEST.json": runtime_manifest},
                                                        "f" * 40)), \
                                read_observation, \
                                patch.object(verifier, "_load_runtime",
                                             side_effect=load_runtime), \
                                patch.object(verifier, "_gh_api", side_effect=publish), \
                                patch.object(verifier, "_write_step_summary"):
                            output = io.StringIO()
                            with contextlib.redirect_stdout(output):
                                exit_code = verifier._main(int(command[-1]))
                        for temporary_runtime in loaded_runtimes:
                            temporary_runtime.cleanup()
                        self.assertEqual(exit_code, 2 if scenario.get("deny_check") else 0)
                        helper_results.append(json.loads(output.getvalue()))
                        return subprocess.CompletedProcess(command, exit_code,
                                                           stdout=output.getvalue())

                    with patch.dict(os.environ, {
                            "GITHUB_EVENT_NAME": scenario["event_name"],
                            "GITHUB_EVENT_PATH": str(event_path),
                            "GITHUB_REPOSITORY": "owner/repo",
                    }), patch.object(trigger.subprocess, "run", side_effect=dispatch):
                        self.assertEqual(trigger.main(),
                                         2 if scenario.get("deny_check") else 0)

                    self.assertEqual(dispatches, [[sys.executable,
                                                   str(installed / "ght-gha-review-verdict.py"),
                                                   "65"]])
                    result = helper_results[0]
                    self.assertEqual(result["verdict"], scenario["expected"])
                    self.assertEqual(len(check_payloads), 1)
                    payload = check_payloads[0]
                    if scenario.get("deny_check"):
                        self.assertNotIn("check_run_id", result)
                        self.assertIn("checks:write", result["reason"])
                    else:
                        self.assertEqual(result["check_run_id"], 733)
                        self.assertEqual(payload["head_sha"], scenario["head"])
                        self.assertEqual(payload["conclusion"],
                                         "success" if scenario["expected"] == "PASS" else "failure")
                        self.assertEqual(payload["external_id"], result["evidence_id"])
                        self.assertEqual(payload["output"]["title"],
                                         f"Canonical exact-SHA review: {scenario['expected']}")

    def test_capsule_adapter_preserves_completion_and_plan_boundaries(self):
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary)
            adapter = SCRIPTS_ROOT / "ght-gha-adapter.sh"
            runtime_scripts = target / "runtime/scripts"
            runtime_scripts.mkdir(parents=True)
            for name in ("ght-gha-complete.sh", "ght-plan-publish.sh"):
                shutil.copy2(SCRIPTS_ROOT / name, runtime_scripts / name)
            stub = target / "ght-stub.py"
            stub.write_text(
                "#!/usr/bin/env python3\n"
                "import json, os, sys\n"
                "open(os.environ['GHT_STUB_OUT'], 'w').write(json.dumps({"
                "'argv': sys.argv[1:], 'publisher': os.environ.get('GHT_PLAN_PUBLISHER_ID'), "
                "'reconciler': os.environ.get('GHT_RECONCILER_ID')}))\n",
                encoding="utf-8")
            stub.chmod(stub.stat().st_mode | stat.S_IXUSR)
            invocation = target / "invocation.json"
            environment = {
                "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
                "GHT_RUNTIME_DIR": str(target / "runtime"),
                "GHT_STUB_OUT": str(invocation),
                "GHT_COMPLETE_GHT_BIN": str(stub),
                "GHT_RECONCILER_ID": "ght-complete-workflow",
                "GHT_EXECUTOR_ID": "ght-complete-workflow",
            }
            complete = subprocess.run(
                ["sh", str(adapter), "complete", "45", "65"], cwd=target,
                env=environment, capture_output=True, text=True)
            self.assertEqual(complete.returncode, 0, complete.stderr)
            self.assertEqual(json.loads(invocation.read_text())["argv"],
                             ["--json", "complete", "45", "--pr", "65"])
            self.assertEqual(json.loads(invocation.read_text())["reconciler"],
                             "ght-complete-workflow")

            plan = target / "docs/plans/current-plan.yaml"
            plan.parent.mkdir(parents=True)
            plan.write_text("plan_id: downstream-fixture\n")
            environment.update({
                "GHT_PLAN_PUBLISH_GHT_BIN": str(stub),
                "GHT_PLAN_PUBLISHER_ID": "ght-plan-publish-workflow",
                "GHT_RUNTIME_REF": "c" * 64,
            })
            publication = subprocess.run(
                ["sh", str(adapter), "plan-publish", str(plan)], cwd=target,
                env=environment, capture_output=True, text=True)
            self.assertEqual(publication.returncode, 0, publication.stderr)
            published = json.loads(invocation.read_text())
            self.assertEqual(published["argv"], [
                "--json", "plan-publish", str(plan), "--bind-contract-digests"])
            self.assertEqual(published["publisher"], "ght-plan-publish-workflow")


if __name__ == "__main__":
    unittest.main()
