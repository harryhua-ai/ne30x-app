"""Focused failure-detector policy regressions for execution leases."""

import os
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import sys

sys.path.insert(0, str(Path(__file__).parents[1]))

from github_task import cli
from . import test_cli_safety as safety_tests


def iso(value):
    return value.isoformat().replace("+00:00", "Z")


def active_claim(lease_expires_at):
    return {
        "v": 3,
        "task": 141,
        "claim_id": "worker-20260924T000000-policy141",
        "executor_id": "worker",
        "github_principal": "worker",
        "branch": "agent/141/policy",
        "contract_digest": "a" * 64,
        "status": "active",
        "heartbeat_at": iso(datetime(2026, 9, 24, tzinfo=timezone.utc)),
        "lease_expires_at": lease_expires_at,
    }


def execution_lease(claim, lease_expires_at):
    return {
        "v": 3,
        "kind": "execution-lease",
        "claim_id": claim["claim_id"],
        "issue": claim["task"],
        "executor_id": claim["executor_id"],
        "github_principal": claim["github_principal"],
        "branch": claim["branch"],
        "contract_digest": claim["contract_digest"],
        "fencing_token": "fence-141",
        "acquired_at": claim["heartbeat_at"],
        "renewed_at": claim["heartbeat_at"],
        "lease_expires_at": lease_expires_at,
    }


class RenewalContext:
    execution_leases_prefix = "refs/ght/execution-leases/"

    def __init__(self, lease_minutes, takeover_grace_minutes):
        self.lease_minutes = lease_minutes
        self.takeover_grace_minutes = takeover_grace_minutes
        self.executor_id = "worker"
        self.github_principal = "worker"

    def claim_commit(self, record, parent=None, document="CLAIM.json"):
        return f"commit-{document}-{record.get('heartbeat_at', record.get('renewed_at'))}"

    def claim_location(self, issue):
        return f"refs/ght/claims/{issue}"

    def save_claim(self, issue, claim, ref_sha):
        self.saved_claim = claim


class LeaseRecoveryPolicyTests(unittest.TestCase):
    def _configured_context(self, overrides=None):
        """Read Context's actual defaults/overrides without GitHub or disk IO."""

        root = Path(__file__).resolve().parents[3]

        def fake_run(args, **_kwargs):
            if "--show-toplevel" in args:
                stdout = str(root)
            elif "--git-common-dir" in args:
                stdout = str(root / ".git")
            else:
                stdout = ""
            return SimpleNamespace(stdout=stdout, returncode=0, stderr="")

        with mock.patch.dict(os.environ):
            for key in ("GHT_LEASE_MINUTES", "GHT_TAKEOVER_GRACE_MINUTES",
                        "GHT_STATE_DIR"):
                os.environ.pop(key, None)
            os.environ.update(overrides or {})
            with (mock.patch.object(cli, "_run", side_effect=fake_run),
                  mock.patch.object(cli.GitHub, "principal", return_value="worker"),
                  mock.patch.object(cli.Context, "_default_branch", return_value="main"),
                  mock.patch.object(Path, "mkdir")):
                return cli.Context()

    def _run_supervisor_once(self, lease_minutes, interval_override=None):
        now = datetime(2026, 9, 24, tzinfo=timezone.utc)
        clock = [now]
        sleeps = []
        claim = active_claim(iso(now + timedelta(hours=1)))
        lease = execution_lease(claim, claim["lease_expires_at"])
        context = SimpleNamespace(
            lease_minutes=lease_minutes,
            executor_id="worker",
            github_principal="worker",
            remote_claim=lambda _issue: (claim, "claim-sha"),
            local_claim=lambda _issue: claim,
        )

        def sleep_once(seconds):
            sleeps.append(seconds)
            clock[0] += timedelta(hours=1)

        host_watch = SimpleNamespace(
            wait=lambda seconds: (sleep_once(seconds), False)[1],
            close=lambda: None)

        env = {"GHT_SUPERVISE_MAX_HOURS": "0.0001",
               "GHT_SUPERVISE_HOST_PID": "123",
               "GHT_SUPERVISE_HOST_START_TOKEN": "fixture-host"}
        if interval_override is not None:
            env["GHT_SUPERVISE_INTERVAL_SECONDS"] = str(interval_override)

        with mock.patch.dict(os.environ, env):
            if interval_override is None:
                os.environ.pop("GHT_SUPERVISE_INTERVAL_SECONDS", None)
            with (mock.patch.object(cli, "Context", return_value=context),
                  mock.patch.object(cli, "_utc_now", side_effect=lambda: clock[0]),
                  mock.patch.object(cli, "_ExecutionHostLiveness", return_value=host_watch),
                  mock.patch.object(cli, "_remote_execution_lease",
                                    return_value=(lease, "lease-sha")),
                  mock.patch.object(cli, "_renew_claim_and_lease",
                                    return_value={"heartbeat_at": iso(now),
                                                  "lease_expires_at": lease["lease_expires_at"]}),
                  mock.patch.object(cli, "_write_supervise_status")):
                cli._cmd_supervise(SimpleNamespace(remote="origin", repo=None, issue=141))
        return sleeps

    def test_default_policy_meets_recovery_slo_and_retry_headroom(self):
        context = self._configured_context()
        interval_seconds = self._run_supervisor_once(context.lease_minutes)[0]

        recovery_window_minutes = (context.lease_minutes +
                                   context.takeover_grace_minutes)
        self.assertLessEqual(recovery_window_minutes, 10)
        self.assertEqual(context.lease_minutes, 6)
        self.assertEqual(context.takeover_grace_minutes, 3)
        self.assertEqual(interval_seconds, 90)

        # Three consecutive renewal attempts fit before expiry, with one full
        # cadence interval remaining after the third failure.
        retry_headroom = context.lease_minutes * 60 - 3 * interval_seconds
        self.assertGreaterEqual(retry_headroom, interval_seconds)

    def test_supervisor_interval_environment_override_remains_effective(self):
        self.assertEqual(self._run_supervisor_once(6, interval_override=37.5), [37.5])

    def test_dead_active_holder_is_recoverable_within_slo_after_final_renewal(self):
        # Small environment overrides keep this failure-class simulation
        # deterministic and fast; no task-duration sleep is used.
        policy = self._configured_context({
            "GHT_LEASE_MINUTES": "0.05",
            "GHT_TAKEOVER_GRACE_MINUTES": "0.05",
        })
        context = RenewalContext(policy.lease_minutes, policy.takeover_grace_minutes)
        renewed_at = datetime(2026, 9, 24, tzinfo=timezone.utc)
        claim = active_claim(iso(renewed_at + timedelta(minutes=1)))
        lease = execution_lease(claim, claim["lease_expires_at"])

        # One real renewal code path succeeds while the ACTIVE holder is live.
        # After this operation, neither the executor nor its supervisor renews.
        with (mock.patch.object(cli, "_remote_execution_lease",
                                return_value=(lease, "lease-sha")),
              mock.patch.object(cli, "_local_lease", return_value={"token": "fence-141"}),
              mock.patch.object(cli, "_utc_now", return_value=renewed_at),
              mock.patch.object(cli, "_atomic_push", return_value=SimpleNamespace(returncode=0)),
              mock.patch.object(cli, "_save_local_lease")):
            renewed_claim = cli._renew_claim_and_lease(context, 141, claim, "claim-sha")

        renewed_lease = {
            **lease,
            "renewed_at": renewed_claim["heartbeat_at"],
            "lease_expires_at": renewed_claim["lease_expires_at"],
        }
        recovery_at = (renewed_at + timedelta(minutes=policy.lease_minutes +
                                               policy.takeover_grace_minutes))

        with (mock.patch.object(cli, "_remote_execution_lease",
                                return_value=(renewed_lease, "lease-sha")),
              mock.patch.object(cli, "_utc_now",
                                return_value=recovery_at - timedelta(microseconds=1))):
            before_grace = cli._execution_capacity(context, renewed_claim)
        self.assertEqual(before_grace["state"], "expired_residue")
        self.assertFalse(before_grace["reacquirable"])

        with (mock.patch.object(cli, "_remote_execution_lease",
                                return_value=(renewed_lease, "lease-sha")),
              mock.patch.object(cli, "_utc_now", return_value=recovery_at)):
            after_grace = cli._execution_capacity(context, renewed_claim)

        elapsed_minutes = (recovery_at - renewed_at).total_seconds() / 60
        self.assertLessEqual(elapsed_minutes, 10)
        self.assertTrue(after_grace["reacquirable"])

    def test_healthy_holder_renews_past_one_base_lease_period(self):
        policy = self._configured_context()
        context = RenewalContext(policy.lease_minutes, policy.takeover_grace_minutes)
        started_at = datetime(2026, 9, 24, tzinfo=timezone.utc)
        interval = timedelta(seconds=90)
        claim = active_claim(iso(started_at + timedelta(minutes=policy.lease_minutes)))
        lease = execution_lease(claim, claim["lease_expires_at"])
        initial_expiry = cli._parse_iso(lease["lease_expires_at"])
        now = started_at + interval

        # Model repeated automatic renewals on the default cadence. The fourth
        # renewal occurs after the original base lease has elapsed, while the
        # most recently renewed lease is still live.
        for _ in range(4):
            self.assertLess(now, cli._parse_iso(lease["lease_expires_at"]))
            with (mock.patch.object(cli, "_remote_execution_lease",
                                    return_value=(lease, "lease-sha")),
                  mock.patch.object(cli, "_local_lease",
                                    return_value={"token": "fence-141"}),
                  mock.patch.object(cli, "_utc_now", return_value=now),
                  mock.patch.object(cli, "_atomic_push",
                                    return_value=SimpleNamespace(returncode=0)),
                  mock.patch.object(cli, "_save_local_lease")):
                claim = cli._renew_claim_and_lease(context, 141, claim, "claim-sha")
            lease = {
                **lease,
                "renewed_at": claim["heartbeat_at"],
                "lease_expires_at": claim["lease_expires_at"],
            }
            now += interval

        self.assertGreater(now, initial_expiry)
        self.assertGreater(cli._parse_iso(claim["lease_expires_at"]), now)

    def test_healthy_supervisor_keeps_renewing_past_one_lease_period(self):
        started_at = datetime.now(timezone.utc).replace(microsecond=0)
        clock = [started_at]
        initial_claim = active_claim(iso(started_at + timedelta(minutes=6)))
        claim_box = [initial_claim]
        lease = execution_lease(initial_claim, initial_claim["lease_expires_at"])
        context = SimpleNamespace(
            lease_minutes=6,
            executor_id="worker",
            github_principal="worker",
            remote_claim=lambda _issue: (claim_box[0], "claim-sha"),
            local_claim=lambda _issue: claim_box[0],
        )
        waits = []
        renewals = []
        statuses = []

        def host_wait(seconds):
            if seconds == 0:
                return False
            waits.append(seconds)
            clock[0] += timedelta(seconds=90)
            return len(waits) > 5

        def renew_once(_ctx, _issue, current_claim, _claim_sha, *, before_commit=None):
            if before_commit is not None:
                before_commit()
            renewed_at = clock[0]
            expiry = iso(renewed_at + timedelta(minutes=6))
            updated = {**current_claim, "heartbeat_at": iso(renewed_at),
                       "lease_expires_at": expiry}
            claim_box[0] = updated
            lease.update(renewed_at=iso(renewed_at), lease_expires_at=expiry)
            renewals.append(renewed_at)
            return updated

        host_watch = SimpleNamespace(wait=host_wait, close=lambda: None)
        env = {"GHT_SUPERVISE_MAX_HOURS": "1",
               "GHT_SUPERVISE_INTERVAL_SECONDS": "90",
               "GHT_SUPERVISE_HOST_PID": "123",
               "GHT_SUPERVISE_HOST_START_TOKEN": "fixture-host"}
        with (mock.patch.dict(os.environ, env),
              mock.patch.object(cli, "Context", return_value=context),
              mock.patch.object(cli, "_utc_now", side_effect=lambda: clock[0]),
              mock.patch.object(cli, "_ExecutionHostLiveness", return_value=host_watch),
              mock.patch.object(cli, "_remote_execution_lease",
                                side_effect=lambda _ctx, _claim_id: (lease, "lease-sha")),
              mock.patch.object(cli, "_renew_claim_and_lease", side_effect=renew_once),
              mock.patch.object(cli, "_write_supervise_status",
                                side_effect=lambda _ctx, _issue, state, **extra:
                                statuses.append((state, extra)))):
            cli._cmd_supervise(SimpleNamespace(remote="origin", repo=None, issue=141))

        initial_expiry = cli._parse_iso(initial_claim["lease_expires_at"])
        self.assertEqual(len(renewals), 5,
                         f"waits={waits!r}; statuses={statuses!r}; claim={claim_box[0]!r}")
        self.assertGreater(renewals[-1], initial_expiry)
        self.assertEqual(waits, [90] * 6)
        self.assertEqual(statuses[-1], ("stopped", {"reason": "execution host exited"}))

    def test_host_exit_guard_blocks_atomic_lease_renewal(self):
        context = RenewalContext(lease_minutes=6, takeover_grace_minutes=3)
        now = datetime.now(timezone.utc).replace(microsecond=0)
        claim = active_claim(iso(now + timedelta(minutes=6)))
        lease = execution_lease(claim, claim["lease_expires_at"])

        def host_exited():
            raise cli.CommandFailure("execution host exited; renewal authority is gone",
                                     cli.OWNERSHIP_LOST)

        with (mock.patch.object(cli, "_remote_execution_lease",
                                return_value=(lease, "lease-sha")),
              mock.patch.object(cli, "_local_lease",
                                return_value={"token": lease["fencing_token"]}),
              mock.patch.object(cli, "_utc_now", return_value=now),
              mock.patch.object(cli, "_atomic_push") as atomic_push,
              self.assertRaises(cli.CommandFailure) as stopped):
            cli._renew_claim_and_lease(context, 141, claim, "claim-sha",
                                       before_commit=host_exited)

        self.assertIn("execution host exited", str(stopped.exception))
        atomic_push.assert_not_called()

    def test_supervisor_stops_cleanly_after_delivery_releases_capacity(self):
        now = datetime(2026, 9, 24, tzinfo=timezone.utc)
        clock = [now]
        claim = {**active_claim(iso(now + timedelta(minutes=6))),
                 "candidate": "a" * 40, "delivery": {"pr": 146}}
        context = SimpleNamespace(
            lease_minutes=6,
            executor_id="worker",
            github_principal="worker",
            remote_claim=lambda _issue: (claim, "claim-sha"),
            local_claim=lambda _issue: claim,
        )
        statuses = []

        def advance(seconds):
            clock[0] += timedelta(seconds=seconds)

        host_watch = SimpleNamespace(wait=lambda seconds: (advance(seconds), False)[1],
                                     close=lambda: None)

        env = {"GHT_SUPERVISE_MAX_HOURS": "0.0001",
               "GHT_SUPERVISE_INTERVAL_SECONDS": "1",
               "GHT_SUPERVISE_HOST_PID": "123",
               "GHT_SUPERVISE_HOST_START_TOKEN": "fixture-host"}
        with (mock.patch.dict(os.environ, env),
              mock.patch.object(cli, "Context", return_value=context),
              mock.patch.object(cli, "_utc_now", side_effect=lambda: clock[0]),
              mock.patch.object(cli, "_ExecutionHostLiveness", return_value=host_watch),
              mock.patch.object(cli, "_remote_execution_lease", return_value=(None, None)),
              mock.patch.object(cli, "_write_supervise_status",
                                side_effect=lambda _ctx, _issue, state, **extra:
                                statuses.append((state, extra))),
              mock.patch.object(cli, "_renew_claim_and_lease") as renew):
            cli._cmd_supervise(SimpleNamespace(remote="origin", repo=None, issue=141))

        self.assertEqual(statuses[-1],
                         ("stopped", {"reason": "execution lease released after delivery"}))
        renew.assert_not_called()

    def test_supervisor_fails_closed_on_replaced_fencing_identity(self):
        now = datetime.now(timezone.utc).replace(microsecond=0)
        clock = [now]
        claim = active_claim(iso(now + timedelta(minutes=6)))
        replaced = execution_lease(claim, claim["lease_expires_at"])
        replaced["fencing_token"] = "replacement-fence"
        context = SimpleNamespace(
            lease_minutes=6,
            executor_id="worker",
            github_principal="worker",
            remote_claim=lambda _issue: (claim, "claim-sha"),
            local_claim=lambda _issue: claim,
        )
        statuses = []

        def advance(seconds):
            clock[0] += timedelta(seconds=seconds)

        host_watch = SimpleNamespace(wait=lambda seconds: (advance(seconds), False)[1],
                                     close=lambda: None)

        env = {"GHT_SUPERVISE_MAX_HOURS": "0.01",
               "GHT_SUPERVISE_INTERVAL_SECONDS": "1",
               "GHT_SUPERVISE_HOST_PID": "123",
               "GHT_SUPERVISE_HOST_START_TOKEN": "fixture-host"}
        with (mock.patch.dict(os.environ, env),
              mock.patch.object(cli, "Context", return_value=context),
              mock.patch.object(cli, "_utc_now", side_effect=lambda: clock[0]),
              mock.patch.object(cli, "_ExecutionHostLiveness", return_value=host_watch),
              mock.patch.object(cli, "_remote_execution_lease",
                                return_value=(replaced, "lease-sha")),
              mock.patch.object(cli, "_local_lease", return_value={"token": "fence-141"}),
              mock.patch.object(cli, "_write_supervise_status",
                                side_effect=lambda _ctx, _issue, state, **extra:
                                statuses.append((state, extra))),
              mock.patch("sys.stderr", new_callable=mock.MagicMock)):
            with self.assertRaises(SystemExit) as stopped:
                cli._cmd_supervise(SimpleNamespace(remote="origin", repo=None, issue=141))

        self.assertEqual(stopped.exception.code, 1)
        self.assertEqual(statuses[-1][0], "failed")
        self.assertIn("fencing identity", statuses[-1][1]["error"])

    def test_live_holder_stays_fenced_and_ambiguous_lease_truth_fails_closed(self):
        context = RenewalContext(lease_minutes=6, takeover_grace_minutes=3)
        now = datetime(2026, 9, 24, tzinfo=timezone.utc)
        claim = active_claim(iso(now + timedelta(minutes=6)))
        lease = execution_lease(claim, claim["lease_expires_at"])

        with (mock.patch.object(cli, "_remote_execution_lease",
                                return_value=(lease, "lease-sha")),
              mock.patch.object(cli, "_utc_now", return_value=now)):
            capacity = cli._execution_capacity(context, claim)
        self.assertEqual(capacity["state"], "live")
        self.assertFalse(capacity["reacquirable"])

        ambiguous = {**lease, "branch": "agent/999/other"}
        with (mock.patch.object(cli, "_remote_execution_lease",
                                return_value=(ambiguous, "lease-sha")),
              mock.patch.object(cli, "_utc_now", return_value=now),
              self.assertRaises(cli.CommandFailure)):
            cli._execution_capacity(context, claim)


class LiveTakeoverFenceTests(unittest.TestCase):
    """Reuse the local-remote CLI fixture to exercise the public takeover gate."""

    setUp = safety_tests.CliSafetyTests.setUp
    tearDown = safety_tests.CliSafetyTests.tearDown
    _write_executable = safety_tests.CliSafetyTests._write_executable
    _git = safety_tests.CliSafetyTests._git
    _activate_default_runtime_pin = safety_tests.CliSafetyTests._activate_default_runtime_pin
    _ght = safety_tests.CliSafetyTests._ght
    _ght_json = safety_tests.CliSafetyTests._ght_json
    _claim = safety_tests.CliSafetyTests._claim

    def test_live_holder_cannot_be_taken_over_before_expiry_and_grace(self):
        self._claim(10)

        result = self._ght(
            "takeover", "10", "--evidence", "executor process exit",
            env_extra={"GHT_EXECUTOR_ID": "worker-2"})

        self.assertEqual(result.returncode, cli.STALE, result.stdout + result.stderr)
        self.assertIn("lease is not expired past takeover grace", result.stdout)


if __name__ == "__main__":
    unittest.main()
