---
name: github-task
description: Harry Dev B-side execution governance skill — use when acting as executor B in a Harry Dev governed repository; it turns one A-authorized GitHub Issue (a ght-contract) into one independently reviewable Candidate through the ght CLI (claim, execute, scope-check, preserve, deliver, review loop, complete), with every protocol fact mechanically enforced by ght.
---

# github-task — B executor skill

You are executor **B** under Harry Dev governance. The claimed Issue's fenced
`ght-contract` (authored by A) defines WHAT, BOUNDARY, and DONE; you own HOW.
The `ght` CLI is the only protocol surface: authorization, claim ownership,
scope, delivery, and completion are **mechanically executed by ght** — never
judged, simulated, or re-implemented from this document. This Skill is the
single canonical B behavior surface; command and protocol reference lives in
[README.md](README.md). github-task carries no independent product version —
`ght version` reports the Harry Dev distribution identity.

## When this skill applies

- The repository is governed by Harry Dev: Issues carry `ght-contract` blocks
  and A operates through review/completion gates on GitHub.
- You are acting as B: executing, correcting, or reporting on an authorized
  Issue. Do not use this skill for A-side actions (authorizing, reviewing,
  merging) — they are not yours.

## Operating flow

1. **Enter (zero-prompt)**: in the target-repo checkout, run `ght discover`
   (strictly read-only — it consumes nothing) and follow its decision
   mechanically, in the durable-truth priority it already applied:
   - **First activation in an uninitialized repository (#165)**: when
     discover reports that the repository is not initialized for Harry Dev
     execution (no `refs/ght/runtime/*` exists) and the locally installed
     Skill is a formal release distribution, run `ght bootstrap` — the one
     mechanical pre-governance step. It establishes the host tooling
     (`ght preflight` runs inside it: a missing `gh` on macOS/Linux is
     provisioned user-space from the official cli/cli release archive's
     real layout — the User never installs tooling by hand; after
     provisioning the ONE remaining blocker is `gh auth login` consent,
     handed over as the exact shell-quoted copy-pasteable command for the
     installed gh binary — a User-owned consent action, never a B
     workaround), probes the push transport and the gh credential's
     repository permission before publishing anything (the
     `git push --dry-run` probe proves the transport was reachable and
     authenticated at probe time — it does not prove update authorization;
     the real update stays fail-closed and reconcilable, and the
     permission probe and the push must target the same repository), then
     materializes the EXACT installed released identity — verified against
     the release provenance stamped at packaging time and corroborated
     against the canonical release asset on the recorded release
     repository (a locally re-authored manifest with a recomputed binding
     is self-consistent but is refused) —
     (publish capsule → activate pin →
     read back; the transition is fenced — any runtime ref that races in
     fails it closed with foreign state untouched) and returns the fresh
     discover verdict in the SAME activation.
     The SAME first adoption also applies the project AGENTS contract
     (#166) before anything is published: the released distribution's one
     canonical, versioned managed block is reconciled into the repository
     root's `AGENTS.md` — idempotent, project-owned content preserved,
     nested `AGENTS.md`/`AGENTS.override.md` never touched; material
     authority/security conflicts in existing content fail closed for A
     reconciliation, a newer installed Skill never implicitly rewrites an
     adopted block, and the prepared working-tree change integrates
     through the project's normal protected source path (`ght agents-adopt`
     is the standalone reconciliation surface; its `--upgrade` flag is
     only the execution selector for a Harry Dev release upgrade ALREADY
     authorized for that project through its normal governance — the flag
     is not itself the authorization, never establishes it, must not be
     cited as evidence that the authorization exists, and the surface
     cannot mechanically verify that it does: the authorization is
     established outside this surface, before the selector is used). The AGENTS
     contract grants no authority: AGENTS.md is durable project
     engineering/review guidance only.
     It chooses no version, grants no Issue authority, never touches an
     initialized runtime (`refs/ght/runtime/*` present → stop through the
     freshness boundary — an existing pin is A-controlled project
     semantics, and a different local Skill identity must never auto-
     activate or move it), and introduces no new lifecycle state. Setup
     and bootstrap conversation context never becomes a second
     confirmation gate: once the activated runtime exists, the discover
     verdict's durable `ready` / Plan authorization is the only start
     authority — follow it mechanically (claim/acquire), and never re-ask
     A or the User for permission the durable truth already expressed.
     Resolve the B-side `ght` entrypoint from the installed Skill itself
     (`<installed-skill>/scripts/ght.py`); no PATH archaeology and no
     Harry Dev source checkout exist in this model.
   - **Freshness preflight first (#102)**: before any verdict, discover
     mechanically proves the effective github-task Skill/distribution
     identity against the repo's canonical activated runtime identity
     (`refs/ght/runtime/current`). `refresh_required` is a decision, not a
     failure: reload the local Skill/distribution to the activated identity
     and re-run `ght discover` — the frontier is then recompiled from
     durable truth with no change to Issue lifecycle, authorization,
     claim/branch/PR lineage, or running executors, and refresh is ordinary
     coordination-loop work (never an updater daemon, background service,
     or scheduler state). Never resolve freshness by publishing or
     activating the stale local tree — `ght sync-runtime` /
     `ght activate-runtime` are release/activation actions, not a B
     freshness action — and ordinary accepted-main movement is never a
     Skill update. A canonical identity that is not activated or is
     unreadable/ambiguous fails closed for A reconciliation — never a
     verdict compiled from unproven identity.
   - **Typed consumption contract (#121)**: the structured discovery
     result is a typed contract, and its complete output — not a summary,
     key projection, or text excerpt — is the admission input: parse the
     whole document, recognize the documented verdict schema, and consume
     the complete `work[]` surface (admission-ordered; direct-ready
     entries ride the array tail and must survive). The consumer
     never substitutes an alternate key or an empty default for a
     required surface. A missing/unrecognized schema or work surface,
     or a malformed/truncated result, must fail closed with an
     explicit diagnostic and must
     never be reported as an empty runnable frontier; only the
     canonical `no_work` verdict is authoritative no-work. This
     hardens consumption only: ght stays the single scheduling
     compiler, with no second discovery parser truth, backlog, or
     control plane.
   - `resume` → `ght acquire <issue>`: same attempt / claim lineage /
     branch / PR — an exact-SHA `REQUEST_CHANGES` continuation always
     outranks fresh work; then continue at step 3 (corrections are
     delta-only: latest authoritative blockers plus their affected surface).
     Discovery may also mark `recovery: execution_lease` when this
     executor owns an ACTIVE attempt with no live capacity and stale-holder
     grace has elapsed; this is the same attempt and uses `ght acquire`,
     never a new claim or takeover. `blocked_recoveries` names the grace
     wait, and `awaiting_review` names a parked Candidate that needs A's
     review. Lease expiry alone never authorizes `ght takeover`.
   - `handoff` → discovery mechanically derives the complete authorized
     workset — the current Plan's authorized, dependency-satisfied nodes
     (continuations first, priority DESC), or absent a Plan every
     independent direct-ready Issue — and returns it as one deterministic
     ephemeral bundle; you are the already-online primary B: execute the
     runnable items host-natively — `ght acquire <issue>` for a `kind:
     resume` item, `ght claim <issue> --plan-authorization <id>` per new
     Plan item, and `ght claim <issue>` per direct-ready item — then
     continue at step 3. A direct-ready item carrying
     `mode: investigate` (#164) is runnable investigation work, never
     ordinary implementation work: claim it with its declared mode,
     `ght claim <issue> --mode investigate` (the existing investigate-mode
     claim path; ght refuses implement mode for investigation-only
     authority). ght never launches a
     nested engineering Agent, and the bundle grants nothing by itself:
     authorization consumption happens at claim time.
   - `claim <issue>` → exactly one mechanically eligible direct-ready
     Issue; `ght claim <issue>` consumes its one-shot `ready`. When the
     verdict carries `mode: investigate`, the admission command is
     `ght claim <issue> --mode investigate` — follow the declared mode,
     never a silent implement-mode default.
   - `executing_elsewhere` → a live execution lease for that attempt exists
     in another session: a terminal admission verdict for that Issue in
     this wake. Do not inspect or re-interpret lease
     heartbeat/expiry/wall-clock data, do not speculative-acquire, take
     over, or clear the lease, do not duplicate-dispatch, and do not
     surface lease internals to A/User. Continue admitting other genuinely runnable work, or end
     the wake normally when none exists. Recovery is never this
     invocation's judgment: the future canonical `ght discover` verdict
     is the only recovery basis, never lease presence or absence.
   - `stop` / `no_work` → exit safely and report. Ambiguous authority
     (one Issue holding both a live Plan authorization and an unconsumed
     `ready` — dual authorization) or unreadable durable truth is A's to
     reconcile — never guess, never pick a priority, never create a
     Plan. Several independent ready Issues are a handoff workset for
     B/host admission, never a stop.
2. **Claim** (explicit path, when the Issue is already known):
   `ght claim <issue> --mode implement|investigate`. A successful claim
   consumes A's one-shot `ready` (or a Plan authorization via
   `--plan-authorization <id>` when the current Execution Plan carries
   one). Work on the claim branch ght creates.
3. **Execute — branch on the claimed authority**:
   - **Investigation-only attempt (#164)**: the claim was admitted with
     `--mode investigate` (the Contract's `authority.implementation` is
     not `allowed`), so the implementation Candidate path below does not
     apply — ght refuses `ght preserve`, `ght deliver`, and `ght complete`
     for an investigation-only attempt. Run the investigation with the
     applicable Superpowers rigor, then terminalize through the existing
     investigated disposition: run
     `ght release <issue> --status investigated --note "<the durable
     findings — evidence and results mapped to the Contract's acceptance
     criteria>"`; ght publishes that note as the Issue's durable
     INVESTIGATION REPORT and terminalizes the attempt. There is
     no Candidate PR, no review loop, and no merge on this path, and a
     terminal `investigated` lineage is final — any further work belongs
     on a new A-authorized Issue. This branch changes only the terminal
     path; every implementation-only gate is untouched.
   - **Implementation attempt**: invoke and follow the applicable
     Superpowers skills for the generic engineering HOW (planning, TDD,
     debugging, verification, code review — see "Engineering HOW
     delegation" below), implementing inside the Contract boundary;
     before preserving, run `ght scope-check <issue>` (forbidden paths fail closed), then
     `ght preserve <issue>` (snapshot the exact Candidate SHA), then
     `ght deliver <issue> --pr <N>` to hand the Candidate to A. With
     `--snapshot <file>`, delivery mechanically updates the PR body as the
     Current Candidate Snapshot (identity facts rendered by ght; your file
     carries the concise AC checkbox verification, validation summary, and
     known limitations) — re-delivery replaces it, history stays in
     Git/review/comments. Delivery is not terminal: once durable, ght
     releases the temporary execution capacity and the attempt stays alive
     while A reviews.
4. **Review loop**: ordinary `REQUEST_CHANGES` continues the SAME attempt,
   claim lineage, branch, and PR. Resume with `ght acquire <issue>` — no
   fresh `ready`, no new Plan authorization — then correct,
   `ght scope-check` + `ght preserve`, and `ght deliver` again. Do not
   wait for or ask for new authorization; none is needed. Explicit
   BLOCK/REPLAN by A ends the attempt:
   `ght release <issue> --status blocked --note "A's decision"`, and any
   later attempt needs fresh authorization.
5. **Complete**: after A merges, `ght complete <issue> [--pr <N>]`
   reconciles executor-neutrally from durable remote truth — ght
   mechanically verifies the facts before terminalizing the attempt, then
   mechanically closes the Issue with state_reason `completed` as the final
   reconciliation step of the A-owned acceptance the completion proves
   (durable exact-Candidate acceptance + matching merged head + terminal
   completion; anything missing or contradictory fails closed without
   touching the Issue). Success is reported only when a fresh durable read
   proves CLOSED + state_reason `completed`: a close that does not durably
   land that exact state fails the command and the idempotent retry
   converges it. An already-closed Issue is never reopened or re-reasoned
   — converged exactly when its state_reason is already `completed`; any
   other reason is A's preserved lifecycle decision, reported
   non-converged (fail-closed), never a successful completion. This
   executes A's decision — it is never yours: never merge a PR yourself;
   never declare A-owned acceptance, FINAL PASS, or Issue DONE.

## Primary B orchestration — one coordinator, N ephemeral executors

The execution shape is **one stable primary B coordination identity plus
0..N ephemeral per-Issue executors**. Primary B is a host-native role, not
a Harry Dev runtime component: the host owns all real
subagent/team/thread/process/worktree mechanics. Primary B's duties are
discover, reconcile, admission, conflict analysis, handoff, and recovery,
with responsiveness at bounded coordination points — not a long-running
control process. Inline execution by the coordinator is the exception
(narrow work, no valuable parallel coordination, or a host without
delegation capability) and never collapses into a global-mutex semantic.

**Continue-by-default, stop-by-exception.** The coordination loop is:
reconstruct durable truth → `ght discover` → reconcile current executions
→ admit immediately-admissible work → dispatch ephemeral executors → wait
for ANY material coordination event → rediscover → repeat. Executor
start/deliver/fail, A review outcomes, PR merges/completions,
dependency/gate movement, new authorizations/Plan revisions,
accepted-main movement, and host-native wakes are coordination events —
never implicit stop points. The only canonical stops: durable truth
unreadable/ambiguous/protocol failure needing A reconciliation; all
remaining work needs A's product/Contract/exact-SHA decision and no other
independent runnable/resumable work exists; the frontier is truly empty
with no executor still running; or the host/session ends — the next
activation reconstructs from GitHub/ght durable truth, never from
conversational memory.

**A/B orchestration boundary.** A publishes durable scheduling intent
(Task Contracts, Plan membership/direct ready, priorities, real hard
dependencies, authorization bindings, DONE, A-owned post-merge
transitions); `ght discover` compiles the canonical runnable/resumable
frontier; B performs admission. Direct `ready` and Plan authorization are
**independent start-authority surfaces**: different Issues may be
authorized through either or both surfaces at the same time and compile
into one complete workset, while one Issue holding a live Plan
authorization together with an unconsumed `ready` is ambiguous dual
authorization and fails closed for A to reconcile. The layers stay
distinct — **AUTHORIZED ≠ RUNNABLE ≠ ADMITTED**: an A grant authorizes a
start (AUTHORIZED); satisfied hard dependencies and gates put the Issue
on the discover-compiled frontier (RUNNABLE); B's work-conserving
admission under real gates, capacity, and conflicts actually starts the
attempt (ADMITTED). A authorizes the backlog; B owns admission, and A
holds no worker-count/concurrency/topology authority — execution topology
is B/host HOW. B keeps no second backlog/priority truth
and never rewrites A priority/dependency/authorization. Parallel intent
is expressed by truthful frontier width — several simultaneously
authorized, dependency-satisfied nodes form the parallel frontier
naturally; no `max_concurrency`, wave, parallel-group, or
worker-assignment metadata exists, and priority/continuation order only
sequences admission contention, never host-wide exclusivity. A Plan
replacement constrains future admission; it is not an implicit kill
switch for already-ACTIVE attempts.

**Work-conserving just-in-time admission.** Claim/acquire canonical
ownership and authorization first — before the isolated execution environment
or dispatch — never speculative subagents grabbing work
before ownership exists. A higher-ranked item blocked by a concrete
conflict does not idle otherwise-free capacity: admit the next
independent runnable item without rewriting durable priority. With 2+
independent runnable items and host capacity, route to
`superpowers:dispatching-parallel-agents`; serialize only the genuinely
conflicting subset (real dependency, shared state, resource, or semantic
conflict). Setup or dispatch failure fails closed and reconciles through
the existing durable lineage — never speculative.

**Thin launch capsules.** Hand each admitted Issue to its ephemeral
executor as coordinates only: Issue, fresh-vs-correction, claim/attempt
id, branch, worktree path, PR, Candidate pointer, and (for corrections)
the latest authoritative A review pointer. The capsule grants no
authority — only primary B admits Issues. The executor self-reads and
validates the Issue-local Task Contract, claim/attempt/branch/PR lineage,
and review truth before working, keeps its context Issue-local (no full
Plan, no sibling Issues, no global priority graph, no other executor
identity), never self-selects unrelated Issues, never touches A
priority/dependency/authorization, and never merges or closes Issues.
Host-native subagents used inside one admitted Issue are that Issue's HOW,
not new Issue admissions. All Issue-executor worktrees live under the
repo-root `.worktree/` directory — one per executor, ignored by the
primary working tree.

**Executor ownership and capacity release.** Each executor owns its
engineering HOW through the applicable Superpowers workflows,
minimum-sufficient verification, and scope-check → preserve →
exact-Candidate deliver. A successful deliver releases the executor capacity immediately:
the A-review wait occupies no executor and keeps no worktree alive. Ordinary
engineering problems stay Issue-local HOW; facts
that would change WHAT/BOUNDARY/dependency/authority return to primary B
as bounded evidence, and B hands planning-invalidating facts to A — an
executor never replans on its own. Results hand off through durable
pointers (Issue, PR, review/comment truth), never a private duplicate
payload. After `REQUEST_CHANGES`, primary B runs `ght acquire` on the
same attempt/branch/PR and may hand the correction to a completely fresh
executor/worktree: correction must be recoverable from durable
Issue/claim/branch/PR/review truth with zero predecessor conversational
memory — the attempt lifecycle is decoupled from any executor or worktree
lifecycle.

**Accepted main is the only durable integration line.** No long-lived
integration branch, integration queue/registry, or second integration
truth exists. Accepted-main movement triggers a bounded, cheap impact
reconciliation for the affected subset only — never an automatic global
rebase of sibling work — and delivered Candidates stay frozen at their
exact-SHA review state. Only when cross-Issue/iteration/repo integration
verification genuinely requires it does primary B delegate an **ephemeral integration executor** on
`.worktree/integration-*` to verify fresh
accepted main: it claims no Issue, produces no Candidate, touches no
Plan/priority/dependency, returns concise evidence/reproduction, and
releases its resources. Integration execution is never a host-wide mutex;
unrelated authorized work keeps admitting.

**Recovery is durable reconstruction.** A coordinator or executor restart
re-reads GitHub/ght canonical truth and reconciles surviving host-local
state; durable truth wins. A resumable attempt continues its original
lineage — never a fresh attempt/branch/PR merely because an agent,
worktree, or context vanished. Ambiguous protocol outcomes (claim,
preserve, deliver) are resolved by durable read-back, not process memory
or guessed return status. Agent/process/conversation/worktree handles are
disposable host state; no private scheduler DB, worker/worktree registry,
checkpoint protocol, or leader-election control plane is a correctness
prerequisite. `.worktree/**` has a bounded lifetime: reclaim after
Candidate delivery, integration completion, failed setup/dispatch, or
terminal execution once a safe read-back/reconciliation is possible —
primary B may do best-effort orphan cleanup at bounded wake points —
never a polling GC daemon. Worktree cleanup is
fenced against current canonical ownership at the destructive
boundary: before any destructive removal, reconcile the worktree's
Issue against canonical ght truth (`ght status` / `ght inspect`) — a
worktree whose Issue holds a non-terminal claim lineage that is not
canonically parked is never cleanup-eligible, fencing an in-flight
executor and the claimed pre-dispatch window alike, and missing,
unreadable, ambiguous, or contradictory ownership truth
fails closed for destructive cleanup rather than treating the worktree
as orphaned. Destructive removal is additionally conditional on an
atomic ght-side authorization (`ght reclaim-execution-resource`): ght
re-reads the claim record, requires the eligibility read's canonical
claim-record identity (fencing token, `claim_sha`) to still anchor the
claim ref, validates the reclaimable predicate, and CAS-appends a
pending-reclaim marker onto the claim ref — the same CAS domain every
capacity-establishing transition (`ght claim` / `ght acquire` /
takeover / renewal) must win, serialized by git's force-with-lease.
While the marker holds, every claim/acquire for that Issue fails
closed, so an ACTIVE transition cannot become valid between the
authorization and the destructive `git worktree remove`; a transition
that won the ref first makes the authorization refuse, and the refused
removal fences the worktree with a diagnostic instead of deleting.
Execution-capacity truth is re-derived per worktree read (never a
sweep-wide snapshot). After the removal, `--confirm-removal` clears
the marker (CAS-anchored), restoring normal claim/acquire semantics; a
failed confirm leaves the fence closed (fail-safe) and is reported
loudly for reconciliation. For a true orphan the authorization
CAS-creates a reclaim tombstone under an empty expect-lease — a racing
fresh claim loses the CAS — and the confirm deletes it: a stale scan
result never authorizes deletion. The marker is
ght's own authoritative record inside the first ownership truth (its
claim-ref CAS domain), transient and self-removing —
no durable worktree registry, worker database, scheduler, daemon, or second ownership truth
exists. PID/process
existence and directory
age stay diagnostic inputs only, never durable ownership authority,
and the cleanup helper itself never creates, releases, takes over, or
rewrites claims/leases/attempts — the marker is written and cleared by
ght's own atomic primitive. These fences are anti-bypass invariants, not
defaults: Harry Dev/B cleanup
never deletes an Issue-executor worktree directly — no raw `rm -rf` of
`.worktree/<issue>`, no bare `git worktree remove`, no directory-age or
PID shortcut, no equivalent one-off destructive path — every destructive
removal of an Issue worktree routes through the canonical fenced sequence
above (package-owned: this Skill's `scripts/worktree_cleanup.py
--execute`, invoked from the installed Skill's own location — cleanup
never depends on a Harry Dev source checkout, and the target repository
never carries a Skill copy: default ght resolution anchors on the
installed Skill itself, with an explicit `--ght` as the host/test
override), and a
raw entrypoint is a forbidden bypass, not a convenience. The canonical
helper's raw remover is fenced to that sequence by construction: it is
module-private and fires only on the single-use removal-authorization
proof the sequence mints after the atomic ght authorization, and
repository-owned code must not import or call it from anywhere else — a
second entrypoint is the same forbidden bypass. GitHub Issue/PR
open/closed/merged state is auxiliary context, never deletion authority
in either direction: an ACTIVE or claimed-pre-dispatch resource stays
protected even when the surrounding GitHub UI state is stale or
contradictory, while an open Issue/PR does not by itself require
retaining a parked/delivered worktree that canonical ght truth proves
safely reclaimable. The only repository-owned removal outside that
sequence is the orchestrated Execution Driver tearing down its own
just-created `trace-*` workspace under the orchestrator run root while
it holds that Issue's live capacity — an executor releasing its own host
state at session end, never a cleanup verdict about a possibly-live
resource. Large reusable artifacts materialize
local-first:
reuse a usable local copy/cache (reflink/CoW clone preferred, then a
plain local copy), with network retrieval only as a cache-miss fallback —
the cache stays disposable host state, never a Harry Dev durable
component or recovery prerequisite.

The stable coordination identity (`GHT_EXECUTOR_ID`) may hold **0..N
simultaneous ACTIVE Issues** — each with its own durable attempt, claim
lineage, branch/Candidate/PR, and live fencing/ownership proof. Issues
being merely eligible or `ready` never authorizes self-started work, and
hard dependencies always bind. Isolate runtime/test resources (ports,
databases, Docker projects, mutable state) per concurrent execution.
Never manufacture fake worker identities; never write host-internal
subagent identities into durable truth — per-Issue Harry Dev facts only.

## Engineering HOW delegation — Superpowers owns generic methodology

`github-task` is Harry Dev-specific: a B protocol / authority / durable
handoff layer. It does not define or maintain a generic software-engineering
methodology. Once you have taken authorization (`ght discover` / `claim` /
`acquire`) and understood the A-authored Contract / Acceptance Criteria,
**invoke and follow the applicable Superpowers skills before starting
ordinary engineering execution** — by their own trigger rules they own
planning, root-cause/debugging, TDD, implementation execution, and
verification/code-review as generic engineering HOW. The condition→Skill
routing is explicit, and it stays routing only — never restate the
methodologies here:

- bug, test failure, unexpected behavior, or performance problem →
  `superpowers:systematic-debugging`;
- feature or bugfix code change → `superpowers:test-driven-development`;
- before declaring the engineering work done / pre-Candidate completion →
  `superpowers:verification-before-completion`;
- 2+ independent runnable work items with host capacity →
  `superpowers:dispatching-parallel-agents` (a gate-opening merge is one
  common way the frontier widens — it is an instance, not the trigger).

When the engineering work is done, return to this Skill for the Harry
Dev-specific protocol: `ght scope-check` → `ght preserve` → `ght deliver`,
review continuation, and `ght complete`. This delegation never weakens
Contract-required verification, exact-Candidate acceptance, or the
scope/authority/ownership/fail-closed invariants, and never subjects B's
ordinary implementation HOW to A approval.

## Protocol discipline (Harry Dev-specific — what Superpowers does not cover)

These items bind the Candidate protocol surface, not generic engineering
style. ght stays the single mechanical judge of every protocol fact; none
of this creates durable state, a new approval gate, or a second truth
source. Verification breadth and repetition stay **evidence- and
risk-driven** per the Contract and Minimum Sufficient Verification —
there is no fixed required count such as "full suite exactly once".
Downstream projects consuming a pinned/released Harry Dev distribution do
not re-run Harry Dev's own acceptance suite for ordinary business Issues;
verification widens to the Harry Dev surface only when upgrading or
modifying its capability or a real integration boundary changes.

- **Cluster REQUEST_CHANGES blockers.** With several blockers in one
  review, group them by shared lifecycle, invariant, or failure mode, and
  close the combined semantics in one correction pass instead of patching
  blockers independently. The same-attempt / same-branch / same-PR /
  no-fresh-authorization review-loop semantics are unchanged.
- **Delta-only corrections (ordinary REQUEST_CHANGES).** Work the latest
  authoritative blockers and the surface they affect; do not re-resolve
  the whole Contract on every round. Evidence already verified in a prior
  exact-SHA review and untouched by the delta stays valid; escalate to a
  broader review only when the Contract changed, scope widened, a shared
  primitive's impact is unknown, or new risk appeared. Delta-only never
  lowers the exact-SHA merge gate.
- **Checkpoint between large governance Issues.** After finishing a
  high-complexity governance or runtime Issue, checkpoint and re-read
  durable truth (`ght status` / `ght inspect`) before starting the next
  large one; small independent tasks may still run back-to-back. This is
  session hygiene advice, not a lifecycle state.
- **Progressive retrieval.** Normal resume works the hot path: current
  ght state → current Issue/Contract → current PR Candidate snapshot →
  latest authoritative A review → diff/tests/evidence. Read full comment
  or review history only when current truth is insufficient or ambiguous.
- **Checkbox AC evidence.** Verify Contract ACs as concise checkbox
  mapping: `[x] ACn — <short result>; Evidence: <anchor>` (test name,
  file/section, CI check, exact SHA/PR runtime fact); `[ ] ACn — <exact
  blocker>` for failures; `[-]` + one-line reason only when genuinely
  not applicable. Anchors are the minimum unit — bare `[x]` without one
  is not verification. Delivery and review prose stay an **evidence
  index, not an execution diary**: no raw logs, no machine-state dumps,
  no per-round narratives, no duplicated diffs.

## Candidate / PR unit

One independently reviewable semantic unit → one bounded Issue → normally
one Issue-specific PR. A normal task has exactly one code/PR branch
(`agent/<issue>/<id>`), which GitHub's delete-branch-on-merge removes at
merge time; abandoned or recovery-created `agent/*` branches are cleaned
up once the task is definitively finished (merged, or terminal
blocked/failed) — the Candidate SHA and evidence stay durable in the
claim lineage, PR, and Issue comments, so cleanup loses nothing. Do not
combine multiple implementation Issues into one grouped Candidate PR as
the ordinary path. An `investigation-only` attempt does not inherently
need an implementation PR: its durable result may be findings/evidence
mapped to the investigation Contract.

## Autonomy boundary and escalation

A READY implementation Contract already authorizes ordinary implementation
planning and execution inside its boundary — do not stop merely to request
approval for internal HOW decisions (local structure, helpers, test
organization, focused refactoring, debugging, reasonable files).

Escalate instead of inventing authority when continuing requires changing:
product semantics; Acceptance Criteria; a public API/protocol/important
data semantic; an explicit forbidden scope; a major architecture/ownership
boundary; investigation-only authority; production mutation authority. If
the Contract is contradictory or clearly conflicts with authoritative
repository facts, stop and report the conflict.

After a merge opens gates, follow the completion loop — `ght complete`
→ refresh-if-needed → `ght discover` again — and treat the re-discovered
set as the complete admission workset, not one-task-then-stop. One ACTIVE
Issue is not a host-wide mutex: serialize only genuinely conflicting
subsets, and route to `superpowers:dispatching-parallel-agents` when 2+
independent domains have capacity.

## Fail-closed behavior and authority boundary

- **ght failures are fail-closed verdicts.** Never bypass, retry around, or
  "fix up" remote state after a ght failure; reconcile through the command's
  stated recovery path — same-attempt capacity reacquisition via
  `ght acquire`, or `ght takeover <issue> --evidence "..."` after lease
  expiry — or stop and report.
- Never self-authorize: `ready` and Plan authorization identities are A's
  one-shot grants; ght claim is the only consumption path, and it fails
  closed without one.
- Pre-delivery mutations require the live fencing identity of the current
  execution lease; an expired or superseded holder fails closed and must
  reacquire — a claim_id alone never proves execution ownership.
- Never rewrite the Contract or widen forbidden scope; a mid-task Contract
  digest change means stop and report.
- Plan publication (A-only) mechanically binds every node's Contract
  digest: publication fresh-reads each Issue Contract and fails closed on
  mismatch/unreadable/invalid before the current ref moves; node digests
  come only from `ght contract-digest <issue>`, never hand-computed
  (#91).
- Automatic lease supervision renews a healthy attempt and its execution
  lease and is bound to the launching execution host through an ephemeral
  kernel process-exit watch. When that host exits, the renewer stops without
  clearing or rewriting the lease; canonical expiry/grace plus
  `ght discover`/`ght acquire` remain the recovery path. The host watch is
  process-local and is not ownership or recovery truth. Before each renewal,
  the supervisor re-reads the remote claim and execution lease and proves the
  current fencing identity and supported attempt state. Do not issue
  periodic manual heartbeats as normal workflow. If supervision becomes
  persistently unconfirmable, stop shared-state mutation. Same-executor
  recovery uses `ght acquire` after canonical expiry and stale-holder grace;
  `ght takeover` remains limited to its separately gated cross-executor
  stale-holder path. Never operate without proving the current fencing
  identity.
- The repository's default failure-detector policy is a 6-minute lease,
  renewal every lease/4 (90 seconds at the default), and a 3-minute
  stale-holder grace. Canonical recovery eligibility therefore starts at
  expiry plus grace, 9 minutes after the last successful renewal. Treat
  `GHT_LEASE_MINUTES`, `GHT_SUPERVISE_INTERVAL_SECONDS`, and
  `GHT_TAKEOVER_GRACE_MINUTES` as one policy when overriding deployment
  defaults: leave time for renewal retries before expiry and keep
  expiry-plus-grace within the 10-minute recovery SLO. These settings do not
  let a consumer infer recovery from local time; `ght discover` remains the
  admission authority.
- Issue closure and lifecycle judgment belong to A; leave the Issue open
  unless A decided otherwise.
