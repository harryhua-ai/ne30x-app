"""Harry Dev B-side execution governance safety core (the github-task skill runtime).

github-task carries no independent product version: the only user-visible
version is the Harry Dev release the runtime came from (``ght version``).
Machine schema versions — Task Contract ``version: 1``, Execution Plan
``version: 1``, claim record ``v: 3`` — are protocol fields, not product
versions, and live in ``core.py``.
"""
