"""Prepare the bounded downstream GitHub Actions adoption proposal."""

from __future__ import annotations

import hashlib
import os
import re
import stat
import tempfile
from pathlib import Path
from typing import Any


class WorkflowAdoptionError(ValueError):
    """A conflicting or unexecutable project-owned workflow surface."""


RUNTIME_TOKEN = "@GHT_RUNTIME_REF@"
ADAPTER_DESTINATION = ".github/scripts/ght-gha-adapter.sh"
COMPONENTS = (
    ("ght-complete", ".github/workflows/ght-complete.yml",
     "workflow_templates/ght-complete.yml"),
    ("ght-plan-publish", ".github/workflows/ght-plan-publish.yml",
     "workflow_templates/ght-plan-publish.yml"),
)
PERMISSIONS = {
    "ght-complete": ("contents: write", "pull-requests: read", "issues: write"),
    "ght-plan-publish": ("contents: write", "issues: read"),
}
MANAGED_MARKERS = {
    "ght-complete": "# ght-adoption-managed: ght-complete/v2",
    "ght-plan-publish": "# ght-adoption-managed: ght-plan-publish/v1",
}
LEGACY_COMPLETE_MARKER = "# ght-adoption-managed: ght-complete/v1"
# These digests bind the repo-local copies to the reviewed verifier sources.
REVIEW_HELPERS = {
    "ght-gha-review-trigger.py": (
        "scripts/ght-gha-review-trigger.py",
        "a183fc66c1ac21aa1f8e59ccac75f35c104b919d583cef07f1ed2d953f7d6941",
    ),
    "ght-gha-review-verdict.py": (
        "scripts/ght-gha-review-verdict.py",
        "470d8a44c0fbb92909a16d401c945b43f598d39e2bd3e0b48d9a64591cd56dda",
    ),
}
REVIEW_DESTINATION = ".github/scripts"
_PIN = re.compile(r"^[0-9a-f]{64}$")
_CALLER = re.compile(r"(?<![A-Za-z0-9_./-])([A-Za-z0-9_./-]+\.sh)(?=\s|$)")


def _package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _template_bytes(relative: str, runtime_ref: str, package_root: Path) -> bytes:
    source = package_root / relative
    if source.is_symlink() or not source.is_file():
        raise WorkflowAdoptionError(f"trusted workflow asset is missing or not regular: {relative}")
    text = source.read_text()
    if text.count(RUNTIME_TOKEN) != 1:
        raise WorkflowAdoptionError(f"trusted workflow asset has an invalid runtime slot: {relative}")
    return text.replace(RUNTIME_TOKEN, runtime_ref).encode()


def _managed_marker(text: str, component: str) -> str | None:
    marker_lines = [line.strip() for line in text.splitlines()
                    if "ght-adoption-managed" in line]
    if not marker_lines:
        return None
    allowed = {MANAGED_MARKERS[component]}
    if component == "ght-complete":
        allowed.add(LEGACY_COMPLETE_MARKER)
    if len(marker_lines) != 1 or marker_lines[0] not in allowed:
        raise WorkflowAdoptionError(f"{component}: malformed or unsupported managed marker")
    return marker_lines[0]


def _trusted_review_helpers(package_root: Path) -> dict[str, bytes]:
    trusted: dict[str, bytes] = {}
    for name, (relative, expected_digest) in REVIEW_HELPERS.items():
        source = package_root / relative
        if source.is_symlink() or not source.is_file():
            raise WorkflowAdoptionError(f"trusted review helper is missing or not regular: {relative}")
        content = source.read_bytes()
        if hashlib.sha256(content).hexdigest() != expected_digest:
            raise WorkflowAdoptionError(f"trusted review helper digest is incompatible: {relative}")
        trusted[f"{REVIEW_DESTINATION}/{name}"] = content
    return trusted


def _review_job(text: str) -> str | None:
    if "  review_verdict:\n" not in text or "\n  complete:\n" not in text:
        return None
    return (text.split("  review_verdict:\n", 1)[1]
            .split("\n  complete:\n", 1)[0]
            .rstrip("\n"))


def _review_route_problem(text: str, trusted_text: str) -> str | None:
    required = (
        "  pull_request_review:\n    types: [submitted, edited, dismissed]",
        "  issue_comment:\n    types: [created, edited, deleted]",
        "github.event_name == 'pull_request_review'",
        "github.event_name == 'issue_comment'",
        "github.event.issue.pull_request",
        "contains(github.event.comment.body, 'A REVIEW')",
        "contains(github.event.changes.body.from, 'A REVIEW')",
        "- uses: actions/checkout@v4\n        with:\n          ref: ${{ github.event.repository.default_branch }}",
        "GH_TOKEN: ${{ github.token }}",
        "GITHUB_REPOSITORY: ${{ github.repository }}",
    )
    if any(anchor not in text for anchor in required):
        return "review events do not route through the canonical repo-local trigger"
    review_job = _review_job(text)
    trusted_review_job = _review_job(trusted_text)
    if review_job is None or trusted_review_job is None:
        return "review job is missing beside the completion job"
    if any(f"      {permission}" not in review_job for permission in
           ("contents: read", "pull-requests: read", "issues: read", "checks: write")):
        return "review job is missing a required read or checks: write permission"
    # Matching the trusted job rejects YAML-equivalent step spellings the bounded check cannot prove.
    if review_job != trusted_review_job:
        return "review job must only check out the default branch and run the canonical trigger"
    return None


def _path_state(root: Path, relative: str) -> tuple[Path, bytes | None]:
    path = root / relative
    parent = root
    for part in Path(relative).parts[:-1]:
        parent = parent / part
        if parent.is_symlink() or (parent.exists() and not parent.is_dir()):
            raise WorkflowAdoptionError(f"project-owned component parent is unsafe: {parent}")
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise WorkflowAdoptionError(f"project-owned component is not a regular file: {relative}")
    return path, path.read_bytes() if path.exists() else None


def _called_scripts(text: str) -> list[str]:
    found = []
    for raw in _CALLER.findall(text):
        normalized = raw.removeprefix("./")
        if normalized not in found:
            found.append(normalized)
    return found


def _runtime_pin_location(text: str, line_number: int) -> tuple[str, bool]:
    lines = text.splitlines()
    line_index = line_number - 1
    indent = len(lines[line_index]) - len(lines[line_index].lstrip(" "))
    stack: list[tuple[int, str]] = []
    for line in lines[:line_index]:
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        sequence = re.match(r"^(?P<indent> *)-\s*(?P<item>.*)$", line)
        if sequence:
            sequence_indent = len(sequence.group("indent"))
            while stack and stack[-1][0] >= sequence_indent:
                stack.pop()
            stack.append((sequence_indent, "[]"))
            item_mapping = re.match(
                r"^(?P<key>[A-Za-z0-9_.-]+):(?P<value>.*)$",
                sequence.group("item"))
            if item_mapping and not item_mapping.group("value").strip(" \t#"):
                stack.append((sequence_indent + 2, item_mapping.group("key")))
            continue
        mapping = re.match(
            r"^(?P<indent> *)(?P<key>[A-Za-z0-9_.-]+):(?P<value>.*)$", line)
        if not mapping:
            continue
        mapping_indent = len(mapping.group("indent"))
        while stack and stack[-1][0] >= mapping_indent:
            stack.pop()
        if not mapping.group("value").strip(" \t#"):
            stack.append((mapping_indent, mapping.group("key")))

    if indent == 2 and stack == [(0, "env")]:
        return f"workflow-level (indent {indent}, line {line_number})", True
    if (indent == 6 and len(stack) == 3 and stack[0] == (0, "jobs")
            and stack[1][0] == 2 and stack[2] == (4, "env")
            and re.fullmatch(r"[A-Za-z0-9_-]+", stack[1][1])):
        return f"jobs.{stack[1][1]} (indent {indent}, line {line_number})", True
    if (indent == 10 and len(stack) == 5 and stack[0] == (0, "jobs")
            and stack[1][0] == 2 and stack[2] == (4, "steps")
            and stack[3] == (6, "[]") and stack[4] == (8, "env")
            and re.fullmatch(r"[A-Za-z0-9_-]+", stack[1][1])):
        return (f"jobs.{stack[1][1]}.steps[*] (indent {indent}, line {line_number})",
                True)
    return f"ambiguous scope (indent {indent}, line {line_number})", False


def _workflow_is_compatible(root: Path, component: str, text: str,
                            runtime_ref: str) -> tuple[str | None, str | None]:
    """Prove the narrow trigger, permission, capsule, and caller contract."""

    requirements = PERMISSIONS[component]
    inline_permissions = re.search(r"(?m)^permissions:\s*\{([^}]*)\}", text)
    inline_text = inline_permissions.group(1) if inline_permissions else ""
    missing_permissions = [
        permission for permission in requirements
        if not re.search(rf"(?m)^  {re.escape(permission)}\s*$", text)
        and permission not in inline_text]
    if missing_permissions:
        return None, "missing required permissions: " + ", ".join(missing_permissions)
    if "skills/github-task/" in text:
        return None, "caller uses a forbidden Harry Dev repository-local source path"
    pin_occurrences = []
    key_pattern = re.compile(
        r"(?<![A-Za-z0-9_])(?:GHT_RUNTIME_REF|\"GHT_RUNTIME_REF\"|"
        r"'GHT_RUNTIME_REF')\s*:")
    for line_number, line in enumerate(text.splitlines(), 1):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        keys = list(key_pattern.finditer(line))
        if not keys:
            continue
        location, scoped = _runtime_pin_location(text, line_number)
        entry = re.fullmatch(
            r"(?P<indent> *)GHT_RUNTIME_REF\s*:[ \t]*(?P<value>.*)", line)
        if len(keys) != 1 or not entry:
            return None, (f"ambiguous GHT_RUNTIME_REF occurrence at {location}: "
                          f"{line.strip()!r}")
        if not scoped:
            return None, f"ambiguous GHT_RUNTIME_REF scope at {location}"
        value = entry.group("value")
        pin_value = re.fullmatch(
            r"(?P<quote>[\"']?)(?P<pin>[0-9a-f]{64})(?P=quote)"
            r"(?:[ \t]+#.*)?[ \t]*",
            value)
        if not pin_value:
            return None, (f"unprovable GHT_RUNTIME_REF value at {location}: "
                          f"{value.strip()!r}")
        pin_occurrences.append((pin_value.group("pin"), location))
    if not pin_occurrences:
        return None, "no explicit immutable GHT_RUNTIME_REF pin"
    if len({pin for pin, _location in pin_occurrences}) > 1:
        locations = "; ".join(f"{location}={pin}"
                               for pin, location in pin_occurrences)
        return None, f"conflicting GHT_RUNTIME_REF pins: {locations}"
    pin = pin_occurrences[0][0]
    if pin != runtime_ref:
        return None, (
            f"incompatible GHT_RUNTIME_REF pin {pin}; "
            f"the activated pin is {runtime_ref}; an authorized upgrade is required "
            "(rerun `ght workflows-adopt --upgrade` only after project authorization)")
    if component == "ght-complete":
        anchors = ("pull_request:", "types: [closed]", "workflow_dispatch:",
                   "merged == true", "GHT_RECONCILER_ID:")
    else:
        anchors = ("push:", "docs/plans/current-plan.yaml", "workflow_dispatch:",
                   "GHT_PLAN_PUBLISHER_ID:")
    if any(anchor not in text for anchor in anchors):
        return None, "workflow trigger or canonical caller is not provably compatible"
    callers = _called_scripts(text)
    if not callers:
        return None, "workflow has no repo-local thin caller"
    return callers[0], None


def _caller_is_compatible(root: Path, component: str, relative: str,
                          planned_adapter: bytes | None) -> str | None:
    path, content = _path_state(root, relative)
    if content is None and relative == ADAPTER_DESTINATION and planned_adapter is not None:
        content = planned_adapter
    if content is None:
        return f"workflow caller file is missing: {relative}"
    marker = b"# ght-adapter-managed: capsule-adapter/v1"
    managed = marker in content
    decoded = content.decode(errors="replace")
    if managed:
        if not re.search(r"(?m)^\s*git fetch\b[^\n]*refs/ght/runtime/", decoded):
            return f"managed caller does not fetch the same-repository runtime capsule: {relative}"
        if not re.search(r'(?m)^\s*case\s+"\$\{GHT_RUNTIME_REF(?::-[^}]*)?\}"\s+in', decoded):
            return f"managed caller does not validate GHT_RUNTIME_REF: {relative}"
        integrity_checks = (
            r'(?m)^\s*pin\s*=\s*sys\.argv\[3\]$',
            r'(?m)^\s*manifest\s*=\s*json\.load\(open\(sys\.argv\[2\]\)\)$',
            r'(?m)^\s*payload_digest\s*=\s*hashlib\.sha256\(open\(sys\.argv\[1\],\s*"rb"\)\.read\(\)\)\.hexdigest\(\)$',
            r'(?m)^\s*if\s+payload_digest\s*!=\s*pin\s*:',
            r'(?m)^\s*if\s+manifest\.get\("digest"\)\s*!=\s*pin\s*:',
            r'(?m)^\s*unzip\s+-q\s+"\$runtime_tmp/runtime\.zip"\s+-d\s+"\$runtime_tmp/runtime"\s*$',
        )
        if not all(re.search(pattern, decoded) for pattern in integrity_checks):
            return f"managed caller does not verify the runtime capsule payload and manifest: {relative}"
    if "refs/ght/runtime/" not in decoded or "GHT_RUNTIME_REF" not in decoded:
        return f"project-owned caller does not prove same-repository runtime capsule use: {relative}"
    if component == "ght-complete":
        invokes_complete = (
            re.search(r'(?m)^\s*exec\s+"\$\{GHT_RUNTIME_DIR\}/scripts/ght-gha-complete\.sh"\s+(?:complete|resolve)\b', decoded)
            if managed else any(token in decoded for token in
                               ("ght complete", "ght-gha-complete.sh")))
        if not invokes_complete:
            return f"project-owned caller does not invoke canonical ght complete: {relative}"
    if component == "ght-plan-publish":
        invokes_publish = (
            re.search(r'(?m)^\s*exec\s+"\$\{GHT_RUNTIME_DIR\}/scripts/ght-plan-publish\.sh"\s+"\$plan_path"\s+--replace(?:-current)?\b', decoded)
            if managed else "ght-plan-publish" in decoded or "plan-publish" in decoded)
        if not invokes_publish:
            return f"project-owned caller does not invoke canonical plan publication: {relative}"
    return None


def inspect(root: str | Path, runtime_ref: str, *, upgrade_selector: bool = False,
            package_root: str | Path | None = None) -> dict[str, Any]:
    """Preflight all component paths without changing the target checkout."""

    if not isinstance(runtime_ref, str) or not _PIN.fullmatch(runtime_ref):
        raise WorkflowAdoptionError("an exact 64-hex active runtime pin is required")
    target_root = Path(root).resolve()
    trusted_root = Path(package_root).resolve() if package_root else _package_root()
    complete_adapter = trusted_root / "scripts" / "ght-gha-adapter.sh"
    if complete_adapter.is_symlink() or not complete_adapter.is_file():
        raise WorkflowAdoptionError("trusted downstream runtime-capsule adapter is missing")
    adapter_bytes = complete_adapter.read_bytes()
    adapter_marker = b"# ght-adapter-managed: capsule-adapter/v1"
    adapter_markers = [line.strip() for line in adapter_bytes.decode(errors="replace").splitlines()
                       if "ght-adapter-managed" in line]
    if adapter_markers != [adapter_marker.decode()]:
        raise WorkflowAdoptionError("trusted downstream runtime-capsule adapter has no identity marker")
    trusted_helpers = _trusted_review_helpers(trusted_root)

    desired: dict[str, bytes] = {}
    current: dict[str, bytes | None] = {}
    compatible_callers: list[tuple[str, str]] = []
    review_required = False
    review_check = "not_applicable"
    for component, destination, asset in COMPONENTS:
        _path, existing = _path_state(target_root, destination)
        current[destination] = existing
        rendered = _template_bytes(asset, runtime_ref, trusted_root)
        if existing is None:
            desired[destination] = rendered
            text = rendered.decode()
        else:
            text = existing.decode(errors="replace")
        marker = _managed_marker(text, component)
        managed = marker is not None
        caller, problem = _workflow_is_compatible(target_root, component, text,
                                                   runtime_ref)
        if problem:
            if existing is not None and not managed:
                raise WorkflowAdoptionError(f"{destination}: project-owned workflow conflict: {problem}")
            if existing is not None and managed and upgrade_selector:
                desired[destination] = rendered
                text = rendered.decode()
                caller, problem = _workflow_is_compatible(target_root, component, text,
                                                           runtime_ref)
            if problem:
                raise WorkflowAdoptionError(f"{destination}: {problem}")
        elif existing is not None and managed and upgrade_selector and existing != rendered:
            desired[destination] = rendered
        elif existing is not None and not managed:
            # Proven project-owned equivalents are reused without churn.
            pass

        if component == "ght-complete":
            route_problem = _review_route_problem(text, rendered.decode())
            if marker == LEGACY_COMPLETE_MARKER:
                if not upgrade_selector:
                    if route_problem is None:
                        raise WorkflowAdoptionError(
                            f"{destination}: v1 marker cannot assert the v2 review route; "
                            "use `ght workflows-adopt --upgrade` only after project authorization")
                    review_check = "upgrade_required"
                else:
                    desired[destination] = rendered
                    text = rendered.decode()
                    caller, problem = _workflow_is_compatible(
                        target_root, component, text, runtime_ref)
                    if problem or _review_route_problem(text, rendered.decode()):
                        raise WorkflowAdoptionError(
                            f"{destination}: trusted v2 review workflow is incompatible: "
                            f"{problem or _review_route_problem(text, rendered.decode())}")
                    review_required = True
                    review_check = "prepared"
            elif route_problem:
                if existing is not None and managed and upgrade_selector:
                    desired[destination] = rendered
                    text = rendered.decode()
                    caller, problem = _workflow_is_compatible(
                        target_root, component, text, runtime_ref)
                    if problem or _review_route_problem(text, rendered.decode()):
                        raise WorkflowAdoptionError(
                            f"{destination}: trusted v2 review workflow is incompatible: "
                            f"{problem or _review_route_problem(text, rendered.decode())}")
                    review_required = True
                    review_check = "prepared"
                elif existing is not None and not managed:
                    raise WorkflowAdoptionError(
                        f"{destination}: project-owned workflow lacks the canonical review route; "
                        "preserve it and reconcile with A")
                else:
                    raise WorkflowAdoptionError(f"{destination}: {route_problem}")
            else:
                review_required = True
                review_check = "prepared"
        if caller:
            compatible_callers.append((component, caller))

    _adapter_path, current_adapter = _path_state(target_root, ADAPTER_DESTINATION)
    current[ADAPTER_DESTINATION] = current_adapter
    adapter_needed = any(caller == ADAPTER_DESTINATION for _component, caller in compatible_callers)
    if adapter_needed:
        if current_adapter is None:
            desired[ADAPTER_DESTINATION] = adapter_bytes
        elif current_adapter != adapter_bytes:
            decoded_adapter = current_adapter.decode(errors="replace")
            adapter_markers = [line.strip() for line in decoded_adapter.splitlines()
                               if "ght-adapter-managed" in line]
            if adapter_markers != [adapter_marker.decode()]:
                raise WorkflowAdoptionError(
                    f"{ADAPTER_DESTINATION}: project-owned caller conflicts with the required capsule adapter")
            if upgrade_selector:
                desired[ADAPTER_DESTINATION] = adapter_bytes
            else:
                # A previous released adapter is retained unless an A-authorized
                # release upgrade selected this reconciliation.
                decoded = current_adapter.decode(errors="replace")
                if "plan-publish" not in decoded:
                    raise WorkflowAdoptionError(
                        f"{ADAPTER_DESTINATION}: installed adapter lacks the Plan caller; use the authorized release-upgrade path")

    review_destinations = []
    for relative, content in trusted_helpers.items():
        _path, existing = _path_state(target_root, relative)
        current[relative] = existing
        if existing is not None:
            if existing != content:
                raise WorkflowAdoptionError(
                    f"{relative}: review helper digest differs from the trusted source")
            mode = stat.S_IMODE((target_root / relative).stat().st_mode)
            if not mode & 0o444:
                raise WorkflowAdoptionError(f"{relative}: review helper is not readable")
        elif review_required:
            desired[relative] = content
        if review_required:
            review_destinations.append(relative)

    for component, caller in compatible_callers:
        problem = _caller_is_compatible(
            target_root, component, caller,
            adapter_bytes if caller == ADAPTER_DESTINATION else None)
        if problem:
            raise WorkflowAdoptionError(f"{COMPONENTS[0 if component == 'ght-complete' else 1][1]}: {problem}")
    if review_required and len(review_destinations) != len(REVIEW_HELPERS):
        raise WorkflowAdoptionError("review helper destinations do not match the trusted helper source set")
    changed_files = sorted(path for path, content in desired.items()
                           if current.get(path) != content)
    return {"root": target_root, "runtime_ref": runtime_ref,
            "package_root": trusted_root,
            "upgrade_selector": upgrade_selector, "desired": desired,
            "current": current, "changed_files": changed_files,
            "compatible_files": sorted(set(current) - set(changed_files)),
            "integration": "not_verified", "review_check": review_check}


def apply(plan: dict[str, Any]) -> dict[str, Any]:
    """Apply only the preflighted missing or managed files to the worktree."""

    root: Path = plan["root"]
    desired: dict[str, bytes] = plan["desired"]
    current: dict[str, bytes | None] = plan["current"]
    changed = list(plan["changed_files"])
    # Recheck every destination before the first write so a conflict never
    # leaves a half-prepared proposal.
    for relative in changed:
        _path, now = _path_state(root, relative)
        if now != current.get(relative):
            raise WorkflowAdoptionError(f"project file changed during adoption preflight: {relative}")
    for relative in changed:
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        content = desired[relative]
        if current.get(relative) is None:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o755 if relative.endswith(".sh") else 0o644)
            with os.fdopen(fd, "wb") as stream:
                stream.write(content)
        else:
            mode = stat.S_IMODE(path.stat().st_mode)
            fd, temporary = tempfile.mkstemp(prefix=".ght-adoption-", dir=path.parent)
            try:
                with os.fdopen(fd, "wb") as stream:
                    stream.write(content)
                os.chmod(temporary, mode)
                if path.read_bytes() != current[relative]:
                    raise WorkflowAdoptionError(f"project file changed during upgrade: {relative}")
                os.replace(temporary, path)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
    return {"status": "proposal_prepared" if changed else "already_compatible",
            "integration": "not_verified", "changed_files": changed,
            "compatible_files": plan["compatible_files"],
            "runtime_ref": plan["runtime_ref"],
            "upgrade_selector": plan["upgrade_selector"],
            "review_check": plan["review_check"],
            "formal_release": "optional_not_installed_by_default"}


def prepare(root: str | Path, runtime_ref: str, *, upgrade_selector: bool = False,
            package_root: str | Path | None = None) -> dict[str, Any]:
    return apply(inspect(root, runtime_ref, upgrade_selector=upgrade_selector,
                         package_root=package_root))
