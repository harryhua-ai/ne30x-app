"""B orchestrator runtime for Harry Dev (#43).

One active orchestrator per current Execution Plan, keyed by the Plan's own
identity and guarded by CAS lease + fencing. Every invocation rebuilds the
world from GitHub durable truth (current Plan revision, claim lineages,
deliveries, execution leases), evaluates the A-authored semantic runnable
predicate per node, admits work through an Execution Driver (actual
concurrency is B/host execution HOW — the operator ``--max-parallel`` is a
dev-fixture ceiling only; the A-authored ``max_concurrency`` envelope is
retired), and exits safely when the remaining progress
depends on A review, unsatisfied barriers, or inadmissible runtime
conditions. The orchestrator owns scheduling mechanics only — it never
edits Plan semantics, mints authorizations, or touches the ready surface.

The Orchestrator Core (this module) is deliberately separate from the
Execution Driver (the provider adapter that hydrates a workspace and runs
the actual engineering execution): the driver is runtime HOW, not durable
truth, and never enters Plan/Contract/claim identity.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import uuid
from datetime import timedelta
from pathlib import Path
from typing import Any

# NOTE: cli.py imports this module lazily (inside _cmd_orchestrate) to keep
# the module graph acyclic; this module may import cli normally.
from .cli import (CommandFailure, Context, OK, INELIGIBLE, OWNERSHIP_LOST, RACE, STALE,
              _atomic_push, _execution_lease_ref, _iso,
                  _parse_iso, _remote_execution_lease, _remote_plan, _resolve_plan_start,
                  _run, _utc_now, _validate_issue_intake, claim_state, contract_digest,
                  _has_durable_delivery)
from .core import has_exact_sha_change_request

ORCHESTRATOR_LEASE = "ORCHESTRATOR.json"
ORCHESTRATORS_PREFIX = "refs/ght/orchestrators/"


# ------------------------------------------------- orchestrator ownership

def _orchestrator_ref(plan_id: str) -> str:
    # The Plan identity is A-authored free text; the ref key is a stable
    # collision-free encoding of it, and the lease record back-proves the
    # exact plan_id + revision.
    key = hashlib.sha256(plan_id.encode("utf-8")).hexdigest()[:32]
    return f"{ORCHESTRATORS_PREFIX}{key}"


def _remote_orchestrator_lease(ctx: Context, plan_id: str) -> tuple[dict[str, Any] | None, str | None]:
    record, ref_sha = ctx.remote_json(_orchestrator_ref(plan_id), document=ORCHESTRATOR_LEASE)
    if record is not None:
        required = ("v", "kind", "plan_id", "plan_revision", "orchestrator_id",
                    "fencing_token", "acquired_at", "renewed_at", "lease_expires_at")
        if any(field not in record for field in required) or record.get("kind") != "orchestrator-lease":
            raise CommandFailure("orchestrator lease is malformed; stand down", OWNERSHIP_LOST,
                                 ref=_orchestrator_ref(plan_id))
    return record, ref_sha


def _orchestrator_back_proof(lease: dict[str, Any], plan_id: str) -> bool:
    return (lease.get("kind") == "orchestrator-lease" and
            lease.get("plan_id") == plan_id)


def _lease_expired_past_grace(record_like: dict[str, Any], ctx: Context) -> bool:
    return (_parse_iso(record_like["lease_expires_at"]) +
            timedelta(minutes=ctx.takeover_grace_minutes)) <= _utc_now()


def acquire_orchestrator(ctx: Context, plan_id: str, plan_revision: str) -> dict[str, Any]:
    """Acquire (or take over) the one orchestrator slot for this Plan (AC1).

    A live lease held by anyone stands down; an identity-proven residue
    expired past the grace window is replaced with a fresh fencing identity.
    """
    ref = _orchestrator_ref(plan_id)
    existing, existing_sha = _remote_orchestrator_lease(ctx, plan_id)
    if existing is not None:
        if not _orchestrator_back_proof(existing, plan_id):
            raise CommandFailure("orchestrator lease does not back-prove the current Plan; "
                                 "fail-closed — reconcile manually", OWNERSHIP_LOST, remote=existing)
        if not _lease_expired_past_grace(existing, ctx):
            raise CommandFailure(
                f"an active orchestrator already owns Plan {plan_id!r}; this invocation "
                "stands down (one active orchestrator per Plan)", RACE,
                lease_expires_at=existing["lease_expires_at"])
    now = _utc_now()
    lease = {"v": 3, "kind": "orchestrator-lease", "plan_id": plan_id,
             "plan_revision": plan_revision, "orchestrator_id": ctx.executor_id,
             "github_principal": ctx.github_principal,
             "fencing_token": uuid.uuid4().hex,
             "acquired_at": _iso(now), "renewed_at": _iso(now),
             "lease_expires_at": _iso(now + timedelta(minutes=ctx.lease_minutes))}
    commit = ctx.claim_commit(lease, document=ORCHESTRATOR_LEASE)
    if existing is not None:
        leases = [f"{ref}:{existing_sha}"]
    else:
        leases = [f"{ref}:"]
    pushed = _atomic_push(ctx, [f"{commit}:{ref}"], leases)
    if pushed.returncode:
        remote, remote_sha = _remote_orchestrator_lease(ctx, plan_id)
        if remote_sha != commit or not remote or not _orchestrator_back_proof(remote, plan_id):
            raise CommandFailure("orchestrator acquisition CAS rejected and remote truth "
                                 "does not prove our lease; stand down", RACE, remote=remote)
    return lease


def fence_orchestrator(ctx: Context, plan_id: str, local: dict[str, Any]) -> tuple[dict[str, Any], str]:
    """Prove this invocation still holds the current orchestrator identity
    before any sensitive shared mutation (AC2)."""
    lease, lease_sha = _remote_orchestrator_lease(ctx, plan_id)
    if lease is None:
        raise CommandFailure("orchestrator lease is gone; this invocation must stand down",
                             OWNERSHIP_LOST)
    if not _orchestrator_back_proof(lease, plan_id):
        raise CommandFailure("orchestrator lease does not back-prove the current Plan; "
                             "fail-closed", OWNERSHIP_LOST, remote=lease)
    if local.get("fencing_token") != lease.get("fencing_token"):
        raise CommandFailure(
            "orchestrator fencing LOST: the Plan's orchestrator lease carries a different "
            "identity; this invocation must stand down (AC2)", OWNERSHIP_LOST,
            remote_fencing=lease.get("fencing_token"))
    if _parse_iso(lease["lease_expires_at"]) <= _utc_now():
        raise CommandFailure("orchestrator lease expired; reacquire before further shared "
                             "mutation", STALE)
    return lease, lease_sha or ""


def renew_orchestrator(ctx: Context, plan_id: str, local: dict[str, Any]) -> dict[str, Any]:
    lease, lease_sha = fence_orchestrator(ctx, plan_id, local)
    ref = _orchestrator_ref(plan_id)
    now = _utc_now()
    updated = {**lease, "renewed_at": _iso(now),
               "lease_expires_at": _iso(now + timedelta(minutes=ctx.lease_minutes))}
    commit = ctx.claim_commit(updated, document=ORCHESTRATOR_LEASE)
    pushed = _run(["git", "push", f"--force-with-lease={ref}:{lease_sha}", ctx.remote,
                   f"{commit}:{ref}"], check=False)
    remote, remote_sha = _remote_orchestrator_lease(ctx, plan_id)
    if (pushed.returncode and (remote_sha != commit or not remote or
                               not _orchestrator_back_proof(remote, plan_id))):
        raise CommandFailure("orchestrator renewal CAS rejected and remote truth does not "
                             "prove our update", OWNERSHIP_LOST, remote=remote)
    return updated


def release_orchestrator(ctx: Context, plan_id: str, local: dict[str, Any]) -> bool:
    """Identity-matched release at a safe exit point; idempotent."""
    ref = _orchestrator_ref(plan_id)
    lease, lease_sha = _remote_orchestrator_lease(ctx, plan_id)
    if lease is None:
        return False
    if not _orchestrator_back_proof(lease, plan_id):
        raise CommandFailure("orchestrator lease does not back-prove the current Plan; "
                             "refusing to release another Plan's slot", OWNERSHIP_LOST,
                             remote=lease)
    if local.get("fencing_token") != lease.get("fencing_token"):
        raise CommandFailure("orchestrator fencing LOST; this invocation must not release "
                             "the slot it no longer holds", OWNERSHIP_LOST)
    pushed = _run(["git", "push", f"--force-with-lease={ref}:{lease_sha}", ctx.remote,
                   f":{ref}"], check=False)
    remaining, _sha = _remote_orchestrator_lease(ctx, plan_id)
    if pushed.returncode and remaining is not None:
        raise CommandFailure("orchestrator release was not confirmed", OWNERSHIP_LOST,
                             remote=remaining)
    return True


# ------------------------------------------------------- reconstruction

def reconstruct(ctx: Context) -> dict[str, Any]:
    """Rebuild orchestration state from GitHub durable truth only (AC3)."""
    plan, revision = _remote_plan(ctx)
    if plan is None:
        raise CommandFailure("no current Execution Plan revision exists; nothing to "
                             "orchestrate", INELIGIBLE)
    claims: dict[str, dict[str, Any]] = {}
    for ref in ctx.claim_refs():
        record, _sha = ctx.remote_json(ref)
        if record is None or record.get("v") != 3:
            continue
        claims[record.get("claim_id")] = record
    live_leases: dict[str, dict[str, Any]] = {}
    result = _run(["git", "ls-remote", ctx.remote, f"{_execution_lease_ref(ctx, '')}*"],
                  check=False)
    if result.returncode:
        # Reconstruction reads GitHub durable truth; an unreadable lease
        # namespace must never be misread as "no live capacity" (AC3/AC4).
        raise CommandFailure(
            "cannot list remote execution leases; durable truth is unreadable "
            "and the orchestrator must not start work", OWNERSHIP_LOST,
            detail=(result.stderr.strip() or result.stdout.strip())[:300])
    for line in result.stdout.splitlines():
        if "\t" not in line:
            continue
        _sha, ref = line.split("\t", 1)
        claim_id = ref[len(_execution_lease_ref(ctx, "")):]
        record, _lease_sha = _remote_execution_lease(ctx, claim_id)
        if record is not None:
            live_leases[claim_id] = record
    # A live execution lease whose claim_id names no durable claim lineage is
    # an ambiguity the orchestrator must not paper over (AC4).
    orphans = sorted(set(live_leases) - set(claims))
    if orphans:
        raise CommandFailure("AMBIGUOUS live execution leases without durable claim "
                             f"lineages: {orphans}; fail-closed — reconcile manually",
                             OWNERSHIP_LOST, orphans=orphans)
    return {"plan": plan, "revision": revision, "claims": claims,
            "live_leases": live_leases}


# ---------------------------------------------------- semantic runnable

def plan_handoff(ctx: Context) -> dict[str, Any]:
    """Read-only evaluation of the current Plan for host-native handoff (#75).

    The production activation path no longer launches engineering agents:
    ght mechanically derives the authorized, dependency-satisfied work from
    durable truth (the same start-gates an interactive claim runs) and hands
    it to the already-online primary B, which executes it through the
    canonical claim primitives and its own host-native orchestration. No
    orchestrator slot is acquired and no driver runs; the bundle is an
    ephemeral handoff, never a durable authority — authorization consumption
    still happens at `ght claim` time."""

    state = reconstruct(ctx)
    plan = state["plan"]
    work: list[dict[str, Any]] = []
    for item in semantic_runnable(ctx, state):
        node = next((n for n in plan["nodes"] if n["issue"] == item["issue"]), {})
        work.append({
            "issue": item["issue"],
            "source": "plan",
            "kind": item.get("kind", "new"),
            "priority": item["priority"],
            "authorization_id": item["authorization_id"],
            "contract_digest": node.get("contract_digest"),
            "runnable": item["runnable"],
            "reason": item.get("reason") or item.get("admissible_reason"),
        })
    return {"plan_id": plan["plan_id"], "plan_revision": state["revision"],
            "work": work,
            "note": ("host-native handoff: execute runnable work via "
                     "`ght claim <issue> --plan-authorization <id>` and the "
                     "canonical github-task Skill; ght does not launch "
                     "engineering agents in production")}


def semantic_runnable(ctx: Context, state: dict[str, Any]) -> list[dict[str, Any]]:
    """Evaluate the A-authored semantic runnable predicate per node (AC4).

    Every mechanical start-gate is re-derived from durable truth via the
    same primitives an interactive plan-authorized claim runs; any ambiguity
    or unmet gate makes the node not-runnable with its durable reason. The
    result is ordered deterministically: priority DESC, then issue ASC (AC5).
    """
    plan = state["plan"]
    entries: list[dict[str, Any]] = []
    for node in sorted(plan["nodes"], key=lambda entry: entry["issue"]):
        issue = node["issue"]
        entry = {"issue": issue, "priority": node["priority"],
                 "authorization_id": node["authorization_id"], "kind": "new"}
        try:
            issue_view = ctx.github.issue_view(issue)
            contract = _validate_issue_intake(ctx, issue, issue_view, require_ready=False)
            if contract.get("authority", {}).get("implementation") != "allowed":
                raise CommandFailure("node authority is investigation-only", INELIGIBLE)
            digest = contract_digest(contract)
            try:
                _resolve_plan_start(ctx, issue, node["authorization_id"], digest)
                kind = "new"
            except CommandFailure as start_failure:
                # AC9: a consumed authorization with a parked attempt of this
                # executor whose Plan node/Contract still match, and whose
                # PR is still under review, is an orchestrated correction
                # resume — same attempt/branch/PR, fresh lease identity, no
                # fresh authorization.
                resume = _resume_eligible(ctx, node, digest)
                if resume is None:
                    raise start_failure
                kind = "resume"
                entry["claim"] = resume
            # #89: cross-Issue live capacity of the same coordination
            # identity is B/host execution HOW — it never gates the
            # runnable verdict. Same-Issue duplicate starts stay fenced by
            # the canonical claim CAS and the eligibility checks above.
            entry["kind"] = kind
            entry["admissible_reason"] = ("semantic runnable (correction resume)"
                                          if kind == "resume" else "semantic runnable")
            entry["runnable"] = True
        except CommandFailure as failure:
            entry["runnable"] = False
            entry["reason"] = str(failure)
        entries.append(entry)
    entries.sort(key=lambda entry: (-entry["priority"], entry["issue"]))
    return entries


def _resume_eligible(ctx: Context, node: dict[str, Any], digest: str) -> dict[str, Any] | None:
    """Return the parked attempt record this Plan node can orchestrate a
    correction for, or None. Eligibility is derived from durable truth
    only (AC9): non-terminal + durable delivery + not completed, same
    principal as this orchestrator with the executor identity this
    orchestrator lineage owns (the base id or one of its derived trace
    ids), same Plan authorization and Contract digest, PR still open
    (review in progress)."""
    prior, _sha = ctx.remote_claim(node["issue"])
    if prior is None or not _has_durable_delivery(prior):
        return None
    executor = prior.get("executor_id") or ""
    owned = (executor == ctx.executor_id or
             executor.startswith(f"{ctx.executor_id}/orch-"))
    if not owned or prior.get("github_principal") != ctx.github_principal:
        return None
    if claim_state(prior) != "ACTIVE":
        return None
    authorization = prior.get("authorization") or {}
    if authorization.get("authorization_id") != node["authorization_id"]:
        return None
    if prior.get("contract_digest") != digest:
        return None
    pr_number = (prior.get("delivery") or {}).get("pr")
    pr = ctx.github.pr_view(int(pr_number or 0))
    if not pr or pr.get("state") != "OPEN":
        return None
    # The durable trigger for an orchestrated correction is A's exact-SHA
    # REQUEST_CHANGES outcome on the PR (native review or the canonical
    # structured comment, same parser family as the acceptance predicate).
    # Without it the orchestrator would loop corrections forever.
    blocking, unreadable = has_exact_sha_change_request(
        reviews=ctx.github.pr_reviews(int(pr_number)),
        comments=ctx.github.pr_comments(int(pr_number)),
        candidate_sha=(prior.get("delivery") or {}).get("sha"))
    if unreadable or not blocking:
        return None
    # A live lease under the current fencing identity means the attempt is
    # already being executed; a foreign live lease is not ours to replace.
    lease, _lease_sha = _remote_execution_lease(ctx, prior["claim_id"])
    if lease is not None:
        return None
    return prior


# ---------------------------------------------------- Execution Driver

class ReferenceDriver:
    """Reference Execution Driver: a provider-neutral adapter that hydrates
    an ephemeral worktree for the attempt branch, launches a real
    engineering-execution process, and cleans the workspace up afterwards
    (AC8/AC16). It is runtime HOW — not durable truth — and is completely
    provider-agnostic: the engineering execution is whatever process the
    configured task command runs.
    """

    name = "reference"

    def __init__(self, ctx: Context):
        self.ctx = ctx
        self.run_root = Path(os.environ.get(
            "GHT_ORCHESTRATOR_RUN_DIR", ctx.main_root / ".ght" / "orchestrator-runs"))

    def admit(self, entry: dict[str, Any]) -> tuple[bool, str]:
        if os.environ.get("GHT_TEST_DRIVER_ADMIT_FAIL") == "1":
            return False, "runtime admission injected to fail (test)"
        if os.environ.get("GHT_TEST_DRIVER_ADMIT_FAIL_ISSUES") == str(entry["issue"]):
            return False, "runtime admission unavailable for this node (test)"
        usage = shutil_disk_free(self.run_root)
        if usage is not None and usage < 100 * 1024 * 1024:
            return False, "insufficient local disk for an isolated execution workspace"
        try:
            self.run_root.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            return False, f"cannot create the orchestrator run root: {exc}"
        return True, "runtime admission granted"

    def prepare(self, entry: dict[str, Any], claim: dict[str, Any]) -> Path:
        worktree = self.run_root / f"trace-{claim['issue']}-{uuid.uuid4().hex[:8]}"
        result = _run(["git", "worktree", "add", "-q", "-B", claim["branch"],
                       str(worktree), claim["execution_base"]], check=False)
        if result.returncode:
            raise CommandFailure(
                f"driver could not hydrate an isolated workspace for #{claim['issue']}: "
                f"{result.stderr.strip()}", INELIGIBLE)
        return worktree

    def launch(self, entry: dict[str, Any], claim: dict[str, Any], worktree: Path) -> dict[str, Any]:
        """Start the engineering-execution process and return a live handle
        (AC16): the orchestrator can poll completion and stop/cancel it —
        provider-neutrally — instead of being wedged inside a blocking call.
        """
        command = os.environ.get("GHT_ORCHESTRATOR_TASK_COMMAND") or (
            f"mkdir -p skills && printf 'orchestrated by the ght reference driver\\n' "
            f"> skills/orchestrated-{claim['issue']}.txt && "
            f"git add skills && "
            f"git -c user.email=driver@ght -c user.name=ght-reference-driver "
            f"commit -qm 'orchestrated engineering execution for #{claim['issue']}'")
        env = {**os.environ, "GHT_ORCHESTRATOR_ISSUE": str(entry["issue"])}
        process = subprocess.Popen(["bash", "-c", command], cwd=str(worktree),
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   text=True, start_new_session=True, env=env)
        return {"process": process, "worktree": worktree}

    def poll(self, handle: dict[str, Any]) -> bool:
        """True when the engineering execution has finished."""
        return handle["process"].poll() is not None

    def stop(self, handle: dict[str, Any]) -> dict[str, Any]:
        """Provider-neutral stop/cancel of the running execution (AC16):
        terminate the whole detached process group (the agent and its
        children), then hard-kill if it survives."""
        import signal
        process = handle["process"]
        if process.poll() is None:
            try:
                group = os.getpgid(process.pid)
                os.killpg(group, signal.SIGTERM)
            except (ProcessLookupError, PermissionError):
                process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    process.kill()
                process.wait()
        return {"ok": False, "stopped": True,
                "returncode": process.returncode,
                "output": ((process.stdout.read() if process.stdout else "") +
                           (process.stderr.read() if process.stderr else ""))[-2000:]}

    def collect(self, handle: dict[str, Any]) -> dict[str, Any]:
        process = handle["process"]
        output = ((process.stdout.read() if process.stdout else "") +
                  (process.stderr.read() if process.stderr else "")).strip()
        if process.returncode:
            return {"ok": False, "output": output[-2000:]}
        sha = _run(["git", "rev-parse", "HEAD"], cwd=str(handle["worktree"]), check=False)
        return {"ok": True, "output": output[-2000:], "head": sha.stdout.strip()}

    def cleanup(self, entry: dict[str, Any], claim: dict[str, Any], worktree: Path) -> None:
        _run(["git", "worktree", "remove", "--force", str(worktree)], check=False)
        _run(["git", "worktree", "prune"], check=False)


def shutil_disk_free(path: Path) -> int | None:
    try:
        return shutil.disk_usage(path).free
    except OSError:
        return None


DRIVERS = {"reference": ReferenceDriver}


def _driver(name: str, ctx: Context) -> Any:
    if name not in DRIVERS:
        raise CommandFailure(f"unknown Execution Driver {name!r}; available: "
                             f"{sorted(DRIVERS)}", INELIGIBLE)
    return DRIVERS[name](ctx)


# ------------------------------------------------------- trace pipeline

class OrchestratorFencingLost(CommandFailure):
    """The launching orchestrator no longer holds the Plan slot (AC2): the
    trace must stop its execution and touch nothing further."""


def _fence_trace(ctx: Context, lease: dict[str, Any],
                 plan_id: str) -> tuple[dict[str, Any], str]:
    """Positively classify EVERY orchestrator-fence failure as fencing loss
    (AC2): a trace that cannot prove the launching orchestrator's identity
    must stop and touch nothing further — it must never fall into the
    generic failure path, whose evidence comment and capacity release are
    shared mutations the current holder now owns."""
    try:
        return fence_orchestrator(ctx, plan_id, lease)
    except CommandFailure as failure:
        raise OrchestratorFencingLost(str(failure)) from failure


def _trace_cli(ctx: Context, lease: dict[str, Any], plan_id: str, args: list[str], *,
               cwd: Path | None = None,
               env_extra: dict[str, str] | None = None) -> tuple[int, str]:
    """Run one ght command for a trace, but FIRST prove the launching
    orchestrator still holds the Plan's current fencing identity (AC2): a
    superseded orchestrator — and therefore its traces — cannot mutate
    shared state (heartbeat/acquire/scope-check/preserve/deliver)."""
    _fence_trace(ctx, lease, plan_id)
    cli = Path(__file__).resolve().parents[1] / "scripts" / "ght.py"
    env = {**os.environ, "GHT_SPAWN_SUPERVISOR": "0"}
    if env_extra:
        env.update(env_extra)
    result = subprocess.run([sys.executable, str(cli), "--json", *args],
                            cwd=str(cwd or ctx.root), capture_output=True, text=True,
                            env=env)
    # stdout alone on success: the subprocess's stderr may carry advisory
    # warnings (mirror cleanup, CAS reconciliations) that would corrupt
    # JSON parsing of the combined streams; both streams on failure are
    # diagnostics only.
    output = result.stdout if result.returncode == OK else (result.stdout + result.stderr)
    return result.returncode, output.strip()


def _ensure_trace_live(ctx: Context, lease: dict[str, Any], plan_id: str,
                       issue: int, env_extra: dict[str, str] | None = None) -> str | None:
    """Renew the trace's claim+lease; an expired lease is reacquired for the
    same executor (the orchestrator claimed it) before post-driver
    mutations. Every step is behind the orchestrator fence (AC2). Returns
    the current execution-lease fencing token when it was reacquired."""
    code, output = _trace_cli(ctx, lease, plan_id, ["heartbeat", str(issue), "--force"],
                              env_extra=env_extra)
    reacquired_token = None
    if code == STALE:
        code, output = _trace_cli(ctx, lease, plan_id, ["acquire", str(issue)],
                                  env_extra=env_extra)
        if code != OK:
            raise CommandFailure(f"cannot reacquire the expired execution lease for "
                                 f"#{issue}; fail-closed", OWNERSHIP_LOST)
        try:
            reacquired_token = json.loads(output)["execution_lease"]["fencing_token"]
        except (json.JSONDecodeError, KeyError, TypeError):
            reacquired_token = None
        code, output = _trace_cli(ctx, lease, plan_id, ["heartbeat", str(issue), "--force"],
                                  env_extra=env_extra)
    if code != OK:
        raise CommandFailure(f"cannot keep the execution lease for #{issue} live; "
                             "fail-closed", OWNERSHIP_LOST)
    return reacquired_token


def _start_trace_claim(ctx: Context, lease: dict[str, Any], plan_id: str,
                       entry: dict[str, Any],
                       env_extra: dict[str, str] | None = None) -> dict[str, Any]:
    code, output = _trace_cli(ctx, lease, plan_id,
                              ["claim", str(entry["issue"]),
                               "--plan-authorization", entry["authorization_id"]],
                              env_extra=env_extra)
    if code != OK:
        raise CommandFailure(f"plan-authorized claim for #{entry['issue']} failed: "
                             f"{output[:500]}", RACE)
    try:
        payload = json.loads(output)
    except json.JSONDecodeError as exc:
        raise CommandFailure(f"claim output was not JSON: {exc}", OWNERSHIP_LOST) from exc
    return payload


def _run_trace(ctx: Context, entry: dict[str, Any], driver: Any,
               lease: dict[str, Any], plan_id: str) -> dict[str, Any]:
    """Claim (or resume), launch, harvest, preserve, and deliver one
    admitted node. The trace is bound to the launching orchestrator's
    fencing identity: every mutation re-proves it, and a fencing loss stops
    the running execution immediately instead of waiting for it (AC2/AC16).
    """
    issue = entry["issue"]
    resume_claim = entry.get("claim")
    record: dict[str, Any] = {"issue": issue, "kind": entry.get("kind", "new")}
    worktree: Path | None = None
    claim_payload: dict[str, Any] = resume_claim or {}
    handle: dict[str, Any] | None = None
    # AC5: each trace executes under its own derived executor identity
    # (`<orchestrator>/orch-<issue>-<rand>`; a resume reuses the recorded
    # one). Leases and fencing stay per identity and per Issue — each
    # derived trace identity holds at most one live lease — while actual
    # trace concurrency is B/host execution HOW (#89: no A-authored
    # envelope exists). The claim/lease/reservation refs stay namespaced
    # under the derived identity, so parallel traces never share mutable
    # bookkeeping.
    if entry.get("kind") == "resume":
        trace_executor = resume_claim.get("executor_id") or ctx.executor_id
    else:
        trace_executor = f"{ctx.executor_id}/orch-{issue}-{uuid.uuid4().hex[:6]}"
    trace_env = {"GHT_EXECUTOR_ID": trace_executor}
    record["trace_executor"] = trace_executor
    try:
        if entry.get("kind") == "resume":
            # Same durable attempt/branch/PR; a FRESH execution lease and
            # fencing identity via the ordinary same-attempt reacquire path.
            code, output = _trace_cli(ctx, lease, plan_id, ["acquire", str(issue)],
                                      env_extra=trace_env)
            if code != OK:
                raise CommandFailure(f"correction resume acquire failed for #{issue}: "
                                     f"{output[:400]}", OWNERSHIP_LOST)
            try:
                acquired = json.loads(output)
                acquired_claim_id = acquired["claim_id"]
                acquired_token = acquired["execution_lease"]["fencing_token"]
            except (json.JSONDecodeError, KeyError, TypeError) as exc:
                raise CommandFailure(f"resume acquire output was not JSON: {exc}",
                                     OWNERSHIP_LOST) from exc
            if resume_claim.get("claim_id") and acquired_claim_id != resume_claim.get("claim_id"):
                raise CommandFailure(
                    f"correction resume acquire returned claim {acquired_claim_id!r}, not the "
                    f"parked attempt {resume_claim.get('claim_id')!r} for #{issue}; fail-closed",
                    OWNERSHIP_LOST, acquired_claim_id=acquired_claim_id)
            # Identity plumbing (AC5/AC7): the resumed trace's record carries
            # the SAME durable claim id plus the fresh fencing token, so any
            # later scope-check/preserve/deliver failure — CommandFailure or
            # unexpected — flows through the fenced exact-identity capacity
            # release instead of stranding the fresh lease until expiry.
            record["claim_id"] = acquired_claim_id
            record["fencing_token"] = acquired_token
            branch = resume_claim["branch"]
            base = (resume_claim.get("candidate") or {}).get("sha")
            if not base:
                raise CommandFailure(f"no durable Candidate SHA for #{issue}'s correction "
                                     "resume; fail-closed", OWNERSHIP_LOST)
            # AC3: rehydrate from GitHub durable truth, never from a
            # pre-existing local ref — a fresh clone / takeover worker only
            # has origin/<branch>. Explicitly fetch the remote branch, then
            # prove the durable Candidate is contained in it before
            # rehydrating at the exact durable SHA.
            fetched = _run(["git", "fetch", "--force", ctx.remote, branch], check=False)
            if fetched.returncode:
                raise CommandFailure(f"cannot fetch #{issue}'s attempt branch from durable "
                                     "truth; fail-closed", OWNERSHIP_LOST)
            contained = _run(["git", "merge-base", "--is-ancestor", base, "FETCH_HEAD"],
                             check=False)
            if contained.returncode:
                raise CommandFailure(f"durable Candidate {str(base)[:12]} is not contained "
                                     f"in #{issue}'s fetched attempt branch; fail-closed",
                                     OWNERSHIP_LOST)
            worktree = driver.prepare(entry, {"issue": issue, "branch": branch,
                                              "execution_base": base})
        else:
            claim_payload = _start_trace_claim(ctx, lease, plan_id, entry,
                                               env_extra=trace_env)
            record["claim_id"] = claim_payload["claim_id"]
            record["fencing_token"] = (claim_payload.get("execution_lease") or {}).get(
                "fencing_token")
            branch = claim_payload["branch"]
            worktree = driver.prepare(entry, claim_payload)
        record["branch"] = branch
        handle = driver.launch(entry, claim_payload or {"issue": issue}, worktree)
        # Poll completion while continuously proving the orchestrator
        # fencing identity; a fencing loss STOPS the running execution
        # (AC16) instead of waiting for the blocking launch.
        while True:
            _fence_trace(ctx, lease, plan_id)
            if driver.poll(handle):
                break
            time.sleep(0.2)
        launched = driver.collect(handle)
        handle = None
        record["driver_output"] = launched.get("output", "")
        if not launched.get("ok"):
            raise CommandFailure(f"Execution Driver failed for #{issue}: "
                                 f"{launched.get('output', '')[:400]}", OWNERSHIP_LOST)
        record["driver_head"] = launched.get("head")
        reacquired = _ensure_trace_live(ctx, lease, plan_id, issue, env_extra=trace_env)
        if reacquired:
            record["fencing_token"] = reacquired
        code, output = _trace_cli(ctx, lease, plan_id, ["scope-check", str(issue)],
                                  cwd=worktree, env_extra=trace_env)
        if code != OK:
            raise CommandFailure(f"scope-check failed for orchestrated #{issue}: "
                                 f"{output[:400]}", INELIGIBLE)
        code, output = _trace_cli(ctx, lease, plan_id, ["preserve", str(issue)],
                                  cwd=worktree, env_extra=trace_env)
        if code != OK:
            raise CommandFailure(f"preserve failed for orchestrated #{issue}: "
                                 f"{output[:400]}", OWNERSHIP_LOST)
        preserved = json.loads(output)
        candidate_sha = preserved["candidate_sha"]
        record["candidate_sha"] = candidate_sha
        if entry.get("kind") == "resume":
            # Re-deliver the SAME PR: the branch tip moved, so the PR head
            # moves with it; the delivery record updates to the new exact
            # Candidate SHA without fresh authorization (AC9).
            pr_number = int((resume_claim.get("delivery") or {}).get("pr"))
        else:
            pr = ctx.github.create_pr(
                branch, f"ght: orchestrated execution for #{issue} (plan "
                        f"{entry.get('plan_id', '')})",
                f"Orchestrated Candidate\n- issue: #{issue}\n"
                f"- candidate_sha: `{candidate_sha}`\n"
                f"- driver: {driver.name}\n- review: A reviews the exact SHA\n",
                cwd=str(worktree))
            pr_number = ctx.github.parse_pr_number(pr)
        reacquired = _ensure_trace_live(ctx, lease, plan_id, issue, env_extra=trace_env)
        if reacquired:
            record["fencing_token"] = reacquired
        code, output = _trace_cli(ctx, lease, plan_id,
                                  ["deliver", str(issue), "--pr", str(pr_number),
                                   "--note", "orchestrated candidate"],
                                  cwd=worktree, env_extra=trace_env)
        if code != OK:
            raise CommandFailure(f"deliver failed for orchestrated #{issue}: "
                                 f"{output[:400]}", OWNERSHIP_LOST)
        record["pr"] = pr_number
        record["delivered"] = True
    except OrchestratorFencingLost as failure:
        if handle is not None and not driver.poll(handle):
            driver.stop(handle)
        record["error"] = str(failure)
        record["fencing_lost"] = True
    except CommandFailure as failure:
        if handle is not None and not driver.poll(handle):
            driver.stop(handle)
        record["error"] = str(failure)
        try:
            marker = f"ght:orchestrator-trace:{record.get('claim_id', issue)}"
            ctx.github.comment(issue, f"<!-- {marker} -->\n"
                               f"**ORCHESTRATED TRACE FAILED** — {failure}", marker)
        except Exception:  # noqa: BLE001 - evidence best-effort
            pass
    except Exception as failure:  # noqa: BLE001 - never die with the trace's identity
        # A non-CommandFailure failure (e.g. MirrorError from PR creation)
        # must still retain everything this trace already established —
        # claim_id, fencing token, trace executor — so the caller can run
        # the same fenced capacity-release path instead of stranding a live
        # lease until expiry, and must leave the same durable evidence.
        if handle is not None and not driver.poll(handle):
            driver.stop(handle)
        record["error"] = f"unexpected trace failure: {failure}"
        try:
            marker = f"ght:orchestrator-trace:{record.get('claim_id', issue)}"
            ctx.github.comment(issue, f"<!-- {marker} -->\n"
                               f"**ORCHESTRATED TRACE FAILED** — unexpected failure: "
                               f"{failure}", marker)
        except Exception:  # noqa: BLE001 - evidence best-effort
            pass
    finally:
        if worktree is not None:
            driver.cleanup(entry, claim_payload or {"issue": issue}, worktree)
    return record


def _release_failed_trace_capacity(ctx: Context, record: dict[str, Any], *,
                                   plan_id: str, lease: dict[str, Any]) -> None:
    """AC10: a failed trace keeps its durable attempt (never an invented A
    decision) but must not hold the executor's live capacity — release its
    execution lease and reservation by exact identity so independent
    branches can continue in the same invocation. AC2: the release is
    itself a shared mutation — positively classify fencing loss FIRST (a
    stale invocation must never touch the current holder's capacity), then
    prove the current execution holder identity before deleting; a lease
    reacquired under a different fencing identity belongs to that holder."""
    from .cli import (_delete_executor_reservation, _release_execution_lease,
                      _remote_executor_reservation)
    try:
        fence_orchestrator(ctx, plan_id, lease)
    except CommandFailure:
        return  # this invocation was superseded: the capacity is not ours to release
    claim, _sha = ctx.remote_claim(record["issue"])
    if claim is None or claim.get("claim_id") != record.get("claim_id"):
        return
    current, _lease_sha = _remote_execution_lease(ctx, claim["claim_id"])
    if current is not None:
        holder_token = record.get("fencing_token")
        if holder_token is not None and holder_token != current.get("fencing_token"):
            return  # reacquired under a different fencing identity — that holder owns it
        if holder_token is None:
            # No recorded identity for this trace: without holder proof the
            # capacity is not ours to release.
            return
    _release_execution_lease(ctx, claim, require_holder=True,
                             expected_token=record.get("fencing_token"))
    reservation, reservation_sha = _remote_executor_reservation(
        ctx, claim.get("executor_id"))
    if reservation is not None and reservation.get("claim_id") == claim["claim_id"]:
        _delete_executor_reservation(ctx, reservation, reservation_sha or "")


# ------------------------------------------------------------ main cycle

def _run_trace_batch(ctx: Context, batch: list[dict[str, Any]], driver: Any,
                     lease: dict[str, Any], plan_id: str) -> list[dict[str, Any]]:
    """Run one admitted batch concurrently (AC5): up to the effective
    ceiling, independent semantic-runnable nodes execute at the same time,
    each through its own full trace pipeline under its own derived executor
    identity. A crashed trace never kills its siblings — it comes back as a
    failed record. Returned records follow the batch order (priority DESC,
    issue ASC)."""
    if len(batch) == 1:
        return [_run_trace(ctx, batch[0], driver, lease, plan_id)]
    results: dict[int, dict[str, Any]] = {}

    def _one(index: int, entry: dict[str, Any]) -> None:
        try:
            results[index] = _run_trace(ctx, entry, driver, lease, plan_id)
        except Exception as exc:  # noqa: BLE001 - one trace must not kill its siblings
            results[index] = {"issue": entry["issue"], "kind": entry.get("kind", "new"),
                              "error": f"trace crashed: {exc}"}

    threads = [threading.Thread(target=_one, args=(index, entry), name=f"ght-trace-{entry['issue']}")
               for index, entry in enumerate(batch)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return [results[index] for index in range(len(batch))]


def orchestrate(ctx: Context, *, max_parallel: int, driver_name: str) -> dict[str, Any]:
    """One orchestrator invocation (AC11): acquire/reconcile → evaluate →
    admit → execute → park delivered → safe exit."""
    state = reconstruct(ctx)
    plan = state["plan"]
    plan_id = plan["plan_id"]
    revision = state["revision"]
    lease = acquire_orchestrator(ctx, plan_id, revision)
    report: dict[str, Any] = {
        "plan_id": plan_id, "plan_revision": revision,
        "orchestrator": {"ref": _orchestrator_ref(plan_id),
                         "fencing_token": lease["fencing_token"]},
        "runnable": [], "started": [], "delivered": [], "failed": [],
        "deferred": [], "paused": False,
    }
    try:
        renew_orchestrator(ctx, plan_id, lease)
        runnable = semantic_runnable(ctx, state)
        report["runnable"] = []
        for item in runnable:
            summary = {key: item[key] for key in ("issue", "priority", "authorization_id",
                                                  "runnable")}
            summary["reason"] = item.get("reason") or item.get("admissible_reason")
            report["runnable"].append(summary)
        driver = _driver(driver_name, ctx)
        # #89: the A-authored max_concurrency envelope is RETIRED — actual
        # execution concurrency is B/host HOW. A legacy field, if present,
        # is ignored (never reinterpreted as pause or unlimited); the
        # operator's --max-parallel remains the only dev-fixture ceiling.
        effective = max_parallel
        # AC11: drive ALL currently authorized/admissible work — re-derive
        # runnable state from durable truth after every round. The ceilings
        # gate whether new starts are allowed and how many run at once; a
        # round executes up to `effective` admitted nodes concurrently
        # (AC5), each to a delivered/parked Candidate, in deterministic
        # selection order. Rounds stop when remaining progress depends on A
        # review, unsatisfied barriers, or admission (AC11 safe exit).
        started_issues: set[int] = set()
        deferred_seen: dict[int, str] = {}
        while effective > 0:
            state = reconstruct(ctx)  # unreadable durable truth propagates fail-closed
            try:
                renew_orchestrator(ctx, plan_id, lease)
            except CommandFailure as failure:
                # Superseded (AC2): the taking-over orchestrator owns the
                # Plan slot and its recovery; this invocation stands down.
                report["stand_down"] = str(failure)
                print(f"ght: WARNING — orchestrator stand-down: {failure}",
                      file=sys.stderr)
                break
            if state["plan"]["plan_id"] != plan_id:
                # A published a different Plan mid-invocation: this slot was
                # acquired for the original plan_id, so this invocation has
                # no authority over the new graph — stand down safely.
                report["stand_down"] = ("the current Plan revision carries a different "
                                        "plan_id; this invocation was acquired for "
                                        f"{plan_id!r}")
                print(f"ght: WARNING — orchestrator stand-down: {report['stand_down']}",
                      file=sys.stderr)
                break
            # #89: no A-authored envelope exists anymore; the operator
            # ceiling alone gates fixture concurrency. Active traces are
            # never preempted.
            effective = max_parallel
            runnable = semantic_runnable(ctx, state)
            runnable = [item for item in runnable if item["issue"] not in started_issues]
            for item in runnable:
                summary = {key: item[key] for key in ("issue", "priority",
                                                      "authorization_id", "runnable")}
                summary["reason"] = item.get("reason") or item.get("admissible_reason")
                report["runnable"].append(summary)
            candidates = [item for item in runnable if item["runnable"]]
            if not candidates:
                break  # safe exit: only gated/consumed work remains
            # Admit in deterministic order up to the effective ceiling; an
            # inadmissible node is an ephemeral runtime fact (AC15) — defer
            # it and keep starting the independent nodes that ARE
            # admissible (AC10).
            batch: list[dict[str, Any]] = []
            for entry in candidates:
                if len(batch) >= effective:
                    break
                admitted, reason = driver.admit(entry)
                if not admitted:
                    deferred_seen[entry["issue"]] = reason
                    continue
                batch.append(entry)
            if not batch:
                break  # safe exit: remaining runnable work is inadmissible
            records = _run_trace_batch(ctx, [{**entry, "plan_id": plan_id} for entry in batch],
                                       driver, lease, plan_id)
            for record in records:
                if record.get("error") and not record.get("fencing_lost") and record.get("claim_id"):
                    # AC10: a failed trace keeps its durable attempt but must
                    # not hold the executor's live capacity hostage — release
                    # it by exact identity so independent branches continue.
                    # The helper re-proves the orchestrator fence first (AC2).
                    _release_failed_trace_capacity(ctx, record, plan_id=plan_id,
                                                   lease=lease)
                started_issues.add(record["issue"])
                report["started"].append(record["issue"])
                if record.get("delivered"):
                    report["delivered"].append({"issue": record["issue"],
                                                "pr": record.get("pr"),
                                                "candidate_sha": record.get("candidate_sha")})
                else:
                    report["failed"].append({"issue": record["issue"],
                                             "error": record.get("error")})
    finally:
        # Safe exit (AC11): release the Plan's orchestrator slot when this
        # invocation can no longer make progress on its own. A superseded
        # invocation cannot release what it no longer holds — warn and stand
        # down; the taking-over holder owns the slot now.
        try:
            release_orchestrator(ctx, plan_id, lease)
        except CommandFailure as failure:
            print(f"ght: WARNING — orchestrator stand-down: {failure}",
                  file=sys.stderr)
    report["deferred"] = [{"issue": issue, "reason": reason}
                          for issue, reason in sorted(deferred_seen.items())]
    return report
