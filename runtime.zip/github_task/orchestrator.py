"""B orchestrator runtime for Harry Dev (#43, #75, #236).

The production `ght orchestrate` / `ght discover` surface is a read-only
host-native handoff: every invocation rebuilds the world from GitHub
durable truth (current Plan revision, claim lineages, execution leases),
evaluates the A-authored semantic runnable predicate per node, and hands
the authorized, dependency-satisfied work to the already-online primary
B. No orchestrator slot exists, no Execution Driver runs, and no
synthetic Candidate can be generated: authorization consumption happens
only at `ght claim` time, and actual execution is B/host HOW through the
canonical claim primitives. The legacy reference-driver launch/trace
pipeline (slot lease + rounds + synthetic task command) is retired by
#236 and is intentionally absent from this module.
"""

from __future__ import annotations

from typing import Any

# NOTE: cli.py imports this module lazily (inside _cmd_orchestrate and
# _cmd_discover) to keep the module graph acyclic; this module may import
# cli normally.
from .cli import (CommandFailure, INELIGIBLE, OWNERSHIP_LOST,
                  _execution_lease_ref, _remote_execution_lease, _remote_plan,
                  _resolve_plan_start, _run, _validate_issue_intake,
                  claim_state, contract_digest, _has_durable_delivery)
from .core import has_exact_sha_change_request


# ------------------------------------------------------- reconstruction

def reconstruct(ctx: Context) -> dict[str, Any]:
    """Rebuild orchestration state from GitHub durable truth only (AC3)."""
    plan, revision = _remote_plan(ctx)
    if plan is None:
        raise CommandFailure("no current Execution Plan revision exists; nothing to "
                             "orchestrate", INELIGIBLE)
    claims: dict[str, dict[str, Any]] = {}
    for ref in ctx.claim_refs():
        record, _sha = ctx.remote_json(ref)
        if record is None or record.get("v") != 3:
            continue
        claims[record.get("claim_id")] = record
    live_leases: dict[str, dict[str, Any]] = {}
    result = _run(["git", "ls-remote", ctx.remote, f"{_execution_lease_ref(ctx, '')}*"],
                  check=False)
    if result.returncode:
        # Reconstruction reads GitHub durable truth; an unreadable lease
        # namespace must never be misread as "no live capacity" (AC3/AC4).
        raise CommandFailure(
            "cannot list remote execution leases; durable truth is unreadable "
            "and the orchestrator must not start work", OWNERSHIP_LOST,
            detail=(result.stderr.strip() or result.stdout.strip())[:300])
    for line in result.stdout.splitlines():
        if "\t" not in line:
            continue
        _sha, ref = line.split("\t", 1)
        claim_id = ref[len(_execution_lease_ref(ctx, "")):]
        record, _lease_sha = _remote_execution_lease(ctx, claim_id)
        if record is not None:
            live_leases[claim_id] = record
    # A live execution lease whose claim_id names no durable claim lineage is
    # an ambiguity the orchestrator must not paper over (AC4).
    orphans = sorted(set(live_leases) - set(claims))
    if orphans:
        raise CommandFailure("AMBIGUOUS live execution leases without durable claim "
                             f"lineages: {orphans}; fail-closed — reconcile manually",
                             OWNERSHIP_LOST, orphans=orphans)
    return {"plan": plan, "revision": revision, "claims": claims,
            "live_leases": live_leases}


# ---------------------------------------------------- semantic runnable

def plan_handoff(ctx: Context) -> dict[str, Any]:
    """Read-only evaluation of the current Plan for host-native handoff (#75).

    The production activation path no longer launches engineering agents:
    ght mechanically derives the authorized, dependency-satisfied work from
    durable truth (the same start-gates an interactive claim runs) and hands
    it to the already-online primary B, which executes it through the
    canonical claim primitives and its own host-native orchestration. No
    orchestrator slot is acquired and no driver runs; the bundle is an
    ephemeral handoff, never a durable authority — authorization consumption
    still happens at `ght claim` time."""

    state = reconstruct(ctx)
    plan = state["plan"]
    work: list[dict[str, Any]] = []
    for item in semantic_runnable(ctx, state):
        node = next((n for n in plan["nodes"] if n["issue"] == item["issue"]), {})
        work.append({
            "issue": item["issue"],
            "source": "plan",
            "kind": item.get("kind", "new"),
            "priority": item["priority"],
            "authorization_id": item["authorization_id"],
            "contract_digest": node.get("contract_digest"),
            "runnable": item["runnable"],
            "reason": item.get("reason") or item.get("admissible_reason"),
        })
    return {"plan_id": plan["plan_id"], "plan_revision": state["revision"],
            "work": work,
            "note": ("host-native handoff: execute runnable work via "
                     "`ght claim <issue> --plan-authorization <id>` and the "
                     "canonical github-task Skill; ght does not launch "
                     "engineering agents in production")}


def semantic_runnable(ctx: Context, state: dict[str, Any]) -> list[dict[str, Any]]:
    """Evaluate the A-authored semantic runnable predicate per node (AC4).

    Every mechanical start-gate is re-derived from durable truth via the
    same primitives an interactive plan-authorized claim runs; any ambiguity
    or unmet gate makes the node not-runnable with its durable reason. The
    result is ordered deterministically: priority DESC, then issue ASC (AC5).
    """
    plan = state["plan"]
    entries: list[dict[str, Any]] = []
    for node in sorted(plan["nodes"], key=lambda entry: entry["issue"]):
        issue = node["issue"]
        entry = {"issue": issue, "priority": node["priority"],
                 "authorization_id": node["authorization_id"], "kind": "new"}
        try:
            issue_view = ctx.github.issue_view(issue)
            contract = _validate_issue_intake(ctx, issue, issue_view, require_ready=False)
            if contract.get("authority", {}).get("implementation") != "allowed":
                raise CommandFailure("node authority is investigation-only", INELIGIBLE)
            digest = contract_digest(contract)
            try:
                _resolve_plan_start(ctx, issue, node["authorization_id"], digest)
                kind = "new"
            except CommandFailure as start_failure:
                # AC9: a consumed authorization with a parked attempt of this
                # executor whose Plan node/Contract still match, and whose
                # PR is still under review, is an orchestrated correction
                # resume — same attempt/branch/PR, fresh lease identity, no
                # fresh authorization.
                resume = _resume_eligible(ctx, node, digest)
                if resume is None:
                    raise start_failure
                kind = "resume"
                entry["claim"] = resume
            # #89: cross-Issue live capacity of the same coordination
            # identity is B/host execution HOW — it never gates the
            # runnable verdict. Same-Issue duplicate starts stay fenced by
            # the canonical claim CAS and the eligibility checks above.
            entry["kind"] = kind
            entry["admissible_reason"] = ("semantic runnable (correction resume)"
                                          if kind == "resume" else "semantic runnable")
            entry["runnable"] = True
        except CommandFailure as failure:
            entry["runnable"] = False
            entry["reason"] = str(failure)
        entries.append(entry)
    entries.sort(key=lambda entry: (-entry["priority"], entry["issue"]))
    return entries


def _resume_eligible(ctx: Context, node: dict[str, Any], digest: str) -> dict[str, Any] | None:
    """Return the parked attempt record this Plan node can orchestrate a
    correction for, or None. Eligibility is derived from durable truth
    only (AC9): non-terminal + durable delivery + not completed, same
    principal as this orchestrator with the executor identity this
    orchestrator lineage owns (the base id or one of its derived trace
    ids), same Plan authorization and Contract digest, PR still open
    (review in progress)."""
    prior, _sha = ctx.remote_claim(node["issue"])
    if prior is None or not _has_durable_delivery(prior):
        return None
    executor = prior.get("executor_id") or ""
    owned = (executor == ctx.executor_id or
             executor.startswith(f"{ctx.executor_id}/orch-"))
    if not owned or prior.get("github_principal") != ctx.github_principal:
        return None
    if claim_state(prior) != "ACTIVE":
        return None
    authorization = prior.get("authorization") or {}
    if authorization.get("authorization_id") != node["authorization_id"]:
        return None
    if prior.get("contract_digest") != digest:
        return None
    pr_number = (prior.get("delivery") or {}).get("pr")
    pr = ctx.github.pr_view(int(pr_number or 0))
    if not pr or pr.get("state") != "OPEN":
        return None
    # The durable trigger for an orchestrated correction is A's exact-SHA
    # REQUEST_CHANGES outcome on the PR (native review or the canonical
    # structured comment, same parser family as the acceptance predicate).
    # Without it the orchestrator would loop corrections forever.
    blocking, unreadable = has_exact_sha_change_request(
        reviews=ctx.github.pr_reviews(int(pr_number)),
        comments=ctx.github.pr_comments(int(pr_number)),
        candidate_sha=(prior.get("delivery") or {}).get("sha"))
    if unreadable or not blocking:
        return None
    # A live lease under the current fencing identity means the attempt is
    # already being executed; a foreign live lease is not ours to replace.
    lease, _lease_sha = _remote_execution_lease(ctx, prior["claim_id"])
    if lease is not None:
        return None
    return prior
