"""CLI shell for the Harry Dev github-task execution-governance safety core.

Commands: version, identity, status, inspect, validate-ready, claim, verify,
heartbeat, takeover, acquire, scope-check, preserve, ready-repair, release,
plan-publish, plan-view, stamp-distribution, orchestrate.

The runtime intentionally has no policy-overlay, lane, promotion, or
lifecycle-label surface. The two one-shot authorization surfaces are the
``ready`` label (direct/JIT) and Plan authorization identities under the
current Execution Plan revision; they are independent paths and neither is
derived from the other. github-task itself carries no independent product
version: user-facing version surfaces report the Harry Dev distribution
identity only.
"""

from __future__ import annotations

import argparse
import ctypes
import errno
import hashlib
import json
import os
import re
import select
import subprocess
import sys
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from .core import (ContractError, ExecutionPlanError, build_claim, claim_state,
                   classify_paths, contract_digest, evaluate_exact_sha_acceptance,
                   has_exact_sha_change_request, new_claim_id, parse_contract,
                   parse_execution_plan, parse_plan_authoring)
from .github import (GitHub, IntakeError, MirrorError, gh_executable,
                     tool_bin_dir)


OK = 0
ERROR = 1
INELIGIBLE = 2
RACE = 3
OWNERSHIP_LOST = 4
STALE = 5

# Execution-lease failure detection is one policy: renewal happens well before
# expiry, while canonical recovery waits for both the lease and stale-holder
# grace. The default expiry+grace window is nine minutes from last renewal.
DEFAULT_LEASE_MINUTES = 6.0
DEFAULT_TAKEOVER_GRACE_MINUTES = 3.0
SUPERVISION_INTERVAL_LEASE_DIVISOR = 4.0


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(moment: datetime) -> str:
    return moment.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_iso(value: str) -> datetime:
    return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


class CommandFailure(RuntimeError):
    def __init__(self, message: str, code: int = ERROR, **details: Any):
        super().__init__(message)
        self.code = code
        self.details = details


def _run(command: list[str], *, cwd: Path | None = None, input_text: str | None = None,
         check: bool = True,
         env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(command, cwd=cwd, input=input_text,
                                capture_output=True, text=True, env=env)
    except OSError as exc:
        # A missing/unrunnable executable degrades to a failed probe result,
        # never an unhandled crash (R1): preflight and every other surface
        # report it through their normal fail-closed paths instead of a
        # traceback (127 = executable not found).
        result = subprocess.CompletedProcess(command, 127, "",
                                             f"{type(exc).__name__}: {exc}")
    if check and result.returncode:
        detail = result.stderr.strip() or result.stdout.strip() or "command failed"
        raise CommandFailure(f"command failed: {' '.join(command[:3])}...: {detail}")
    return result


class Context:
    def __init__(self, remote: str = "origin", repo: str | None = None):
        self.root = Path(_run(["git", "rev-parse", "--show-toplevel"]).stdout.strip())
        common = _run(["git", "rev-parse", "--path-format=absolute", "--git-common-dir"], check=False).stdout.strip()
        self.main_root = Path(common).parent if common.endswith("/.git") else self.root
        self.remote = remote
        self.github = GitHub(repo, remote)
        principal = self.github.principal()
        reconciler = os.environ.get("GHT_RECONCILER_ID", "").strip()
        publisher = os.environ.get("GHT_PLAN_PUBLISHER_ID", "").strip()
        release_publisher = os.environ.get("GHT_RELEASE_PUBLISHER_ID", "").strip()
        if principal:
            # Canonical authenticated principal semantics — unchanged for
            # every ordinary user-credential runtime.
            self.github_principal = principal
            self.executor_id = os.environ.get("GHT_EXECUTOR_ID", principal)
        elif reconciler:
            # Machine caller identity: reachable ONLY for executor-neutral
            # completion (main() refuses this environment on every other
            # command). It is audit metadata for completed_by alone — it
            # never overrides a durable attempt's original identity and
            # never participates in ownership or fencing.
            self.github_principal = reconciler
            self.executor_id = os.environ.get("GHT_EXECUTOR_ID", reconciler)
        elif publisher:
            # Machine caller identity for A-side remote Plan publication
            # (#82): reachable ONLY for `ght plan-publish` (main() refuses
            # this environment on every other command). It records the
            # publication event under the runner's installation credential —
            # it carries no attempt identity, ownership, or fencing role.
            self.github_principal = publisher
            self.executor_id = os.environ.get("GHT_EXECUTOR_ID", publisher)
        elif release_publisher:
            # Machine caller identity for the canonical formal-release
            # publication (#130): reachable ONLY for `ght release-publish`
            # (main() refuses this environment on every other command). It
            # records the publication actor under the runner's installation
            # credential — execution/audit identity ONLY: it carries NO
            # release authorization (the User authorization mirror stays
            # the sole authority), and no attempt identity, ownership, or
            # fencing role.
            self.github_principal = release_publisher
            self.executor_id = os.environ.get("GHT_EXECUTOR_ID", release_publisher)
        else:
            # No authenticated principal under this credential (e.g. an
            # installation token that cannot answer GET /user) and no
            # explicit machine identity: fail closed instead of guessing.
            raise CommandFailure(
                "no authenticated GitHub principal is available (`gh api user` failed "
                "under this credential) and no machine identity "
                "(GHT_RECONCILER_ID / GHT_PLAN_PUBLISHER_ID / GHT_RELEASE_PUBLISHER_ID) "
                "is set for this command; fail closed", OWNERSHIP_LOST)
        self.lease_minutes = float(os.environ.get(
            "GHT_LEASE_MINUTES", str(DEFAULT_LEASE_MINUTES)))
        self.takeover_grace_minutes = float(os.environ.get(
            "GHT_TAKEOVER_GRACE_MINUTES", str(DEFAULT_TAKEOVER_GRACE_MINUTES)))
        # Canonical non-branch namespace (refs/ght/* never appears in the
        # GitHub Branches list). Newly created claims and reservations live
        # here exclusively; the legacy refs/heads namespace remains readable
        # for attempts that started before the cutover.
        self.claims_prefix = os.environ.get("GHT_CLAIMS_PREFIX", "refs/ght/claims/")
        self.executor_claims_prefix = os.environ.get(
            "GHT_EXECUTOR_CLAIMS_PREFIX", "refs/ght/claims-by-executor/"
        )
        self.legacy_claims_prefix = os.environ.get("GHT_LEGACY_CLAIMS_PREFIX", "refs/heads/claims/")
        self.legacy_executor_claims_prefix = os.environ.get(
            "GHT_LEGACY_EXECUTOR_CLAIMS_PREFIX", "refs/heads/claims-by-executor/"
        )
        # #93: per-invocation remote-truth snapshot. A local, discardable
        # cache namespace (`refs/ght-snapshot/<invocation>/**`, never
        # pushed) that ONE batched fetch populates at the start of a
        # discovery invocation into a UNIQUE per-invocation sub-namespace;
        # reads then resolve locally instead of one network round-trip per
        # ref. It is not authority, is invisible to other invocations, and
        # is deterministically deleted when the invocation ends (see
        # begin_remote_snapshot / end_remote_snapshot).
        self.snapshot_base = "refs/ght-snapshot/"
        self.snapshot_prefix = self.snapshot_base
        self.snapshot_active = False
        self.branch_prefix = os.environ.get("GHT_BRANCH_PREFIX", "agent/")
        self.ready_label = os.environ.get("GHT_READY_LABEL", "ready")
        # Current Execution Plan pointer (AC: exactly one current revision).
        # The revision it targets is an immutable Git commit carrying
        # PLAN.json; history is the ordinary Git object graph.
        self.plan_ref = os.environ.get("GHT_PLAN_REF", "refs/ght/plans/current")
        # Temporary execution capacity (durable attempt vs live lease
        # separation, #42): one lease ref per attempt, keyed by the durable
        # claim_id — the attempt identity itself (no second id).
        self.execution_leases_prefix = os.environ.get(
            "GHT_EXECUTION_LEASES_PREFIX", "refs/ght/execution-leases/")
        self.default_branch = os.environ.get("GHT_DEFAULT_BRANCH", "") or self._default_branch()
        state_root = self.main_root / os.environ.get("GHT_STATE_DIR", ".ght")
        # Local state is a cache, never shared between workers; hashing also
        # keeps an executor id from becoming a path component.
        executor_key = hashlib.sha256(self.executor_id.encode("utf-8")).hexdigest()[:32]
        self.state = state_root / "executors" / executor_key
        self.state.mkdir(parents=True, exist_ok=True)

    def _default_branch(self) -> str:
        output = _run(["git", "remote", "show", self.remote], check=False).stdout
        for line in output.splitlines():
            if "HEAD branch:" in line:
                return line.split(":", 1)[1].strip()
        return "main"

    def protected_head(self) -> str:
        _run(["git", "fetch", "-q", self.remote, self.default_branch])
        return _run(["git", "rev-parse", f"{self.remote}/{self.default_branch}"]).stdout.strip()

    def begin_remote_snapshot(self) -> None:
        """#93 (AC2/AC3/AC8; R2 invocation isolation): establish THIS
        invocation's read-only remote snapshot with ONE batched round-trip
        into a UNIQUE per-invocation local namespace under
        ``refs/ght-snapshot/<pid>-<nonce>/``. Overlapping activations each
        build their own namespace, so a later fetch can never move or prune
        refs another invocation is still reading, and an earlier invocation
        keeps reading exactly its own consistent view — including refs the
        remote has since deleted or moved (its snapshot predates the
        change). Fetch failure fails closed; the namespace is never pushed
        nor treated as authority. Only discovery invocations build it;
        mutating commands always read the remote directly."""

        # A namespace no other invocation can collide with (pid alone is
        # not enough: pids are reused across time).
        self.snapshot_prefix = (f"{self.snapshot_base}"
                                f"{os.getpid()}-{uuid.uuid4().hex[:12]}/")
        refspecs = [f"+refs/ght/*:{self.snapshot_prefix}ght/*",
                    f"+refs/heads/claims/*:{self.snapshot_prefix}heads/claims/*",
                    "+refs/heads/claims-by-executor/*:"
                    f"{self.snapshot_prefix}heads/claims-by-executor/*"]
        result = _run(["git", "fetch", "--force", "--prune", "-q",
                       self.remote, *refspecs], check=False)
        if result.returncode:
            detail = result.stderr.strip() or result.stdout.strip() or "snapshot fetch failed"
            raise CommandFailure(
                f"cannot build the invocation remote snapshot: {detail}; "
                "discovery must not guess from partial truth", OWNERSHIP_LOST)
        self.snapshot_active = True

    def end_remote_snapshot(self) -> None:
        """#93 R2: deterministic cleanup of THIS invocation's snapshot
        namespace — the refs never outlive the invocation, and cleanup
        deletes only the invocation's own refs, never another overlapping
        invocation's view."""

        if not self.snapshot_active:
            return
        try:
            listed = _run(["git", "for-each-ref", "--format=%(refname)",
                           self.snapshot_prefix], check=False)
            for ref in listed.stdout.split():
                _run(["git", "update-ref", "-d", ref], check=False)
        finally:
            self.snapshot_active = False
            self.snapshot_prefix = self.snapshot_base

    def snapshot_ref(self, ref: str) -> str | None:
        """Snapshot-local ref name for `ref`, or None when no snapshot is
        active or the ref is out of snapshot scope (callers fall back to
        the direct remote read)."""

        if not self.snapshot_active:
            return None
        for src, dst in (
                ("refs/ght/", f"{self.snapshot_prefix}ght/"),
                ("refs/heads/claims/", f"{self.snapshot_prefix}heads/claims/"),
                ("refs/heads/claims-by-executor/",
                 f"{self.snapshot_prefix}heads/claims-by-executor/")):
            if ref.startswith(src):
                return dst + ref[len(src):]
        return None

    def snapshot_sha(self, ref: str) -> str | None:
        """Local existence/SHA read from the active invocation snapshot.
        An absent snapshot ref means the remote ref is absent or was
        deleted (the prune removed it) — never a stale hit."""

        dst = self.snapshot_ref(ref)
        if dst is None:
            return None
        result = _run(["git", "rev-parse", "--verify", "--quiet", dst], check=False)
        if result.returncode:
            return None
        return result.stdout.strip() or None

    def ls_remote(self, ref: str) -> str | None:
        if self.snapshot_active:
            dst = self.snapshot_ref(ref)
            if dst is not None:
                # In-scope refs resolve locally: fresh from this
                # invocation's single batched fetch, deletions pruned.
                return self.snapshot_sha(ref)
        result = _run(["git", "ls-remote", self.remote, ref], check=False)
        if result.returncode:
            detail = result.stderr.strip() or result.stdout.strip() or "remote ref read failed"
            raise CommandFailure(f"cannot read remote ref {ref}: {detail}", OWNERSHIP_LOST)
        for line in result.stdout.splitlines():
            if "\t" in line:
                sha, returned_ref = line.split("\t", 1)
                if returned_ref == ref:
                    return sha
        return None

    def claim_refs(self) -> dict[str, str]:
        """Dual-read discovery: list claim refs in BOTH namespaces.

        Keys are full ref names; each ref is parsed according to the
        namespace it actually came from. Same-number presence in both
        namespaces is ambiguous and is rejected by the readers that need a
        single location (see ``claim_location``). With an active
        invocation snapshot the listing resolves locally from the same
        batched fetch (#93); identical deletion semantics apply.
        """

        refs: dict[str, str] = {}
        if self.snapshot_active:
            for prefix in {self.claims_prefix, self.legacy_claims_prefix}:
                dst = self.snapshot_ref(prefix)
                if dst is None:
                    continue
                result = _run(["git", "for-each-ref", "--format=%(refname) %(objectname)",
                               dst], check=False)
                if result.returncode:
                    raise CommandFailure(
                        "cannot read the snapshot claim listing; discovery must not "
                        "guess from partial truth", OWNERSHIP_LOST)
                for line in result.stdout.splitlines():
                    if " " in line:
                        snap_ref, sha = line.rsplit(" ", 1)
                        refs[prefix + snap_ref[len(dst):]] = sha
            return refs
        for prefix in {self.claims_prefix, self.legacy_claims_prefix}:
            result = _run(["git", "ls-remote", self.remote, f"{prefix}*"], check=False)
            if result.returncode:
                detail = result.stderr.strip() or result.stdout.strip() or "remote claim listing failed"
                raise CommandFailure(f"cannot list remote claims: {detail}", OWNERSHIP_LOST)
            for line in result.stdout.splitlines():
                if "\t" in line:
                    sha, ref = line.split("\t", 1)
                    if ref.startswith(prefix):
                        refs[ref] = sha
        return refs

    def claim_location(self, number: int) -> str:
        """Single full ref name for this Issue's claim lineage.

        Dual-read with an ambiguity guard: the same lineage present in both
        namespaces is ambiguous ownership state and fails closed instead of
        silently preferring either copy.
        """

        current = f"{self.claims_prefix}{number}"
        legacy = f"{self.legacy_claims_prefix}{number}"
        if current == legacy:
            return current
        in_current = self.ls_remote(current) is not None
        in_legacy = self.ls_remote(legacy) is not None
        if in_current and in_legacy:
            raise CommandFailure(
                f"AMBIGUOUS claim state: #{number} exists in both {current} and {legacy}; "
                "fail-closed — do not mutate; reconcile via `ght migrate-claims` (terminal only) "
                "or manual review", OWNERSHIP_LOST, current=current, legacy=legacy)
        if in_current:
            return current
        if in_legacy:
            return legacy
        return current

    def remote_json(self, ref: str, *, document: str = "CLAIM.json") -> tuple[dict[str, Any] | None, str | None]:
        if self.snapshot_active:
            dst = self.snapshot_ref(ref)
            if dst is not None:
                sha = self.snapshot_sha(ref)
                if sha is None:
                    # In-scope and absent from the fresh snapshot: the
                    # remote ref does not exist (or was deleted).
                    return None, None
                result = _run(["git", "show", f"{dst}:{document}"], check=False)
                if result.returncode:
                    raise CommandFailure(f"remote ref {ref} has no readable {document}", OWNERSHIP_LOST)
                try:
                    record = json.loads(result.stdout)
                except json.JSONDecodeError as exc:
                    raise CommandFailure(f"remote ref {ref} is not valid JSON", OWNERSHIP_LOST) from exc
                if not isinstance(record, dict):
                    raise CommandFailure(f"remote ref {ref} does not contain a JSON object",
                                         OWNERSHIP_LOST)
                # The single batched fetch is the point-in-time snapshot:
                # SHA and content come from one local object, so the
                # moved-while-being-read double-check is unnecessary here.
                return record, sha
            # Out of snapshot scope → fall through to the direct read.
        remote_sha = self.ls_remote(ref)
        if remote_sha is None:
            return None, None
        # Fetch into a private temp ref: FETCH_HEAD is shared by every
        # process in the worktree, and the lease supervisor reads claims
        # concurrently with the worker — a shared FETCH_HEAD would race.
        temp_ref = f"refs/ght-read/{os.getpid()}-{uuid.uuid4().hex[:12]}"
        try:
            fetched = _run(["git", "fetch", "-q", self.remote, f"+{ref}:{temp_ref}"],
                           check=False)
            if fetched.returncode:
                detail = fetched.stderr.strip() or fetched.stdout.strip() or "remote ref fetch failed"
                raise CommandFailure(f"cannot fetch remote ref {ref}: {detail}", OWNERSHIP_LOST)
            fetched_sha = _run(["git", "rev-parse", temp_ref]).stdout.strip()
            if fetched_sha != remote_sha:
                raise CommandFailure(f"remote ref {ref} moved while being read", OWNERSHIP_LOST,
                                     first_sha=remote_sha, fetched_sha=fetched_sha)
            result = _run(["git", "show", f"{temp_ref}:{document}"], check=False)
            if result.returncode:
                raise CommandFailure(f"remote ref {ref} has no readable {document}", OWNERSHIP_LOST)
            try:
                record = json.loads(result.stdout)
            except json.JSONDecodeError as exc:
                raise CommandFailure(f"remote ref {ref} is not valid JSON", OWNERSHIP_LOST) from exc
            if not isinstance(record, dict):
                raise CommandFailure(f"remote ref {ref} does not contain a JSON object",
                                     OWNERSHIP_LOST)
            latest_sha = self.ls_remote(ref)
            if latest_sha != fetched_sha:
                raise CommandFailure(f"remote ref {ref} moved while being read", OWNERSHIP_LOST,
                                     fetched_sha=fetched_sha, latest_sha=latest_sha)
            return record, fetched_sha
        finally:
            _run(["git", "update-ref", "-d", temp_ref], check=False)

    def remote_claim(self, number: int) -> tuple[dict[str, Any] | None, str | None]:
        ref = self.claim_location(number)
        record, ref_sha = self.remote_json(ref)
        if record is not None:
            required = ("v", "task", "claim_id", "github_principal", "executor_id",
                        "claimed_at", "lease_expires_at", "execution_base", "status",
                        "branch", "contract_digest")
            if record.get("v") == 3 and any(field not in record for field in required):
                raise CommandFailure(f"remote claim {ref} is malformed; stand down", OWNERSHIP_LOST)
        return record, ref_sha

    def local_claim_path(self, number: int) -> Path:
        return self.state / f"claim-{number}.json"

    def local_claim(self, number: int) -> dict[str, Any] | None:
        path = self.local_claim_path(number)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            raise CommandFailure(f"local claim record is invalid: {path}") from exc

    def save_claim(self, number: int, claim: dict[str, Any], ref_sha: str) -> None:
        # The `_lease` block is local-only fencing state (never part of the
        # remote record); a plain record rewrite must carry it forward or
        # every CAS update would silently strip the holder's token.
        existing = self.local_claim(number)
        lease = claim.get("_lease") or (existing or {}).get("_lease")
        payload: dict[str, Any] = {**claim, "_ref_sha": ref_sha}
        if lease:
            payload["_lease"] = lease
        self.local_claim_path(number).write_text(json.dumps(payload, indent=2) + "\n")

    def claim_commit(self, claim: dict[str, Any], parent: str | None = None,
                     *, document: str = "CLAIM.json") -> str:
        blob = _run(["git", "hash-object", "-w", "--stdin"],
                    input_text=json.dumps(claim, indent=1)).stdout.strip()
        tree = _run(["git", "mktree"],
                    input_text=f"100644 blob {blob}\t{document}\n").stdout.strip()
        command = ["git", "commit-tree", tree]
        if parent:
            command += ["-p", parent]
        label = claim.get("claim_id") or claim.get("plan_id") or claim.get("kind") or "record"
        command += ["-m", f"ght: {claim.get('status', claim.get('kind', 'record'))} {label[:24]}"]
        executor = claim.get("executor_id", "github-task")
        env = {**os.environ, "GIT_AUTHOR_NAME": executor,
               "GIT_AUTHOR_EMAIL": f"{executor}@ght",
               "GIT_COMMITTER_NAME": executor,
               "GIT_COMMITTER_EMAIL": f"{executor}@ght"}
        result = subprocess.run(command, capture_output=True, text=True, env=env)
        if result.returncode:
            raise CommandFailure(f"commit-tree failed: {result.stderr.strip()}")
        return result.stdout.strip()

    def branch_ref(self, claim: dict[str, Any]) -> str:
        return f"refs/heads/{claim['branch']}"


def _fail(failure: CommandFailure, json_output: bool) -> None:
    payload = {"ok": False, "error": str(failure), **failure.details}
    if json_output:
        print(json.dumps(payload))
    else:
        print(f"ght: {failure}", file=sys.stderr)
    raise SystemExit(failure.code)


def _same_record(left: dict[str, Any] | None, right: dict[str, Any] | None) -> bool:
    if not left or not right:
        return False
    return {key: value for key, value in left.items() if key != "_ref_sha"} == {
        key: value for key, value in right.items() if key != "_ref_sha"
    }


# --------------------------------------------------------------- intake

def _validate_issue_intake(ctx: Context, number: int, issue: dict[str, Any], *,
                           require_ready: bool) -> dict[str, Any]:
    """Validate one GitHub object as an executable Issue per canonical intake.

    - open Issue, not a Pull Request (URL-shape discrimination already
      happened in the GitHub surface);
    - optional one-shot ``ready`` authorization;
    - exactly one parseable ``ght-contract``;
    - every declared hard dependency that is still open blocks the claim; a
      closed dependency never needs an invented lifecycle label;
    - Contract authority bounds the claim mode (checked by the caller).
    """

    if str(issue.get("state", "")).lower() != "open":
        raise CommandFailure(f"#{number} is not open", INELIGIBLE)
    labels = {label.get("name", "") for label in issue.get("labels", [])}
    if require_ready and ctx.ready_label not in labels:
        raise CommandFailure(f"#{number} lacks the one-shot READY label {ctx.ready_label!r}", INELIGIBLE)
    try:
        contract = parse_contract(issue.get("body", ""))
    except ContractError as exc:
        raise CommandFailure(f"#{number} is not claimable: {exc}", INELIGIBLE) from exc
    for dependency in contract.get("depends_on", []):
        dependency_number = int(str(dependency).lstrip("#"))
        try:
            dependency_issue = ctx.github.issue_view(dependency_number)
        except IntakeError as exc:
            raise CommandFailure(
                f"hard dependency #{dependency_number} cannot be verified as closed "
                f"({exc}); the mechanical gate blocks fail-closed", INELIGIBLE) from exc
        if str(dependency_issue.get("state", "")).lower() != "closed":
            raise CommandFailure(
                f"hard dependency #{dependency_number} is still open", INELIGIBLE)
    return contract


def _assert_mode_matches_authority(contract: dict[str, Any], mode: str) -> str:
    authority = contract["authority"]["implementation"]
    if mode == "implement" and authority != "allowed":
        raise CommandFailure(
            "Contract authority is investigation-only; claim with --mode investigate "
            "or have A change the Contract and grant a fresh READY attempt", INELIGIBLE)
    return authority


# ------------------------------------------------- executor isolation

def _executor_reservation_ref(ctx: Context, executor_id: str | None = None) -> str:
    key = hashlib.sha256((executor_id or ctx.executor_id).encode("utf-8")).hexdigest()[:32]
    return f"{ctx.executor_claims_prefix}{key}"


def _legacy_executor_reservation_ref(ctx: Context, executor_id: str | None = None) -> str:
    key = hashlib.sha256((executor_id or ctx.executor_id).encode("utf-8")).hexdigest()[:32]
    return f"{ctx.legacy_executor_claims_prefix}{key}"


def _executor_reservation_location(ctx: Context, executor_id: str | None = None) -> str:
    current = _executor_reservation_ref(ctx, executor_id)
    legacy = _legacy_executor_reservation_ref(ctx, executor_id)
    if current == legacy:
        return current
    in_current = ctx.ls_remote(current) is not None
    in_legacy = ctx.ls_remote(legacy) is not None
    if in_current and in_legacy:
        raise CommandFailure(
            f"AMBIGUOUS executor reservation: present in both {current} and {legacy}; "
            "fail-closed — do not mutate; reconcile manually", OWNERSHIP_LOST,
            current=current, legacy=legacy)
    if in_current:
        return current
    if in_legacy:
        return legacy
    return current


def _remote_executor_reservation(ctx: Context, executor_id: str | None = None) -> tuple[dict[str, Any] | None, str | None]:
    record, ref_sha = ctx.remote_json(_executor_reservation_location(ctx, executor_id))
    if record is not None:
        required = ("v", "kind", "claim_id", "executor_id", "github_principal",
                    "issue", "claimed_at", "lease_expires_at")
        if any(field not in record for field in required) or record.get("kind") != "executor-reservation":
            raise CommandFailure("executor reservation is malformed; stand down", OWNERSHIP_LOST)
    return record, ref_sha


def _active_executor_claim(ctx: Context, *, ignore_claim_id: str | None = None) -> dict[str, Any] | None:
    by_number: dict[str, list[str]] = {}
    for ref in ctx.claim_refs():
        for prefix in (ctx.claims_prefix, ctx.legacy_claims_prefix):
            if ref.startswith(prefix):
                by_number.setdefault(ref[len(prefix):], []).append(ref)
                break
    for number, refs in sorted(by_number.items()):
        if len(refs) > 1:
            raise CommandFailure(
                f"AMBIGUOUS claim state: #{number} exists in both namespaces; "
                "fail-closed until reconciled", OWNERSHIP_LOST, refs=sorted(refs))
        ref = refs[0]
        # Lenient read from the ref's own namespace: pre-v3 records cannot
        # hold a v3 ACTIVE claim and are skipped, not treated as malformed.
        other, _sha = ctx.remote_json(ref)
        if other is None or other.get("v") != 3:
            continue
        # AC9 (#42/#43): capacity is the LIVE EXECUTION LEASE, not the
        # non-terminal claim record. A parked (delivered, unreviewed)
        # attempt holds no lease and neither does an attempt whose
        # temporary capacity was released or expired — an executor may keep
        # any number of them while executing one live attempt.
        if (other.get("executor_id") == ctx.executor_id and
                other.get("claim_id") != ignore_claim_id and
                claim_state(other) == "ACTIVE"):
            if _is_parked(ctx, other):
                continue
            lease, _lease_sha = _remote_execution_lease(ctx, other["claim_id"])
            if lease is None:
                continue
            return other
    return None


def _delete_executor_reservation(ctx: Context, expected: dict[str, Any], expected_sha: str) -> None:
    """Delete the reservation where it actually lives (AC6).

    Location-aware, but strictly identity- and lease-checked: the remote
    record must equal the expected reservation object and the ref must sit
    at the expected exact SHA before a leased delete is attempted. There is
    deliberately NO unconditional fallback deletion of the other namespace.
    """

    ref = _executor_reservation_location(ctx, expected.get("executor_id"))
    current, current_sha = ctx.remote_json(ref)
    if current is None:
        return
    if current_sha != expected_sha or not _same_record(current, expected):
        raise CommandFailure("executor reservation moved; refusing to delete another worker's reservation",
                             OWNERSHIP_LOST, remote=current)
    _run(["git", "push", f"--force-with-lease={ref}:{expected_sha}", ctx.remote, f":{ref}"], check=False)
    remaining, _ = ctx.remote_json(ref)
    if remaining is not None:
        raise CommandFailure("executor reservation cleanup was not confirmed", OWNERSHIP_LOST,
                             remote=remaining)


def _release_executor_marker(ctx: Context, claim_id: str,
                             reservation: dict[str, Any] | None,
                             reservation_sha: str | None) -> None:
    """#89: the executor marker is shared audit state under multi-active
    coordination. Clean it up only when it still names THIS attempt; a
    sibling attempt may already have overwritten it, and a foreign marker
    is left alone — never deleted, never an error."""
    if reservation is None:
        return
    if reservation.get("claim_id") != claim_id:
        print(f"ght: executor marker now names another attempt "
              f"({str(reservation.get('claim_id'))[:24]}); left untouched",
              file=sys.stderr)
        return
    _delete_executor_reservation(ctx, reservation, reservation_sha or "")


def _reservation_expired_past_grace(ctx: Context, reservation: dict[str, Any]) -> bool:
    try:
        expiry = _parse_iso(reservation["lease_expires_at"])
    except (KeyError, TypeError, ValueError) as exc:
        raise CommandFailure("executor reservation has no valid lease; stand down", OWNERSHIP_LOST) from exc
    return expiry + timedelta(minutes=ctx.takeover_grace_minutes) <= _utc_now()


def _prepare_executor_reservation(ctx: Context, issue: int, claim_id: str,
                                  *, ignore_claim_id: str | None = None
                                  ) -> tuple[dict[str, Any], str, str]:
    # #89: several independent authorized executions may run concurrently
    # under one coordination identity; this in-flight marker remains
    # best-effort audit state, never a cross-Issue gate.
    existing, existing_sha = _remote_executor_reservation(ctx)
    if existing:
        if (existing.get("executor_id") != ctx.executor_id or
                existing.get("github_principal") != ctx.github_principal):
            raise CommandFailure("executor reservation identity mismatch; stand down", OWNERSHIP_LOST)
        # #89: the marker is overwritten (audit state); it never gates
        # another Issue's start under multi-active coordination.

    reservation = {
        "v": 3,
        "kind": "executor-reservation",
        "claim_id": claim_id,
        "executor_id": ctx.executor_id,
        "github_principal": ctx.github_principal,
        "issue": issue,
        "claimed_at": _iso(_utc_now()),
        # Keep the in-flight lock alive even in tests or recovery commands
        # that intentionally give the Issue claim a zero-minute lease.
        "lease_expires_at": _iso(_utc_now() + timedelta(minutes=max(ctx.lease_minutes, 1.0))),
    }
    commit = ctx.claim_commit(reservation)
    # The caller CAS-overwrites the marker under an expect-lease on the
    # sha observed here (empty when absent): multi-active coordination
    # means several attempts legitimately overwrite it in sequence.
    return reservation, commit, existing_sha or ""


# ------------------------------------------------------- CAS machinery

def _atomic_push(ctx: Context, refspecs: list[str], leases: list[str] | None = None) -> subprocess.CompletedProcess[str]:
    command = ["git", "push", "--atomic"]
    command.extend(f"--force-with-lease={lease}" for lease in leases or [])
    command.extend([ctx.remote, *refspecs])
    return _run(command, check=False)


def _push_reconciled(ctx: Context, commit: str, record: dict[str, Any], ref: str, *,
                     reservation_expected: dict[str, Any] | None = None,
                     reservation_commit: str | None = None) -> bool:
    """Decide an ambiguous push outcome from remote truth, never by retrying."""

    remote, remote_sha = ctx.remote_json(ref)
    ours = remote_sha == commit and _same_record(remote, record)
    if reservation_expected is not None:
        res_record, res_sha = ctx.remote_json(_executor_reservation_ref(ctx))
        ours = ours and res_sha == reservation_commit and _same_record(res_record, reservation_expected)
    return ours


def _supervision_gate(ctx: Context, issue: int) -> None:
    # Automatic-supervision gate (AC3/AC4): if supervisor establishment
    # previously failed for this attempt, no gated command may continue —
    # the worker must not silently degrade to manual renewal. Starting
    # `ght supervise <issue>` (which re-establishes automatic renewal) is
    # the reconciliation path; same-attempt recovery uses `ght acquire`
    # after canonical expiry and stale-holder grace.
    # The gate reads the supervision status file, not the spawn flag: a
    # disabled deployment never writes spawn-failed and is unaffected,
    # while a failed establishment blocks regardless of later env changes.
    status_path = _supervise_status_path(ctx, issue)
    if status_path.exists():
        try:
            supervise_status = json.loads(status_path.read_text())
        except json.JSONDecodeError:
            supervise_status = {}
        # `failed` covers a supervisor that could not maintain renewal
        # (persistent unconfirmable state): remote ownership reads may look
        # healthy again, but mutation authority stays blocked (AC3) until
        # supervision is re-established or the same attempt is reacquired
        # after canonical expiry and grace. Transient `degraded` cycles never block.
        if supervise_status.get("state") in ("spawn-failed", "failed"):
            raise CommandFailure(
                f"FAIL-CLOSED: automatic lease supervision is not established for "
                f"#{issue} (state: {supervise_status.get('state')}); mutation authority "
                "is blocked (AC3/AC4). Re-establish it with `ght supervise " + str(issue)
                + "` while the execution host is live, or resume the same attempt with `ght acquire "
                + str(issue) + "` after expiry and grace.", INELIGIBLE)


def _ready_mirror_gate(ctx: Context, issue: int) -> None:
    # One-shot READY fail-closed gate: while a stale `ready` label
    # persists on the Issue, no gated command may continue — it must
    # never be mistakable for fresh authorization of a future attempt.
    try:
        labels = ctx.github.issue_labels(issue)
    except IntakeError as exc:
        raise CommandFailure(f"cannot verify READY mirror on #{issue}: {exc}", OWNERSHIP_LOST) from exc
    if ctx.ready_label in labels:
        raise CommandFailure(
            f"FAIL-CLOSED: stale READY label {ctx.ready_label!r} still present on #{issue}; "
            "run `ght ready-repair " + str(issue) + "` from the owning worker before continuing",
            INELIGIBLE)


def _owned_active(ctx: Context, issue: int, *, require_ready_consumed: bool = True) -> tuple[dict[str, Any], str]:
    local = ctx.local_claim(issue)
    remote, remote_sha = ctx.remote_claim(issue)
    if not local or not remote or not remote_sha:
        raise CommandFailure(f"no owned active claim for #{issue}", OWNERSHIP_LOST)
    if remote.get("claim_id") != local.get("claim_id"):
        raise CommandFailure("ownership LOST: remote claim lineage differs; STOP mutating shared state",
                             OWNERSHIP_LOST, remote=remote)
    if (remote.get("executor_id") != ctx.executor_id or
            remote.get("github_principal") != ctx.github_principal):
        raise CommandFailure("ownership LOST: claim identity does not match this executor/principal",
                             OWNERSHIP_LOST, remote=remote)
    if claim_state(remote) != "ACTIVE":
        raise CommandFailure(f"claim for #{issue} is not ACTIVE", STALE)
    if remote_sha != local.get("_ref_sha"):
        ctx.save_claim(issue, remote, remote_sha)
    _supervision_gate(ctx, issue)
    if require_ready_consumed:
        _ready_mirror_gate(ctx, issue)
    return remote, remote_sha


def _assert_contract_unchanged(ctx: Context, issue: int, claim: dict[str, Any]) -> dict[str, Any]:
    try:
        contract = parse_contract(ctx.github.issue_view(issue).get("body", ""))
    except (ContractError, IntakeError) as exc:
        raise CommandFailure(f"invalid Issue Contract: {exc}", INELIGIBLE) from exc
    if contract_digest(contract) != claim.get("contract_digest"):
        raise CommandFailure("Issue Contract changed during the active claim; stop and ask A to re-authorize",
                             INELIGIBLE)
    return contract


def _contract_drift(ctx: Context, issue: int, claim: dict[str, Any]) -> dict[str, Any] | None:
    """The canonical CURRENT contract when the claim's recorded
    contract_digest no longer matches it, else None (#166 incident class).

    Read-only drift detection over the ONE digest primitive — exactly the
    comparison `_assert_contract_unchanged` fail-closes on; it never
    weakens that fence. An unreadable Contract is NOT drift: None is
    returned so the caller's ordinary invalid-Contract failure stays
    intact, and the drift verdict is never guessed."""
    try:
        contract = parse_contract(ctx.github.issue_view(issue).get("body", ""))
    except (ContractError, IntakeError):
        return None
    if contract_digest(contract) == claim.get("contract_digest"):
        return None
    return contract


def _cas_update(ctx: Context, issue: int, current: dict[str, Any], current_sha: str,
                mutate: Callable[[dict[str, Any]], dict[str, Any]]) -> dict[str, Any]:
    updated = mutate(dict(current))
    commit = ctx.claim_commit(updated, parent=current_sha)
    # Namespace stickiness (AC2): an attempt's ref location is fixed for its
    # whole lifetime; ordinary writes never move it across namespaces.
    ref = ctx.claim_location(issue)
    pushed = _run(["git", "push", f"--force-with-lease={ref}:{current_sha}", ctx.remote,
                   f"{commit}:{ref}"], check=False)
    if pushed.returncode:
        # Reconcile from remote truth: acceptance requires the remote to
        # already carry exactly our update (lost response), not a hopeful
        # idempotence guess.
        remote, remote_sha = ctx.remote_claim(issue)
        if remote_sha != commit or not _same_record(remote, updated):
            raise CommandFailure("CAS push rejected and remote truth does not prove our update",
                                 OWNERSHIP_LOST, remote=remote)
    remote, remote_sha = ctx.remote_claim(issue)
    if not remote or remote.get("claim_id") != current.get("claim_id") or not remote_sha:
        raise CommandFailure("ownership LOST after CAS update; STOP mutating shared state", OWNERSHIP_LOST,
                             remote=remote)
    if remote_sha != commit:
        raise CommandFailure("CAS update did not reconcile to the requested record", OWNERSHIP_LOST,
                             remote_sha=remote_sha, expected_sha=commit)
    ctx.save_claim(issue, remote, remote_sha)
    return remote


# ------------------------------------------------- execution leases (#42)

def _execution_lease_ref(ctx: Context, claim_id: str) -> str:
    # AC15: the attempt identity IS the durable claim_id; issue numbers,
    # branches, executor ids, or worktree paths never name the lease.
    return f"{ctx.execution_leases_prefix}{claim_id}"


def _remote_execution_lease(ctx: Context, claim_id: str) -> tuple[dict[str, Any] | None, str | None]:
    record, ref_sha = ctx.remote_json(_execution_lease_ref(ctx, claim_id), document="LEASE.json")
    if record is not None:
        required = ("v", "kind", "claim_id", "issue", "executor_id", "github_principal",
                    "branch", "contract_digest", "fencing_token",
                    "acquired_at", "renewed_at", "lease_expires_at")
        malformed = (any(field not in record for field in required) or
                     record.get("v") != 3 or record.get("kind") != "execution-lease" or
                     any(not isinstance(record.get(field), str) or not record[field]
                         for field in ("claim_id", "executor_id", "github_principal",
                                       "branch", "contract_digest", "fencing_token")))
        if not malformed:
            try:
                for field in ("acquired_at", "renewed_at", "lease_expires_at"):
                    _parse_iso(record[field])
            except (TypeError, ValueError):
                malformed = True
        if malformed:
            raise CommandFailure("execution lease is malformed; stand down", OWNERSHIP_LOST,
                                 ref=_execution_lease_ref(ctx, claim_id))
    return record, ref_sha


def _lease_back_proof(lease: dict[str, Any], claim: dict[str, Any]) -> bool:
    """The lease record must prove it belongs to exactly this claim lineage
    (AC15): attempt identity, Issue, both owner identities, branch, and
    Contract digest all bind."""

    return (lease.get("kind") == "execution-lease" and
            lease.get("claim_id") == claim.get("claim_id") and
            lease.get("issue") == claim.get("task") and
            lease.get("executor_id") == claim.get("executor_id") and
            lease.get("github_principal") == claim.get("github_principal") and
            lease.get("branch") == claim.get("branch") and
            lease.get("contract_digest") == claim.get("contract_digest"))


def _has_durable_delivery(claim: dict[str, Any] | None) -> bool:
    """Durable-fact precondition of the parked condition: a non-terminal
    attempt carrying a Candidate delivery and no completion record."""

    return bool(claim and claim.get("status") == "active" and
                claim.get("delivery") and not claim.get("completed"))


def _execution_capacity(ctx: Context, claim: dict[str, Any]) -> dict[str, Any]:
    """Classify temporary capacity separately from the durable attempt.

    An expired lease ref is residue, not a live executor. Reacquisition is
    available only to the exact attempt owner after the configured stale
    holder grace; callers still perform that mutation through `ght acquire`.
    """

    required = ("v", "task", "claim_id", "executor_id", "github_principal",
                "branch", "contract_digest", "status", "lease_expires_at")
    malformed = (any(field not in claim for field in required) or
                 claim.get("v") != 3 or claim.get("status") != "active" or
                 not isinstance(claim.get("task"), int) or
                 isinstance(claim.get("task"), bool) or
                 any(not isinstance(claim.get(field), str) or not claim[field]
                     for field in ("claim_id", "executor_id", "github_principal",
                                   "branch", "contract_digest")))
    if not malformed:
        try:
            _parse_iso(claim["lease_expires_at"])
        except (TypeError, ValueError):
            malformed = True
    if malformed:
        raise CommandFailure("claim lineage is malformed; cannot classify execution capacity; "
                             "fail-closed", OWNERSHIP_LOST)

    lease, _sha = _remote_execution_lease(ctx, claim["claim_id"])
    if lease is None:
        return {"state": "absent", "reacquirable": True}
    if not _lease_back_proof(lease, claim):
        raise CommandFailure("execution lease does not back-prove this claim lineage; "
                             "fail-closed — reconcile manually", OWNERSHIP_LOST,
                             remote=lease)
    expiry = _parse_iso(lease["lease_expires_at"])
    if expiry > _utc_now():
        return {"state": "live", "lease_expires_at": lease["lease_expires_at"],
                "executor_id": lease["executor_id"], "reacquirable": False}
    recover_after = expiry + timedelta(minutes=ctx.takeover_grace_minutes)
    return {"state": "expired_residue", "lease_expires_at": lease["lease_expires_at"],
            "reacquirable": recover_after <= _utc_now(),
            "recovery_after": _iso(recover_after)}


def _is_parked(ctx: Context, claim: dict[str, Any] | None) -> bool:
    """Canonical parked predicate (AC5): non-terminal attempt + durable
    Candidate delivery + NO live execution lease. An expired identity-proven
    ref is stale residue, not live capacity; a delivery-present crash window
    with an unexpired lease is still not parked."""

    if not _has_durable_delivery(claim):
        return False
    return _execution_capacity(ctx, claim)["state"] != "live"


def _local_lease(ctx: Context, issue: int) -> dict[str, Any] | None:
    claim = ctx.local_claim(issue)
    lease = (claim or {}).get("_lease")
    return lease if isinstance(lease, dict) else None


def _save_local_lease(ctx: Context, issue: int, lease: dict[str, Any], ref_sha: str) -> None:
    # The local cache's `_ref_sha` stays the CLAIM ref sha (ownership truth);
    # the lease block carries its own ref sha for diagnostics only.
    claim = ctx.local_claim(issue) or {}
    ctx.save_claim(issue, {**claim, "_lease": {"ref": _execution_lease_ref(ctx, lease["claim_id"]),
                                               "token": lease["fencing_token"],
                                               "ref_sha": ref_sha,
                                               "lease_expires_at": lease.get("lease_expires_at")}},
                   claim.get("_ref_sha") or "")


def _build_lease_record(ctx: Context, claim: dict[str, Any], *,
                        token: str | None = None) -> dict[str, Any]:
    now = _utc_now()
    return {"v": 3, "kind": "execution-lease", "claim_id": claim["claim_id"],
            "issue": claim["task"], "executor_id": claim["executor_id"],
            "github_principal": claim["github_principal"], "branch": claim["branch"],
            "contract_digest": claim["contract_digest"],
            "fencing_token": token or uuid.uuid4().hex,
            "acquired_at": _iso(now), "renewed_at": _iso(now),
            "lease_expires_at": _iso(now + timedelta(minutes=ctx.lease_minutes))}


def _fence_execution_lease(ctx: Context, issue: int, claim: dict[str, Any]) -> tuple[dict[str, Any], str]:
    """Prove live execution ownership before a fenced mutation (AC3/AC13).

    The remote lease record must exist, back-prove this exact claim lineage,
    carry the fencing identity this worker acquired, and still be valid.
    Old holders — expired, superseded by a reacquire, or cache-less — fail
    closed with the recovery path; they can never continue on the claim_id
    alone.
    """

    lease, lease_sha = _remote_execution_lease(ctx, claim["claim_id"])
    if lease is None:
        if _has_durable_delivery(claim):
            raise CommandFailure(
                f"no live execution lease for #{issue}: capacity was released after the "
                "durable Candidate delivery (the attempt stays non-terminal); reacquire a "
                "fresh lease identity with `ght acquire " + str(issue) + "`", INELIGIBLE)
        raise CommandFailure(
            f"no live execution lease for #{issue}; the attempt has no temporary execution "
            "ownership — reacquire with `ght acquire " + str(issue) + "`", OWNERSHIP_LOST)
    if not _lease_back_proof(lease, claim):
        raise CommandFailure("execution lease does not back-prove this claim lineage; "
                             "fail-closed — reconcile manually", OWNERSHIP_LOST, remote=lease)
    local = _local_lease(ctx, issue) or {}
    if local.get("token") != lease.get("fencing_token"):
        raise CommandFailure(
            "execution ownership LOST: the live lease carries a different fencing identity; "
            "this holder must not mutate shared state (AC3). Reacquire with `ght acquire "
            + str(issue) + "` if the lease has expired", OWNERSHIP_LOST,
            remote_fencing=lease.get("fencing_token"))
    if _parse_iso(lease["lease_expires_at"]) <= _utc_now():
        raise CommandFailure(
            f"execution lease for #{issue} has expired; the stale holder must not mutate "
            "shared state — reacquire with `ght acquire " + str(issue) + "` (same attempt, "
            "new fencing identity)", STALE, lease_expires_at=lease["lease_expires_at"])
    return lease, lease_sha or ""


def _release_execution_lease(ctx: Context, claim: dict[str, Any], *,
                             require_holder: bool,
                             expected_token: str | None = None) -> bool:
    """Release this attempt's temporary execution capacity (AC4).

    Exact-identity checked and idempotent from remote truth: an absent lease
    is already-released success; a present lease must back-prove this exact
    claim lineage before its exact-ref delete. ``require_holder`` enforces
    the fencing identity of a live holder (pre-delivery release paths);
    post-delivery residue cleanup may proceed on lineage proof alone once
    the durable delivery makes the attempt's Candidate identity remote truth.
    The holder identity comes from the local lease cache, or — for a caller
    acting on a trace claimed under a derived executor identity — from the
    explicit ``expected_token`` this caller recorded when it minted the
    lease.
    """

    ref = _execution_lease_ref(ctx, claim["claim_id"])
    lease, lease_sha = _remote_execution_lease(ctx, claim["claim_id"])
    if lease is None:
        return False
    if not _lease_back_proof(lease, claim):
        raise CommandFailure("execution lease residue does not back-prove this claim "
                             "lineage; refusing to release another attempt's capacity",
                             OWNERSHIP_LOST, remote=lease)
    if require_holder:
        local = _local_lease(ctx, claim["task"]) or {}
        holder_token = local.get("token")
        if expected_token is not None:
            holder_token = expected_token
        if holder_token != lease.get("fencing_token"):
            raise CommandFailure(
                "execution lease is held under a different fencing identity; this holder "
                "must not release it", OWNERSHIP_LOST, remote=lease)
    pushed = _run(["git", "push", f"--force-with-lease={ref}:{lease_sha}", ctx.remote,
                   f":{ref}"], check=False)
    remaining, _ = _remote_execution_lease(ctx, claim["claim_id"])
    if pushed.returncode and remaining is not None:
        raise CommandFailure("execution lease release was not confirmed; capacity residue "
                             "must be reconciled before continuing", OWNERSHIP_LOST, remote=remaining)
    return True


def _renew_claim_and_lease(ctx: Context, issue: int, claim: dict[str, Any], claim_sha: str, *,
                          before_commit: Callable[[], None] | None = None) -> dict[str, Any]:
    """One fenced renewal of the attempt liveness AND the execution lease.

    Both refs move in one atomic CAS push: renewing the claim record while
    losing the lease (or vice versa) would split durable-liveness from
    live-capacity ownership. The holder must prove the current fencing
    identity and an unexpired lease — an expired lease is reacquired, never
    renewed in place (AC3).
    """

    lease, lease_sha = _remote_execution_lease(ctx, claim["claim_id"])
    if lease is None:
        if _has_durable_delivery(claim):
            raise CommandFailure(
                f"no live execution lease for #{issue}: capacity was released after the "
                "Candidate delivery; reacquire with `ght acquire " + str(issue) + "`",
                INELIGIBLE)
        raise CommandFailure(f"no live execution lease for #{issue}; reacquire with "
                             "`ght acquire " + str(issue) + "`", OWNERSHIP_LOST)
    if not _lease_back_proof(lease, claim):
        raise CommandFailure("execution lease does not back-prove this claim lineage; "
                             "fail-closed", OWNERSHIP_LOST, remote=lease)
    local = _local_lease(ctx, issue) or {}
    if local.get("token") != lease.get("fencing_token"):
        raise CommandFailure(
            "execution ownership LOST: the live lease carries a different fencing identity "
            "(AC3); reacquire with `ght acquire " + str(issue) + "` after expiry", OWNERSHIP_LOST)
    now = _utc_now()
    if _parse_iso(lease["lease_expires_at"]) <= now:
        raise CommandFailure(
            f"execution lease for #{issue} expired; the stale holder must reacquire with "
            "`ght acquire " + str(issue) + "` instead of renewing", STALE)
    new_expiry = _iso(now + timedelta(minutes=ctx.lease_minutes))
    updated_claim = {**claim, "heartbeat_at": _iso(now), "lease_expires_at": new_expiry}
    updated_lease = {**lease, "renewed_at": _iso(now), "lease_expires_at": new_expiry}
    claim_commit = ctx.claim_commit(updated_claim, parent=claim_sha)
    lease_commit = ctx.claim_commit(updated_lease, document="LEASE.json")
    claim_ref = ctx.claim_location(issue)
    lease_ref = _execution_lease_ref(ctx, claim["claim_id"])
    if before_commit is not None:
        before_commit()
    pushed = _atomic_push(ctx, [f"{claim_commit}:{claim_ref}", f"{lease_commit}:{lease_ref}"],
                          [f"{claim_ref}:{claim_sha}", f"{lease_ref}:{lease_sha}"])
    if pushed.returncode:
        remote_claim_row, remote_claim_sha = ctx.remote_claim(issue)
        remote_lease_row, remote_lease_sha = _remote_execution_lease(ctx, claim["claim_id"])
        if (remote_claim_sha != claim_commit or not _same_record(remote_claim_row, updated_claim) or
                remote_lease_sha != lease_commit or not _same_record(remote_lease_row, updated_lease)):
            raise CommandFailure("renewal CAS rejected and remote truth does not prove our update",
                                 OWNERSHIP_LOST, remote=remote_claim_row)
    ctx.save_claim(issue, updated_claim, claim_commit)
    _save_local_lease(ctx, issue, updated_lease, lease_commit)
    return updated_claim


def _acquire_execution_lease(ctx: Context, issue: int, claim: dict[str, Any], claim_sha: str) -> dict[str, Any]:
    """Acquire a fresh temporary execution lease for an owned attempt.

    Same-attempt resume (AC6): the durable claim identity is untouched; the
    lease is created fresh (or replaces only an identity-proven residue that
    is expired past the stale-holder grace) with a NEW fencing identity.
    Concurrent live holders and in-grace residues fail closed.
    """

    existing, existing_sha = _remote_execution_lease(ctx, claim["claim_id"])
    if existing is not None:
        if not _lease_back_proof(existing, claim):
            raise CommandFailure("execution lease residue does not back-prove this claim "
                                 "lineage; fail-closed — reconcile manually", OWNERSHIP_LOST,
                                 remote=existing)
        expiry = _parse_iso(existing["lease_expires_at"])
        if expiry > _utc_now():
            raise CommandFailure(
                f"#{issue} already holds a live execution lease (fencing identity active); "
                "a second concurrent holder is refused", RACE, lease_expires_at=existing["lease_expires_at"])
        if expiry + timedelta(minutes=ctx.takeover_grace_minutes) > _utc_now():
            raise CommandFailure(
                f"the expired execution lease for #{issue} is within the stale-holder grace "
                "window; reacquire after it passes", RACE, lease_expires_at=existing["lease_expires_at"])
    token = uuid.uuid4().hex
    now = _utc_now()
    lease = _build_lease_record(ctx, claim, token=token)
    lease_ref = _execution_lease_ref(ctx, claim["claim_id"])

    updated_claim = {**claim, "heartbeat_at": _iso(now),
                     "lease_expires_at": _iso(now + timedelta(minutes=ctx.lease_minutes))}
    claim_commit = ctx.claim_commit(updated_claim, parent=claim_sha)
    lease_commit = ctx.claim_commit(lease, document="LEASE.json")

    # Direct-executor capacity companion (AC16): restore the reservation the
    # delivered attempt released, or refresh the in-flight one this attempt
    # already holds.
    reservation, reservation_sha = _remote_executor_reservation(ctx)
    reservation_refspecs: list[str] = []
    reservation_leases: list[str] = []
    reservation_record = None
    if reservation is not None:
        # #89: the marker is audit state. It is refreshed under THIS
        # attempt's identity without touching another attempt's capacity —
        # independent Issues no longer serialize on it.
        refreshed = {**reservation, "claim_id": claim["claim_id"], "issue": issue,
                     "claimed_at": _iso(now),
                     "lease_expires_at": _iso(now + timedelta(minutes=max(ctx.lease_minutes, 1.0)))}
        reservation_record = refreshed
        commit = ctx.claim_commit(refreshed)
        reservation_refspecs = [f"{commit}:{_executor_reservation_ref(ctx)}"]
        reservation_leases = [f"{_executor_reservation_ref(ctx)}:{reservation_sha}"]
        reservation_commit = commit
    else:
        reservation_record = {"v": 3, "kind": "executor-reservation", "claim_id": claim["claim_id"],
                              "executor_id": ctx.executor_id,
                              "github_principal": ctx.github_principal, "issue": issue,
                              "claimed_at": _iso(now),
                              "lease_expires_at": _iso(now + timedelta(minutes=max(ctx.lease_minutes, 1.0)))}
        reservation_commit = ctx.claim_commit(reservation_record)
        reservation_refspecs = [f"{reservation_commit}:{_executor_reservation_ref(ctx)}"]
        reservation_leases = [f"{_executor_reservation_ref(ctx)}:"]

    claim_ref = ctx.claim_location(issue)
    if existing is not None:
        lease_leases = [f"{lease_ref}:{existing_sha}"]
    else:
        lease_leases = [f"{lease_ref}:"]
    pushed = _atomic_push(
        ctx, [f"{claim_commit}:{claim_ref}", f"{lease_commit}:{lease_ref}", *reservation_refspecs],
        [f"{claim_ref}:{claim_sha}", *lease_leases, *reservation_leases])
    if pushed.returncode:
        remote_claim_row, remote_claim_sha = ctx.remote_claim(issue)
        remote_lease_row, remote_lease_sha = _remote_execution_lease(ctx, claim["claim_id"])
        if (remote_claim_sha != claim_commit or not _same_record(remote_claim_row, updated_claim) or
                remote_lease_sha != lease_commit or not _same_record(remote_lease_row, lease)):
            raise CommandFailure("acquire CAS rejected and remote truth does not prove our update",
                                 RACE, remote=remote_claim_row)
    ctx.save_claim(issue, updated_claim, claim_commit)
    _save_local_lease(ctx, issue, lease, lease_commit)
    return lease


# ------------------------------------------------------------- commands

# Harry Dev release packaging writes this manifest into the skill directory,
# so formal release installs keep their identity without any git metadata
# (copied directories, extracted release archives, adapter file copies).
DISTRIBUTION_MANIFEST = "DISTRIBUTION.json"
_RELEASE_TAG = re.compile(r"v\d+(?:\.\d+)*")


def _carried_release(root: Path) -> tuple[str | None, str | None]:
    """Read the carried Harry Dev release identity from the distribution
    manifest. Returns (release, source_sha); (None, None) when the manifest
    is absent, unreadable, or does not carry a well-formed Harry Dev release
    — a manifest that cannot prove a release never claims one."""

    try:
        data = json.loads((root / DISTRIBUTION_MANIFEST).read_text())
    except (OSError, ValueError):
        return None, None
    if not isinstance(data, dict):
        return None, None
    release = data.get("release")
    if not isinstance(release, str) or not _RELEASE_TAG.fullmatch(release.strip()):
        return None, None
    if "product" in data and data.get("product") != "harry-dev":
        return None, None
    sha = data.get("source_sha")
    return release.strip(), (sha.strip() if isinstance(sha, str) and sha.strip() else None)


def _distribution_content_digest(source: Path) -> str:
    """The deterministic content digest of a distribution tree EXCLUDING the
    identity manifest itself (the manifest records a digest derived from
    this one — including it would be circular). Same canonical
    serialization as the runtime capsule payload, so the digest is stable
    across copy/archive/extract and is computed identically by the producer
    (``stamp-distribution``) and the consumer (bootstrap/preflight). The
    digest is the identity of file BYTES + relative paths — deliberately
    NOT of unix modes: a release install is download + extract and
    extraction does not carry modes, so a mode-dependent digest would
    refuse every legitimate install of a distribution carrying executable
    files (review R3 finding 1: the provenance chain must hold for the
    real installed bytes)."""

    import io
    import zipfile
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(source.rglob("*")):
            if path.is_dir():
                continue
            rel = path.relative_to(source).as_posix()
            if rel.startswith(".git/") or "__pycache__" in rel:
                continue
            if rel == DISTRIBUTION_MANIFEST:
                continue
            info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
            info.external_attr = 0o644 << 16  # bytes+path identity, not modes
            archive.writestr(info, path.read_bytes())
    return hashlib.sha256(buffer.getvalue()).hexdigest()


def _distribution_identity_binding(release: str, source_sha: str | None,
                                   content_digest: str) -> str:
    """The recorded release provenance digest: the content digest bound to
    the exact manifest identity fields, so neither the installed tree NOR
    the manifest's claimed identity can change without breaking the
    recorded binding."""

    canonical = json.dumps({"product": "harry-dev", "release": release,
                            "source_sha": source_sha}, sort_keys=True)
    return hashlib.sha256(
        f"{content_digest}\n{canonical}".encode()).hexdigest()


def _release_content_provenance(root: Path | None = None) -> dict[str, Any]:
    """Verify an installed distribution's release identity against the
    provenance recorded at stamp time (review R2, provenance disposition).

    Root of trust, stated exactly: the release producer stamps
    ``DISTRIBUTION.json`` ONLY from a source checkout that sits exactly on
    the release tag (the ``stamp-distribution`` gate) and records the
    content-binding digest of the stamped tree. The ``released``
    determination therefore derives from the installed tree VERIFYING
    against that recorded digest — not from the manifest's claim alone: a
    locally modified tree that merely retains (or edits) DISTRIBUTION.json
    fails verification. The canonical GitHub Release asset (URL + digest —
    the same bytes published at ``refs/ght/runtime/<digest>``) remains the
    external anchor; this local binding proves the installed tree IS the
    tree the release producer stamped from the exact-tag checkout. It
    cannot exclude an adversary who rewrites the tree AND recomputes the
    binding — excluding that would require a signing/external-anchor
    mechanism, which #165 deliberately does not add; downstream install
    should obtain the tree from the canonical release asset.

    Returns facts, never raises: {manifest_present, release, source_sha,
    release_repo, digest, content_digest, verified, reason}."""

    base = os.environ.get("GHT_DISTRIBUTION_ROOT")
    resolved = root or (Path(base).resolve() if base
                        else Path(__file__).resolve().parents[1])
    facts: dict[str, Any] = {"manifest_present": False, "release": None,
                             "source_sha": None, "release_repo": None,
                             "digest": None,
                             "content_digest": None, "verified": False,
                             "reason": None}
    try:
        data = json.loads((resolved / DISTRIBUTION_MANIFEST).read_text())
    except (OSError, ValueError):
        facts["reason"] = "no readable identity manifest (dev/unstamped tree)"
        return facts
    if not isinstance(data, dict):
        facts["reason"] = "unreadable identity manifest"
        return facts
    release = data.get("release")
    sha = data.get("source_sha")
    digest = data.get("digest")
    repo = data.get("release_repo")
    release = release.strip() if isinstance(release, str) else None
    sha = sha.strip() if isinstance(sha, str) and sha.strip() else None
    repo = repo.strip() if isinstance(repo, str) and repo.strip() else None
    facts.update({"manifest_present": True, "release": release,
                  "source_sha": sha, "release_repo": repo})
    if not release or not _RELEASE_TAG.fullmatch(release):
        facts["reason"] = "no well-formed release claim"
        return facts
    if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
        facts["reason"] = ("the manifest carries no verifiable content-binding "
                           "digest (a pre-R2 install) — re-install from a "
                           "current release distribution")
        return facts
    facts["digest"] = digest
    content = _distribution_content_digest(resolved)
    facts["content_digest"] = content
    if _distribution_identity_binding(release, sha, content) != digest:
        facts["reason"] = ("the installed distribution does not verify against "
                           "its stamped release identity — the installed "
                           "content does not match its stamped digest "
                           "(content drift or tampering)")
        return facts
    facts["verified"] = True
    return facts


def _corroborate_release_provenance(root: Path) -> dict[str, Any]:
    """Consumer leg of the formal-release provenance chain (review R3
    finding 1): bootstrap's ``released`` determination consumes the
    ESTABLISHED provenance — the canonical durable release surface — and
    never manufactures release truth from the mutable local manifest
    alone.

    The chain, with the fact that anchors each step stated exactly:

      frozen ``--target`` SHA
        → the producer packages ONLY from a checkout whose HEAD is exactly
          that SHA and whose tree is clean (``release-publish`` proof,
          pre-stamp) — the packaged bytes are the frozen target's bytes;
        → packaged distribution bytes
          (``DISTRIBUTION.json`` records the content-binding digest at the
          exact-tag checkout; the consumer's local verification compares
          the installed tree against it);
        → runtime capsule digest (the content-addressed ref name;
          producer-side the asset digest is proven equal to it BEFORE
          upload);
        → canonical Release asset bytes (the durable anchor): the producer
          records the release repository in the stamped manifest and the
          consumer DOWNLOADS the canonical ``github-task-<release>.zip``
          from it through the standard gh surface and requires the
          installed manifest AND installed tree content to be exactly the
          asset's.

    A locally re-authored manifest + recomputed binding is self-consistent
    and passes the local verification; it cannot pass this corroboration,
    which is anchored in bytes this host does not author. Remaining
    unproven, stated honestly: an adversary who controls a GitHub Release
    carrying a matching self-consistent asset on the recorded repository
    still passes — equivalently, the trust root remains the canonical
    release surface of the recorded release repository, the same boundary
    #165 already states (no PKI/control plane is added); the corroboration
    is offline-testable through the standard gh surface fixtures.
    """

    base = os.environ.get("GHT_DISTRIBUTION_ROOT")
    resolved = root or (Path(base).resolve() if base
                        else Path(__file__).resolve().parents[1])
    try:
        data = json.loads((resolved / DISTRIBUTION_MANIFEST).read_text())
    except (OSError, ValueError) as exc:
        raise CommandFailure(
            "the installed distribution carries no readable identity manifest, so its "
            "release identity cannot be corroborated against the canonical release "
            f"surface ({exc})", INELIGIBLE) from exc
    if not isinstance(data, dict):
        raise CommandFailure(
            "the installed distribution's identity manifest is not a JSON object; the "
            "release identity cannot be corroborated", INELIGIBLE)
    release = data.get("release")
    release = release.strip() if isinstance(release, str) else ""
    if not _RELEASE_TAG.fullmatch(release):
        raise CommandFailure(
            "the installed distribution carries no well-formed release claim to "
            "corroborate against the canonical release surface", INELIGIBLE)
    repo = data.get("release_repo")
    if not isinstance(repo, str) or not repo.strip():
        raise CommandFailure(
            "the installed distribution's identity manifest carries no "
            "release-repository fact (a pre-provenance install): bootstrap must "
            "corroborate the installed identity against the canonical release surface, "
            "not the mutable local manifest alone — re-install from a current release "
            "distribution", INELIGIBLE)
    repo = repo.strip()
    asset_name = f"github-task-{release}.zip"
    record = _run([gh_executable(), "api",
                   f"repos/{repo}/releases/tags/{release}"], check=False)
    if record.returncode:
        raise CommandFailure(
            f"no canonical release {release!r} is readable on the recorded release "
            f"repository {repo!r} ({record.stderr.strip() or record.stdout.strip()}): "
            "the installed identity cannot be corroborated against the durable release "
            "surface — install the distribution from the official release asset",
            OWNERSHIP_LOST)
    try:
        parsed = json.loads(record.stdout)
    except ValueError as exc:
        raise CommandFailure(
            f"the release surface for {release!r} on {repo!r} returned invalid JSON",
            OWNERSHIP_LOST) from exc
    assets = [asset for asset in (parsed.get("assets") or [])
              if isinstance(asset, dict)] if isinstance(parsed, dict) else []
    if (not isinstance(parsed, dict) or parsed.get("draft") or parsed.get("prerelease")
            or not any(asset.get("name") == asset_name for asset in assets)):
        raise CommandFailure(
            f"the release {release!r} on {repo!r} is not a final release carrying the "
            f"canonical distribution asset {asset_name!r}; the installed identity "
            "cannot be corroborated against the durable release surface",
            OWNERSHIP_LOST)
    import tempfile
    import zipfile as _zipfile
    with tempfile.TemporaryDirectory(prefix="ght-provenance-") as tmp:
        got = _run([gh_executable(), "--repo", repo, "release", "download",
                    release, "--pattern", asset_name, "--dir", tmp], check=False)
        if got.returncode:
            raise CommandFailure(
                f"cannot download the canonical distribution asset {asset_name!r} from "
                f"{repo!r} ({got.stderr.strip() or got.stdout.strip()}): the installed "
                "identity cannot be corroborated against the durable release surface",
                OWNERSHIP_LOST)
        asset_path = Path(tmp) / asset_name
        asset_sha = hashlib.sha256(asset_path.read_bytes()).hexdigest()
        asset_tree = Path(tmp) / "asset"
        try:
            with _zipfile.ZipFile(asset_path) as archive:
                archive.extractall(asset_tree)
        except (_zipfile.BadZipFile, OSError) as exc:
            raise CommandFailure(
                f"the canonical distribution asset {asset_name!r} on {repo!r} is not a "
                f"readable distribution archive ({exc})", OWNERSHIP_LOST) from exc
        try:
            asset_manifest = json.loads(
                (asset_tree / DISTRIBUTION_MANIFEST).read_text())
        except (OSError, ValueError):
            asset_manifest = None
        if asset_manifest != data:
            raise CommandFailure(
                "the installed identity manifest is not the manifest the canonical "
                f"release asset {asset_name!r} on {repo!r} carries; the local manifest "
                "is mutable and cannot manufacture release truth — re-install the "
                "distribution from the official release asset",
                OWNERSHIP_LOST, installed_manifest=data,
                asset_manifest=asset_manifest)
        installed_digest = _distribution_content_digest(resolved)
        asset_digest = _distribution_content_digest(asset_tree)
        if installed_digest != asset_digest:
            raise CommandFailure(
                "the installed distribution does not match the canonical release asset "
                f"{asset_name!r} on {repo!r} (installed content {installed_digest[:12]}, "
                f"asset content {asset_digest[:12]}); a locally re-authored tree and "
                "recomputed binding are self-consistent but are not the released bytes "
                "— re-install the distribution from the official release asset",
                OWNERSHIP_LOST, installed_content_digest=installed_digest,
                asset_content_digest=asset_digest)
    return {"verified": True, "release_repo": repo, "asset": asset_name,
            "asset_sha256": asset_sha}


def _write_distribution_manifest(root: Path, release: str,
                                 source_sha: str | None,
                                 release_repo: str | None = None) -> None:
    """Producer side of the same manifest contract the reader enforces:
    exactly the keys the reader accepts, release pre-validated against the
    shared ``v*`` pattern, written as plain JSON so release packaging can
    stamp a distribution deterministically. The stamp also records the
    content-binding digest (review R2, provenance disposition) so the
    consumer-side ``released`` determination verifies the installed tree
    against what the producer proved, instead of trusting the manifest's
    claim alone. ``release_repo`` records the canonical release repository
    (review R3 finding 1) — the durable surface the consumer corroborates
    the installed identity against; the stamp alone cannot know it, so it
    is optional at stamping and mandatory for bootstrap corroboration."""

    digest = _distribution_identity_binding(
        release, source_sha, _distribution_content_digest(root))
    payload = {"product": "harry-dev", "release": release,
               "source_sha": source_sha, "digest": digest}
    if release_repo and release_repo.strip():
        payload["release_repo"] = release_repo.strip()
    (root / DISTRIBUTION_MANIFEST).write_text(json.dumps(payload, sort_keys=True))


def _cmd_stamp_distribution(args: argparse.Namespace) -> None:
    """Stamp the carried Harry Dev release identity onto a distribution.

    Released truth must be proven, not declared: the producer writes the
    manifest only after the release source checkout proves the requested
    identity — the source worktree's HEAD must sit exactly on the
    requested release tag (``git describe --tags --exact-match``), so a
    dev checkout or a differently tagged source can never mint a release
    manifest. With ``--source <release-checkout> --root <packaged-dir>``
    release packaging verifies the checkout and stamps the packaged copy;
    with only ``--root`` (defaulting to the runtime's own source tree) the
    root is verified and stamped in place. The write is verified by
    reading it back through the same contract ``ght version`` uses; every
    refusal happens before anything is written, so an existing manifest is
    never clobbered by a failed stamp.
    """

    release = args.release.strip()
    if not _RELEASE_TAG.fullmatch(release):
        raise CommandFailure(
            f"--release must be a Harry Dev release tag (v<major>[.<minor>...]), "
            f"got {args.release!r}", INELIGIBLE)
    source_base = args.source or args.root or os.environ.get("GHT_DISTRIBUTION_ROOT")
    source_root = (Path(source_base).resolve() if source_base
                   else Path(__file__).resolve().parents[1])
    if not source_root.is_dir():
        raise CommandFailure(f"release source {str(source_root)!r} is not a directory",
                             INELIGIBLE)

    def _git(*command: str) -> subprocess.CompletedProcess[str]:
        return _run(["git", "-C", str(source_root), *command], check=False)

    if _git("rev-parse", "--is-inside-work-tree").returncode:
        raise CommandFailure(
            f"release source {str(source_root)!r} has no git provenance; a release "
            "manifest can only be stamped from a source checkout that proves the "
            "requested release", INELIGIBLE)
    describe = _git("describe", "--tags", "--exact-match", "--match", "v*", "HEAD")
    if describe.returncode or describe.stdout.strip() != release:
        found = describe.stdout.strip() if describe.returncode == 0 else None
        raise CommandFailure(
            f"release source {str(source_root)!r} does not carry the requested release "
            f"{release!r}"
            + (f" (HEAD sits exactly on {found!r})" if found else
               " (HEAD is not exactly on any v* tag)"),
            INELIGIBLE, requested=release, source_release=found)
    # #178 AC1: the stamped source identity is the FULL exact 40-hex frozen
    # HEAD. The abbreviated form is the proven v1.1.2 producer defect — the
    # shipped thin consumer refuses any capsule manifest carrying it — and a
    # released identity that is not the exact commit fails closed here,
    # before anything is written.
    source_sha = _git("rev-parse", "HEAD").stdout.strip() or None
    if not source_sha or not re.fullmatch(r"[0-9a-f]{40}", source_sha):
        raise CommandFailure(
            f"release source {str(source_root)!r} does not prove an exact commit SHA "
            f"(resolved {source_sha!r}); a released identity must carry the full "
            "40-hex frozen HEAD — fail closed, nothing was stamped", INELIGIBLE)

    root_base = args.root or os.environ.get("GHT_DISTRIBUTION_ROOT")
    root = Path(root_base).resolve() if root_base else source_root
    if not root.is_dir():
        raise CommandFailure(f"distribution root {str(root)!r} is not a directory",
                             INELIGIBLE)
    release_repo = getattr(args, "release_repo", None)
    previous, _sha = _carried_release(root)
    _write_distribution_manifest(root, release, source_sha,
                                 release_repo=release_repo)
    verified, _verified_sha = _carried_release(root)
    if verified != release:
        raise CommandFailure(
            f"stamped manifest at {str(root / DISTRIBUTION_MANIFEST)!r} does not read "
            f"back as {release!r}; the distribution identity must not be trusted — "
            "inspect the manifest manually", OWNERSHIP_LOST)
    # Report the identity resolved from the same root the manifest was
    # written to, reusing the ordinary read path end-to-end.
    saved = os.environ.get("GHT_DISTRIBUTION_ROOT")
    os.environ["GHT_DISTRIBUTION_ROOT"] = str(root)
    try:
        identity = distribution_identity()
    finally:
        if saved is None:
            os.environ.pop("GHT_DISTRIBUTION_ROOT", None)
        else:
            os.environ["GHT_DISTRIBUTION_ROOT"] = saved
    print(json.dumps({"root": str(root),
                      "source": str(source_root),
                      "stamped": {"product": "harry-dev", "release": release,
                                  "source_sha": source_sha},
                      "identity": identity,
                      "replaced_release": previous}))


def distribution_identity(root: Path | None = None) -> dict[str, Any]:
    """Resolve the Harry Dev distribution identity for user-facing version
    surfaces (AC2/#54): github-task has no independent product version.

    A formal release install carries its identity in
    ``DISTRIBUTION.json`` beside the package (written by release packaging;
    survives copying/archiving, no ``.git`` required) and reports that
    Harry Dev tag. A source checkout sitting exactly on a ``v*`` tag is
    likewise released; development source reports unreleased with its
    locatable source SHA and never impersonates the nearest release; and a
    root without any release provenance fails honest as unreleased.
    ``GHT_DISTRIBUTION_ROOT`` overrides where the identity is resolved
    from (defaults to the package's own source tree, not the caller's cwd);
    an explicit ``root`` argument (used by the bootstrap/preflight surfaces
    to name the effective installed tree) wins over both.
    """

    base = os.environ.get("GHT_DISTRIBUTION_ROOT")
    resolved = root or (Path(base).resolve() if base
                        else Path(__file__).resolve().parents[1])

    def _git(*args: str) -> subprocess.CompletedProcess[str]:
        return _run(["git", "-C", str(resolved), *args], check=False)

    carried_release, carried_sha = _carried_release(resolved)
    in_git = _git("rev-parse", "--is-inside-work-tree").returncode == 0
    sha = (_git("rev-parse", "--short", "HEAD").stdout.strip() or None) if in_git else None
    release = carried_release
    if release is None and in_git:
        describe = _git("describe", "--tags", "--exact-match", "--match", "v*", "HEAD")
        if describe.returncode == 0:
            release = describe.stdout.strip()
    return {"product": "harry-dev", "status": "released" if release else "unreleased",
            "release": release, "source_sha": sha or carried_sha}


def _distribution_string(identity: dict[str, Any]) -> str:
    if identity["status"] == "released":
        return f"{identity['product']} {identity['release']}"
    if identity["source_sha"]:
        return f"{identity['product']} unreleased (dev source {identity['source_sha']})"
    return f"{identity['product']} unreleased (no source provenance)"


class _LazyVersionAction(argparse.Action):
    """``--version`` without taxing every invocation (#66 profiling).

    argparse's built-in ``version`` action needs its version string at
    parser-construction time, so ``main()`` eagerly resolved the
    distribution identity (several git subprocesses) on EVERY ght call —
    even for commands and ``--help`` that never report it — and ``ght
    version`` resolved it a second time. This action defers
    ``distribution_identity()`` until ``--version`` is actually invoked
    and prints the exact string the built-in action would (identity text
    plus a newline, exit status 0).
    """

    def __init__(self, option_strings, dest, default=argparse.SUPPRESS,
                 help="show program's version number and exit"):
        super().__init__(option_strings=option_strings, dest=dest, nargs=0,
                         default=default, help=help)

    def __call__(self, parser, namespace, values, option_string=None):
        # The same observable behavior as argparse's built-in version action
        # (identity text on stdout, exit 0), resolved only now.
        print(_distribution_string(distribution_identity()))
        parser.exit()


def _cmd_version(_: argparse.Namespace) -> None:
    print(json.dumps(distribution_identity()))


def _cmd_identity(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    print(json.dumps({"distribution": distribution_identity(),
                      "github_principal": ctx.github_principal,
                      "executor_id": ctx.executor_id, "repo": str(ctx.root),
                      "remote": ctx.remote, "default_branch": ctx.default_branch,
                      "lease_minutes": ctx.lease_minutes}))


# ------------------------------------------------- downstream onboarding

# #165 supported-host contract (AC2): the host class the distribution
# supports, stated once and reported by `ght preflight`. Non-secret tooling
# is established by the product itself on supported hosts — git and python3
# through the host's standard user-space installers, and gh provisioned
# automatically into the Skill-owned user-space tool dir when missing.
# Nothing here requires root, and credentials are only ever consumed
# through the standard gh credential surface (never read, printed, or
# persisted by ght); authentication consent is ALWAYS a User action.
SUPPORTED_HOST_CONTRACT = (
    "user-space POSIX host (macOS/Linux); no root required; git and "
    "python3 (>=3.10) via the host's standard user-space installers; gh "
    "is provisioned automatically by ght into the user-space tool dir "
    "(~/.local/share/harry-dev/bin) from the official cli/cli release "
    "when missing; GitHub credentials only through the standard gh "
    "credential surface (e.g. `gh auth login`)")

# The pinned gh release the provisioning path installs (overridable with
# GHT_GH_VERSION). The canonical URL pattern below resolves ONLY official
# cli/cli release archives — no mirrors, no "latest".
GH_PROVISION_VERSION = "2.63.0"
GH_INSTALL_MARKER = "gh-provision.json"


def _gh_provision_version() -> str:
    return os.environ.get("GHT_GH_VERSION", GH_PROVISION_VERSION).strip()


def _gh_download_url(version: str, system: str, machine: str) -> str:
    """The pinned canonical upstream URL: the official cli/cli release
    archive for exactly this platform and version. No mirrors, no
    'latest', no caller-supplied URLs."""
    arch = {"x86_64": "amd64", "amd64": "amd64",
            "arm64": "arm64", "aarch64": "arm64"}.get(machine)
    if not arch:
        raise CommandFailure(
            f"cannot map machine architecture {machine!r} to an official gh "
            "release archive; install gh manually from https://cli.github.com/",
            INELIGIBLE)
    if system == "Darwin":
        return (f"https://github.com/cli/cli/releases/download/v{version}/"
                f"gh_{version}_macOS_{arch}.zip")
    if system == "Linux":
        return (f"https://github.com/cli/cli/releases/download/v{version}/"
                f"gh_{version}_linux_{arch}.tar.gz")
    raise CommandFailure(
        f"unsupported platform {system!r}; supported hosts are macOS/Linux — "
        "install gh manually from https://cli.github.com/", INELIGIBLE)


def _gh_archive_bytes(url: str) -> bytes:
    """The archive bytes for the canonical URL. ``GHT_TEST_DOWNLOAD_DIR``
    is the offline fixture seam: tests serve the 'download' from a local
    directory so the network path never runs under test."""
    name = url.rsplit("/", 1)[-1]
    seam = os.environ.get("GHT_TEST_DOWNLOAD_DIR", "").strip()
    if seam:
        local = Path(seam) / name
        if not local.is_file():
            raise CommandFailure(f"download failed: {name!r} not found in the "
                                 f"offline download dir {seam!r}")
        return local.read_bytes()
    import urllib.request
    with urllib.request.urlopen(url, timeout=120) as response:  # noqa: S310 — pinned canonical https URL
        if getattr(response, "status", 200) != 200:
            raise CommandFailure(f"download failed for {name!r}: "
                                 f"HTTP {response.status}")
        return response.read()


def _gh_archive_member(names: list[str]) -> str:
    """The gh binary member inside an official cli/cli release archive,
    located in the REAL upstream layout (review R2 finding 1; verified
    against the actual cli/cli release assets, e.g. v2.63.0): ONE versioned
    top-level directory ``gh_<version>_<platform>_<arch>/`` whose
    ``bin/gh`` is the binary — identical shape on the macOS zip and the
    linux tar.gz (the rest is LICENSE and share/man pages); there is no
    ``bin/gh/gh`` nesting. Anything else fails closed, naming the observed
    archive layout — a half-install is never produced from a surprise
    layout."""
    candidates = [name for name in names
                  if re.fullmatch(r"gh_[^/]+/bin/gh", name)]
    if len(candidates) != 1:
        top = sorted({name.split("/", 1)[0].rstrip("/") for name in names
                      if name and not name.endswith("/")})
        raise CommandFailure(
            "the gh release archive does not carry gh_<version>_<platform>_"
            "<arch>/bin/gh (the real upstream layout); observed top-level "
            f"entries: {top}; refusing to install")
    return candidates[0]


def _provision_gh() -> dict[str, Any]:
    """AC2 provisioning (R1): establish gh on a supported host — user-space,
    no root, official upstream only, never a half-install.

    - Location: ``tool_bin_dir()/gh`` (``~/.local/share/harry-dev/bin``,
      XDG-aware; ``GHT_TOOL_BIN_DIR`` overrides). Deliberately OUTSIDE the
      installed distribution tree: a tool installation must never change
      the installed distribution's content identity.
    - Source: the pinned canonical ``cli/cli`` release archive URL for the
      detected platform (``_gh_download_url``). The binary is located at
      the REAL upstream archive layout ``gh_<version>_<platform>_<arch>/``
      ``bin/gh`` (verified against the actual cli/cli release assets;
      identical shape on the macOS zip and the linux tar.gz) — never a
      guessed path; an unexpected layout fails closed (``_gh_archive_member``).
    - Verification, stated exactly: the extracted binary is executed BEFORE
      it is published and must run and report ``gh version <pinned>`` on
      stdout. That proves the property the runtime needs — a working gh of
      the exact requested identity from the official archive layout. It
      does not add a trust anchor beyond the official https release URL
      (the same trust level as a host package-manager install); anything
      corrupted or truncated fails this probe and nothing is installed.
    - The install is staged in a temp dir, verified, then atomically moved
      into place, and the installed version is recorded in
      ``gh-provision.json``. Unsupported platforms DECLINE — they never
      half-install. Auth is NEVER provisioned: ``gh auth login`` stays a
      User action."""

    import io
    import platform
    import shutil
    import tarfile
    import tempfile
    import zipfile
    info: dict[str, Any] = {"attempted": False, "installed": False,
                            "declined": None, "version": None, "path": None,
                            "source_url": None, "verified": None}
    system, machine = platform.system(), platform.machine()
    if system not in ("Darwin", "Linux"):
        info["declined"] = (f"unsupported platform {system}; supported hosts "
                            "are macOS/Linux — install gh manually from "
                            "https://cli.github.com/")
        return info
    version = _gh_provision_version()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
        info["declined"] = (f"GHT_GH_VERSION {version!r} is not a gh release "
                            "version (N.N.N); nothing was installed")
        return info
    try:
        url = _gh_download_url(version, system, machine)
    except CommandFailure as exc:
        info["declined"] = str(exc)
        return info
    info.update({"attempted": True, "version": version, "source_url": url})
    staging = Path(tempfile.mkdtemp(prefix="ght-provision-"))
    bin_dir = tool_bin_dir()
    target = bin_dir / "gh"
    try:
        blob = _gh_archive_bytes(url)
        if url.endswith(".zip"):
            with zipfile.ZipFile(io.BytesIO(blob)) as archive:
                member = _gh_archive_member(archive.namelist())
                binary = archive.read(member)
        else:
            with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as archive:
                member = _gh_archive_member([m.name for m in archive.getmembers()
                                             if m.isfile() or m.islnk()])
                binary = archive.extractfile(member).read()
        staged = staging / "gh"
        staged.write_bytes(binary)
        staged.chmod(0o755)
        # Verify BEFORE publish: the artifact must run and report exactly
        # the pinned version (see the docstring for why this is the
        # sufficient, honestly-stated proof).
        probe = _run([str(staged), "--version"], check=False)
        first = (probe.stdout.strip().splitlines() or [""])[0]
        if probe.returncode or not first.startswith(f"gh version {version}"):
            raise CommandFailure(
                f"the provisioned gh did not verify: expected 'gh version "
                f"{version}', got {first!r} (rc {probe.returncode}); nothing "
                "was installed")
        bin_dir.mkdir(parents=True, exist_ok=True)
        staged_target = bin_dir / f".gh.tmp-{os.getpid()}"
        shutil.copyfile(staged, staged_target)
        staged_target.chmod(0o755)  # copyfile carries content, not the mode
        os.replace(staged_target, target)  # atomic publish — never half-installed
        (bin_dir / GH_INSTALL_MARKER).write_text(json.dumps(
            {"tool": "gh", "version": version, "source_url": url,
             "verified": f"executed --version reports gh version {version}",
             "installed_at": _iso(_utc_now())}, sort_keys=True))
        info.update({"installed": True, "path": str(target), "verified": first})
    except CommandFailure as exc:
        info["declined"] = str(exc)
    except (OSError, zipfile.BadZipFile, tarfile.TarError, KeyError) as exc:
        info["declined"] = f"provisioning failed: {exc}"
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    return info


def _remote_runtime_refs(ctx: Context) -> dict[str, str]:
    """The target repo's published ``refs/ght/runtime/*`` namespace — the
    provable Harry Dev runtime state (absent ⇒ uninitialized repository;
    any presence ⇒ the identity is A-controlled project semantics)."""

    result = _run(["git", "ls-remote", ctx.remote, "refs/ght/runtime/*"],
                  check=False)
    if result.returncode:
        raise CommandFailure(
            f"cannot list the runtime namespace on {ctx.remote}: "
            f"{result.stderr.strip() or result.stdout.strip()}; the repository "
            "runtime state must be proven, never guessed", OWNERSHIP_LOST)
    return {row[1]: row[0] for row in
            (line.split() for line in result.stdout.splitlines() if line.strip())}


def _runtime_namespace_initialized(refs: dict[str, str]) -> bool:
    """The ONE definition of 'already initialized' (R1), shared by
    preflight and bootstrap: the repository runtime namespace is
    initialized iff ANY ``refs/ght/runtime/*`` ref exists — an activated
    pin or an orphan capsule alike. An orphan namespace is never 'fresh
    ground' for bootstrap, and preflight never reports it uninitialized."""

    return bool(refs)


# The throwaway refspec of the preflight mutation-transport probe (R2
# finding 5). The probe is a `git push --dry-run`: git completes the whole
# push negotiation against the configured remote and stops before any ref
# update — verified read-only (no refs created, no objects uploaded). Per
# review R3 finding 3 the probe's claim is narrowed accordingly: it proves
# transport reachability/authentication at probe time, never update
# authorization.
GHT_WRITE_PROBE_REF = "refs/ght/runtime/write-probe"


def _github_repo_slug_from_url(url: str) -> str | None:
    """The ``owner/repo`` slug a configured remote URL identifies, for the
    canonical GitHub URL forms (https, ssh, and https-with-credentials);
    None when the URL carries no GitHub repository identity (local paths,
    other hosts) — the same-repository fact is then unprovable from the
    URL (review R3 finding 4)."""

    url = (url or "").strip()
    if not url:
        return None
    owner = r"[A-Za-z0-9][A-Za-z0-9._-]*"
    repo = r"[A-Za-z0-9._-]+?"
    for pattern in (
            rf"https?://(?:[^/@]+@)?github\.com/({owner})/({repo})(?:\.git)?/?",
            rf"ssh://(?:[^/@]+@)?github\.com/({owner})/({repo})(?:\.git)?/?",
            r"git@github\.com:({})/({})(?:\.git)?/?".format(owner, repo)):
        match = re.fullmatch(pattern, url)
        if match:
            return f"{match.group(1)}/{match.group(2)}"
    return None


def _gh_auth_login_instruction() -> str | None:
    """The exact, copy-pasteable ``auth login`` command for THIS host's gh
    (review R2 finding 3): the resolved absolute binary path — the same
    binary every ght surface uses — so the User never has to discover an
    internal binary location or edit PATH. The path is shell-quoted
    (review R3 finding 5) so the command copies and pastes safely on any
    host (paths with spaces or metacharacters parse back as exactly one
    command plus the ``auth login`` subcommand). None when gh cannot be
    resolved at all (the manual-install blocker applies instead)."""

    import shlex
    import shutil
    gh = gh_executable()
    if os.path.sep not in gh:
        gh = shutil.which(gh) or gh
    if os.path.sep not in gh:
        return None
    return f"{shlex.quote(gh)} auth login"


def _host_preflight_report(remote: str = "origin",
                           repo: str | None = None) -> dict[str, Any]:
    """The first-run/install preflight (AC2): ESTABLISH the non-secret
    local tooling in ONE pass over the standard host surfaces.

    Repository state and credentials stay strictly read-only and
    credential-clean: it runs ``git --version``, ``gh --version``, the
    canonical ``gh api user`` principal read, the standard read-only
    collaborator-permission probe, the mutation-transport probe, and the
    repository's runtime-namespace listing — never ``gh auth token``,
    never any other credential material; raw secrets are never scraped,
    printed, or persisted. The one supported write is the AC2 provisioning
    act itself: a missing gh on a SUPPORTED platform is installed
    user-space from the official upstream release (never on unsupported
    platforms, never a half-install). Every remaining missing piece is
    collected into ONE actionable blocker list, and after tooling
    provisioning the ONLY User-owned blocker left is authentication
    consent — named as the executable, copy-pasteable
    ``<resolved gh path> auth login`` command (review R2 finding 3), never
    a bare instruction that needs PATH editing or binary discovery.

    Repository write is claimed ONLY as exactly what was proven (review R2
    finding 5, narrowed per review R3 finding 3): ``write_access`` carries
    the two independent legs — the gh credential's collaborator permission
    (GitHub-side, informational) and the ``git push --dry-run``
    mutation-transport probe against the configured remote, which proves
    the transport was reachable and authenticated AT PROBE TIME and
    explicitly does NOT prove update authorization (server-side
    hooks/rules/update-time policy can still reject the real push — the
    real mutation stays fail-closed and reconcilable). Neither leg alone
    is the write proof; ``ok`` requires both, plus the same-repository
    proof (review R3 finding 4): the selected remote's configured push URL
    must identify the same repository the permission probe addressed.
    An explicit ``--repo`` is honored everywhere while every gh invocation
    stays argv-valid for the real CLI (review R2 finding 2): repo-scoped
    subcommands carry ``--repo``, global commands (``gh api user``) never
    do."""

    import platform
    system = platform.system()
    blockers: list[str] = []
    supported_platform = system in ("Darwin", "Linux")
    if not supported_platform:
        blockers.append(
            f"unsupported host platform {system!r}; Harry Dev supports "
            "user-space POSIX hosts (macOS/Linux) — see the supported-host "
            "contract below")
    git_result = _run(["git", "--version"], check=False)
    git_ok = git_result.returncode == 0
    gh_result = _run([gh_executable(), "--version"], check=False)
    gh_ok = gh_result.returncode == 0
    provision: dict[str, Any] = {"attempted": False, "installed": False,
                                 "declined": None, "version": None,
                                 "path": None, "source_url": None,
                                 "verified": None}
    if not gh_ok and supported_platform:
        provision = _provision_gh()
        if provision["installed"]:
            gh_result = _run([gh_executable(), "--version"], check=False)
            gh_ok = gh_result.returncode == 0
    login_command = _gh_auth_login_instruction() if gh_ok else None
    if not gh_ok:
        manual = ("install the GitHub CLI (gh) manually from "
                  "https://cli.github.com/ and re-run `ght preflight`")
        if provision["declined"]:
            blockers.append(f"could not provision gh automatically "
                            f"({provision['declined']}); {manual}")
        else:
            blockers.append(f"the gh CLI is not available ({manual})")
    tools = {"git": {"ok": git_ok,
                     "version": (git_result.stdout.strip().splitlines() or [""])[0]
                     if git_ok else None},
             "gh": {"ok": gh_ok,
                    "version": (gh_result.stdout.strip().splitlines() or [""])[0]
                    if gh_ok else None}}
    if not git_ok:
        blockers.append("install git via the host's standard user-space installer")

    in_repo = bool(git_ok and
                   _run(["git", "rev-parse", "--is-inside-work-tree"],
                        check=False).returncode == 0)
    principal = None
    if gh_ok and in_repo:
        # Global-scope invocation: `gh api` refuses --repo on the real CLI,
        # so the principal read is repo-independent (review R2 finding 2).
        who = _run([gh_executable(), "api", "user", "--jq", ".login"],
                   check=False)
        principal = (who.stdout.strip() or None) if not who.returncode else None
        if principal is None:
            exact = (f"authenticate with GitHub by running: `{login_command}` "
                     "(copy-paste the exact command; it names the gh binary "
                     "this host uses — no PATH editing or binary discovery "
                     "needed)" if login_command else
                     "authenticate with `gh auth login` (the standard host "
                     "GitHub credential surface)")
            blockers.append(f"{exact} and ensure the account can access the "
                            "target repository; ght never reads, prints, or "
                            "persists raw credentials")
    if git_ok and not in_repo:
        blockers.append("run inside a checkout of the target repository (no "
                        "resolvable work tree here)")

    slug = None
    write_access: dict[str, Any] = {"ok": False, "permission": None,
                                    "api_permission_probe": None,
                                    "push_transport": None}
    runtime: dict[str, Any] = {"initialized": False, "pin": None, "refs": []}
    if git_ok and gh_ok and in_repo and principal:
        try:
            ctx = Context(remote, repo)
        except CommandFailure as exc:
            blockers.append(f"identity preflight failed: {exc}")
        else:
            slug = ctx.github.slug()
            if not slug:
                blockers.append("gh cannot identify the target repository from this "
                                "checkout (no resolvable origin); run inside a clone "
                                "of the target repository")
            else:
                inferred = GitHub(None, remote).slug() if repo else None
                if repo and inferred not in (None, slug):
                    blockers.append(
                        f"explicit --repo {slug!r} does not match this checkout's "
                        f"origin {inferred!r}; preflight refuses to probe one "
                        "repository while sitting in another")
                    slug = repo.strip()
                else:
                    # TWO independent write legs, claimed as exactly what
                    # they are (review R2 finding 5). Leg 1 (informational,
                    # GitHub-side): the gh credential's collaborator
                    # permission. Leg 2 (the mutation-transport proof): a
                    # `git push --dry-run` through the configured remote —
                    # it completes the push negotiation and stops before any
                    # ref update, so it exercises the exact transport the
                    # bootstrap mutation will use (which may carry a
                    # different credential or a broken push URL that the gh
                    # API probe can never see) while remaining read-only to
                    # refs.
                    perm = _run([gh_executable(), "api",
                                 f"repos/{slug}/collaborators/{principal}/"
                                 f"permission"], check=False)
                    permission = None
                    if not perm.returncode:
                        try:
                            permission = json.loads(perm.stdout).get("permission")
                        except (ValueError, AttributeError):
                            permission = None
                    api_probe = {"ok": permission in ("admin", "write"),
                                 "permission": permission}
                    if not api_probe["ok"]:
                        blockers.append(
                            f"cannot prove write access to {slug!r} for "
                            f"{principal!r} via the gh credential "
                            f"(permission: {permission!r}); bootstrap "
                            "publishes refs/ght/runtime/* — request "
                            "repository write access (or fix the credential) "
                            "and re-run")
                    # R3 finding 4: the permission target and the git mutation
                    # target must be the SAME repository. Resolve the selected
                    # remote's CONFIGURED push URL (raw git config, so local
                    # insteadOf transport rewriting cannot mask the configured
                    # repository identity) and require its GitHub slug to be
                    # the probed slug — before any push probe, before any
                    # mutation.
                    push_url = (_run(["git", "config", "--get",
                                      f"remote.{ctx.remote}.pushurl"],
                                     check=False).stdout.strip()
                                or _run(["git", "config", "--get",
                                         f"remote.{ctx.remote}.url"],
                                        check=False).stdout.strip() or "")
                    push_slug = _github_repo_slug_from_url(push_url)
                    same_repo = {"ok": True, "remote": ctx.remote,
                                 "push_url": push_url, "push_slug": push_slug,
                                 "expected_slug": slug}
                    push_probe: dict[str, Any] | None = None
                    if push_slug is not None and push_slug != slug:
                        same_repo["ok"] = False
                        blockers.append(
                            f"the selected remote {ctx.remote!r} pushes to "
                            f"{push_slug!r} but the write-permission probe targets "
                            f"{slug!r}: the permission probe and the runtime-ref push "
                            "must target the SAME repository — fix --repo/--remote "
                            "(or the remote's push URL) and re-run")
                    elif push_slug is None and repo and repo.strip():
                        # An explicitly selected repository cannot be
                        # correlated with an unresolvable push URL: the
                        # same-repository fact stays unproven, so the
                        # mutation is refused.
                        same_repo["ok"] = False
                        blockers.append(
                            f"cannot prove that the selected remote {ctx.remote!r} "
                            f"pushes to the explicitly selected repository {slug!r}: "
                            f"its push URL ({push_url!r}) carries no GitHub repository "
                            "identity — set the remote's push URL to the selected "
                            "repository and re-run")
                    else:
                        push = _run(["git", "push", "--dry-run", ctx.remote,
                                     f"HEAD:{GHT_WRITE_PROBE_REF}"], check=False)
                        push_probe = {
                            "ok": push.returncode == 0,
                            "remote": ctx.remote,
                            "ref": GHT_WRITE_PROBE_REF,
                            # R3 finding 3: state exactly what the probe
                            # proves — reachability/authentication at probe
                            # time — and explicitly disclaim update
                            # authorization (a dry-run sends no update and
                            # can succeed where the real update is rejected).
                            "proves": ("push transport reachable and authenticated "
                                       "as of probe time (read-only: no refs "
                                       "changed, nothing sent)"),
                            "does_not_prove": ("update authorization — server-side "
                                               "hooks/rules/update-time policy can "
                                               "still reject the real push"),
                            "detail": ("dry-run push completed; no refs changed"
                                       if not push.returncode else
                                       (push.stderr.strip() or
                                        push.stdout.strip() or
                                        f"git push --dry-run failed "
                                        f"(rc {push.returncode})"))}
                        if push_probe is not None and not push_probe["ok"]:
                            blockers.append(
                                f"cannot prove the mutation transport to "
                                f"{ctx.remote!r}: `git push --dry-run` failed "
                                f"({push_probe['detail']}); the probe proves "
                                "transport reachability only, not update "
                                "authorization — bootstrap publishes "
                                "refs/ght/runtime/* through git push and the real "
                                "update can still be rejected by server-side policy "
                                "(bootstrap then fails closed); fix the configured "
                                "remote/push URL or push credential and re-run")
                    write_access = {"ok": bool(api_probe["ok"] and same_repo["ok"]
                                               and push_probe and push_probe["ok"]),
                                    "permission": permission,
                                    "api_permission_probe": api_probe,
                                    "push_transport": push_probe,
                                    "same_repository": same_repo}
                    refs = _remote_runtime_refs(ctx)
                    runtime["refs"] = sorted(refs)
                    runtime["initialized"] = (
                        _runtime_namespace_initialized(refs))
                    if RUNTIME_PIN_REF in refs:
                        try:
                            runtime["pin"] = _read_runtime_pin(ctx)
                        except CommandFailure:
                            runtime["pin"] = None
    return {"ok": not blockers,
            "host": {"system": system,
                     "python": platform.python_version(),
                     "supported_host": SUPPORTED_HOST_CONTRACT},
            "tools": tools,
            "auth": {"principal": principal, "ok": principal is not None,
                     "login_command": login_command},
            "repo": slug,
            "write_access": write_access,
            "runtime": runtime,
            "provision": provision,
            "installed_identity": distribution_identity(),
            "installed_provenance": _release_content_provenance(),
            "blockers": blockers}


def _cmd_preflight(args: argparse.Namespace) -> None:
    """Report/establish the supported-host/install state (AC2) — one pass;
    tooling is provisioned, and every remaining missing piece lands in ONE
    actionable blocker list (after provisioning, that is auth consent)."""

    report = _host_preflight_report(args.remote, args.repo)
    if report["blockers"]:
        raise CommandFailure(
            "host preflight failed: " + " | ".join(report["blockers"]),
            INELIGIBLE, **{key: value for key, value in report.items()
                           if key != "ok"})
    print(json.dumps(report))


def _bootstrap_namespace_fence(ctx: Context, expected: dict[str, str],
                               phase: str) -> None:
    """R1 bootstrap concurrency fence: the runtime namespace must hold
    EXACTLY the expected refs (full SHA identity). Any other runtime ref —
    above all a foreign pin that raced in between the empty-namespace
    check and the activation — fails bootstrap closed; foreign project
    state is never overwritten, moved, or deleted."""

    refs_now = _remote_runtime_refs(ctx)
    foreign = {ref: sha for ref, sha in refs_now.items()
               if expected.get(ref) != sha}
    if foreign:
        raise CommandFailure(
            "bootstrap fenced: runtime namespace ref(s) appeared " + phase +
            " that bootstrap did not publish (" + ", ".join(sorted(foreign)) +
            "); fail closed — foreign project state is never overwritten or "
            "deleted; reconcile with A", OWNERSHIP_LOST,
            foreign_refs=sorted(foreign),
            expected={ref: (sha or "")[:12] for ref, sha in expected.items()})


def _cmd_bootstrap(args: argparse.Namespace) -> None:
    """One-time mechanical downstream bootstrap (#165 AC3/AC5): the
    pre-governance root transition for a provably uninitialized target
    repository and ONE exact installed released distribution.

    Guarantees, mechanically enforced and fail-closed:
    - the host preflight passes first (ONE blocker list, AC2 — including
      user-space tooling provisioning, the same-repository proof between
      the permission probe and the selected remote's push URL (review R3
      finding 4), and the reachable mutation transport — whose probe
      proves reachability/authentication at probe time, never update
      authorization (review R3 finding 3); the real mutation stays
      fail-closed and reconcilable), so nothing is left for B/User to
      discover mid-run;
    - the repository runtime namespace ``refs/ght/runtime/*`` is EMPTY —
      any existing runtime ref means this is not a bootstrap (the identity
      is A-controlled project semantics; the mismatch stops through the
      existing freshness/upgrade boundary, never an implicit upgrade);
    - the installed distribution carries a released Harry Dev identity that
      VERIFIES against its stamped provenance (review R2, provenance
      disposition): the installed tree must match the content-binding
      digest recorded by the release producer at the exact-tag checkout —
      a locally modified tree that merely retains or edits
      DISTRIBUTION.json never bootstraps. Unstamped/dev installs never
      bootstrap, and the selected installed release is the ONLY identity
      this materializes (no "latest", no version choice);
    - the transition is FENCED against concurrency (R1): after the capsule
      publish, the namespace must hold exactly that capsule before any pin
      is touched, the activation itself is CREATE-ONLY (a pin that raced
      in is never moved), and after activation the namespace must hold
      exactly {capsule, pin} — foreign state is never overwritten or
      deleted;
    - it then reuses the canonical primitives unchanged — ``sync-runtime``
      (create-only CAS capsule publish) → ``activate-runtime`` (leased pin
      move) → the release read-back (pin/capsule dual-ref + manifest
      identity proof) — and grants NO Issue execution authority and
      creates NO new lifecycle state or registry;
    - the SAME activation continues into ordinary B operation: the emitted
      document IS a fresh ``ght discover`` verdict (with the ``bootstrap``
      facts attached) compiled after the runtime exists, so bootstrap
      conversation context can never become a second confirmation gate
      over durable ready/Plan authorization.
    """

    report = _host_preflight_report(args.remote, args.repo)
    if report["blockers"]:
        raise CommandFailure(
            "host preflight failed: " + " | ".join(report["blockers"]),
            INELIGIBLE, **{key: value for key, value in report.items()
                           if key != "ok"})
    ctx = Context(args.remote, args.repo)
    root = _runtime_self_root()
    identity = distribution_identity(root)
    if identity["status"] != "released":
        raise CommandFailure(
            "the installed github-task distribution carries no released Harry Dev "
            f"identity ({_distribution_string(identity)}); bootstrap materializes "
            "only an exact released identity — install a formal release "
            "distribution (the release's github-task-<version>.zip asset) and "
            "re-run `ght bootstrap`", INELIGIBLE, installed_identity=identity)
    # Review R2, provenance disposition: the released CLAIM must also
    # VERIFY — the installed tree has to match the content-binding digest
    # the release producer recorded at the exact-tag checkout. A locally
    # modified tree that retains or edits DISTRIBUTION.json fails closed
    # here, before anything is published.
    provenance = _release_content_provenance(root)
    if not provenance["verified"]:
        raise CommandFailure(
            "the installed distribution cannot prove the released identity it "
            f"claims ({_distribution_string(identity)}): {provenance['reason']}; "
            "bootstrap materializes only a verifiably released identity — "
            "re-install the distribution from the official release asset and "
            "re-run `ght bootstrap`",
            INELIGIBLE, installed_identity=identity,
            installed_provenance=provenance)
    # Review R3, finding 1 (consumer leg of the provenance chain): the
    # released determination must consume the ESTABLISHED provenance — the
    # canonical durable release surface recorded by the producer — and
    # never manufacture release truth from the mutable local manifest
    # alone: a locally re-authored tree + recomputed binding is
    # self-consistent and must not pass by self-consistency. See
    # _corroborate_release_provenance for the exact anchoring (and what
    # remains unproven, stated there).
    _corroborate_release_provenance(root)
    refs = _remote_runtime_refs(ctx)
    if _runtime_namespace_initialized(refs):
        pin = None
        try:
            pin = _read_runtime_pin(ctx)
        except CommandFailure:
            pin = None
        self_digest = _runtime_payload_digest(root)
        if pin and pin.get("digest") == self_digest:
            raise CommandFailure(
                "this repository is already initialized: the activated runtime "
                f"identity {self_digest[:12]} IS the installed identity — bootstrap "
                "is not needed and grants nothing; run `ght discover`", INELIGIBLE,
                existing_refs=sorted(refs))
        raise CommandFailure(
            "bootstrap never touches an initialized repository: the project runtime "
            f"namespace refs/ght/runtime/* already exists ({len(refs)} ref(s)), so the "
            "runtime identity is A-controlled project semantics — reload the local "
            f"Skill/distribution to {RUNTIME_PIN_REF} and re-run `ght discover` "
            "(the existing refresh_required boundary), or have A explicitly review "
            "the upgrade/rollback pin change (`ght activate-runtime`); bootstrap "
            "never activates, upgrades, or moves an existing pin", OWNERSHIP_LOST,
            existing_refs=sorted(refs))

    release = identity["release"]
    # #166: the project AGENTS contract is part of first adoption. It is
    # reconciled BEFORE the first repository mutation, so a blocked
    # adoption (material conflict, malformed/duplicate managed-marker
    # state, upgrade_required)
    # publishes nothing and the same one bootstrap path re-runs after A's
    # reconciliation. The outcome is a working-tree proposal only (AC3) —
    # integration goes through the project's protected source path.
    agents = _bootstrap_agents_reconciliation(ctx)
    import io
    from contextlib import redirect_stdout
    sync_io, activate_io = io.StringIO(), io.StringIO()
    with redirect_stdout(sync_io):
        _cmd_sync_runtime(argparse.Namespace(source=str(root), remote=args.remote,
                                             repo=args.repo))
    digest = json.loads(sync_io.getvalue())["digest"]
    capsule_ref = f"{RUNTIME_REF_PREFIX}{digest}"
    capsule_sha = ctx.ls_remote(capsule_ref)
    # Fence #1 (R1): between the initial empty-namespace check and the
    # activation, a concurrent writer may have created any runtime ref.
    # Require the namespace to hold exactly the capsule bootstrap just
    # published — BEFORE any pin is touched.
    _bootstrap_namespace_fence(ctx, {capsule_ref: capsule_sha},
                               "after the capsule publish")
    with redirect_stdout(activate_io):
        _cmd_activate_runtime(argparse.Namespace(digest=digest,
                                                 remote=args.remote,
                                                 repo=args.repo,
                                                 require_absent_pin=True))
    _verify_release_runtime_publication(ctx, digest, release,
                                        identity["source_sha"])
    # Fence #2 (R1): post-activation, the namespace must be exactly
    # {capsule, pin} — one published object — nothing foreign.
    _bootstrap_namespace_fence(
        ctx, {capsule_ref: capsule_sha, RUNTIME_PIN_REF: capsule_sha},
        "after the activation")
    bootstrap = {"status": "bootstrapped", "digest": digest, "release": release,
                 "source_sha": identity["source_sha"], "pin_ref": RUNTIME_PIN_REF,
                 "capsule_ref": capsule_ref,
                 "note": "one-time mechanical bootstrap of the exact installed "
                         "release; grants no Issue authority — start authority "
                         "stays with durable ready/Plan truth"}
    _cmd_discover(argparse.Namespace(remote=args.remote, repo=args.repo,
                                     evidence_comment=False),
                  extra={"bootstrap": bootstrap, "agents": agents}, ctx=ctx)


# ------------------------------------------------- project AGENTS contract

def _agents_adopt_root(root: Path, *, upgrade_selector: bool = False,
                       identity: dict[str, Any] | None = None) -> dict[str, Any]:
    """Apply/reconcile the canonical project AGENTS contract (#166) in ONE
    root file of the target repository. Purely local: no ``gh``, no
    network, no remote access, no durable ght state.

    - absent root ``AGENTS.md`` → prepare a concise root file containing
      exactly the shipped canonical managed block;
    - existing file → preserve ALL project-owned content byte-for-byte and
      reconcile exactly one managed block (nested ``AGENTS.md`` /
      ``AGENTS.override.md`` are never enumerated or touched);
    - re-running converges: a canonical current block is a byte-stable
      no-op (no duplicate block, no churn);
    - material authority/security/credential conflicts in project-owned
      content, duplicate/malformed managed-marker state, and version
      changes without a release upgrade ALREADY authorized for the
      project all FAIL CLOSED for A reconciliation — adoption is never
      silently declared successful over them (AC2/AC4); ``upgrade_selector``
      is an execution selector only, never the authorization itself;
    - the outcome is a WORKING-TREE PROPOSAL ONLY (AC3): this surface
      never commits, never pushes, and grants no execution, acceptance,
      merge, scheduling, or release authority — the prepared root-AGENTS
      change integrates through the target project's normal protected
      source path, and later ordinary AGENTS.md edits need normal Task
      Contract authorization."""

    from .agents_contract import _REFUSE_STATUSES, reconcile

    target = root / "AGENTS.md"
    if target.is_symlink() or (target.exists() and not target.is_file()):
        raise CommandFailure(
            f"the project root surface {str(target)!r} is not a regular file; "
            "adoption never follows links or special files — reconcile with A",
            INELIGIBLE, path=str(target))
    existing = target.read_text() if target.exists() else None
    decision = reconcile(existing, upgrade_selector=upgrade_selector)
    if decision["status"] in _REFUSE_STATUSES:
        raise CommandFailure(
            f"the project AGENTS contract could not be adopted: "
            f"{decision['reason']}", INELIGIBLE, **{
                key: value for key, value in decision.items()
                if key not in ("action", "reason")})
    facts = {key: value for key, value in decision.items()
             if key not in ("action", "reason", "content")}
    facts.update({"path": "AGENTS.md",
                  "changed": decision["action"] == "write"})
    if decision["action"] == "write":
        target.write_text(decision["content"])
    if identity is not None:
        facts["installed_identity"] = identity
    return facts


def _bootstrap_agents_reconciliation(ctx: Context) -> dict[str, Any]:
    """The first-adoption leg of the #165 bootstrap flow (#166): reconcile
    the project AGENTS contract BEFORE the first repository mutation, so a
    blocked adoption (material conflict, malformed/duplicate
    managed-marker state, upgrade_required)
    leaves the repository untouched — nothing is published — and a re-run
    after A's reconciliation is the same one bootstrap path."""

    try:
        return _agents_adopt_root(ctx.root, identity=distribution_identity())
    except CommandFailure as failure:
        raise CommandFailure(
            f"first adoption could not apply the project AGENTS contract: "
            f"{failure}; nothing was published — reconcile with A, then "
            "re-run `ght bootstrap` (or `ght agents-adopt` directly); the "
            "prepared root-AGENTS.md change integrates through this "
            "project's normal protected source path",
            failure.code, agents=failure.details) from failure


def _cmd_agents_adopt(args: argparse.Namespace) -> None:
    """The standalone reconciliation surface for the project AGENTS
    contract (#166): the SAME primitive the first-adoption bootstrap runs,
    reachable for a release-upgrade reconciliation of the managed block
    and for re-running adoption after A reconciled a blocked state. The
    ``--upgrade`` flag is ONLY the execution selector for a Harry Dev
    release upgrade ALREADY authorized for this project through its
    normal governance — the flag is not itself the authorization and can
    never establish it, and this surface cannot mechanically prove that
    the authorization exists: no input to this command is authorization
    evidence, so using the selector without that independently
    established authorization is a Contract violation this surface cannot
    detect. It is not a second install/bootstrap path — the runtime
    install/bootstrap surface is exactly #165's; this prepares only the
    bounded root-AGENTS source change."""

    if args.root:
        root = Path(args.root).expanduser().resolve()
        checked = _run(["git", "-C", str(root), "rev-parse", "--show-toplevel"],
                       check=False)
        if checked.returncode:
            raise CommandFailure(
                f"--root {str(root)!r} is not inside a git work tree; the "
                "project AGENTS contract is adopted into a target "
                "repository", INELIGIBLE)
        root = Path(checked.stdout.strip())
    else:
        checked = _run(["git", "rev-parse", "--show-toplevel"], check=False)
        if checked.returncode:
            raise CommandFailure(
                "not inside a git work tree; the project AGENTS contract is "
                "adopted into a target repository (run from the checkout, "
                "or pass --root)", INELIGIBLE)
        root = Path(checked.stdout.strip())
    facts = _agents_adopt_root(root, upgrade_selector=args.upgrade,
                               identity=distribution_identity())
    print(json.dumps(facts))


def _cmd_status(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    owned = []
    seen_numbers: dict[str, list[str]] = {}
    for ref in sorted(ctx.claim_refs()):
        for prefix in (ctx.claims_prefix, ctx.legacy_claims_prefix):
            if ref.startswith(prefix):
                seen_numbers.setdefault(ref[len(prefix):], []).append(ref)
                break
    for number, refs in sorted(seen_numbers.items()):
        if len(refs) > 1:
            raise CommandFailure(
                f"AMBIGUOUS claim state: #{number} exists in both namespaces; "
                "fail-closed until reconciled", OWNERSHIP_LOST, refs=refs)
        if not number.isdigit():
            continue
        record, ref_sha = ctx.remote_claim(int(number))
        if record and record.get("executor_id") == ctx.executor_id:
            if record.get("github_principal") != ctx.github_principal:
                raise CommandFailure(
                    f"claim #{number} has a github principal mismatch for this executor; "
                    "fail-closed and reconcile ownership", OWNERSHIP_LOST,
                    claim_executor=record.get("executor_id"),
                    claim_principal=record.get("github_principal"))
            if record.get("status") == "active":
                owned.append({"issue": int(number), "claim_id": record["claim_id"],
                              "ref_sha": ref_sha, "branch": record.get("branch"),
                              "attempt_state": claim_state(record),
                              "execution_capacity": _execution_capacity(ctx, record)})
    print(json.dumps({"distribution": distribution_identity(),
                      "executor_id": ctx.executor_id,
                      "github_principal": ctx.github_principal, "active_claims": owned}))


def _cmd_inspect(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    claim, ref_sha = ctx.remote_claim(args.issue)
    print(json.dumps({"issue": args.issue, "claim": claim or "none", "claim_sha": ref_sha,
                      "claim_state": claim_state(claim)}))


# ------------------------------------------------- pre-READY validation

def _cmd_validate_ready(args: argparse.Namespace) -> None:
    """Read-only pre-READY mechanical eligibility validation.

    The check is executor-neutral and strictly read-only: its verdict
    depends only on the target Issue's durable state, never on
    ``GHT_EXECUTOR_ID`` — per-Issue ownership/lineage/authorization
    safety remains claim-time checks in ``ght claim``. It
    creates no claim or executor reservation, does not mutate ``ready``,
    does not modify ownership refs, and never authorizes execution. It
    reuses the canonical claim-intake validation primitives — the same
    Contract parser/schema, the dependency gate, claim-state
    classification, and namespace dual-presence discovery — so there is no
    second parser or validation model. PASS proves mechanical eligibility
    only; semantic readiness and the one-shot ``ready`` grant remain A's
    decisions.
    """

    ctx = Context(args.remote, args.repo)
    number = args.issue
    checks: list[dict[str, Any]] = []

    def record(check_id: str, ok: bool, detail: str) -> None:
        checks.append({"id": check_id, "ok": ok, "detail": detail})

    ambiguous = False
    contract: dict[str, Any] | None = None

    # Claim-intake surface: open-Issue target, exactly-one-parseable Contract
    # (schema + authority enum), and closed hard dependencies — the same
    # primitive `claim` runs at intake, minus the one-shot READY gate, so a
    # prepared Issue also validates before A grants `ready`.
    try:
        issue = ctx.github.issue_view(number)
    except IntakeError as exc:
        issue = None
        record("target", False, str(exc))
    if issue is not None:
        try:
            contract = _validate_issue_intake(ctx, number, issue, require_ready=False)
            record("target", True, f"#{number} is an open Issue, not a Pull Request")
            record("contract", True, "exactly one machine-readable ght-contract; "
                                     "schema and authority enum valid")
            record("authority", True,
                   f"implementation: {contract['authority']['implementation']}")
            record("dependencies", True,
                   "no hard dependency declared" if not contract.get("depends_on") else
                   f"declared hard dependencies are closed: {contract['depends_on']}")
        except CommandFailure as exc:
            record("claim-intake", False, str(exc))

    # Ownership and namespace truth: the same dual-read discovery and
    # claim-state classification claim preconditions use. Reads only.
    prior: dict[str, Any] | None = None
    try:
        prior, _prior_sha = ctx.remote_claim(number)
        record("namespace", True,
               f"claim lineage location is unambiguous: {ctx.claim_location(number)}")
        state = claim_state(prior)
        if _is_parked(ctx, prior):
            record("ownership", False,
                   "a delivered Candidate awaits review (parked non-terminal attempt); "
                   "the same attempt resumes via ght acquire, and a new attempt needs "
                   "A's explicit BLOCK/REPLAN plus fresh authorization")
        elif state == "NONE":
            record("ownership", True,
                   "no claim lineage exists; a claim would create a fresh lineage")
        elif state == "ACTIVE":
            record("ownership", False,
                   f"conflicting ACTIVE claim exists for this Issue "
                   f"(claim {(prior or {}).get('claim_id')})")
        elif state == "STALE":
            record("ownership", False, "STALE claim exists; recovery is takeover with "
                                       "durable evidence, not a fresh claim")
        elif prior.get("status") in ("delivered", "blocked", "failed"):
            record("ownership", True,
                   f"terminal lineage ({prior.get('status')}); a fresh one-shot ready "
                   "authorizes a new CAS-appended attempt recording supersedes")
        else:
            record("ownership", False,
                   f"claim lineage is terminal ({prior.get('status')}) and final; "
                   "new work belongs on a new Issue")
    except CommandFailure as exc:
        ambiguous = True
        record("namespace", False, str(exc))

    # Mechanically checkable referenced state: repo-path design anchors must
    # exist in the protected-branch tree. Non-path anchors are skipped.
    if contract is not None:
        refs = contract.get("design_refs") or []
        if not isinstance(refs, list) or not all(isinstance(item, str) for item in refs):
            record("design_refs", False, "design_refs must be a list of path strings")
        else:
            checkable = [ref for ref in refs if "://" not in ref]
            if not checkable:
                record("design_refs", True, "no repo-path design anchors declared")
            else:
                try:
                    base = ctx.protected_head()
                    missing = [ref for ref in checkable
                               if _run(["git", "cat-file", "-e", f"{base}:{ref}"],
                                       check=False).returncode]
                except CommandFailure as exc:
                    record("design_refs", False, f"cannot read protected-branch tree: {exc}")
                else:
                    if missing:
                        record("design_refs", False,
                               f"referenced design anchor(s) missing from the protected "
                               f"branch: {missing}")
                    else:
                        record("design_refs", True,
                               f"referenced design anchor(s) exist on "
                               f"{ctx.default_branch}: {checkable}")

    # READY coherence: present or absent are both valid pre-READY states; a
    # stale `ready` coexisting with an ACTIVE claim is the one incoherent
    # combination (failed mirror repair) and fails closed.
    ready_state = "unreadable"
    try:
        labels = ctx.github.issue_labels(number)
        ready_present = ctx.ready_label in labels
        ready_state = "present" if ready_present else "absent"
        if ready_present and prior is not None and claim_state(prior) == "ACTIVE":
            record("ready", False, "incoherent: stale ready label coexists with an ACTIVE "
                                   "claim; the owning worker must repair the mirror with "
                                   "ready-repair")
        elif ready_present:
            record("ready", True, "ready present: a successful claim would consume it")
        else:
            record("ready", True, "ready absent: prepared state awaiting A's one-shot "
                                  "authorization")
    except IntakeError as exc:
        record("ready", False, f"cannot read labels: {exc}")

    failed = [check for check in checks if not check["ok"]]
    eligible = not failed
    print(json.dumps({
        "issue": number, "ok": eligible, "eligible": eligible, "ready": ready_state,
        "checks": checks, "read_only": True, "ambiguous": ambiguous,
        "note": "PASS proves mechanical eligibility only; it cannot judge semantic "
                "completeness and never replaces A's semantic readiness judgment or "
                "the one-shot ready authorization",
    }, indent=2))
    if failed:
        print(f"ght: validate-ready: {len(failed)} check(s) failed for #{number}: "
              f"{', '.join(check['id'] for check in failed)}", file=sys.stderr)
        raise SystemExit(OWNERSHIP_LOST if ambiguous else INELIGIBLE)


# ----------------------------------------------------- Execution Plan

def _plan_commit(text: str, parent: str | None = None,
                 identity: str = "github-task") -> str:
    """Build one immutable Execution Plan revision commit (PLAN.json).

    The revision carries an explicit publisher identity (the authenticated
    principal, or the plan-publication-only machine identity) so commit-tree
    succeeds on a clean hosted runner where no human git identity exists —
    the same pattern the durable claim/lease records already use."""

    blob = _run(["git", "hash-object", "-w", "--stdin"], input_text=text).stdout.strip()
    tree = _run(["git", "mktree"], input_text=f"100644 blob {blob}\tPLAN.json\n").stdout.strip()
    command = ["git", "commit-tree", tree]
    if parent:
        command += ["-p", parent]
    command += ["-m", "ght: Execution Plan revision"]
    author = identity or "github-task"
    env = {**os.environ, "GIT_AUTHOR_NAME": author,
           "GIT_AUTHOR_EMAIL": f"{author}@ght",
           "GIT_COMMITTER_NAME": author,
           "GIT_COMMITTER_EMAIL": f"{author}@ght"}
    result = subprocess.run(command, capture_output=True, text=True, env=env)
    if result.returncode:
        raise CommandFailure(f"commit-tree failed: {result.stderr.strip()}")
    return result.stdout.strip()


def _remote_plan(ctx: Context, revision: str | None = None) -> tuple[dict[str, Any] | None, str | None]:
    """Read the current (or an exact historical) Execution Plan revision.

    Every published revision is by construction an ancestor of the current
    pointer (CAS requires each publish to replace the exact prior), so
    history stays reconstructable from the ordinary Git object graph —
    never rewritten in place.
    """

    if revision is None:
        raw, current_sha = ctx.remote_json(ctx.plan_ref, document="PLAN.json")
        if raw is None:
            return None, None
        try:
            return parse_execution_plan(json.dumps(raw)), current_sha
        except ExecutionPlanError as exc:
            raise CommandFailure(f"current Execution Plan revision is invalid: {exc}",
                                 INELIGIBLE) from exc
    temp_ref = f"refs/ght-read/plan-{os.getpid()}-{uuid.uuid4().hex[:12]}"
    try:
        fetched = _run(["git", "fetch", "-q", ctx.remote,
                        f"+{ctx.plan_ref}:{temp_ref}"], check=False)
        if fetched.returncode:
            detail = fetched.stderr.strip() or fetched.stdout.strip() or "plan ref fetch failed"
            raise CommandFailure(f"cannot fetch {ctx.plan_ref}: {detail}", OWNERSHIP_LOST)
        current_sha = _run(["git", "rev-parse", temp_ref]).stdout.strip()
        ancestry = _run(["git", "merge-base", "--is-ancestor", revision, temp_ref], check=False)
        if ancestry.returncode:
            raise CommandFailure(
                f"Execution Plan revision {revision[:12]} is not part of the reconstructable "
                f"history of {ctx.plan_ref} ({current_sha[:12]})", INELIGIBLE)
        result = _run(["git", "show", f"{revision}:PLAN.json"], check=False)
        if result.returncode:
            raise CommandFailure(f"Execution Plan revision {revision[:12]} has no readable "
                                 "PLAN.json", INELIGIBLE)
    finally:
        _run(["git", "update-ref", "-d", temp_ref], check=False)
    try:
        parsed = parse_execution_plan(result.stdout)
    except ExecutionPlanError as exc:
        raise CommandFailure(f"Execution Plan revision {revision[:12]} is invalid: {exc}",
                             INELIGIBLE) from exc
    return parsed, revision


def _assert_plan_barrier_met(ctx: Context, barrier: dict[str, Any]) -> None:
    """Mechanically evaluate one Plan barrier against durable GitHub truth.

    ``merged`` requires the upstream Issue's delivered Candidate, a PR that
    is MERGED at that exact Candidate SHA, and a durable exact-SHA A
    acceptance on the PR in one of the two canonical surfaces (native
    APPROVED review, or the structured ACCEPT comment fallback) — decided
    by the shared ``evaluate_exact_sha_acceptance`` predicate. ``issue_done``
    requires the stronger Issue-level DONE fact — CLOSED with closure reason
    ``completed`` — and is never derived from a merge.
    """

    number = barrier["issue"]
    gate = barrier["gate"]
    if gate == "merged":
        prior, _sha = ctx.remote_claim(number)
        candidate = (prior or {}).get("candidate")
        delivery = (prior or {}).get("delivery") or {}
        # The upstream attempt may be parked (active with a durable
        # delivery, capacity released) or already terminal "delivered"
        # (post-merge completion ran) — the gate reads the Candidate
        # delivery facts, never the post-merge completion itself.
        if (prior is None or prior.get("status") not in ("active", "delivered") or
                not isinstance(candidate, dict) or not candidate.get("sha") or
                not delivery.get("pr") or delivery.get("sha") != candidate.get("sha")):
            raise CommandFailure(
                f"barrier merged:#{number} is not satisfied: no delivered attempt with a "
                "preserved Candidate and a durable delivery/PR record", INELIGIBLE)
        candidate_sha = candidate["sha"]
        pr_number = delivery["pr"]
        pr = ctx.github.pr_view(int(pr_number))
        if not pr or pr.get("state") != "MERGED" or pr.get("headRefOid") != candidate_sha:
            raise CommandFailure(
                f"barrier merged:#{number} is not satisfied: PR #{pr_number} is not MERGED at "
                f"the delivered Candidate SHA {candidate_sha}", INELIGIBLE)
        # The authoritative Candidate-level acceptance lives on the PR,
        # bound to the exact delivered Candidate SHA, decided by one shared
        # mechanical predicate. Chat/Issue-only text never substitutes;
        # unreadable surfaces, absence, quoted/negated/explanatory
        # pseudo-acceptances, and acceptances bound to a different SHA all
        # fail closed. The execution-attempt completion record is
        # deliberately NOT part of this predicate: completion is a separate
        # post-merge transition.
        verdict = evaluate_exact_sha_acceptance(
            reviews=ctx.github.pr_reviews(int(pr_number)),
            comments=ctx.github.pr_comments(int(pr_number)),
            candidate_sha=candidate_sha)
        if verdict["unreadable"]:
            raise CommandFailure(
                f"barrier merged:#{number} cannot be evaluated: the review/acceptance "
                f"surface of PR #{pr_number} is unreadable; fail-closed", INELIGIBLE)
        if not verdict["accepted"]:
            if verdict["approved_other_shas"]:
                bound = sorted({sha[:12] for sha in verdict["approved_other_shas"]})
                raise CommandFailure(
                    f"barrier merged:#{number} is not satisfied: the APPROVED review(s) on "
                    f"PR #{pr_number} bind {bound}, not the delivered Candidate SHA "
                    f"{candidate_sha}, and no structured exact-SHA ACCEPT comment is present",
                    INELIGIBLE)
            raise CommandFailure(
                f"barrier merged:#{number} is not satisfied: PR #{pr_number} has no APPROVED "
                f"review bound to {candidate_sha[:12]} and no structured exact-SHA ACCEPT "
                "comment — merged requires a durable A acceptance outcome on the PR itself",
                INELIGIBLE)
    elif gate == "issue_done":
        try:
            issue = ctx.github.issue_view(number)
        except IntakeError as exc:
            raise CommandFailure(f"barrier issue_done:#{number} cannot be evaluated: {exc}",
                                 INELIGIBLE) from exc
        if str(issue.get("state", "")).lower() != "closed":
            raise CommandFailure(
                f"barrier issue_done:#{number} is not satisfied: the Issue is still open "
                "(a merge alone never derives Issue-level DONE)", INELIGIBLE)
        # DONE needs the durable closure reason, not merely a closed state:
        # not_planned/duplicate closures never unblock downstream work, and
        # an unreadable reason fails closed.
        reason = str(issue.get("stateReason") or "").strip().lower()
        if reason != "completed":
            raise CommandFailure(
                f"barrier issue_done:#{number} is not satisfied: the Issue closure reason is "
                f"{reason!r}, not completed; only CLOSED with state_reason completed counts "
                "as Issue-level DONE", INELIGIBLE)
    else:  # pragma: no cover - parse_execution_plan rejects unknown gates
        raise CommandFailure(f"unsupported Plan barrier gate {gate!r}", INELIGIBLE)


def _lineage_authorization_hit(ctx: Context, ref: str, authorization_id: str, *,
                               ignore_claim_id: str | None = None) -> dict[str, Any] | None:
    """Walk ONE claim lineage's durable ancestry for this authorization id.

    The authorization that started an attempt stays recorded in the parent
    commits forever, even after later attempts supersede it; only the whole
    ancestry is the audit truth, so the replay check walks every commit of
    the lineage, not just its current tip record.
    """

    # #93: with an active invocation snapshot, the lineage's full commit
    # history is already local (the batched fetch pulled every object), so
    # the walk resolves against the snapshot ref directly — no per-lineage
    # network round-trip.
    snap = ctx.snapshot_ref(ref)
    if snap is not None:
        snap_sha = ctx.snapshot_sha(ref)
        if snap_sha is None:
            return None  # lineage absent/deleted in the fresh snapshot
        for commit in _run(["git", "rev-list", snap]).stdout.split():
            result = _run(["git", "show", f"{commit}:CLAIM.json"], check=False)
            if result.returncode:
                continue
            try:
                record = json.loads(result.stdout)
            except json.JSONDecodeError:
                continue
            if not isinstance(record, dict) or record.get("v") != 3:
                continue
            if ignore_claim_id and record.get("claim_id") == ignore_claim_id:
                continue
            authorization = record.get("authorization")
            if (isinstance(authorization, dict) and authorization.get("type") == "plan" and
                    authorization.get("authorization_id") == authorization_id):
                return {"claim_id": record.get("claim_id"), "issue": record.get("task"),
                        "status": record.get("status")}
        return None

    temp_ref = f"refs/ght-read/{os.getpid()}-{uuid.uuid4().hex[:12]}"
    # No active invocation snapshot (mutating commands never build one):
    # the direct fallback — fetch this ONE lineage, walk its durable
    # ancestry, always clean the private temp ref up. The one-authorization
    # replay gate must keep its exact semantics outside discovery too.
    try:
        fetched = _run(["git", "fetch", "-q", ctx.remote, f"+{ref}:{temp_ref}"], check=False)
        if fetched.returncode:
            detail = fetched.stderr.strip() or fetched.stdout.strip() or "remote ref fetch failed"
            raise CommandFailure(f"cannot fetch remote ref {ref}: {detail}", OWNERSHIP_LOST)
        for commit in _run(["git", "rev-list", temp_ref]).stdout.split():
            result = _run(["git", "show", f"{commit}:CLAIM.json"], check=False)
            if result.returncode:
                continue
            try:
                record = json.loads(result.stdout)
            except json.JSONDecodeError:
                continue
            if not isinstance(record, dict) or record.get("v") != 3:
                continue
            if ignore_claim_id and record.get("claim_id") == ignore_claim_id:
                continue
            authorization = record.get("authorization")
            if (isinstance(authorization, dict) and authorization.get("type") == "plan" and
                    authorization.get("authorization_id") == authorization_id):
                return {"claim_id": record.get("claim_id"), "issue": record.get("task"),
                        "status": record.get("status")}
        return None
    finally:
        _run(["git", "update-ref", "-d", temp_ref], check=False)


def _plan_authorization_consumption(ctx: Context, authorization_id: str, *,
                                    ignore_claim_id: str | None = None) -> dict[str, Any] | None:
    """Durable replay check: scan claim lineages for this authorization id.

    Any prior claim record anywhere in any lineage's ancestry — ACTIVE,
    STALE, or terminal, in either namespace — blocks a second start;
    ordinary review corrections never consume a new authorization. A start
    never counts its own claim record (the post-acquisition recheck re-runs
    this scan). Ambiguous dual presence still fails closed.
    """

    by_number: dict[str, list[str]] = {}
    for ref in ctx.claim_refs():
        for prefix in (ctx.claims_prefix, ctx.legacy_claims_prefix):
            if ref.startswith(prefix):
                by_number.setdefault(ref[len(prefix):], []).append(ref)
                break
    for number, refs in sorted(by_number.items()):
        if len(refs) > 1:
            raise CommandFailure(
                f"AMBIGUOUS claim state: #{number} exists in both namespaces; fail-closed "
                "until reconciled", OWNERSHIP_LOST, refs=sorted(refs))
        hit = _lineage_authorization_hit(ctx, refs[0], authorization_id,
                                         ignore_claim_id=ignore_claim_id)
        if hit:
            return hit
    return None


def _ready_path_plan_authority_conflict(ctx: Context, number: int) -> dict[str, Any] | None:
    """Dual-authority XOR (AC4): a direct ``ready`` start must fail closed
    when the current Execution Plan also carries a live, unconsumed
    authorization for the same Issue. Both grants present at once is an
    ambiguity only A can reconcile — the claim never auto-prefers either
    surface. None means no conflict: no current Plan, no node for this
    Issue, or the node's authorization is already consumed."""
    plan, _revision = _remote_plan(ctx)
    if plan is None:
        return None
    node = next((entry for entry in plan["nodes"] if entry["issue"] == number), None)
    if node is None:
        return None
    if _plan_authorization_consumption(ctx, node["authorization_id"]) is not None:
        return None
    return {"plan_id": plan["plan_id"], "authorization_id": node["authorization_id"]}


def _resolve_plan_start(ctx: Context, number: int, authorization_id: str,
                        expected_digest: str, *,
                        ignore_claim_id: str | None = None) -> tuple[dict[str, Any], str, str]:
    """Mechanically resolve one Plan-authorized start against current truth.

    AC gates: the current revision must carry a node for this Issue with
    exactly this authorization identity, the node's contract digest must
    equal the authoritative Issue Contract digest, the identity must not
    have started an attempt before, every barrier must be satisfied, and
    the independent ``ready`` surface must not be present. Any miss fails
    closed before any remote state is created.
    """

    plan, revision = _remote_plan(ctx)
    if plan is None:
        raise CommandFailure("no current Execution Plan revision exists; plan-authorized "
                            "claims require refs/ght/plans/current", INELIGIBLE)
    node = next((entry for entry in plan["nodes"] if entry["issue"] == number), None)
    if node is None:
        raise CommandFailure(f"current Execution Plan revision {revision[:12]} carries no node "
                             f"for #{number}", INELIGIBLE)
    if node["authorization_id"] != authorization_id:
        raise CommandFailure(
            f"Plan node for #{number} authorizes {node['authorization_id']!r}, not "
            f"{authorization_id!r}", INELIGIBLE)
    consumed = _plan_authorization_consumption(ctx, authorization_id,
                                               ignore_claim_id=ignore_claim_id)
    if consumed:
        raise CommandFailure(
            f"plan authorization {authorization_id!r} was already consumed by claim "
            f"{consumed['claim_id']} on #{consumed['issue']}; one authorization starts at "
            "most one new attempt", INELIGIBLE, **consumed)
    if node["contract_digest"] != expected_digest:
        raise CommandFailure(
            "Plan node contract_digest does not match the authoritative Issue Contract; "
            "A must publish a fresh revision for the changed Contract", INELIGIBLE)
    for barrier in node["after"]:
        _assert_plan_barrier_met(ctx, barrier)
    if ctx.ready_label in ctx.github.issue_labels(number):
        raise CommandFailure(
            f"the one-shot READY label {ctx.ready_label!r} is present; direct and Plan "
            "authorization are independent paths — exactly one may authorize a start",
            INELIGIBLE)
    return node, revision, plan["plan_id"]


def _plan_start_recheck_error(ctx: Context, number: int, authorization_id: str,
                              expected_digest: str, claim_id: str) -> str | None:
    """Post-acquisition Plan recheck; None means the start may proceed."""

    try:
        _resolve_plan_start(ctx, number, authorization_id, expected_digest,
                            ignore_claim_id=claim_id)
    except CommandFailure as failure:
        return str(failure)
    return None


def _revoke_plan_start(ctx: Context, number: int, claim: dict[str, Any], commit: str,
                       reason: str, *, label: str = "Plan-authorized start") -> str:
    """Terminalize a just-acquired ownership state whose authority broke
    after CAS acquisition.

    A start that must never look like a validly authorized attempt: the
    claim lineage CAS-appends a durable ``failed`` record and the in-flight
    reservation and execution lease are released.
    """

    revoked = {**claim, "status": "failed",
               "note": (f"{label} revoked fail-closed: {reason}")[:2000],
               "lease_expires_at": _iso(_utc_now())}
    revoke_commit = ctx.claim_commit(revoked, parent=commit)
    ref = ctx.claim_location(number)
    pushed = _run(["git", "push", f"--force-with-lease={ref}:{commit}", ctx.remote,
                   f"{revoke_commit}:{ref}"], check=False)
    if pushed.returncode:
        raise CommandFailure(
            "could not revoke the plan-authorized start fail-closed; the ownership state "
            "must be reconciled manually before any further mutation", OWNERSHIP_LOST,
            remote_sha=ctx.ls_remote(ref))
    reservation, reservation_sha = _remote_executor_reservation(ctx)
    _release_executor_marker(ctx, claim["claim_id"], reservation, reservation_sha)
    _release_execution_lease(ctx, claim, require_holder=False)
    ctx.save_claim(number, revoked, revoke_commit)
    marker = f"<!-- ght:revoke:{claim['claim_id']} -->"
    try:
        authority_line = ""
        if label == "Plan-authorized start":
            authorization_id = claim.get("authorization", {}).get("authorization_id")
            authority_line = f" — plan authorization `{authorization_id}`"
        ctx.github.comment(number, marker + f"\n**START REVOKED**{authority_line} on "
                           f"#{number}\n- reason: {reason}\n"
                           "- the attempt never becomes executable; a new start needs a fresh "
                           "authorization", marker)
    except MirrorError as exc:
        print(f"ght: WARNING — revocation comment failed: {exc}", file=sys.stderr)
    return revoke_commit


def _fresh_contract_digest(ctx: Context, number: int) -> str:
    """#91 (AC1): read the Issue's fenced Contract fresh and digest it with
    the one canonical primitive (``parse_contract`` + ``contract_digest``)
    — the only sanctioned digest path; no second parser, no hand-computed
    hash. Any unreadable or invalid Contract fails closed."""
    try:
        issue = ctx.github.issue_view(number)
    except (IntakeError, CommandFailure) as exc:
        raise CommandFailure(f"#{number} is unreadable; digest fails closed ({exc})",
                             OWNERSHIP_LOST) from exc
    if not issue:
        raise CommandFailure(f"#{number} is unreadable; digest fails closed",
                             OWNERSHIP_LOST)
    try:
        contract = parse_contract(issue.get("body", ""))
    except ContractError as exc:
        raise CommandFailure(f"#{number} has no valid ght-contract; digest fails "
                             f"closed ({exc})", INELIGIBLE) from exc
    return contract_digest(contract)


def _cmd_contract_digest(args: argparse.Namespace) -> None:
    """A-facing mechanical digest surface (#91 AC1): the ONLY sanctioned
    way to obtain an Issue Contract's digest for Plan authoring. The value
    is produced by the same canonical primitives the claim gate binds —
    hand-computing or externally re-implementing this digest is
    prohibited (see prompts/A-project-rules.md)."""
    ctx = Context(args.remote, args.repo)
    print(json.dumps({"issue": args.issue,
                      "contract_digest": _fresh_contract_digest(ctx, args.issue)}))


def _cmd_plan_publish(args: argparse.Namespace) -> None:
    """Publish a new immutable Execution Plan revision by exact-prior CAS.

    A-only action surface: the first publish creates the current pointer
    with an empty expect-lease; every later publish must name the exact
    prior revision it supersedes (--replace) and becomes a child commit of
    it. A lost CAS race fails closed — re-read the new pointer and publish
    on top of it.
    """

    ctx = Context(args.remote, args.repo)
    text = sys.stdin.read() if args.plan_file == "-" else Path(args.plan_file).read_text()
    # #156 (AC1/AC2): the remote-A authoring surface may commit nodes WITHOUT
    # a contract_digest; only an invocation that explicitly carries the
    # mechanical binding mode may parse such a document. Without the flag the
    # strict v1 parse keeps refusing unbound nodes exactly as before.
    try:
        plan = (parse_plan_authoring(text) if args.bind_contract_digests
                else parse_execution_plan(text))
    except ExecutionPlanError as exc:
        raise CommandFailure(f"invalid Execution Plan: {exc}", INELIGIBLE) from exc
    # #89 (AC1/AC6): a PRESENCE check on the raw authored document, not a
    # value check on the parsed result — the parser drops JSON nulls for
    # legacy readability, but publication persists the exact input text,
    # so even `max_concurrency: null` would carry the retired field into
    # canonical current truth. Fail closed before any ref mutation.
    if "max_concurrency" in json.loads(text):
        raise CommandFailure(
            "the authored Execution Plan carries the retired `max_concurrency` "
            "concurrency envelope: a new/current Plan revision must author no "
            "concurrency field, including an explicit JSON null (historical "
            "revisions may keep the field; the runtime reads those as "
            "audit-only). Fail-closed before any ref mutation.",
            INELIGIBLE)
    # #156 (AC2/AC3): mechanical remote-A Contract binding. The ONLY value
    # this step produces is the protocol-required Contract identity: each
    # UNBOUND node gets its contract_digest from _fresh_contract_digest —
    # the exact canonical primitive behind `ght contract-digest`. Membership,
    # priorities, after barriers, and authorization ids are never touched
    # here; an unreadable or invalid Contract fails closed right here.
    bound_any = False
    if args.bind_contract_digests:
        for node in plan["nodes"]:
            if node["contract_digest"] is None:
                node["contract_digest"] = _fresh_contract_digest(ctx, node["issue"])
                bound_any = True
        if bound_any:
            # The publication text becomes the BOUND document: a digest-free
            # authoring payload must never persist as an unparseable revision.
            text = json.dumps(plan, ensure_ascii=False, indent=2) + "\n"
    # #91 (AC2): fresh-read every node's Issue Contract and bind the
    # canonical digest — a hand-computed or stale digest can no longer
    # enter canonical current truth. Validation only (AC3): nodes,
    # priorities, authorizations, and membership are never rewritten here.
    # The loop re-reads EVERY node — including just-bound ones — so a
    # Contract mutated BETWEEN binding and publication still fails closed
    # (stale-binding refusal) instead of silently publishing a stale
    # digest (#156 AC3).
    for node in plan["nodes"]:
        digest = _fresh_contract_digest(ctx, node["issue"])
        if digest != node["contract_digest"]:
            raise CommandFailure(
                f"Plan node #{node['issue']} contract_digest mismatch: the Plan "
                f"carries {node['contract_digest'][:12]}… but the Issue Contract "
                f"fresh-read digests to {digest[:12]}…; node digests must come "
                "only from `ght contract-digest <issue>` — obtain the fresh "
                "digest and republish. Fail-closed before any ref mutation.",
                INELIGIBLE, issue=node["issue"],
                plan_digest=node["contract_digest"], fresh_digest=digest)
    prior_sha = ctx.ls_remote(ctx.plan_ref)
    if args.replace is not None:
        if prior_sha is None or prior_sha != args.replace:
            raise CommandFailure(
                f"CAS mismatch: current Execution Plan pointer is "
                f"{prior_sha[:12] if prior_sha else 'absent'}, expected "
                f"{args.replace[:12]}; fail-closed — re-read the pointer and publish on "
                "top of the exact new prior revision", RACE, current=prior_sha,
                expected=args.replace)
        if _run(["git", "cat-file", "-e", f"{prior_sha}^{{commit}}"], check=False).returncode:
            _run(["git", "fetch", "-q", ctx.remote, ctx.plan_ref], check=False)
        if _run(["git", "cat-file", "-e", f"{prior_sha}^{{commit}}"], check=False).returncode:
            raise CommandFailure(f"prior revision {prior_sha[:12]} is not a readable commit "
                                 "object; publish cannot chain the lineage", OWNERSHIP_LOST)
        # One repository execution context has one long-lived stable plan_id;
        # revisions evolve that identity immutably. A replacement that tries
        # to establish a different Plan identity fails closed before any
        # ref mutation.
        prior_text = _run(["git", "show", f"{prior_sha}:PLAN.json"], check=False)
        if prior_text.returncode:
            raise CommandFailure(f"prior revision {prior_sha[:12]} has no readable PLAN.json; "
                                 "publish cannot verify plan identity stability", OWNERSHIP_LOST)
        try:
            prior_plan = parse_execution_plan(prior_text.stdout)
        except ExecutionPlanError as exc:
            raise CommandFailure(f"prior revision {prior_sha[:12]} is invalid: {exc}",
                                 INELIGIBLE) from exc
        if prior_plan["plan_id"] != plan["plan_id"]:
            raise CommandFailure(
                "plan_id must stay stable across revisions: prior revision "
                f"{prior_sha[:12]} carries {prior_plan['plan_id']!r}, the new document "
                f"carries {plan['plan_id']!r}; v1 has no Plan identity replacement — "
                "fail-closed", INELIGIBLE, prior_plan_id=prior_plan["plan_id"],
                new_plan_id=plan["plan_id"])
        commit = _plan_commit(text, parent=prior_sha,
                              identity=ctx.github_principal)
        lease = f"{ctx.plan_ref}:{prior_sha}"
    else:
        if prior_sha is not None:
            raise CommandFailure(
                f"an Execution Plan revision already exists at {ctx.plan_ref} "
                f"({prior_sha[:12]}); publish a new revision with "
                "--replace <prior-revision-sha>", RACE, current=prior_sha)
        commit = _plan_commit(text, identity=ctx.github_principal)
        lease = f"{ctx.plan_ref}:"
    pushed = _run(["git", "push", f"--force-with-lease={lease}", ctx.remote,
                   f"{commit}:{ctx.plan_ref}"], check=False)
    if pushed.returncode:
        raise CommandFailure("Execution Plan CAS push rejected; the current pointer moved — "
                            "fail-closed, re-read and publish on top of the exact new prior",
                            RACE, current=ctx.ls_remote(ctx.plan_ref))
    if ctx.ls_remote(ctx.plan_ref) != commit:
        raise CommandFailure("Execution Plan publication could not be confirmed from remote "
                             "truth", OWNERSHIP_LOST)
    print(json.dumps({"plan_id": plan["plan_id"], "revision": commit, "replaced": args.replace,
                      "ref": ctx.plan_ref, "nodes": len(plan["nodes"])}))


def _cmd_plan_view(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    plan, revision = _remote_plan(ctx, revision=args.revision)
    print(json.dumps({"revision": revision, "ref": ctx.plan_ref, "plan": plan}))


def _pending_resource_reclaim(prior: dict[str, Any] | None) -> bool:
    """Canonical pending-reclaim fence predicate (#147): a claim lineage
    carrying a ``resource_reclaim`` marker has destructive execution-resource
    removal authorized and pending at the cleanup boundary — every new
    start is fenced until the removal confirms. ONE predicate, shared by
    the canonical claim intake and discovery eligibility, so a discovery
    verdict can never advertise a start the supported claim path refuses
    (#164 R3)."""
    return bool(prior and prior.get("resource_reclaim"))


def _claim_preconditions(ctx: Context, number: int, mode: str, *,
                         require_ready: bool) -> tuple[dict[str, Any], dict[str, Any] | None, str | None]:
    """Re-read every eligibility fact; return (contract, prior_claim, prior_sha)."""

    issue = ctx.github.issue_view(number)
    contract = _validate_issue_intake(ctx, number, issue, require_ready=require_ready)
    _assert_mode_matches_authority(contract, mode)
    prior, prior_sha = ctx.remote_claim(number)
    if prior is not None:
        if _pending_resource_reclaim(prior):
            # Pending execution-resource reclaim (#147): destructive worktree
            # removal is authorized at the cleanup boundary; a new attempt
            # cannot become ACTIVE until the removal confirms.
            raise CommandFailure(
                f"#{number} has a pending execution-resource reclaim marker "
                "(destructive worktree removal in flight at the cleanup boundary); "
                "a new attempt cannot start until the removal confirms — reconcile "
                "via `ght reclaim-execution-resource " + str(number) +
                " --confirm-removal --expect-claim-sha <claim_sha>`",
                RACE, remote=prior)
        if _is_parked(ctx, prior):
            # A parked delivered attempt keeps its durable identity: review
            # continues the SAME attempt (ght acquire), and a genuinely new
            # attempt requires A's explicit BLOCK/REPLAN + fresh
            # authorization — never a silent overwrite of a delivered
            # Candidate awaiting review.
            raise CommandFailure(
                f"#{number} has a delivered Candidate awaiting review (parked non-terminal "
                "attempt); resume the same attempt with `ght acquire " + str(number) + "`, or "
                "have A explicitly BLOCK/REPLAN before a fresh authorization", INELIGIBLE,
                remote=prior)
        state = claim_state(prior)
        if state == "ACTIVE":
            raise CommandFailure(f"claim already exists and is ACTIVE for #{number}", RACE, remote=prior)
        if state == "STALE":
            raise CommandFailure(
                "existing claim lease expired; use takeover with durable evidence to recover "
                "the same active attempt (no fresh READY is needed for recovery)", STALE, remote=prior)
        # TERMINAL: durable history, not a dead end (terminal lineage). A
        # delivered/blocked/failed attempt may be followed by a genuinely
        # NEW attempt, but only through the normal READY-gated path; the
        # new claim CAS-appends and durably records the superseded prior
        # identity. An investigated report answered the Contract — new work
        # belongs on a new Issue.
        if prior.get("status") not in ("delivered", "blocked", "failed"):
            raise CommandFailure(
                f"claim for #{number} is terminal ({prior.get('status')}); a terminal "
                "investigation is final — new work belongs on a new Issue", INELIGIBLE,
                remote=prior)
    # #89: a stable B coordination identity may hold several independent,
    # fully authorized ACTIVE executions at once — ownership/fencing remain
    # per-Issue, so no cross-Issue gate applies here.
    return contract, prior, prior_sha


def _migrate_terminal_claim(ctx: Context, number: int, legacy_ref: str, sha: str) -> str:
    """Migrate one TERMINAL legacy claim ref (AC5, dual-presence rule of AC4).

    Provenance decides everything: only a transient duplicate that THIS
    invocation created (empty expect-lease) and proved via remote truth
    (identical SHA) may be followed by the exact-lease delete of the legacy
    pointer. A current-namespace ref that already existed before this call
    is a pre-existing dual presence: ambiguous regardless of SHA, both refs
    are kept, and the command fails closed.
    """

    target = f"{ctx.claims_prefix}{number}"
    if ctx.ls_remote(target) is not None:
        raise CommandFailure(
            f"AMBIGUOUS dual presence for #{number}: {target} already exists and was not "
            "created by this migration; neither copy may be auto-deleted — fail-closed",
            OWNERSHIP_LOST, legacy_ref=legacy_ref, target=target)
    _run(["git", "push", f"--force-with-lease={target}:", ctx.remote,
          f"{sha}:{target}"], check=False)
    copied = ctx.ls_remote(target)
    if copied != sha:
        raise CommandFailure("terminal claim migration could not prove the copied object "
                             "from remote truth", OWNERSHIP_LOST, target=target,
                             remote_sha=copied, expected_sha=sha)
    _run(["git", "push", f"--force-with-lease={legacy_ref}:{sha}", ctx.remote, f":{legacy_ref}"],
         check=False)
    if ctx.ls_remote(legacy_ref) is not None:
        raise CommandFailure(
            "legacy pointer deletion unconfirmed after migration; the remaining dual presence "
            "is ambiguous — fail-closed", OWNERSHIP_LOST, legacy_ref=legacy_ref, target=target)
    return target


def _cmd_claim(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    number = args.issue
    mode = args.mode
    # Two independent one-shot authorization surfaces: the direct/JIT
    # ``ready`` label and a Plan authorization identity under the current
    # Execution Plan revision. Exactly one may authorize a start; neither
    # is derived from, or materialized by, the other.
    plan_authorization = getattr(args, "plan_authorization", None)
    plan_path = plan_authorization is not None

    # First read: fail fast before creating any remote state. A fresh
    # lineage (no prior ref) or a fresh-authorization new attempt over a
    # delivered/blocked/failed terminal lineage may be claimed.
    contract, prior, prior_sha = _claim_preconditions(
        ctx, number, mode, require_ready=not plan_path)
    if not plan_path:
        conflict = _ready_path_plan_authority_conflict(ctx, number)
        if conflict is not None:
            raise CommandFailure(
                f"dual authority for #{number}: the direct READY label and the live Plan "
                f"authorization {conflict['authorization_id']!r} (plan "
                f"{conflict['plan_id']!r}) are both present; exactly one may authorize a "
                "new attempt — fail-closed for A reconciliation", INELIGIBLE, **conflict)

    plan_node = None
    plan_revision = None
    plan_id = None
    if plan_path:
        plan_node, plan_revision, plan_id = _resolve_plan_start(
            ctx, number, plan_authorization, contract_digest(contract))

    supersedes = None
    if prior is not None and prior_sha is not None:
        supersedes = {"claim_id": prior["claim_id"], "sha": prior_sha,
                      "status": prior.get("status")}

    reservation_id = new_claim_id(ctx.executor_id, _utc_now())
    reservation, reservation_commit, reservation_prior_sha = _prepare_executor_reservation(
        ctx, number, reservation_id)
    reservation_ref = _executor_reservation_ref(ctx)

    execution_base = ctx.protected_head()
    branch = f"{ctx.branch_prefix}{number}/{uuid.uuid4().hex[:8]}"
    now = _utc_now()
    claim = build_claim(issue=number, github_principal=ctx.github_principal,
                        executor_id=ctx.executor_id, execution_base=execution_base,
                        branch=branch, contract=contract, now=_iso(now),
                        lease_expires_at=_iso(now + timedelta(minutes=ctx.lease_minutes)),
                        supersedes=supersedes)
    # Durable runtime binding (AC21 downstream model): a new attempt records
    # the project's activated runtime capsule identity at start. acquire/
    # resume preserves it (the lineage record is never rewritten), later
    # project pin upgrades never move it, and the Mechanical Reconciler
    # executes the attempt under its own bound capsule.
    runtime_pin = _read_runtime_pin(ctx)
    if runtime_pin:
        claim["runtime"] = runtime_pin
    # The in-flight reservation and the final claim share one identity so
    # recovery/cleanup decisions never split between two ids.
    claim["claim_id"] = reservation_id
    if plan_path:
        # Durable start authority: exactly what authorized this attempt.
        claim["authorization"] = {"type": "plan", "plan_id": plan_id,
                                  "authorization_id": plan_authorization,
                                  "plan_revision": plan_revision,
                                  "contract_digest": claim["contract_digest"]}

    # Authoritative re-read immediately before the atomic claim push: every
    # eligibility fact is re-fetched, and the lineage base must not have
    # moved under us.
    latest_contract, latest_prior, latest_prior_sha = _claim_preconditions(
        ctx, number, mode, require_ready=not plan_path)
    if contract_digest(latest_contract) != claim["contract_digest"]:
        raise CommandFailure("Issue Contract changed immediately before claim; stand down", INELIGIBLE)
    if not plan_path:
        conflict = _ready_path_plan_authority_conflict(ctx, number)
        if conflict is not None:
            raise CommandFailure(
                f"dual authority for #{number}: the direct READY label and the live Plan "
                f"authorization {conflict['authorization_id']!r} (plan "
                f"{conflict['plan_id']!r}) are both present; exactly one may authorize a "
                "new attempt — fail-closed for A reconciliation", INELIGIBLE, **conflict)
    if plan_path:
        latest_node, latest_revision, _plan_id = _resolve_plan_start(
            ctx, number, plan_authorization, contract_digest(latest_contract),
            ignore_claim_id=claim["claim_id"])
        if latest_revision != plan_revision:
            raise CommandFailure("Execution Plan revision changed immediately before claim; "
                                 "stand down and re-read the current revision", RACE,
                                 first_revision=plan_revision, latest_revision=latest_revision)
        if latest_node["authorization_id"] != plan_node["authorization_id"]:
            raise CommandFailure("Plan node identity changed immediately before claim; stand down",
                                 RACE)
    if (prior_sha is None) != (latest_prior_sha is None):
        raise CommandFailure("claim lineage changed immediately before claim; stand down", RACE,
                             remote=latest_prior)
    if prior_sha is not None and (latest_prior_sha != prior_sha or
                                  not _same_record(latest_prior, prior)):
        raise CommandFailure("claim lineage changed immediately before claim; stand down", RACE,
                             remote=latest_prior)
    if supersedes != ({"claim_id": latest_prior["claim_id"], "sha": latest_prior_sha,
                       "status": latest_prior.get("status")}
                      if latest_prior is not None and latest_prior_sha is not None else None):
        raise CommandFailure("claim lineage changed immediately before claim; stand down", RACE,
                             remote=latest_prior)

    if prior_sha and ctx.claim_location(number) == ctx.legacy_claims_prefix + str(number):
        # A new attempt after a TERMINAL legacy prior is a NEW claim, so it
        # is created in the current namespace (AC1); the terminal legacy ref
        # is migrated with the exact-identity procedure of AC5 first.
        _migrate_terminal_claim(ctx, number, ctx.legacy_claims_prefix + str(number), prior_sha)
        prior, prior_sha = ctx.remote_claim(number)
    ref = f"{ctx.claims_prefix}{number}"
    if prior_sha:
        commit = ctx.claim_commit(claim, parent=prior_sha)
        # Expect-lease on the prior terminal commit: the append is CAS-safe.
        leases = [f"{ref}:{prior_sha}"]
    else:
        commit = ctx.claim_commit(claim)
        # Empty expect-lease: the claim ref must not exist for a fresh lineage.
        leases = [f"{ref}:"]
    # Temporary execution capacity is acquired with the attempt (AC1/AC3):
    # the fresh lease and its fencing identity land in the same atomic push.
    lease = _build_lease_record(ctx, claim)
    lease_ref = _execution_lease_ref(ctx, claim["claim_id"])
    lease_commit = ctx.claim_commit(lease, document="LEASE.json")
    leases.append(f"{lease_ref}:")
    leases.append(f"{reservation_ref}:{reservation_prior_sha}")
    pushed = _atomic_push(ctx, [f"{reservation_commit}:{reservation_ref}",
                                f"{commit}:{ref}", f"{lease_commit}:{lease_ref}"],
                          leases)

    reconciled = False
    if pushed.returncode:
        if not _push_reconciled(ctx, commit, claim, ref,
                                reservation_expected=reservation,
                                reservation_commit=reservation_commit):
            raise CommandFailure("claim race lost or ambiguous push could not be reconciled", RACE,
                                 remote=ctx.remote_claim(number)[0])
        reconciled = True
    remote, remote_sha = ctx.remote_claim(number)
    remote_reservation, reservation_sha = _remote_executor_reservation(ctx)
    remote_lease, lease_sha = _remote_execution_lease(ctx, claim["claim_id"])
    if (not remote or remote_sha != commit or not _same_record(remote, claim) or
            remote_reservation is None or reservation_sha != reservation_commit or
            not _same_record(remote_reservation, reservation) or
            remote_lease is None or lease_sha != lease_commit or
            not _same_record(remote_lease, lease)):
        raise CommandFailure("post-claim verification failed: remote state is not our claim",
                             OWNERSHIP_LOST, remote=remote, remote_sha=remote_sha)
    ctx.save_claim(number, remote, remote_sha)
    _save_local_lease(ctx, number, remote_lease, lease_sha)

    if plan_path:
        # Post-acquisition Plan recheck (before any implementation mutation):
        # the current revision is re-read fresh. A revision change is fine
        # while the same authorization semantics still hold; a deleted node,
        # changed identity or digest, or a newly unsatisfied barrier revokes
        # the just-acquired ownership state fail-closed.
        recheck_error = _plan_start_recheck_error(
            ctx, number, plan_authorization, claim["contract_digest"], claim["claim_id"])
        if recheck_error is not None:
            _revoke_plan_start(ctx, number, claim, commit, recheck_error)
            raise CommandFailure(
                f"plan-authorized start on #{number} was revoked fail-closed after "
                f"acquisition: {recheck_error}", INELIGIBLE,
                claim_id=claim["claim_id"], authorization_id=plan_authorization)
        mirror = {"consumed": True, "path": "plan-authorization",
                  "note": "plan authorization consumed; the independent ready surface "
                          "was not involved"}
    else:
        # READY is one-shot authorization. Claim CAS is ownership truth, but a
        # failed label removal must never leave the authorization mirror looking
        # like fresh authorization for a future attempt: this attempt FAILS
        # CLOSED and every gated command refuses to continue until the mirror is
        # repaired via `ght ready-repair` (never by re-claiming).
        mirror = ctx.github.consume_ready(number, ctx.ready_label)
        if not mirror["consumed"]:
            raise CommandFailure(
                f"claim {claim['claim_id']} owns #{number}, but READY label {ctx.ready_label!r} "
                f"could not be removed after {mirror['attempts']} attempt(s): {mirror.get('error')}. "
                "FAIL-CLOSED: run `ght ready-repair " + str(number) + "` from the owning worker; "
                "gated commands refuse to continue while the stale mirror persists.",
                ERROR, claim_id=claim["claim_id"], ref=ref, ref_sha=remote_sha,
                ready_mirror=mirror)
        # AC4 post-acquisition recheck (mirrors the Plan path's symmetric
        # race guard): a Plan authorization CAS-published between the final
        # pre-push check and this claim landing leaves BOTH one-shot
        # authorities on the same new attempt — revoke the just-acquired
        # start fail-closed before any implementation mutation.
        conflict = _ready_path_plan_authority_conflict(ctx, number)
        if conflict is not None:
            reason = (f"a live unconsumed Plan authorization "
                      f"{conflict['authorization_id']!r} (plan {conflict['plan_id']!r}) "
                      f"appeared for #{number} during acquisition; both one-shot "
                      "authorities existed for this new attempt")
            _revoke_plan_start(ctx, number, claim, remote_sha, reason,
                               label="Direct-ready start")
            raise CommandFailure(
                f"dual authority for #{number} detected after acquisition: the direct "
                "READY start was revoked fail-closed for A reconciliation",
                INELIGIBLE, **conflict)

    marker = f"<!-- ght:claim:{claim['claim_id']} -->"
    authority = contract["authority"]["implementation"]
    try:
        lineage = (f"\n- supersedes: `{supersedes['claim_id']}` ({supersedes['status']} at "
                   f"`{supersedes['sha'][:12]}`)" if supersedes else "")
        authorization_line = (f"\n- authorization: plan `{plan_authorization}` "
                              f"(`{plan_id}` at revision `{plan_revision[:12]}`)"
                              if plan_path else "")
        ctx.github.comment(number, marker + f"\n**CLAIMED** by {ctx.executor_id}\n"
                           f"- claim_id: `{claim['claim_id']}`\n- execution_base: `{execution_base}`\n"
                           f"- branch: `{branch}`\n- authority: `{authority}` ({mode} attempt)"
                           f"{authorization_line}{lineage}\n"
                           f"- ownership source of truth: `{ref}`", marker)
    except MirrorError as exc:
        print(f"ght: WARNING — claim comment failed: {exc}", file=sys.stderr)

    supervisor = _spawn_supervisor(ctx, number)
    print(json.dumps({"issue": number, "claim_id": claim["claim_id"], "ref": ref,
                      "ref_sha": remote_sha, "branch": branch, "mode": mode,
                      "authority": authority, "supersedes": supersedes,
                      "execution_base": execution_base, "reconciled": reconciled,
                      "supervisor": supervisor, "ready_mirror": mirror,
                      "authorization": claim.get("authorization"),
                      "execution_lease": {"ref": lease_ref,
                                          "fencing_token": remote_lease.get("fencing_token"),
                                          "lease_expires_at": remote_lease.get("lease_expires_at")}}))


def _cmd_ready_repair(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    # The repair tool must reach the mirror while the stale label is exactly
    # what blocks every other gated command.
    _owned_active(ctx, args.issue, require_ready_consumed=False)
    mirror = ctx.github.consume_ready(args.issue, ctx.ready_label)
    print(json.dumps({"issue": args.issue, "ready_mirror": mirror}))
    if not mirror["consumed"]:
        raise SystemExit(ERROR)


def _cmd_verify(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    claim, ref_sha = _owned_active(ctx, args.issue)
    _assert_contract_unchanged(ctx, args.issue, claim)
    # Verification proves live execution ownership, not just the durable
    # attempt record (AC13): the holder must present the current fencing
    # identity of a valid lease.
    lease, lease_sha = _fence_execution_lease(ctx, args.issue, claim)
    print(json.dumps({"issue": args.issue, "owned": True, "claim_id": claim["claim_id"],
                      "ref_sha": ref_sha, "status": claim["status"],
                      "execution_lease": {"ref": _execution_lease_ref(ctx, claim["claim_id"]),
                                          "fencing_token": lease.get("fencing_token"),
                                          "lease_expires_at": lease.get("lease_expires_at")}}))


def _cmd_heartbeat(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    claim, ref_sha = _owned_active(ctx, args.issue)
    now = _utc_now()
    if not args.force and _parse_iso(claim["lease_expires_at"]) - now > timedelta(minutes=ctx.lease_minutes / 2):
        print(json.dumps({"issue": args.issue, "renewed": False,
                          "lease_expires_at": claim["lease_expires_at"]}))
        return
    # One fenced renewal moves the attempt-liveness record and the live
    # execution lease together (AC1/AC3): they must never drift apart.
    updated = _renew_claim_and_lease(ctx, args.issue, claim, ref_sha)
    print(json.dumps({"issue": args.issue, "renewed": True,
                      "lease_expires_at": updated["lease_expires_at"]}))


def _cmd_acquire(args: argparse.Namespace) -> None:
    """Resume an owned non-terminal attempt by acquiring a fresh lease.

    Ordinary REQUEST_CHANGES resume (AC6): the durable attempt, claim
    lineage, branch, and Contract stay exactly as they are; a new temporary
    execution lease with a new fencing identity is acquired and the
    execution workspace may be rebuilt. No fresh `ready` and no new Plan
    authorization is involved. The caller must be the attempt's own
    executor — recovering an attempt across executors is `ght takeover`.
    """

    ctx = Context(args.remote, args.repo)
    claim, claim_sha = ctx.remote_claim(args.issue)
    if not claim or claim.get("v") != 3:
        raise CommandFailure(f"no claim lineage on #{args.issue}", INELIGIBLE)
    if claim.get("status") == "delivered" and claim.get("completed"):
        raise CommandFailure(f"attempt on #{args.issue} is terminal; execution capacity "
                             "no longer exists for it", STALE)
    if claim.get("status") != "active":
        raise CommandFailure(f"attempt on #{args.issue} is terminal ({claim.get('status')}); "
                             "a new attempt needs A's fresh authorization", STALE)
    if claim.get("resource_reclaim"):
        # Pending execution-resource reclaim (#147): the destructive-boundary
        # fence holds the CAS domain — no capacity can be re-established for
        # this Issue until the removal confirms.
        raise CommandFailure(
            f"#{args.issue} has a pending execution-resource reclaim marker "
            "(destructive worktree removal in flight at the cleanup boundary); "
            "execution capacity cannot be re-established until it confirms — "
            "reconcile via `ght reclaim-execution-resource " + str(args.issue) +
            " --confirm-removal --expect-claim-sha <claim_sha>`", RACE)
    claim_executor = claim.get("executor_id") or ""
    owned = (claim_executor == ctx.executor_id or
             claim_executor.startswith(f"{ctx.executor_id}/orch-"))
    if (not owned or claim.get("github_principal") != ctx.github_principal):
        raise CommandFailure(
            f"the attempt on #{args.issue} belongs to executor {claim.get('executor_id')!r}; "
            "resuming another executor's attempt is `ght takeover` with durable evidence",
            OWNERSHIP_LOST, remote_executor=claim.get("executor_id"))
    _assert_contract_unchanged(ctx, args.issue, claim)
    _ready_mirror_gate(ctx, args.issue)
    _supervision_gate(ctx, args.issue)
    lease = _acquire_execution_lease(ctx, args.issue, claim, claim_sha or "")
    supervisor = _spawn_supervisor(ctx, args.issue)
    print(json.dumps({"issue": args.issue, "claim_id": claim["claim_id"],
                      "status": claim["status"],
                      "execution_lease": {"ref": _execution_lease_ref(ctx, claim["claim_id"]),
                                          "fencing_token": lease["fencing_token"],
                                          "lease_expires_at": lease["lease_expires_at"]},
                      "supervisor": supervisor}))


def _validate_reclaim_eligible(ctx: Context, issue: int, claim: dict[str, Any]) -> None:
    """Canonical reclaimable predicate for destructive-removal authorization.

    Mirrors the cleanup eligibility fence exactly: a terminal lineage, or a
    non-terminal lineage canonically parked (durable Candidate delivery, no
    live execution capacity) owned by this coordination identity. A current
    non-parked execution resource — in-flight or pre-dispatch — is never
    cleanup-eligible."""

    state = claim_state(claim)
    if state == "TERMINAL":
        return
    if state in ("ACTIVE", "STALE") and _is_parked(ctx, claim):
        claim_executor = claim.get("executor_id") or ""
        owned = (claim_executor == ctx.executor_id or
                 claim_executor.startswith(f"{ctx.executor_id}/orch-"))
        if not owned:
            raise CommandFailure(
                f"the parked attempt on #{issue} belongs to executor "
                f"{claim.get('executor_id')!r}; another identity's review-wait "
                "resource is not this cleanup's to judge", OWNERSHIP_LOST,
                remote_executor=claim.get("executor_id"))
        return
    raise CommandFailure(
        f"#{issue} is a current non-terminal execution resource (claim_state "
        f"{state}, not canonically parked); its worktree is never cleanup-eligible",
        INELIGIBLE, claim_state=state)


def _cmd_reclaim_execution_resource(args: argparse.Namespace) -> None:
    """Atomic destructive-removal authorization for fenced worktree cleanup.

    Closes the destructive-boundary race mechanically (#147 AC3): the removal
    of an execution resource (an Issue worktree) is authorized by a single
    CAS transition on the Issue's canonical claim ref — the same CAS domain
    every capacity-establishing transition (``ght claim`` / ``ght acquire`` /
    takeover / renewal) must win to become valid. ``ght`` is the only writer
    of that domain, so authorization and ownership truth stay bound: the
    marker is ght's own authoritative record, not a second truth.

    Authorize (default): re-reads the claim record fresh and requires the
    caller's ``--expect-claim-sha`` (the ``claim_sha`` of the authorizing
    eligibility read) to still anchor the ref head — any ownership movement
    since the read voids the stale decision fail-closed; validates the
    reclaimable predicate (terminal lineage, or parked delivery owned by
    this coordination identity); CAS-appends a ``resource_reclaim`` marker
    (or, for a true orphan with no claim lineage, CAS-creates a reclaim
    tombstone with an empty expect-lease) so every ``ght claim`` / ``ght
    acquire`` for the Issue fails closed while the removal is pending.
    Because authorize and every capacity-establishing transition anchor on
    the same ref with git's force-with-lease, an ACTIVE transition cannot
    become valid between authorization and destructive removal: either the
    transition won the ref first (authorization refused, no removal) or the
    marker holds and the transition is refused.

    ``--confirm-removal`` clears the marker after the removal (CAS-anchored
    on the marker commit for lineage records; exact-lease ref deletion for
    tombstones), restoring normal claim/acquire semantics. Re-authorization
    against an unchanged marker head is idempotent, so an interrupted
    cleanup re-run resumes instead of wedging.
    """

    ctx = Context(args.remote, args.repo)
    issue = args.issue
    expected = (args.expect_claim_sha or "").strip()
    ref = ctx.claim_location(issue)
    current, current_sha = ctx.remote_claim(issue)
    now = _iso(_utc_now())

    if args.confirm_removal:
        if current is None or not current_sha:
            raise CommandFailure(f"no claim lineage on #{issue}; nothing to confirm",
                                 OWNERSHIP_LOST)
        if not current.get("resource_reclaim"):
            raise CommandFailure(f"no pending execution-resource reclaim on #{issue}",
                                 INELIGIBLE)
        if current_sha != expected:
            raise CommandFailure(
                "confirm anchor mismatch: the claim ref moved since the reclaim "
                "authorization; re-read ownership and reconcile via ght",
                OWNERSHIP_LOST, remote_sha=current_sha, expected_sha=expected)
        if current.get("reclaim_tombstone"):
            pushed = _run(["git", "push", f"--force-with-lease={ref}:{current_sha}",
                           ctx.remote, f":{ref}"], check=False)
            if pushed.returncode or ctx.ls_remote(ref) is not None:
                raise CommandFailure(
                    "reclaim tombstone deletion was not confirmed; the removal fence "
                    "stays closed — reconcile via ght reclaim-execution-resource",
                    OWNERSHIP_LOST, ref=ref)
            print(json.dumps({"issue": issue, "mode": "confirm-removal",
                              "confirmed": True, "ref": ref, "tombstone_deleted": True}))
            return
        _cas_update(ctx, issue, current, current_sha,
                    lambda record: {key: value for key, value in record.items()
                                    if key != "resource_reclaim"})
        _final, final_sha = ctx.remote_claim(issue)
        print(json.dumps({"issue": issue, "mode": "confirm-removal", "confirmed": True,
                          "ref": ref, "tombstone_deleted": False,
                          "ref_sha": final_sha}))
        return

    if current is None:
        if expected:
            raise CommandFailure(
                "canonical ownership moved: the claim record read at the eligibility "
                f"read is gone from {ref}; the stale cleanup decision is voided",
                OWNERSHIP_LOST, expected_sha=expected)
        # True orphan: no claim lineage exists, so the marker rides a minimal
        # reclaim tombstone created under an empty expect-lease — a fresh
        # claim racing the tombstone create loses the CAS and fails closed.
        tombstone = {
            "v": 3, "task": issue,
            "claim_id": f"reclaim-{issue}-{uuid.uuid4().hex[:8]}",
            "github_principal": ctx.github_principal,
            "executor_id": ctx.executor_id,
            "claimed_at": now, "lease_expires_at": now,
            "execution_base": "", "status": "blocked", "branch": "",
            "heartbeat_at": now, "supersedes": None, "contract_digest": "",
            "candidate": None, "reclaim_tombstone": True,
            "resource_reclaim": {"v": 1, "authorized_at": now,
                                 "reason": "execution-resource cleanup (#147)"},
        }
        commit = ctx.claim_commit(tombstone)
        pushed = _run(["git", "push", f"--force-with-lease={ref}:", ctx.remote,
                       f"{commit}:{ref}"], check=False)
        if pushed.returncode:
            raise CommandFailure(
                f"reclaim tombstone create lost a race (a claim lineage appeared for "
                f"#{issue}); re-read ownership and reconcile via ght", RACE, ref=ref)
        print(json.dumps({"issue": issue, "mode": "authorize", "authorized": True,
                          "ref": ref, "marker_sha": commit, "claim_state": "NONE",
                          "tombstone": True}))
        return

    if current_sha != expected:
        raise CommandFailure(
            "canonical ownership moved since the authorizing eligibility read (claim "
            "ref head is not the expected claim_sha); the stale cleanup decision is voided",
            OWNERSHIP_LOST, remote_sha=current_sha, expected_sha=expected or None)
    _validate_reclaim_eligible(ctx, issue, current)
    if current.get("resource_reclaim"):
        # Idempotent re-authorization: the marker is still the current head,
        # so an interrupted cleanup re-run re-emits the anchor instead of
        # wedging on its own pending removal.
        print(json.dumps({"issue": issue, "mode": "authorize", "authorized": True,
                          "ref": ref, "marker_sha": current_sha,
                          "claim_state": claim_state(current),
                          "tombstone": bool(current.get("reclaim_tombstone")),
                          "idempotent": True}))
        return
    _cas_update(ctx, issue, current, current_sha,
                lambda record: {**record,
                                "resource_reclaim": {"v": 1, "authorized_at": now,
                                                     "claim_sha": expected}})
    marker_sha = ctx.ls_remote(ref)
    print(json.dumps({"issue": issue, "mode": "authorize", "authorized": True,
                      "ref": ref, "marker_sha": marker_sha,
                      "claim_state": claim_state(current), "tombstone": False}))


def _cmd_takeover(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    current, current_sha = ctx.remote_claim(args.issue)
    if not current or not current_sha:
        raise CommandFailure(f"no claim ref on #{args.issue}", RACE)
    issue = ctx.github.issue_view(args.issue)
    contract = _validate_issue_intake(ctx, args.issue, issue, require_ready=False)
    _assert_mode_matches_authority(contract, args.mode)
    if contract_digest(contract) != current.get("contract_digest"):
        raise CommandFailure("Issue Contract changed before takeover; stop and ask A to re-authorize",
                             INELIGIBLE)
    state = claim_state(current)
    if state == "TERMINAL":
        raise CommandFailure("terminal claim cannot be taken over; grant a fresh READY and claim a new attempt",
                             STALE)
    if _is_parked(ctx, current):
        raise CommandFailure(
            f"#{args.issue} is a parked delivered attempt (Candidate awaiting review); takeover does "
            "not apply — the owning executor resumes it with `ght acquire " + str(args.issue) + "`",
            INELIGIBLE)
    if state != "STALE" or _parse_iso(current["lease_expires_at"]) + timedelta(minutes=ctx.takeover_grace_minutes) > _utc_now():
        raise CommandFailure("lease is not expired past takeover grace", STALE)
    if not args.evidence.strip():
        raise CommandFailure("takeover requires durable evidence", STALE)

    # The stale attempt's execution lease is identity-proven residue of the
    # same lineage: replaceable only because it expired past the grace
    # window together with the claim lease.
    old_lease, old_lease_sha = _remote_execution_lease(ctx, current["claim_id"])
    if old_lease is not None:
        if not _lease_back_proof(old_lease, current):
            raise CommandFailure("execution lease residue does not back-prove this claim "
                                 "lineage; fail-closed — reconcile manually", OWNERSHIP_LOST,
                                 remote=old_lease)
        if _parse_iso(old_lease["lease_expires_at"]) + timedelta(minutes=ctx.takeover_grace_minutes) > _utc_now():
            raise CommandFailure("the attempt's execution lease has not expired past the "
                                 "stale-holder grace; stand down", RACE,
                                 lease_expires_at=old_lease["lease_expires_at"])

    now = _utc_now()
    # AC15/AC3: the durable attempt identity (claim_id, branch, lineage) is
    # preserved — takeover replaces the temporary execution HOLDER and its
    # fencing identity, never the attempt itself. A genuinely new attempt
    # belongs to BLOCK/REPLAN plus fresh A authorization.
    new_id = current["claim_id"]
    reservation, reservation_commit, _marker_prior_sha = _prepare_executor_reservation(
        ctx, args.issue, new_id, ignore_claim_id=new_id)
    # The stale predecessor's reservation slot holds this attempt's residue
    # under the OLD executor identity: exact-clean it (fail closed on
    # conflict) so the previous holder loses its capacity companion.
    old_reservation, old_reservation_sha = _remote_executor_reservation(
        ctx, current.get("executor_id"))
    # #89: under multi-active coordination the old executor's marker may
    # legitimately name another of their live attempts — leave it.
    _release_executor_marker(ctx, new_id, old_reservation, old_reservation_sha)

    def recheck() -> tuple[dict[str, Any] | None, str | None]:
        latest_contract = _validate_issue_intake(
            ctx, args.issue, ctx.github.issue_view(args.issue), require_ready=False)
        if contract_digest(latest_contract) != current.get("contract_digest"):
            raise CommandFailure("Issue Contract changed before takeover CAS; stand down", INELIGIBLE)
        latest, latest_sha = ctx.remote_claim(args.issue)
        if latest_sha != current_sha or not _same_record(latest, current):
            raise CommandFailure("claim changed before takeover CAS; stand down", OWNERSHIP_LOST)
        return latest, latest_sha

    recheck()
    takeover = {**current, "executor_id": ctx.executor_id,
                "github_principal": ctx.github_principal,
                "lease_expires_at": _iso(now + timedelta(minutes=ctx.lease_minutes)),
                "heartbeat_at": _iso(now),
                "taken_over_at": _iso(now),
                "takeover_evidence": args.evidence.strip()}
    commit = ctx.claim_commit(takeover, parent=current_sha)
    recheck()
    # Same-attempt recovery keeps the lineage where it lives (AC2): a stale
    # claim in the legacy namespace is recovered there, never moved.
    ref = ctx.claim_location(args.issue)
    # The recovered attempt keeps its lease ref (keyed by the unchanged
    # claim_id); the fencing identity and holder fields are replaced in the
    # same atomic push as the lineage append.
    new_lease = _build_lease_record(ctx, takeover)
    if old_lease is not None:
        new_lease["acquired_at"] = old_lease.get("acquired_at")
    new_lease_ref = _execution_lease_ref(ctx, takeover["claim_id"])
    new_lease_commit = ctx.claim_commit(new_lease, document="LEASE.json")
    refspecs = [f"{reservation_commit}:{_executor_reservation_ref(ctx)}",
                f"{commit}:{ref}", f"{new_lease_commit}:{new_lease_ref}"]
    leases = [f"{ref}:{current_sha}",
              f"{_executor_reservation_ref(ctx)}:{_marker_prior_sha}"]
    if old_lease is not None:
        leases.append(f"{new_lease_ref}:{old_lease_sha}")
    else:
        leases.append(f"{new_lease_ref}:")
    pushed = _atomic_push(ctx, refspecs, leases)
    if pushed.returncode and not _push_reconciled(
            ctx, commit, takeover, ref,
            reservation_expected=reservation,
            reservation_commit=reservation_commit):
        raise CommandFailure("takeover CAS rejected or ambiguous; stand down", OWNERSHIP_LOST,
                             remote=ctx.remote_claim(args.issue)[0])
    remote, remote_sha = ctx.remote_claim(args.issue)
    remote_reservation, reservation_sha = _remote_executor_reservation(ctx)
    remote_lease, new_lease_sha = _remote_execution_lease(ctx, takeover["claim_id"])
    if (not remote or remote_sha != commit or not _same_record(remote, takeover) or
            remote_reservation is None or reservation_sha != reservation_commit or
            not _same_record(remote_reservation, reservation) or
            remote_lease is None or new_lease_sha != new_lease_commit or
            not _same_record(remote_lease, new_lease)):
        raise CommandFailure("takeover CAS did not reconcile to the requested record", OWNERSHIP_LOST,
                             remote=remote, remote_sha=remote_sha)
    ctx.save_claim(args.issue, remote, remote_sha)
    _save_local_lease(ctx, args.issue, remote_lease, new_lease_sha)
    # Recovery of the same attempt: repair the READY mirror the crashed
    # predecessor may have left behind, fail-closed on exhaustion.
    mirror = ctx.github.consume_ready(args.issue, ctx.ready_label)
    if not mirror["consumed"]:
        raise CommandFailure(
            f"takeover claim {new_id} owns #{args.issue}, but READY label {ctx.ready_label!r} "
            f"could not be removed after {mirror['attempts']} attempt(s): {mirror.get('error')}. "
            "FAIL-CLOSED: run `ght ready-repair " + str(args.issue) + "` from the owning worker.",
            ERROR, ready_mirror=mirror)
    marker = f"<!-- ght:claim:{new_id} -->"
    try:
        ctx.github.comment(args.issue, marker + f"\n**TAKEOVER** by {ctx.executor_id} recovers "
                           f"the same attempt `{current['claim_id']}` (durable identity and "
                           f"branch preserved)\nevidence: {args.evidence.strip()}", marker)
    except MirrorError as exc:
        print(f"ght: WARNING — takeover comment failed: {exc}", file=sys.stderr)
    supervisor = _spawn_supervisor(ctx, args.issue)
    print(json.dumps({"issue": args.issue, "claim_id": new_id,
                      "attempt_identity_preserved": True,
                      "branch": takeover["branch"], "ref_sha": remote_sha,
                      "supervisor": supervisor, "ready_mirror": mirror,
                      "execution_lease": {"ref": _execution_lease_ref(ctx, new_id),
                                          "fencing_token": remote_lease.get("fencing_token"),
                                          "lease_expires_at": remote_lease.get("lease_expires_at")}}))


def _changed_paths(ctx: Context, claim: dict[str, Any]) -> list[str]:
    result = _run(["git", "diff", "--name-only", f"{claim['execution_base']}...HEAD"], check=False)
    if result.returncode:
        raise CommandFailure(result.stderr.strip() or "cannot inspect candidate diff", INELIGIBLE)
    return sorted({line.strip() for line in result.stdout.splitlines() if line.strip()})


def _candidate_scope(ctx: Context, claim: dict[str, Any], contract: dict[str, Any]) -> dict[str, Any]:
    """Classify the Issue-owned candidate delta against the Contract's
    forbidden scope (#104 AC1/AC2).

    The candidate diff (``execution_base...HEAD``) is computed exactly as
    before. When it touches a forbidden path, that path is attributable to
    accepted main — and only then — through the mechanical lineage proof:

    1. the remote's CURRENT accepted main (``refs/heads/<default_branch>``
       read live via ``git ls-remote``) is readable, and its exact object is
       present locally — a stale ``<remote>/<default_branch>`` tracking ref
       is never accepted as current-main attribution;
    2. the claim's ``execution_base`` is an ancestor of that exact current
       accepted-main object;
    3. the path's content in the Candidate tree is byte-identical to that
       object's tree (the Candidate introduced none of it);
    4. the path actually moved on accepted main since the execution_base
       (an attributed path main never moved would be an unprovable claim).

    Each unprovable step fails closed with its recovery diagnostic instead
    of ignoring the path; content the Candidate itself introduced (its tree
    differs from accepted main's) stays a strict forbidden violation. With
    no forbidden match in the delta no attribution is attempted, so the
    ordinary fresh-attempt path is unchanged.
    """

    paths = _changed_paths(ctx, claim)
    result = classify_paths(paths, contract.get("scope"))
    if result["pass"]:
        return result
    main_ref = f"refs/heads/{ctx.default_branch}"
    listed = _run(["git", "ls-remote", ctx.remote, main_ref], check=False)
    main_sha = ""
    if not listed.returncode:
        for line in listed.stdout.splitlines():
            if "\t" in line and line.split("\t", 1)[1] == main_ref:
                main_sha = line.split("\t", 1)[0].strip()
                break
    if not main_sha:
        raise CommandFailure(
            "the candidate delta touches forbidden scope, but the accepted-main lineage "
            f"cannot be proven: the remote's current accepted main ({ctx.remote} "
            f"{main_ref}) is not readable; attributing any path to accepted main would "
            "be guesswork — fail-closed (reconcile the branch onto a readable accepted "
            "main, or correct the forbidden content)", INELIGIBLE)
    if _run(["git", "cat-file", "-e", f"{main_sha}^{{commit}}"], check=False).returncode:
        raise CommandFailure(
            "the candidate delta touches forbidden scope, but the accepted-main lineage "
            f"cannot be proven: current accepted main {main_sha[:12]} is not present in "
            f"this checkout (the local {ctx.remote}/{ctx.default_branch} tracking ref is "
            "stale or its objects are missing) — fail-closed: fetch and reconcile the "
            "branch onto the current accepted main, then re-run", INELIGIBLE,
            main_sha=main_sha)
    if _run(["git", "merge-base", "--is-ancestor", claim["execution_base"], main_sha],
            check=False).returncode:
        raise CommandFailure(
            "the candidate delta touches forbidden scope, but the accepted-main lineage "
            f"cannot be proven: execution_base {claim['execution_base'][:12]} is not an "
            f"ancestor of accepted main {main_sha[:12]} — fail-closed (no path may be "
            "attributed to accepted main without a proven lineage)", INELIGIBLE)
    moved = _run(["git", "diff", "--name-only", claim["execution_base"], main_sha], check=False)
    if moved.returncode:
        raise CommandFailure(
            "the candidate delta touches forbidden scope, but the accepted-main lineage "
            f"cannot be proven: main movement since the execution_base is unreadable — "
            "fail-closed", INELIGIBLE)
    main_moved_paths = {line.strip() for line in moved.stdout.splitlines() if line.strip()}
    attributable: set[str] = set()
    for violation in result["violations"]:
        path = violation["path"]
        identical_to_main = _run(
            ["git", "diff", "--quiet", main_sha, "HEAD", "--", path], check=False).returncode == 0
        if not identical_to_main:
            continue  # Candidate-authored content: stays a strict violation.
        if path not in main_moved_paths:
            raise CommandFailure(
                f"unprovable accepted-main attribution for {path!r}: the Candidate tree "
                "equals accepted main, but accepted main never moved the path since the "
                "execution_base — fail-closed", INELIGIBLE)
        attributable.add(path)
    if not attributable:
        return result
    attributed = classify_paths(paths, contract.get("scope"),
                                main_attributable=attributable)
    attributed["main_lineage"] = {"ref": main_ref, "remote": ctx.remote,
                                  "sha": main_sha,
                                  "attributed_paths": sorted(attributable)}
    return attributed


def _meaningful_dirty(ctx: Context) -> str:
    result = _run(["git", "status", "--porcelain", "--untracked-files=all"], check=False)
    meaningful = []
    for line in result.stdout.splitlines():
        path = line[3:] if len(line) >= 4 else line
        if path.startswith(".ght/"):
            continue
        meaningful.append(line)
    return "\n".join(meaningful)


def _cmd_scope_check(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    claim, _ = _owned_active(ctx, args.issue)
    contract = _assert_contract_unchanged(ctx, args.issue, claim)
    result = _candidate_scope(ctx, claim, contract)
    print(json.dumps({"issue": args.issue, "execution_base": claim["execution_base"], **result}))
    if not result["pass"]:
        raise SystemExit(INELIGIBLE)


def _cmd_preserve(args: argparse.Namespace) -> None:
    ctx = Context(args.remote, args.repo)
    claim, ref_sha = _owned_active(ctx, args.issue)
    _fence_execution_lease(ctx, args.issue, claim)
    contract = _assert_contract_unchanged(ctx, args.issue, claim)
    if contract["authority"]["implementation"] != "allowed":
        raise CommandFailure(
            "investigation-only authority cannot preserve an implementation Candidate; "
            "release an investigation report instead", INELIGIBLE)
    branch = _run(["git", "branch", "--show-current"]).stdout.strip()
    if branch != claim["branch"]:
        raise CommandFailure(f"candidate must be preserved from Issue branch {claim['branch']!r}", INELIGIBLE)
    dirty = _meaningful_dirty(ctx)
    if dirty:
        raise CommandFailure(f"candidate worktree is dirty; commit before preserve: {dirty[:300]}", INELIGIBLE)
    scope = _candidate_scope(ctx, claim, contract)
    if not scope["pass"]:
        raise CommandFailure("candidate violates forbidden scope", INELIGIBLE, scope=scope)
    candidate_sha = _run(["git", "rev-parse", "HEAD"]).stdout.strip()
    branch_ref = ctx.branch_ref(claim)
    pushed = _run(["git", "push", ctx.remote, f"HEAD:{branch_ref}"], check=False)
    remote_sha = ctx.ls_remote(branch_ref)
    if remote_sha != candidate_sha:
        raise CommandFailure("remote candidate branch does not equal candidate HEAD", OWNERSHIP_LOST,
                             remote_sha=remote_sha, candidate_sha=candidate_sha)
    candidate = {"branch": claim["branch"], "sha": candidate_sha, "scope": scope,
                 "preserved_at": _iso(_utc_now())}
    updated = _cas_update(ctx, args.issue, claim, ref_sha,
                          lambda record: {**record, "candidate": candidate})
    print(json.dumps({"issue": args.issue, "candidate_sha": candidate_sha, "branch": claim["branch"],
                      "scope": scope, "push_reconciled": pushed.returncode != 0,
                      "claim_sha": ctx.ls_remote(f"{ctx.claims_prefix}{args.issue}"),
                      "status": updated["status"]}))


def _candidate_delivery_facts(ctx: Context, claim: dict[str, Any], contract: dict[str, Any]) -> dict[str, Any]:
    """Pre-merge delivery gate: the Candidate branch must still be live at
    its recorded SHA. Post-merge `complete` deliberately does not use this —
    the branch may have been deleted by delete_branch_on_merge."""
    if contract["authority"]["implementation"] != "allowed":
        raise CommandFailure("investigation-only authority cannot deliver an implementation Candidate; "
                             "release an investigation report instead", INELIGIBLE)
    candidate = claim.get("candidate") or {}
    if not candidate:
        raise CommandFailure("requires a remotely preserved candidate (ght preserve)", INELIGIBLE)
    if ctx.ls_remote(ctx.branch_ref({"branch": candidate["branch"]})) != candidate.get("sha"):
        raise CommandFailure("candidate is not preserved at its recorded remote SHA", OWNERSHIP_LOST)
    if not (candidate.get("scope") or {}).get("pass"):
        raise CommandFailure("candidate did not pass forbidden-scope check", INELIGIBLE)
    return candidate


def _reconcile_durable_delivery(ctx: Context, issue: int, remote: dict[str, Any]) -> dict[str, Any]:
    """Finish the capacity cleanup of an already-durable delivery (AC4).

    Only the attempt's own executor reconciles its delivery. The lease is
    released when this holder still owns it (token match) or when it is an
    identity-proven residue expired past grace; a lease live under a
    reacquired holder's fencing identity is not ours to release. The
    reservation is cleaned only once no live lease remains for the attempt.
    Returns the reconciliation report payload; the caller emits it together
    with the snapshot synchronization result (#136).
    """

    if (remote.get("executor_id") != ctx.executor_id or
            remote.get("github_principal") != ctx.github_principal):
        raise CommandFailure(
            f"the delivered attempt on #{issue} belongs to executor "
            f"{remote.get('executor_id')!r}; its delivery cleanup is not this caller's to "
            "reconcile", OWNERSHIP_LOST, remote_executor=remote.get("executor_id"))
    claim_id = remote["claim_id"]
    lease, lease_sha = _remote_execution_lease(ctx, claim_id)
    if lease is not None:
        if not _lease_back_proof(lease, remote):
            raise CommandFailure("execution lease does not back-prove this claim lineage; "
                                 "fail-closed", OWNERSHIP_LOST, remote=lease)
        local = _local_lease(ctx, issue) or {}
        expired_past_grace = (_parse_iso(lease["lease_expires_at"]) +
                              timedelta(minutes=ctx.takeover_grace_minutes)) <= _utc_now()
        if local.get("token") == lease.get("fencing_token"):
            _release_execution_lease(ctx, remote, require_holder=True)
        elif expired_past_grace:
            _release_execution_lease(ctx, remote, require_holder=False)
        else:
            return {"issue": issue, "claim_id": claim_id,
                    "execution_lease_released": False,
                    "note": "delivery already durable; live execution lease is "
                            "held under a newer fencing identity and was left "
                            "to its holder"}
    reservation, reservation_sha = _remote_executor_reservation(ctx, remote.get("executor_id"))
    _release_executor_marker(ctx, claim_id, reservation, reservation_sha)
    delivery = remote["delivery"]
    return {"issue": issue, "claim_id": claim_id, "pr": delivery.get("pr"),
            "candidate_sha": delivery.get("sha"), "status": remote.get("status"),
            "execution_lease_released": True,
            "review": "delivery already durable — remaining capacity cleanup "
                      "reconciled (AC4)"}


def _assert_durable_delivery_is_current(ctx: Context, remote: dict[str, Any],
                                        delivery: dict[str, Any]) -> None:
    """#104 AC3: bind the durable-delivery reconciliation to the CURRENT
    exact Candidate. A delivery whose recorded SHA no longer matches the
    preserved candidate branch head, or the executing checkout's HEAD, must
    never reconcile as "delivery already durable" — the moved state demands
    a NEW exact-SHA delivery, so the retry fails closed with that recovery
    path instead of stale-success."""
    sha = delivery.get("sha")
    candidate = remote.get("candidate") or {}
    branch_head = ctx.ls_remote(ctx.branch_ref({"branch": candidate.get("branch")}))
    if branch_head != sha:
        head_label = f"{str(branch_head)[:12]}" if branch_head else "<missing>"
        raise CommandFailure(
            f"the durable delivery binds Candidate {str(sha)[:12]}, but the preserved "
            f"candidate branch head is {head_label}; a moved head "
            "must not reconcile as 'delivery already durable' — fail-closed: run "
            "`ght scope-check` and `ght preserve`, then deliver the current exact Candidate",
            INELIGIBLE, delivery_sha=sha, branch_head=branch_head)
    head = _run(["git", "rev-parse", "HEAD"], check=False).stdout.strip()
    if head != sha:
        raise CommandFailure(
            f"the durable delivery binds Candidate {str(sha)[:12]}, but the current HEAD "
            f"is {head[:12] or '<unknown>'}; re-delivery must bind the current exact "
            "Candidate — fail-closed: run `ght scope-check` and `ght preserve`, then "
            "deliver the current exact Candidate",
            INELIGIBLE, delivery_sha=sha, head=head)


def _sync_candidate_snapshot(ctx: Context, *, issue: int, pr: int,
                             claim: dict[str, Any], candidate: dict[str, Any],
                             note: str, snapshot: str | None,
                             previous_delivery_claim: dict[str, Any] | None = None
                             ) -> bool | None:
    """Current Candidate Snapshot update (AC14/AC19), shared by the fresh
    delivery and the durable-delivery retry (#136): when B supplies the
    concise evidence file, delivery mechanically standardizes the PR body —
    re-delivery REPLACES the snapshot instead of appending round reports.
    The durable delivery record is the truth either way; a failed snapshot
    update is surfaced explicitly, never disguised as synced. ``None`` when
    no snapshot was supplied: absence of an update attempt must not read as
    "synced". ``previous_delivery_claim`` is the attempt record whose
    delivery identity drives the previous-REVIEWED-Candidate discovery — the
    record before this delivery replaced it; omitted when there is no prior
    Candidate at all (a first delivery, or the exact-Candidate repair, whose
    Candidate has no predecessor)."""

    if not snapshot:
        return None
    snapshot_file = Path(snapshot)
    if not snapshot_file.is_file():
        print(f"ght: WARNING — snapshot file not found: {snapshot}; the PR body "
              "is NOT updated and this delivery must not be treated as "
              "snapshot-synced (AC19)", file=sys.stderr)
        return False
    previous_reviewed = (_discover_previous_reviewed(ctx, previous_delivery_claim, pr)
                         if previous_delivery_claim else None)
    snapshot_body = _candidate_snapshot_text(
        issue=issue, pr=pr, claim=claim, candidate=candidate,
        previous_reviewed=previous_reviewed, note=note,
        detail=snapshot_file.read_text())
    synced = ctx.github.pr_edit_body(pr, snapshot_body)
    if not synced:
        print("ght: WARNING — PR snapshot update failed; the delivery is durable "
              "but the PR body is NOT the current snapshot (AC19 evidence)",
              file=sys.stderr)
    return synced


def _cmd_deliver(args: argparse.Namespace) -> None:
    """Hand the preserved Candidate to A for review. Not terminal.

    Ordinary review corrections continue the same task: after
    REQUEST_CHANGES, B reacquires a fresh execution lease (`ght acquire`),
    pushes corrections, re-preserves and re-delivers under the same ACTIVE
    claim. No fresh `ready` is involved.

    Once the delivery record is durable remote truth, the attempt's
    temporary execution capacity is released (AC4): the lease and the
    executor reservation are exact-identity cleaned while the attempt stays
    non-terminal — the parked condition is derived from durable facts, and
    no lifecycle state or label is created.

    Crash/retry reconciliation (AC4): when the EXACT delivery (same PR at
    the same preserved Candidate SHA) is already durable AND still binds the
    current preserved candidate branch head and HEAD exactly (#104 AC3),
    this invocation reconciles the remaining capacity cleanup without
    fencing or minting a new execution lease — a lost release response must
    never wedge the attempt, and a lease now live under a reacquired
    holder's identity is left to that holder. A moved head/preserved
    Candidate never stale-succeeds: it fails closed with the exact-SHA
    recovery path, or — when the Candidate was re-preserved past the durable
    delivery — falls through to record the NEW exact-SHA delivery.

    Snapshot repair (#136): the same exact retry, given --snapshot, then
    re-applies the PR Current Candidate Snapshot for that SAME exact
    Candidate — the whole observable delivery operation is idempotent, so a
    durable delivery whose snapshot update failed stays repairable without
    minting a new delivery identity.
    """

    ctx = Context(args.remote, args.repo)
    remote, _remote_sha = ctx.remote_claim(args.issue)
    delivery = (remote or {}).get("delivery") or {}
    if (_has_durable_delivery(remote) and delivery.get("pr") == args.pr and
            delivery.get("sha") == (remote.get("candidate") or {}).get("sha")):
        # #136: an exact retry of a still-current durable delivery stays
        # exact-SHA fenced, reconciles the outstanding capacity cleanup, and
        # — when --snapshot is supplied — re-applies the PR Current Candidate
        # Snapshot for the SAME exact Candidate. The repair re-renders from
        # durable truth: it never mints a new delivery record, claim, lease,
        # or review round.
        _assert_durable_delivery_is_current(ctx, remote, delivery)
        report = _reconcile_durable_delivery(ctx, args.issue, remote)
        snapshot_synced = _sync_candidate_snapshot(
            ctx, issue=args.issue, pr=args.pr, claim=remote,
            candidate=remote.get("candidate") or {}, note=(args.note or "")[:2000],
            snapshot=args.snapshot)
        report.update({"pr": delivery.get("pr"), "candidate_sha": delivery.get("sha"),
                       "snapshot_synced": snapshot_synced})
        print(json.dumps(report))
        return
    claim, ref_sha = _owned_active(ctx, args.issue)
    _fence_execution_lease(ctx, args.issue, claim)
    contract = _assert_contract_unchanged(ctx, args.issue, claim)
    candidate = _candidate_delivery_facts(ctx, claim, contract)
    pr = ctx.github.pr_view(args.pr)
    if pr is None:
        raise CommandFailure(f"PR #{args.pr} not found", INELIGIBLE)
    if pr.get("headRefOid") != candidate.get("sha"):
        raise CommandFailure("PR head does not equal the preserved Candidate SHA; "
                             "push the branch or re-preserve before delivering", INELIGIBLE,
                             pr_head=pr.get("headRefOid"), candidate_sha=candidate.get("sha"))
    note = (args.note or "")[:2000]
    delivery = {"pr": args.pr, "sha": candidate["sha"], "note": note,
                "delivered_at": _iso(_utc_now())}

    def apply_delivery(record: dict[str, Any]) -> dict[str, Any]:
        # Idempotent retry (AC4): a durable delivery of the same PR at the
        # same exact Candidate SHA is remote truth already — only the
        # capacity release can still be outstanding.
        prior_delivery = record.get("delivery") or {}
        if (_has_durable_delivery(record) and prior_delivery.get("pr") == delivery["pr"] and
                prior_delivery.get("sha") == delivery["sha"]):
            return record
        return {**record, "delivery": delivery}

    updated = _cas_update(ctx, args.issue, claim, ref_sha, apply_delivery)
    # Capacity release is idempotent from remote truth: an absent lease
    # means a prior release already landed (crash/retry path, AC4).
    _release_execution_lease(ctx, updated, require_holder=True)
    reservation, reservation_sha = _remote_executor_reservation(ctx)
    _release_executor_marker(ctx, updated["claim_id"], reservation, reservation_sha)
    marker = f"<!-- ght:deliver:{updated['claim_id']}:{candidate['sha']} -->"
    body = marker + (f"\n## Candidate ready for review\n- pr: #{args.pr}\n"
                     f"- candidate_sha: `{candidate['sha']}`\n"
                     f"- review: A reviews the exact SHA; ordinary REQUEST_CHANGES continues "
                     f"this task without a fresh `ready`\n- execution capacity released; "
                     f"resume with `ght acquire {args.issue}` after review findings\n"
                     f"- merge: NO — A review required\n{note}")
    try:
        ctx.github.comment(args.issue, body, marker)
    except MirrorError as exc:
        print(f"ght: WARNING — delivery comment failed: {exc}", file=sys.stderr)
    # Current Candidate Snapshot (AC14/AC19): when B supplies the concise
    # evidence file, delivery mechanically standardizes the PR body. The
    # delivery record above is the durable truth either way; a failed
    # snapshot update is surfaced explicitly, never disguised as synced.
    snapshot_synced = _sync_candidate_snapshot(
        ctx, issue=args.issue, pr=args.pr, claim=updated, candidate=candidate,
        note=note, snapshot=args.snapshot, previous_delivery_claim=claim)
    print(json.dumps({"issue": args.issue, "claim_id": updated["claim_id"], "pr": args.pr,
                      "candidate_sha": candidate["sha"], "status": updated["status"],
                      "execution_lease_released": True,
                      "snapshot_synced": snapshot_synced,
                      "review": "awaiting A — same task continues through ordinary review changes"}))


def _reconcile_issue_done(ctx: Context, issue: int, *, pr_number: int,
                          candidate_sha: str,
                          verdict: dict[str, Any] | None = None) -> dict[str, Any]:
    """Final mechanical reconciliation of the A-owned Issue-DONE decision the
    completed attempt already proves (#171).

    The close gains no DONE authority of its own (AC2): it executes ONLY as
    the mechanical consequence of the durable A acceptance that gated this
    very completion — the shared canonical exact-SHA predicate (native
    APPROVED review or structured ACCEPT comment bound to the exact
    Candidate SHA), on top of the merged-head identity and the terminal
    completion record every path re-proves before calling here. When the
    closure itself must decide (an unconverged retry), the acceptance is
    re-proven from the same durable surfaces — missing, unreadable, or
    contradictory evidence fails closed without touching the Issue (AC3).
    Successful convergence is reported only when the durable Issue proves
    CLOSED with state_reason completed: an already-closed Issue is never
    reopened or re-reasoned — converged exactly when its state_reason is
    already completed, and otherwise an A-owned lifecycle decision
    preserved untouched but reported non-converged (fail-closed; no
    provenance distinction, no second registry). A failed close mutation
    fails the command so the documented idempotent retry converges it; the
    attempt stays terminal ``delivered`` throughout.
    """

    if verdict is None:
        verdict = evaluate_exact_sha_acceptance(
            reviews=ctx.github.pr_reviews(pr_number),
            comments=ctx.github.pr_comments(pr_number),
            candidate_sha=candidate_sha)
        if verdict["unreadable"]:
            raise CommandFailure(
                f"issue closure cannot be evaluated: the review/acceptance surface of PR "
                f"#{pr_number} is unreadable; fail-closed", INELIGIBLE,
                unreadable=verdict["unreadable"])
        if not verdict["accepted"]:
            raise CommandFailure(
                f"issue closure refused: PR #{pr_number} carries no durable A acceptance bound "
                f"to the exact Candidate SHA {candidate_sha}; the completion record alone never "
                "closes an Issue (AC10/AC17/#171 fail-closed)", INELIGIBLE,
                approved_other_shas=verdict["approved_other_shas"])
    try:
        outcome = ctx.github.issue_close_completed(issue)
    except IntakeError as exc:
        raise CommandFailure(f"issue closure cannot be evaluated: {exc}; fail-closed",
                             INELIGIBLE) from exc
    if outcome.get("action") == "failed":
        if outcome.get("preserved"):
            raise CommandFailure(
                f"Issue closure did not converge: {outcome.get('error')}; the "
                f"attempt stays terminal `delivered` and A's lifecycle decision "
                "stays untouched — `ght complete` never re-reasons it, so a "
                "retry stays non-converged until A's lifecycle truth says "
                "completed (AC1/AC3)", ERROR)
        raise CommandFailure(
            f"Issue close failed: {outcome.get('error')}; the attempt stays terminal "
            f"`delivered` — re-run `ght complete {issue}` to converge the Issue close "
            "idempotently", ERROR)
    return outcome


def _cmd_complete(args: argparse.Namespace) -> None:
    """Executor-neutral post-merge mechanical reconciliation (AC10).

    Terminalization is decided exclusively from durable remote facts: the
    attempt's preserved Candidate + delivery record, the A acceptance
    outcome on the PR bound to the same exact Candidate SHA (the shared
    canonical predicate of AC17), the merged PR head identity, and the
    Contract/lineage/namespace truth. The caller needs neither the original
    executor identity, nor a local claim cache, worktree, live lease, or B
    session; any authenticated principal may reconcile. Original execution
    identity stays intact in the record; the reconciling actor is recorded
    as audit information only (``completed_by``).
    """

    ctx = Context(args.remote, args.repo)
    # Dual-read with the ambiguity guard: a lineage present in both
    # namespaces raises here (AC11 namespace ambiguity).
    claim, ref_sha = ctx.remote_claim(args.issue)
    if not claim or not ref_sha:
        raise CommandFailure(f"no claim lineage on #{args.issue}", INELIGIBLE)
    if claim.get("v") != 3:
        raise CommandFailure("claim record is not a v3 attempt; stand down", OWNERSHIP_LOST)
    pr_number = args.pr or (claim.get("delivery") or {}).get("pr")
    if claim.get("status") == "delivered":
        # Idempotent retry after an uncertain response: accept only when the
        # recorded completion matches the current durable PR truth exactly.
        completed = claim.get("completed") or {}
        if not completed:
            raise CommandFailure("attempt is terminal without a completion record; "
                                 "fail-closed — reconcile manually", OWNERSHIP_LOST)
        if pr_number and int(pr_number) != completed.get("pr"):
            raise CommandFailure("completion record binds a different PR; fail-closed",
                                 OWNERSHIP_LOST, completed=completed, requested=int(pr_number))
        pr = ctx.github.pr_view(int(completed.get("pr") or 0))
        if (not pr or pr.get("state") != "MERGED" or
                pr.get("headRefOid") != completed.get("candidate_sha")):
            raise CommandFailure("recorded completion does not match current durable PR "
                                 "truth; fail-closed", OWNERSHIP_LOST, completed=completed)
        # #171 convergence: an unconverged retry must still prove the SAME
        # authoritative acceptance before the mechanical Issue close runs;
        # an already-closed Issue converges as a no-op (see the helper).
        closure = _reconcile_issue_done(ctx, args.issue,
                                        pr_number=int(completed.get("pr") or 0),
                                        candidate_sha=str(completed.get("candidate_sha") or ""))
        _print_complete(args.issue, claim, completed, pr, closure=closure)
        return
    if claim.get("status") != "active":
        raise CommandFailure(f"attempt on #{args.issue} is terminal ({claim.get('status')}); "
                             "only a non-terminal delivered attempt can complete", INELIGIBLE)
    contract = _assert_contract_unchanged(ctx, args.issue, claim)
    # Post-merge completion relies on durable facts only: the preserved
    # Candidate SHA recorded in the claim and the merged PR's head identity.
    # delete_branch_on_merge may legitimately have removed the Candidate
    # branch, so its continued existence is NOT a completion requirement —
    # exact Candidate identity is enforced against the merged PR instead.
    if contract["authority"]["implementation"] != "allowed":
        raise CommandFailure("investigation-only authority cannot complete an implementation Candidate",
                             INELIGIBLE)
    candidate = claim.get("candidate") or {}
    if not candidate:
        raise CommandFailure("complete requires a preserved candidate (ght preserve)", INELIGIBLE)
    if not (candidate.get("scope") or {}).get("pass"):
        raise CommandFailure("candidate did not pass forbidden-scope check", INELIGIBLE)
    delivery = claim.get("delivery") or {}
    if not delivery.get("pr"):
        raise CommandFailure("complete requires a delivered Candidate PR (ght deliver)", INELIGIBLE)
    # The durable delivery must bind the EXACT Candidate being completed
    # (AC10/AC11): a corrected Candidate that was re-preserved but never
    # re-delivered has no durable delivery of its own and must not
    # terminalize on an older delivery record.
    if delivery.get("sha") != candidate["sha"]:
        raise CommandFailure(
            "the durable delivery binds Candidate "
            f"{str(delivery.get('sha'))[:12]}, not the preserved Candidate SHA "
            f"{candidate['sha']}; the exact Candidate was never durably delivered — "
            "fail-closed (re-run `ght deliver` for the corrected Candidate)", INELIGIBLE,
            delivery_sha=delivery.get("sha"), candidate_sha=candidate["sha"])
    pr_number = int(delivery["pr"])
    if args.pr and int(args.pr) != pr_number:
        raise CommandFailure("--pr does not match the durable delivery record; fail-closed",
                             INELIGIBLE, delivery_pr=pr_number, requested=int(args.pr))
    pr = ctx.github.pr_view(pr_number)
    if not pr or pr.get("state") != "MERGED":
        raise CommandFailure(f"PR #{pr_number} is not merged; A's merge is the acceptance "
                             "decision, so the attempt stays non-terminal until then", INELIGIBLE)
    if pr.get("headRefOid") != candidate.get("sha"):
        raise CommandFailure("merged PR head does not equal the preserved Candidate SHA",
                             OWNERSHIP_LOST, pr_head=pr.get("headRefOid"),
                             candidate_sha=candidate.get("sha"))
    # Durable exact-SHA A acceptance (AC10/AC17): one shared mechanical
    # predicate for the merged barrier, completion, and reconciliation —
    # native exact-SHA APPROVED review, or the canonical structured ACCEPT
    # comment; wrong-SHA, chat/Issue-only, ambiguous, or unreadable evidence
    # all fail closed.
    verdict = evaluate_exact_sha_acceptance(
        reviews=ctx.github.pr_reviews(pr_number),
        comments=ctx.github.pr_comments(pr_number),
        candidate_sha=candidate["sha"])
    if verdict["unreadable"]:
        raise CommandFailure(
            f"completion cannot be evaluated: the review/acceptance surface of PR "
            f"#{pr_number} is unreadable; fail-closed", INELIGIBLE, unreadable=verdict["unreadable"])
    if not verdict["accepted"]:
        raise CommandFailure(
            f"PR #{pr_number} carries no durable A acceptance bound to the exact Candidate "
            f"SHA {candidate['sha']}; post-merge reconciliation requires it (AC10/AC17)",
            INELIGIBLE, approved_other_shas=verdict["approved_other_shas"])
    # Live-capacity residue (AC18): only an identity-proven lease of THIS
    # attempt is cleaned; anything that cannot be proven to belong here
    # blocks completion.
    lease, lease_sha = _remote_execution_lease(ctx, claim["claim_id"])
    if lease is not None:
        if not _lease_back_proof(lease, claim):
            raise CommandFailure("conflicting live execution lease does not back-prove this "
                                 "claim lineage; cannot safely reconcile", OWNERSHIP_LOST,
                                 remote=lease)
        _release_execution_lease(ctx, claim, require_holder=False)
    # Live-capacity residue at the ORIGINAL executor's reservation slot
    # (AC10/AC11/AC18): the location derives from the attempt's historical
    # executor identity, not the reconciling caller's. While this attempt's
    # capacity lifecycle is incomplete (its lease still exists), anything
    # other than this attempt's own reservation at that slot is conflicting
    # residue and blocks completion; once the capacity is released, a later
    # execution may legitimately have recycled the slot.
    had_lease = lease is not None
    reservation, reservation_sha = _remote_executor_reservation(
        ctx, claim.get("executor_id"))
    # #89: a foreign marker here is just a sibling attempt's audit state.
    _release_executor_marker(ctx, claim["claim_id"], reservation, reservation_sha)
    merge_commit = (pr.get("mergeCommit") or {}).get("oid") if isinstance(pr.get("mergeCommit"), dict) else pr.get("mergeCommit")
    updated = {**claim,
               "status": "delivered",
               "completed": {"pr": pr_number, "merge_commit": merge_commit,
                             "candidate_sha": candidate["sha"],
                             "completed_by": ctx.github_principal,
                             "completed_at": _iso(_utc_now())}}
    commit = ctx.claim_commit(updated, parent=ref_sha)
    ref = ctx.claim_location(args.issue)
    pushed = _run(["git", "push", f"--force-with-lease={ref}:{ref_sha}", ctx.remote,
                   f"{commit}:{ref}"], check=False)
    if pushed.returncode:
        remote, remote_sha = ctx.remote_claim(args.issue)
        if remote_sha != commit or not _same_record(remote, updated):
            raise CommandFailure("completion CAS rejected and remote truth does not prove "
                                 "our update; retry idempotently", OWNERSHIP_LOST, remote=remote)
    remote, remote_sha = ctx.remote_claim(args.issue)
    if not remote or remote.get("claim_id") != claim["claim_id"] or remote_sha != commit:
        raise CommandFailure("completion did not reconcile to the requested record", OWNERSHIP_LOST,
                             remote=remote)
    completed = remote["completed"]
    marker = f"<!-- ght:complete:{claim['claim_id']} -->"
    try:
        ctx.github.comment(args.issue, marker + (f"\n## Task complete\n- pr: #{pr_number}\n"
                           f"- candidate_sha: `{candidate['sha']}`\n"
                           f"- merge_commit: `{merge_commit}`\n"
                           f"- accepted by A review + merge; attempt terminal `delivered` "
                           f"(executor-neutral reconciliation)\n"
                           f"- reconciled_by: `{ctx.github_principal}`"), marker)
    except MirrorError as exc:
        print(f"ght: WARNING — completion comment failed: {exc}", file=sys.stderr)
    # #171: the mechanical Issue close is the final reconciliation step of
    # the A-owned acceptance proven above (exact-SHA verdict + merged head ==
    # Candidate + terminal completion, all durable). A close failure is NOT
    # swallowed: #166's "completion marker present but Issue OPEN" must never
    # again be a normal successful output — the documented retry converges.
    closure = _reconcile_issue_done(ctx, args.issue, pr_number=pr_number,
                                    candidate_sha=candidate["sha"], verdict=verdict)
    _print_complete(args.issue, remote, completed, pr, closure=closure)


def _print_complete(issue: int, claim: dict[str, Any], completed: dict[str, Any],
                    pr: dict[str, Any],
                    closure: dict[str, Any] | None = None) -> None:
    merge_commit = completed.get("merge_commit")
    payload = {"issue": issue, "status": claim["status"],
               "claim_id": claim["claim_id"], "pr": completed.get("pr"),
               "candidate_sha": completed.get("candidate_sha"),
               "merge_commit": merge_commit}
    if closure is not None:
        payload["issue_closure"] = closure
    print(json.dumps(payload))


def _cmd_release(args: argparse.Namespace) -> None:
    """Terminal investigation report or an explicit A stop/replan record.

    Contract-drift termination (#166 incident class): when the ONLY
    condition blocking the attempt is the Contract-digest drift (the
    claim's recorded digest ≠ the current canonical digest, which fences
    every continuation), the BLOCKED/INVESTIGATED disposition is the one
    legal exit — termination is not continuation. It ends the stale
    authority and grants none: a fresh claim still requires the normal
    fresh one-shot READY/Plan authorization and binds the CURRENT Contract
    digest. Ownership stays exact-identity validated, the disposition/note
    gates stay in force, and every other drift condition (foreign
    identity, foreign live fencing) stays fail-closed."""
    ctx = Context(args.remote, args.repo)
    already_terminal = False
    drift_exit = False
    try:
        claim, ref_sha = _owned_active(ctx, args.issue)
    except CommandFailure as failure:
        # A terminal CAS can succeed while comment publication loses its
        # response. Permit an exact, identity-checked retry so reporting is
        # recoverable without reopening a terminal claim.
        if failure.code != STALE:
            raise
        claim, ref_sha = ctx.remote_claim(args.issue)
        local = ctx.local_claim(args.issue)
        if _is_parked(ctx, claim):
            # A's explicit stop of a parked attempt: no live execution
            # capacity exists, so the durable-attempt identity check (exact
            # executor lineage) is what authorizes recording the decision.
            if (not local or claim.get("claim_id") != local.get("claim_id") or
                    claim.get("executor_id") != ctx.executor_id or
                    claim.get("github_principal") != ctx.github_principal):
                raise failure
        elif (not local or not claim or claim.get("status") not in ("investigated", "blocked") or
                claim.get("claim_id") != local.get("claim_id") or
                claim.get("executor_id") != ctx.executor_id or
                claim.get("github_principal") != ctx.github_principal):
            # The contract-drift termination exit for the deadlocked shape
            # (#166): a STALE, non-parked, non-terminal attempt owned by
            # this exact identity whose Contract digest drifted. `ght
            # acquire` is fenced under the stale authority, so the lease
            # can never be re-fenced — the identity checks above (executor
            # AND principal) remain what authorizes the termination.
            if not (claim and claim.get("status") == "active" and
                    claim.get("executor_id") == ctx.executor_id and
                    claim.get("github_principal") == ctx.github_principal and
                    _contract_drift(ctx, args.issue, claim) is not None):
                raise failure
            drift_exit = True
        else:
            already_terminal = True
    # Blocking/replan-terminalizing is a fenced mutation whenever the
    # attempt still holds live execution capacity (AC3/AC13): only the
    # canonical parked state — durable delivery AND no live execution
    # lease — proceeds on durable-attempt identity alone. A delivery record
    # by itself never releases capacity, so the delivery-present crash
    # window with a live lease still requires the current fencing identity.
    # The stale drift exit holds no live capacity by construction (the
    # claim liveness lease has expired; its identity-proven residue is
    # released by the terminal cleanup below) — requiring the unattainable
    # fence would recreate the deadlock it exits.
    if not already_terminal and not drift_exit and not _is_parked(ctx, claim):
        _fence_execution_lease(ctx, args.issue, claim)
    if args.status not in ("investigated", "blocked"):
        raise CommandFailure("release status must be investigated (investigation report) or "
                             "blocked (explicit A stop/replan); implementation Candidates use "
                             "ght deliver + ght complete", INELIGIBLE)
    drift = _contract_drift(ctx, args.issue, claim)
    if drift is not None:
        # Under drift the CURRENT canonical contract carries the authority
        # facts for the disposition rules below; the old digest would fail
        # the continuation fence that termination deliberately does not
        # re-enter.
        contract = drift
        drift_exit = True
    else:
        contract = _assert_contract_unchanged(ctx, args.issue, claim)
    candidate = claim.get("candidate") or {}
    if args.status == "investigated":
        if contract["authority"]["implementation"] == "allowed" and not args.note.strip():
            raise CommandFailure("investigated release of an implementation-allowed Issue "
                                 "requires a note explaining why no Candidate follows", INELIGIBLE)
    else:
        if not args.note.strip():
            raise CommandFailure("blocked release requires the recorded A stop/replan "
                                 "decision as --note", INELIGIBLE)
    note = (args.note or claim.get("note") or "")[:2000]
    if already_terminal:
        updated = claim
    else:
        updated = _cas_update(
            ctx, args.issue, claim, ref_sha,
            lambda record: {**record, "status": args.status, "note": note,
                            "lease_expires_at": _iso(_utc_now() + timedelta(minutes=1))})
    reservation, reservation_sha = _remote_executor_reservation(ctx)
    _release_executor_marker(ctx, updated.get("claim_id"), reservation, reservation_sha)
    # A terminal attempt holds no execution capacity (AC2): release the
    # identity-proven lease residue of this lineage.
    _release_execution_lease(ctx, updated, require_holder=False)
    marker = f"<!-- ght:report:{updated['claim_id']} -->"
    title = "INVESTIGATION REPORT" if args.status == "investigated" else "TASK STOPPED — A REPLAN"
    try:
        ctx.github.comment(args.issue, marker + f"\n## Executor report — {title}\n{note}", marker)
    except MirrorError as exc:
        print(f"ght: WARNING — report comment failed: {exc}", file=sys.stderr)
    print(json.dumps({"issue": args.issue, "status": updated["status"],
                      "claim_id": updated["claim_id"]}))


def _cmd_migrate_claims(args: argparse.Namespace) -> None:
    """Batch-migrate TERMINAL legacy claim refs into refs/ght (AC5).

    Only terminal refs are touched: ACTIVE/STALE claims are live or
    recoverable state and are skipped. An identical object already present
    in the current namespace is an interrupted migration and is reconciled
    by removing the legacy pointer; a divergent object is ambiguous and
    stops the command fail-closed. Expired legacy executor reservations are
    deleted under an exact lease; live ones are skipped.
    """

    ctx = Context(args.remote, args.repo)
    moved: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    if ctx.claims_prefix == ctx.legacy_claims_prefix:
        print(json.dumps({"moved": moved, "skipped": skipped, "ok": True}))
        return
    for ref, sha in sorted(ctx.claim_refs().items()):
        if not ref.startswith(ctx.legacy_claims_prefix):
            continue
        number = ref[len(ctx.legacy_claims_prefix):]
        if not number.isdigit():
            continue
        record, record_sha = ctx.remote_json(ref)
        if record is None or record_sha != sha:
            skipped.append({"ref": ref, "reason": "unreadable or moved"})
            continue
        state = claim_state(record)
        if state != "TERMINAL":
            skipped.append({"ref": ref, "issue": number, "state": state})
            continue
        # AC5: ambiguous mutations (pre-existing dual presence, divergent
        # objects, unconfirmed deletes) propagate as a failing command —
        # they are never caught into `skipped` and reported as success.
        _migrate_terminal_claim(ctx, number, ref, sha)
        moved.append({"legacy_ref": ref,
                      "new_ref": f"{ctx.claims_prefix}{number}", "sha": sha})
    # Reservations are checked in BOTH namespaces (AC6): the same lock key
    # present in both is ambiguous dual presence and fails closed; every
    # deletion verifies the exact expected identity and ref SHA under lease.
    # Genuinely expired single-namespace locks are removed so an orphan can
    # never linger as (or authorize) a second owner.
    reservation_refs: dict[str, list[tuple[str, str]]] = {}
    for prefix in (ctx.executor_claims_prefix, ctx.legacy_executor_claims_prefix):
        listing = _run(["git", "ls-remote", ctx.remote, f"{prefix}*"], check=False)
        for line in listing.stdout.splitlines():
            if "\t" not in line:
                continue
            sha, ref = line.split("\t", 1)
            if ref.startswith(prefix):
                reservation_refs.setdefault(ref[len(prefix):], []).append((ref, sha))
    for key, entries in sorted(reservation_refs.items()):
        if len(entries) > 1:
            raise CommandFailure(
                "AMBIGUOUS executor reservation: the same lock exists in both namespaces; "
                "fail-closed — neither copy may be auto-deleted", OWNERSHIP_LOST,
                refs=sorted(ref for ref, _sha in entries))
        ref, sha = entries[0]
        record, record_sha = ctx.remote_json(ref)
        if (record is None or record.get("kind") != "executor-reservation"
                or record_sha != sha):
            raise CommandFailure(
                f"reservation {ref} is unreadable or moved; fail-closed — no best-effort "
                "deletion", OWNERSHIP_LOST, ref=ref)
        if not _reservation_expired_past_grace(ctx, record):
            skipped.append({"ref": ref, "reason": "reservation lease still live"})
            continue
        _run(["git", "push", f"--force-with-lease={ref}:{sha}", ctx.remote, f":{ref}"],
             check=False)
        if ctx.ls_remote(ref) is not None:
            raise CommandFailure(
                f"reservation deletion unconfirmed for {ref}; the ref moved or was replaced "
                "under us — fail-closed, the replacement must not be deleted", OWNERSHIP_LOST,
                ref=ref)
        moved.append({"legacy_ref": ref, "deleted": True, "sha": sha})
    print(json.dumps({"moved": moved, "skipped": skipped, "ok": True}))


def _supervise_status_path(ctx: Context, issue: int) -> Path:
    return ctx.state / f"supervise-{issue}.json"


def _execution_host_start_token(pid: int) -> str:
    """Return an OS process-generation token without persisting host state."""

    if pid <= 0:
        raise OSError(errno.ESRCH, "invalid execution host pid")
    if sys.platform == "darwin":
        class ProcBsdInfo(ctypes.Structure):
            _fields_ = [
                ("pbi_flags", ctypes.c_uint32), ("pbi_status", ctypes.c_uint32),
                ("pbi_xstatus", ctypes.c_uint32), ("pbi_pid", ctypes.c_uint32),
                ("pbi_ppid", ctypes.c_uint32), ("pbi_uid", ctypes.c_uint32),
                ("pbi_gid", ctypes.c_uint32), ("pbi_ruid", ctypes.c_uint32),
                ("pbi_rgid", ctypes.c_uint32), ("pbi_svuid", ctypes.c_uint32),
                ("pbi_svgid", ctypes.c_uint32), ("rfu_1", ctypes.c_uint32),
                ("pbi_comm", ctypes.c_char * 16), ("pbi_name", ctypes.c_char * 32),
                ("pbi_nfiles", ctypes.c_uint32), ("pbi_pgid", ctypes.c_uint32),
                ("pbi_pjobc", ctypes.c_uint32), ("e_tdev", ctypes.c_uint32),
                ("e_tpgid", ctypes.c_uint32), ("pbi_nice", ctypes.c_int32),
                ("pbi_start_tvsec", ctypes.c_uint64),
                ("pbi_start_tvusec", ctypes.c_uint64),
            ]

        info = ProcBsdInfo()
        libproc = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
        proc_pidinfo = libproc.proc_pidinfo
        proc_pidinfo.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint64,
                                 ctypes.c_void_p, ctypes.c_int]
        proc_pidinfo.restype = ctypes.c_int
        size = ctypes.sizeof(info)
        received = proc_pidinfo(pid, 3, 0, ctypes.byref(info), size)
        if received != size or info.pbi_pid != pid:
            error = ctypes.get_errno() or errno.ESRCH
            raise OSError(error, os.strerror(error))
        return f"darwin:{info.pbi_start_tvsec}:{info.pbi_start_tvusec}"

    if sys.platform.startswith("linux"):
        stat = Path(f"/proc/{pid}/stat").read_text()
        fields = stat[stat.rfind(")") + 1:].split()
        # /proc stat starts this suffix at field 3 (state); starttime is 22.
        if len(fields) <= 19:
            raise OSError(errno.EIO, "execution host process identity is malformed")
        return f"linux:{fields[19]}"

    raise OSError(errno.ENOTSUP, "kernel process-exit watch is unsupported on this platform")


class _ExecutionHostLiveness:
    """Ephemeral kernel watch for the executor process that launched ght.

    This handle only decides whether the detached renewer may remain alive. It
    is not written to durable ownership state and never performs recovery.
    """

    def __init__(self, pid: int, start_token: str):
        self._backend = ""
        self._queue = None
        self._pidfd = None
        self._poller = None
        self._exited = False
        if _execution_host_start_token(pid) != start_token:
            raise OSError(errno.ESRCH, "execution host process identity changed")

        if sys.platform == "darwin" and hasattr(select, "kqueue"):
            self._queue = select.kqueue()
            try:
                event = select.kevent(
                    pid, filter=select.KQ_FILTER_PROC,
                    flags=select.KQ_EV_ADD | select.KQ_EV_ONESHOT,
                    fflags=select.KQ_NOTE_EXIT)
                self._queue.control([event], 0, 0)
                if _execution_host_start_token(pid) != start_token:
                    raise OSError(errno.ESRCH, "execution host process identity changed")
            except Exception:
                self.close()
                raise
            self._backend = "kqueue"
            return

        if sys.platform.startswith("linux") and hasattr(os, "pidfd_open"):
            self._pidfd = os.pidfd_open(pid, 0)
            try:
                if _execution_host_start_token(pid) != start_token:
                    raise OSError(errno.ESRCH, "execution host process identity changed")
            except Exception:
                self.close()
                raise
            self._poller = select.poll()
            self._poller.register(self._pidfd,
                                  select.POLLIN | select.POLLHUP | select.POLLERR)
            self._backend = "pidfd"
            return

        raise OSError(errno.ENOTSUP, "kernel process-exit watch is unsupported on this platform")

    def wait(self, timeout: float) -> bool:
        """Wait until the host exits or timeout elapses; return True on exit."""

        if self._exited:
            return True
        timeout = max(0.0, timeout)
        if self._backend == "kqueue":
            self._exited = bool(self._queue.control(None, 1, timeout))
            return self._exited
        if self._backend == "pidfd":
            timeout_ms = int(timeout * 1000)
            if timeout and timeout_ms == 0:
                timeout_ms = 1
            self._exited = bool(self._poller.poll(timeout_ms))
            return self._exited
        raise OSError(errno.EBADF, "execution host liveness watch is closed")

    def close(self) -> None:
        if self._queue is not None:
            self._queue.close()
            self._queue = None
        if self._pidfd is not None:
            os.close(self._pidfd)
            self._pidfd = None
        self._backend = ""


def _write_supervise_status(ctx: Context, issue: int, state: str, **extra: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {"issue": issue, "pid": os.getpid(), "state": state,
                               "updated_at": _iso(_utc_now())}
    payload.update(extra)
    path = _supervise_status_path(ctx, issue)
    path.write_text(json.dumps(payload, indent=2) + "\n")
    return payload


def _spawn_supervisor(ctx: Context, issue: int) -> str:
    """Start the detached lease-renewal supervisor for a claimed attempt.

    Lease health must not depend on the engineering agent remembering
    heartbeat commands (AC3/AC4 of the supervision Contract). If the
    supervisor cannot be established the attempt is NOT usable: the failure
    is recorded in the supervision status (which gates every subsequent
    mutation) and raised loudly. Re-establishing supervision via
    `ght supervise <issue>` is the reconciliation path; there is no
    manual-heartbeat fallback.
    """

    if os.environ.get("GHT_SPAWN_SUPERVISOR") == "0":
        return "disabled"
    if os.environ.get("GHT_SUPERVISE_FORCE_SPAWN_FAILURE") == "1":
        _write_supervise_status(ctx, issue, "spawn-failed",
                                error="supervisor spawn forced to fail (test injection)")
        raise CommandFailure(
            f"cannot establish automatic lease supervision for #{issue}; the attempt is "
            "blocked — renewals would not be guaranteed and manual heartbeat is not a valid "
            "substitute. Re-establish supervision with `ght supervise " + str(issue) + "`, "
            "or resume the same attempt with `ght acquire " + str(issue)
            + "` after expiry and grace.", OWNERSHIP_LOST)
    status_path = _supervise_status_path(ctx, issue)
    log_path = ctx.state / f"supervise-{issue}.log"
    host_pid = os.getppid()
    try:
        host_start_token = _execution_host_start_token(host_pid)
        probe = _ExecutionHostLiveness(host_pid, host_start_token)
        probe.close()
    except (OSError, ValueError) as exc:
        _write_supervise_status(ctx, issue, "spawn-failed", error=str(exc))
        raise CommandFailure(
            f"cannot bind automatic lease supervision for #{issue} to its execution host "
            f"({exc}); the attempt is blocked — renewals would not be guaranteed. "
            "Re-establish supervision with `ght supervise " + str(issue) + "`, or let the "
            "lease expire and resume the same attempt with `ght acquire " + str(issue)
            + "` after grace.", OWNERSHIP_LOST) from exc
    package_root = str(Path(__file__).resolve().parents[1])
    code = ("import sys; sys.path.insert(0, %r); "
            "from github_task.cli import main; main()" % package_root)
    env = {**os.environ,
           "GHT_SUPERVISE_HOST_PID": str(host_pid),
           "GHT_SUPERVISE_HOST_START_TOKEN": host_start_token}
    try:
        with open(log_path, "ab") as log:
            process = subprocess.Popen(
                [sys.executable, "-c", code, "--json", "supervise", str(issue)],
                stdout=log, stderr=log, stdin=subprocess.DEVNULL,
                start_new_session=True, cwd=str(ctx.root), env=env)
    except OSError as exc:
        _write_supervise_status(ctx, issue, "spawn-failed", error=str(exc))
        raise CommandFailure(
            f"cannot establish automatic lease supervision for #{issue} ({exc}); the attempt "
            "is blocked — renewals would not be guaranteed and manual heartbeat is not a valid "
            "substitute. Re-establish supervision with `ght supervise " + str(issue) + "`, "
            "or resume the same attempt with `ght acquire " + str(issue)
            + "` after expiry and grace.", OWNERSHIP_LOST) from exc
    status_path.write_text(json.dumps({"issue": issue, "pid": process.pid,
                                       "state": "spawned",
                                       "started_at": _iso(_utc_now())}, indent=2) + "\n")
    return "spawned"


def _cmd_supervise(args: argparse.Namespace) -> None:
    """Keep the ACTIVE attempt and its execution lease renewed.

    One cycle = re-read ownership from remote truth, CAS-renew the attempt
    liveness record AND the execution lease in one atomic push, sleep. A
    released lease on a parked (delivered, unreviewed) attempt ends
    supervision cleanly; a missing lease mid-attempt or an unconfirmable
    renewal fails loudly and non-zero: mutation authority is lost until
    ownership is reconciled (fail-closed).
    """

    ctx = Context(args.remote, args.repo)
    issue = args.issue
    host_pid_text = os.environ.get("GHT_SUPERVISE_HOST_PID")
    host_start_token = os.environ.get("GHT_SUPERVISE_HOST_START_TOKEN")
    try:
        host_pid = int(host_pid_text) if host_pid_text else os.getppid()
        if not host_start_token:
            host_start_token = _execution_host_start_token(host_pid)
        host_watch = _ExecutionHostLiveness(host_pid, host_start_token)
    except (OSError, ValueError) as exc:
        _write_supervise_status(ctx, issue, "failed",
                                error=f"execution host liveness could not be bound: {exc}")
        print(f"ght: SUPERVISION FAILED — execution host liveness could not be bound "
              f"({exc}); no lease renewal was attempted", file=sys.stderr)
        raise SystemExit(1)

    interval = float(os.environ.get("GHT_SUPERVISE_INTERVAL_SECONDS")
                     or max(ctx.lease_minutes * 60 / SUPERVISION_INTERVAL_LEASE_DIVISOR, 5))
    max_hours = float(os.environ.get("GHT_SUPERVISE_MAX_HOURS", "8"))
    deadline = _utc_now() + timedelta(hours=max_hours)
    _write_supervise_status(ctx, issue, "running")
    consecutive_failures = 0

    def check_execution_host_before_renewal() -> None:
        try:
            if host_watch.wait(0):
                raise CommandFailure("execution host exited; renewal authority is gone",
                                     OWNERSHIP_LOST)
        except OSError as exc:
            raise CommandFailure(f"execution host liveness could not be confirmed: {exc}",
                                 OWNERSHIP_LOST) from exc

    try:
        while _utc_now() < deadline:
            try:
                if host_watch.wait(interval):
                    _write_supervise_status(ctx, issue, "stopped",
                                            reason="execution host exited")
                    return
            except OSError as failure:
                _write_supervise_status(ctx, issue, "failed",
                                        error=f"execution host liveness watch failed: {failure}")
                print(f"ght: SUPERVISION FAILED — execution host liveness watch failed "
                      f"({failure}); all shared-state mutation must stop", file=sys.stderr)
                raise SystemExit(1)
            # Remote durable truth remains the ownership authority. Host
            # liveness only determines whether this process may keep renewing.
            try:
                claim, ref_sha = ctx.remote_claim(issue)
                if claim is None:
                    raise CommandFailure("claim ref disappeared; ownership is gone", OWNERSHIP_LOST)
                state = claim_state(claim)
                if state == "TERMINAL":
                    _write_supervise_status(ctx, issue, "stopped", reason="claim is TERMINAL")
                    return
                lease, _lease_sha = _remote_execution_lease(ctx, claim["claim_id"])
                if lease is None:
                    if _has_durable_delivery(claim):
                        _write_supervise_status(ctx, issue, "stopped",
                                                reason="execution lease released after delivery")
                        return
                    raise CommandFailure("execution lease is missing mid-attempt; live execution "
                                         "ownership is gone", OWNERSHIP_LOST)
                local = ctx.local_claim(issue)
                if (local is None or claim.get("claim_id") != local.get("claim_id")
                        or claim.get("executor_id") != ctx.executor_id
                        or claim.get("github_principal") != ctx.github_principal):
                    raise CommandFailure("ownership LOST: remote claim lineage differs from this worker",
                                         OWNERSHIP_LOST, remote=claim)
                if state != "ACTIVE":
                    raise CommandFailure(
                        f"claim is {state}; renewal was not maintained while supervised", STALE)
                updated = _renew_claim_and_lease(
                    ctx, issue, claim, ref_sha,
                    before_commit=check_execution_host_before_renewal)
            except CommandFailure as failure:
                consecutive_failures += 1
                _write_supervise_status(ctx, issue, "degraded" if consecutive_failures < 3 else "failed",
                                        error=str(failure),
                                        consecutive_failures=consecutive_failures)
                if consecutive_failures >= 3:
                    print(f"ght: SUPERVISION FAILED — lease renewal could not be confirmed against "
                          f"remote claim truth ({failure}); all shared-state mutation must stop "
                          f"until ownership is reconciled", file=sys.stderr)
                    raise SystemExit(1)
                continue
            consecutive_failures = 0
            _write_supervise_status(ctx, issue, "running", last_renewal=updated["heartbeat_at"],
                                    lease_expires_at=updated["lease_expires_at"])
        _write_supervise_status(ctx, issue, "stopped", reason="max supervision window reached")
    finally:
        host_watch.close()


# ------------------------------------------------------- B auto-discovery

DISCOVERY_EVIDENCE_MARKER = "ght:discovery-blocked"
RUNTIME_REF_PREFIX = "refs/ght/runtime/"


def _runtime_payload_digest(source: Path) -> str:
    """The content digest of a runtime tree, via the same deterministic
    serialization sync-runtime publishes — the identity an installed
    runtime compares itself against."""
    import io
    import zipfile
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(source.rglob("*")):
            if path.is_dir():
                continue
            rel = path.relative_to(source).as_posix()
            if rel.startswith(".git/") or "__pycache__" in rel:
                continue
            info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
            # Preserve the executable bit (scripts/ght.py, *.sh) so a
            # materialized capsule runs directly.
            info.external_attr = ((0o755 if path.stat().st_mode & 0o111
                                   else 0o644) << 16)
            archive.writestr(info, path.read_bytes())
    return hashlib.sha256(buffer.getvalue()).hexdigest()


def _runtime_capsule_payload(source: Path) -> tuple[bytes, dict[str, Any]]:
    """Deterministic runtime payload from the installed/stamped skill
    distribution: a fixed-order, fixed-timestamp zip of the tree plus the
    manifest binding release identity, exact source SHA, and the content
    digest. Identical content always yields the identical digest."""
    import io
    import zipfile
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(source.rglob("*")):
            if path.is_dir():
                continue
            rel = path.relative_to(source).as_posix()
            if rel.startswith(".git/") or "__pycache__" in rel:
                continue
            info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
            info.external_attr = ((0o755 if path.stat().st_mode & 0o111
                                   else 0o644) << 16)
            archive.writestr(info, path.read_bytes())
    payload = buffer.getvalue()
    release, source_sha = _carried_release(source)
    manifest = {"v": 1, "kind": "runtime-capsule", "product": "harry-dev",
                "release": release, "source_sha": source_sha,
                "digest": hashlib.sha256(payload).hexdigest()}
    return payload, manifest


def _verify_runtime_capsule(ctx: Context, ref: str, payload: bytes,
                            manifest: dict[str, Any]) -> bool:
    """Fetch an existing capsule ref and verify it is exact-identical to
    the identity being synced: the ref name is the payload digest, so the
    fetched payload must hash to that digest and the manifest must carry
    the same release/source_sha/digest identity. Any divergence is a
    corrupted or tampered capsule → fail closed (never overwritten). Read
    through a private temp ref — never the shared FETCH_HEAD."""
    fetched_payload, remote_identity = _fetch_capsule(ctx, ref)
    actual = hashlib.sha256(fetched_payload).hexdigest()
    if actual != manifest["digest"]:
        raise CommandFailure(
            f"runtime capsule {ref} content digest is {actual[:12]}, not the identity "
            f"{manifest['digest'][:12]}; same-identity content diverged — fail closed",
            OWNERSHIP_LOST)
    for key in ("release", "source_sha", "digest"):
        if remote_identity.get(key) != manifest[key]:
            raise CommandFailure(
                f"runtime capsule {ref} manifest identity diverged on {key!r}; "
                "fail closed — never overwrite an existing capsule", OWNERSHIP_LOST)
    return True


RUNTIME_PIN_REF = "refs/ght/runtime/current"


def _read_runtime_pin(ctx: Context) -> dict[str, Any] | None:
    """The project's activated runtime capsule identity (AC21 downstream
    model), read from the explicit project pin ref. None when no runtime
    has been activated — new attempts then carry no runtime binding at
    all, never a guessed one. Reads go through the canonical private
    temp-ref reader: never the shared FETCH_HEAD."""
    manifest, _sha = ctx.remote_json(RUNTIME_PIN_REF, document="MANIFEST.json")
    if not isinstance(manifest, dict):
        return None
    digest = manifest.get("digest")
    if not isinstance(digest, str) or not digest:
        return None
    return {"digest": digest, "release": manifest.get("release"),
            "source_sha": manifest.get("source_sha")}


def _fetch_capsule(ctx: Context, ref: str) -> tuple[bytes, dict[str, Any]]:
    """Private temp-ref read of a runtime capsule's payload and manifest —
    correctness never depends on the shared FETCH_HEAD, and the fetched
    object identity is pinned against the remote SHA for the whole read."""
    remote_sha = ctx.ls_remote(ref)
    if remote_sha is None:
        raise CommandFailure(
            f"runtime capsule {ref} is not published in the target repo; the attempt "
            "is bound to this runtime identity, so this is fail closed — materialize "
            "the bound distribution with `ght sync-runtime --source <bound dist>` or "
            "reconcile with A", OWNERSHIP_LOST)
    temp_ref = f"refs/ght-read/{os.getpid()}-{uuid.uuid4().hex[:12]}"
    try:
        fetched = _run(["git", "fetch", "-q", ctx.remote, f"+{ref}:{temp_ref}"],
                       check=False)
        if fetched.returncode:
            detail = fetched.stderr.strip() or "capsule fetch failed"
            raise CommandFailure(f"cannot fetch runtime capsule {ref}: {detail}",
                                 OWNERSHIP_LOST)
        fetched_sha = _run(["git", "rev-parse", temp_ref]).stdout.strip()
        if fetched_sha != remote_sha:
            raise CommandFailure(f"runtime capsule {ref} moved while being read",
                                 OWNERSHIP_LOST)
        payload = subprocess.run(
            ["git", "cat-file", "blob", f"{temp_ref}:runtime.zip"],
            capture_output=True, check=True).stdout
        manifest_text = _run(["git", "show", f"{temp_ref}:MANIFEST.json"]).stdout
        try:
            manifest = json.loads(manifest_text)
        except ValueError as exc:
            raise CommandFailure(f"runtime capsule {ref} manifest is not valid JSON: "
                                 f"{exc}", OWNERSHIP_LOST) from exc
        return payload, manifest
    finally:
        _run(["git", "update-ref", "-d", temp_ref], check=False)


def _cmd_activate_runtime(args: argparse.Namespace) -> None:
    """Explicit project runtime activation (AC21 downstream model): point
    the project pin ``refs/ght/runtime/current`` at an already-synced
    capsule digest. ``sync-runtime`` never activates; this is the one
    mechanical, verified step — new attempts bind the activated identity,
    existing ACTIVE attempts keep the binding they started under (recorded
    in their durable claim lineage), and rollback is simply activating the
    retained old digest again. Historical attempt bindings are never
    rewritten."""
    ctx = Context(args.remote, args.repo)
    digest = args.digest.strip()
    ref = f"{RUNTIME_REF_PREFIX}{digest}"
    remote_sha = ctx.ls_remote(ref)
    if remote_sha is None:
        raise CommandFailure(
            f"no runtime capsule {ref} exists in the target repo; activate only a "
            "capsule published by `ght sync-runtime`", INELIGIBLE)
    # Private temp ref: unrelated fetches cannot swap the verified object.
    temp_ref = f"refs/ght-read/{os.getpid()}-{uuid.uuid4().hex[:12]}"
    fetched_sha = ""
    try:
        fetched = _run(["git", "fetch", "-q", ctx.remote, f"+{ref}:{temp_ref}"],
                       check=False)
        if fetched.returncode:
            raise CommandFailure(f"cannot fetch runtime capsule {ref}; refusing to "
                                 "activate", OWNERSHIP_LOST)
        fetched_sha = _run(["git", "rev-parse", temp_ref]).stdout.strip()
        if fetched_sha != remote_sha:
            raise CommandFailure(f"runtime capsule {ref} moved while being read",
                                 OWNERSHIP_LOST)
        manifest_text = _run(["git", "show", f"{temp_ref}:MANIFEST.json"],
                             check=False)
        try:
            manifest = json.loads(manifest_text.stdout)
        except ValueError:
            manifest = {}
        if manifest_text.returncode or manifest.get("digest") != digest:
            raise CommandFailure(
                f"runtime capsule {ref} does not verify against its own manifest; "
                "refusing to activate", OWNERSHIP_LOST)
        current = ctx.ls_remote(RUNTIME_PIN_REF) or ""
        if getattr(args, "require_absent_pin", False) and current:
            # Bootstrap-only create-only activation (R1): a pin that raced
            # in during the bootstrap transition is foreign project state —
            # never moved, never overwritten.
            raise CommandFailure(
                "bootstrap fenced: a project runtime pin appeared during "
                f"bootstrap ({current[:12]}); activation is create-only — "
                "the foreign pin is untouched, fail closed", OWNERSHIP_LOST,
                existing_pin_sha=current)
        lease = f"--force-with-lease={RUNTIME_PIN_REF}:{current}"
        pushed = _run(["git", "push", lease, ctx.remote,
                       f"{fetched_sha}:{RUNTIME_PIN_REF}"], check=False)
        if pushed.returncode:
            # R3 finding 3: surface the server's rejection of the REAL
            # update — it is authoritative where the dry-run probe only
            # proved reachability; the failure stays fail-closed and
            # reconcilable.
            detail = pushed.stderr.strip() or pushed.stdout.strip() or "no detail"
            raise CommandFailure(
                "project runtime pin activation failed: the update was rejected "
                f"({detail}); re-run to verify against the moved pin", RACE)
    finally:
        _run(["git", "update-ref", "-d", temp_ref], check=False)
    print(json.dumps({"status": "activated", "digest": digest,
                      "ref": RUNTIME_PIN_REF, "release": manifest.get("release"),
                      "source_sha": manifest.get("source_sha"),
                      "note": "new attempts bind this identity; existing ACTIVE "
                              "attempts keep the binding they started under"}))


# R4-1: commands that CONTINUE an existing ACTIVE attempt must execute
# under the runtime identity that attempt is durably bound to.
CONTINUATION_COMMANDS = ("acquire", "verify", "scope-check", "preserve",
                         "deliver", "heartbeat")
RUNTIME_DISPATCH_ENV = "GHT_RUNTIME_DISPATCHED"


def _runtime_self_root() -> Path:
    """The installed/extracted runtime tree this process is running from.

    In production, the dispatched child runs from the extracted capsule tree.
    The parent sets GHT_RUNTIME_EXTRACTED_ROOT to point to that extracted tree.
    The test seam GHT_INSTALLED_SKILL_DIR still works for unit tests that simulate
    an upgraded installed runtime without actual extraction."""
    extracted = os.environ.get("GHT_RUNTIME_EXTRACTED_ROOT")
    if extracted:
        return Path(extracted)
    return Path(os.environ.get("GHT_INSTALLED_SKILL_DIR",
                               Path(__file__).resolve().parents[1]))


def _runtime_dispatch_guard(args: argparse.Namespace) -> None:
    """An attempt durably bound to runtime capsule A continues under A even
    when the locally installed runtime has moved to B (AC21 downstream
    model): for continuation commands, compare the running installation's
    content digest with the attempt's binding. Equal → proceed. Different →
    materialize the bound capsule from the target repo (private temp-ref
    read, payload digest + manifest verified) and re-dispatch the exact same
    argv to it; the dispatched runtime carries GHT_RUNTIME_DISPATCHED, but
    it must still prove it IS the bound runtime (self-digest check). Unbound
    (legacy) attempts and read-only commands are unaffected. A
    missing/divergent bound capsule fails closed with the mechanical recovery
    path instead of silently continuing under the new runtime."""
    if getattr(args, "command", None) not in CONTINUATION_COMMANDS:
        return
    dispatched_marker = os.environ.get(RUNTIME_DISPATCH_ENV)
    issue = getattr(args, "issue", None)
    if issue is None:
        return
    ctx = Context(args.remote, args.repo)
    claim, _sha = ctx.remote_claim(int(issue))
    bound_digest = ((claim or {}).get("runtime") or {}).get("digest")
    if not bound_digest:
        return  # unbound (legacy) attempt: no runtime identity to enforce

    self_digest = _runtime_payload_digest(_runtime_self_root())

    if dispatched_marker:
        # The marker indicates this process was dispatched by the guard after
        # verifying the capsule (payload SHA-256 + manifest). The child runs
        # from the extracted capsule tree and MUST mechanically prove its
        # actual executing identity equals the attempt-bound digest.
        if dispatched_marker != bound_digest:
            raise CommandFailure(
                f"dispatched runtime marker {dispatched_marker[:12]} does not match "
                f"the attempt-bound digest {bound_digest[:12]}; fail closed",
                OWNERSHIP_LOST)
        if self_digest != bound_digest:
            raise CommandFailure(
                f"dispatched runtime self-digest {self_digest[:12]} diverges from "
                f"the attempt-bound digest {bound_digest[:12]}; fail closed",
                OWNERSHIP_LOST)
        # Verified: this process IS the bound runtime.
        return

    # Not yet dispatched: check if we're already the bound runtime.
    if self_digest == bound_digest:
        return  # this process already IS the bound runtime

    # Dispatch required: materialize and verify the bound capsule, then
    # re-exec with the dispatch marker.
    ref = f"{RUNTIME_REF_PREFIX}{bound_digest}"
    payload, manifest = _fetch_capsule(ctx, ref)
    # Verify BOTH manifest digest AND payload SHA-256 before executing.
    actual_payload_digest = hashlib.sha256(payload).hexdigest()
    if actual_payload_digest != bound_digest:
        raise CommandFailure(
            f"the attempt-bound runtime capsule {ref} payload digest is "
            f"{actual_payload_digest[:12]}, not the bound identity "
            f"{bound_digest[:12]}; fail closed",
            OWNERSHIP_LOST)
    if manifest.get("digest") != bound_digest:
        raise CommandFailure(
            f"the attempt-bound runtime capsule {ref} manifest digest diverges; "
            "fail closed", OWNERSHIP_LOST)
    import tempfile
    import zipfile as _zipfile
    with tempfile.TemporaryDirectory() as tmp:
        capsule_zip = Path(tmp) / "runtime.zip"
        capsule_zip.write_bytes(payload)
        runtime_dir = Path(tmp) / "runtime"
        with _zipfile.ZipFile(capsule_zip) as archive:
            archive.extractall(runtime_dir)
        # zipfile on macOS doesn't preserve executable bit from external_attr;
        # restore permissions from zipinfo to ensure extracted tree matches
        # the original capsule digest when re-zipped for self-digest check.
        with _zipfile.ZipFile(capsule_zip) as archive:
            for info in archive.infolist():
                extracted = runtime_dir / info.filename
                if extracted.exists():
                    perm = (info.external_attr >> 16) & 0o777
                    if perm:
                        extracted.chmod(perm)
        glue = runtime_dir / "scripts" / "ght.py"
        if not glue.is_file():
            raise CommandFailure(
                "the bound runtime capsule does not carry the ght runtime; "
                "fail closed", OWNERSHIP_LOST)
        # Child runs from the extracted capsule; set GHT_RUNTIME_EXTRACTED_ROOT
        # so _runtime_self_root() returns the extracted tree. Do not inherit
        # GHT_INSTALLED_SKILL_DIR (test seam) from the parent.
        child_env = {k: v for k, v in os.environ.items()
                     if k != "GHT_INSTALLED_SKILL_DIR"}
        child_env[RUNTIME_DISPATCH_ENV] = bound_digest
        child_env["GHT_RUNTIME_EXTRACTED_ROOT"] = str(runtime_dir)
        print(f"ght: dispatching to the attempt-bound runtime capsule "
              f"{bound_digest[:12]} (installed runtime differs)", file=sys.stderr)
        result = subprocess.run([sys.executable, str(glue), *sys.argv[1:]],
                                env=child_env)
        raise SystemExit(result.returncode)


RELEASE_PUBLISH_USAGE = ("ght release-publish --version <vX.Y.Z> --target <exact-sha> "
                         "--notes-file <file> [--checkout <release-source-dir>]")


def _release_read_gh_json(ctx: Context, path: str) -> dict[str, Any] | None:
    """Read one GitHub API JSON document through the authenticated gh
    principal; 404 → None, any other failure → fail closed."""
    result = _run([gh_executable(), "api", f"repos/{ctx.github.slug()}/{path}"],
                  check=False)
    if result.returncode:
        if "Not Found" in (result.stderr + result.stdout):
            return None
        raise CommandFailure(f"GitHub API read failed for {path}: "
                             f"{result.stderr.strip() or result.stdout.strip()}",
                             OWNERSHIP_LOST)
    return json.loads(result.stdout)


def _release_tag_remote_sha(ctx: Context, version: str) -> str | None:
    """The remote tag's commit SHA (peeled for annotated tags), or None."""
    out = _run(["git", "ls-remote", ctx.remote, f"refs/tags/{version}",
                f"refs/tags/{version}^{{}}"], check=False).stdout.strip()
    shas = [line.split()[0] for line in out.splitlines() if line.strip()]
    return shas[-1] if shas else None


# #125 R4: the ONE designated formal-release governance-record path, named
# by repository policy (the #82-pattern contents write that is A's
# canonical remote trigger). It is never caller-selectable: no CLI flag,
# workflow input, or break-glass retry variant can nominate another
# repository path as release-cut governance or redefine this one. The
# governance-only exception's eligibility is granted mechanically by the
# designated record's own durable content — an ACTIVE formal-release
# record binding the exact frozen target (#125 R5) — see
# _governance_only_advance.
FORMAL_RELEASE_DISPATCH_PATH = "docs/releases/dispatch.yaml"

# The designated record's structural semantics (flat `key: value` head +
# one optional verbatim notes block) are owned by the workflow gate
# (scripts/formal_release_gate.py: NOTES_BEGIN/NOTES_END/ACTION_RELEASE/
# ACTION_NONE). The primitive's local predicate mirrors exactly those
# constants and that strict parse so both readers of the record fail
# closed identically; the gate remains the sole validator of the record's
# remaining authorization mirror (timing, statement, notes content,
# frozen CHANGELOG entry).
_DISPATCH_NOTES_BEGIN = "release-notes-begin:"
_DISPATCH_NOTES_END = "release-notes-end:"
_DISPATCH_ACTION_RELEASE = "release"
_DISPATCH_ACTION_NONE = "none"
_DISPATCH_AUTHORIZED_BY = "User"


def _parse_dispatch_record(text: str) -> dict[str, str] | None:
    """Strict parse of the designated formal-release dispatch record,
    mirroring formal_release_gate.parse_dispatch field-for-field: flat
    single-line `key: value` pairs, blank/comment lines ignored outside
    the notes block, then at most one verbatim
    `release-notes-begin:` ... `release-notes-end:` block. Any malformed
    line, empty key or value, duplicate key, stray block-end marker,
    duplicate block, or unclosed block is a fail-closed record (None).
    Returns the flat-head fields; the notes content is the gate's
    concern, not the primitive's."""
    fields: dict[str, str] = {}
    in_notes = False
    notes_closed = False
    notes_seen = False
    for raw in text.splitlines():
        stripped = raw.strip()
        if in_notes:
            if stripped == _DISPATCH_NOTES_END:
                in_notes = False
                notes_closed = True
            continue
        if not stripped or stripped.startswith("#"):
            continue
        if stripped == _DISPATCH_NOTES_BEGIN:
            if notes_closed or notes_seen:
                return None  # duplicate notes block — fail closed
            in_notes = True
            notes_seen = True
            continue
        if stripped == _DISPATCH_NOTES_END:
            return None  # block end without begin — fail closed
        if ":" not in stripped:
            return None  # not a `key: value` line — fail closed
        key, _, value = stripped.partition(":")
        key, value = key.strip(), value.strip()
        if not key or not value:
            return None  # empty key or value — fail closed
        if key in fields:
            return None  # duplicate key — fail closed
        fields[key] = value
    if in_notes:
        return None  # unclosed notes block — fail closed
    return fields


def _dispatch_record_binds_target(head: str, version: str, target: str) -> bool:
    """#125 R5: True iff the designated formal-release dispatch record in
    `head`'s tree is a mechanically valid ACTIVE formal-release record for
    exactly this publication — `action: release`, `authorized_by: User`,
    `version` equal to the `version` being published, and an exact,
    unique `target` binding to the frozen `target` — the mechanical
    eligibility grant for the governance-only release-cut exception. The
    grant comes from the canonical record's own content at the
    policy-designated path, never from a caller argument, and a merely
    matching `target:` line is never enough: a record that is absent,
    cleared (`action: none`), carries any other or missing `action`, a
    non-User `authorized_by`, a different `version`, or any
    malformed/duplicate/conflicting structure grants nothing, and the
    fresh-publication rule stays exact current-main equality. The
    record's remaining authorization mirror (timing, statement, notes,
    frozen CHANGELOG entry) stays with the workflow gate; this predicate
    proves only that the designated write is active release governance
    for THIS frozen decision, not a cleared or unrelated record."""
    shown = _run(["git", "show", f"{head}:{FORMAL_RELEASE_DISPATCH_PATH}"],
                 check=False)
    if shown.returncode:
        return False  # no durable record at the designated path — no grant
    fields = _parse_dispatch_record(shown.stdout)
    if fields is None:
        return False  # malformed/duplicate/conflicting record — no grant
    if fields.get("action") == _DISPATCH_ACTION_NONE:
        return False  # a cleared record is never a release instruction
    if (fields.get("action") != _DISPATCH_ACTION_RELEASE
            or fields.get("authorized_by") != _DISPATCH_AUTHORIZED_BY
            or fields.get("version") != version
            or fields.get("target") != target):
        return False
    return True


def _governance_only_advance(base: str, head: str, version: str) -> bool:
    """#125 R4: True iff `head` is strictly ahead of `base`, EVERY
    intervening commit is a single-parent commit that touches ONLY the
    designated formal-release dispatch record path, AND the designated
    record in `head`'s tree is a mechanically valid ACTIVE formal-release
    record (#125 R5: `action: release`, User-authorized, for exactly this
    `version`) durably binding the exact frozen `base` target — the
    canonical formal-release dispatch record itself mechanically grants
    the release-cut exception. A's dispatch-record trigger write lands
    after the exact-target freeze, so the current accepted main can
    legitimately sit designated-record writes ahead of the frozen target
    at publication time — those writes are release-cut governance
    evidence, never a new accepted source cut. No caller input
    participates: without an active, User-authorized, exactly-bound
    record at the designated path (any other path, or a cleared/
    malformed/duplicate/conflicting/differently-bound record) the
    fresh-publication rule is exact current-main equality, exactly as
    before this exception existed. Any merge commit, an unprovable range,
    or any other path in the range is material drift: the caller must
    fail closed and A must reconcile."""
    if base == head:
        return False
    if _run(["git", "merge-base", "--is-ancestor", base, head],
            check=False).returncode:
        return False
    commits = _run(["git", "rev-list", f"{base}..{head}"], check=False)
    if commits.returncode or not commits.stdout.strip():
        return False
    wanted = [FORMAL_RELEASE_DISPATCH_PATH]
    for commit in commits.stdout.split():
        parents = _run(["git", "rev-list", "--parents", "-n", "1", commit],
                       check=False)
        if parents.returncode or len(parents.stdout.split()) != 2:
            return False
        names = _run(["git", "diff-tree", "--no-commit-id", "--name-only",
                      "-r", commit], check=False)
        if names.returncode or sorted(
                filter(None, names.stdout.splitlines())) != wanted:
            return False
    return _dispatch_record_binds_target(head, version, base)


def _verify_release_runtime_publication(ctx: Context, digest: str, version: str,
                                        target: str) -> dict[str, Any]:
    """AC6 read-back: the activated pin, the capsule ref, and the capsule
    manifest must prove exactly the requested release identity — including
    remote object equality between `refs/ght/runtime/current` and
    `refs/ght/runtime/<digest>`. Any mismatch is fail closed — the
    operation is never reported DONE."""
    pin_sha = ctx.ls_remote(RUNTIME_PIN_REF)
    capsule_sha = ctx.ls_remote(f"{RUNTIME_REF_PREFIX}{digest}")
    if not pin_sha or not capsule_sha or pin_sha != capsule_sha:
        raise CommandFailure(
            f"runtime activation read-back mismatch: refs/ght/runtime/current "
            f"({(pin_sha or 'absent')[:12]}) and refs/ght/runtime/{digest[:12]} "
            f"({(capsule_sha or 'absent')[:12]}) are not the same published object; "
            "the release operation is not DONE", OWNERSHIP_LOST)
    pin = _read_runtime_pin(ctx)
    if not pin or pin.get("digest") != digest:
        raise CommandFailure(
            f"runtime activation read-back mismatch: the project pin is "
            f"{str((pin or {}).get('digest'))[:12]!r}, not the synced capsule "
            f"{digest[:12]!r}; the release operation is not DONE", OWNERSHIP_LOST)
    if pin.get("release") != version:
        raise CommandFailure(
            f"runtime activation read-back mismatch: capsule manifest release "
            f"{pin.get('release')!r} != requested {version!r}", OWNERSHIP_LOST)
    # #178 AC1: exact source equality — the capsule manifest must carry the
    # FULL frozen target SHA; a matching abbreviation is a mismatch, not a
    # proof (the v1.1.2 producer defect is never read back as released
    # truth for a new activation).
    if not pin.get("source_sha") or pin["source_sha"] != target:
        raise CommandFailure(
            f"runtime activation read-back mismatch: capsule manifest source_sha "
            f"{pin.get('source_sha')!r} is not the exact requested target "
            f"{target[:12]!r}", OWNERSHIP_LOST)
    return {"digest": digest, "release": pin.get("release"),
            "source_sha": pin.get("source_sha"), "capsule_ref_sha": capsule_sha,
            "pin_ref_sha": pin_sha}


def _validate_release_frozen_checkout(checkout: Path, version: str,
                                      target: str) -> None:
    """Producer proof that the packaging checkout IS the exact clean frozen
    target (review R3 finding 1): HEAD must be exactly the requested
    frozen ``--target`` SHA and the tree must be clean (no modified and no
    untracked files — untracked files inside the packaged tree would enter
    the distribution bytes). Matching the tag NAME is not enough: a
    parallel checkout can carry a same-named tag at a different commit.
    Runs BEFORE anything is stamped, synced, or uploaded — the packaged
    distribution must be the frozen target's bytes, fail closed."""

    head = _run(["git", "-C", str(checkout), "rev-parse", "HEAD^{commit}"],
                check=False)
    head_sha = head.stdout.strip() if not head.returncode else ""
    if head.returncode or head_sha != target:
        raise CommandFailure(
            f"release source checkout {str(checkout)!r} is not the exact frozen target: "
            f"HEAD is {head_sha[:12] or 'unreadable'!r}, the frozen target is "
            f"{target[:12]!r}; the packaged distribution must be built from the exact "
            "clean frozen target — fail closed, nothing was stamped or published",
            INELIGIBLE, checkout=str(checkout), checkout_head=head_sha,
            frozen_target=target)
    status = _run(["git", "-C", str(checkout), "status", "--porcelain"],
                  check=False)
    if status.returncode or status.stdout.strip():
        dirty = [line for line in status.stdout.splitlines() if line.strip()][:5]
        raise CommandFailure(
            f"release source checkout {str(checkout)!r} is not clean: the packaged "
            "distribution must be the exact clean frozen target, and local "
            f"modifications would enter the release bytes ({'; '.join(dirty)}...) — "
            "fail closed, nothing was stamped or published",
            INELIGIBLE, checkout=str(checkout), dirty_entries=dirty)


def _cmd_release_publish(args: argparse.Namespace) -> None:
    """A-facing canonical release publication surface (#108): execute the
    release operation under the corrected authority model —
    User release authorization -> A exact-target reconciliation ->
    target SHA, GitHub Release on that tag, stamped distribution, synced
    immutable runtime capsule, explicit runtime activation, full read-back.

    Authority boundary (AC7): User owns whether/when/which version; A owns
    post-authorization exact-target reconciliation, mechanical publication,
    and activation acceptance/read-back; B owns implementation HOW. This
    surface executes the frozen decision given on the command line and
    never chooses a version, target, release membership, or publication
    time itself.

    Every phase re-reads durable truth and is idempotent only on the exact
    equivalence fact (same tag → same SHA; same Release identity; same
    capsule digest). Any drift, collision, mismatch, or partial state that
    cannot be proven equivalent fails closed (AC2/AC3/AC4/AC6) and is safe
    to re-run after reconciliation — completed immutable facts are never
    rewritten (AC9 resume); this includes the downstream install asset
    (review R2 finding 4): an already-published asset is digest-verified in
    place and never re-uploaded or overwritten, a divergent one fails
    closed."""
    import io
    from contextlib import redirect_stdout

    version = (args.version or "").strip()
    target = (args.target or "").strip()
    if not _RELEASE_TAG.fullmatch(version):
        raise CommandFailure(f"--version must be a Harry Dev release tag "
                             f"(v<major>[.<minor>...]), got {version!r}", INELIGIBLE)
    if not target or not re.fullmatch(r"[0-9a-f]{7,40}", target):
        raise CommandFailure(f"--target must be an exact commit SHA, got {target!r}",
                             INELIGIBLE)
    notes_path = Path(args.notes_file) if args.notes_file else None
    if not notes_path or not notes_path.is_file():
        raise CommandFailure(f"release notes file not found: {args.notes_file!r} "
                             f"(--notes-file is required)", INELIGIBLE)
    notes = notes_path.read_text()

    ctx = Context(args.remote, args.repo)
    slug = ctx.github.slug()
    if not slug:
        raise CommandFailure("cannot identify the target repository from this "
                             "checkout", INELIGIBLE)

    # --- Phase 0/1: preflight + exact tag (AC2/AC3) — read existing
    # tag/Release identity BEFORE the freeze gate. A same-version tag at
    # the requested target is an already-frozen publication: it may RESUME
    # (finish stamp/sync/activate/read-back) even after accepted main has
    # advanced, and its immutable facts are never rewritten. A fresh
    # publication (no tag yet) requires current-main equality before the
    # first immutable write — with one #125 R4 exception: an advance
    # consisting solely of designated formal-release dispatch-record
    # writes (A's trigger) whose durable record binds the exact frozen
    # target never changes the release source cut, so the frozen target
    # is still published; a same-name tag at any other SHA is a collision
    # and fails closed.
    tag_sha = _release_tag_remote_sha(ctx, version)
    if tag_sha is not None and tag_sha != target:
        raise CommandFailure(
            f"tag collision: {version!r} already points at {tag_sha[:12]!r}, not the "
            f"requested target {target[:12]!r}; published version tags are immutable "
            "and are never force-moved", OWNERSHIP_LOST,
            tag=version, tag_sha=tag_sha, requested_target=target)
    existing_release = _release_read_gh_json(ctx, f"releases/tags/{version}")
    if existing_release is not None:
        if (existing_release.get("tag_name") != version
                or existing_release.get("draft") or existing_release.get("prerelease")):
            raise CommandFailure(
                f"Release identity mismatch for {version!r}: an existing Release "
                "carries a different identity (tag_name/draft/prerelease); fail "
                "closed — reconcile with A", OWNERSHIP_LOST)
    if tag_sha is None:
        current_main = ctx.protected_head()
        if current_main != target:
            # #125 R4/R5: the caller's frozen exact target stays the release
            # source cut. A designated formal-release dispatch-record write
            # (A's trigger) may sit between the frozen target and current
            # accepted main, and the exception is granted ONLY by the
            # designated record itself — at the policy-fixed path, an
            # ACTIVE formal-release record (`action: release`, User-
            # authorized, for exactly this version) durably binding this
            # exact target. No caller input participates (the
            # caller-selectable flag is gone), and ANY other intervening
            # content — another path, or a cleared/malformed/duplicate/
            # conflicting/non-User/differently bound record — is target
            # drift: fail closed, A reconciles, never auto-retarget.
            if not _governance_only_advance(target, current_main, version):
                raise CommandFailure(
                    f"target drift: requested target {target[:12]!r} is not the current "
                    f"accepted main {current_main[:12]!r}"
                    + (" and the intervening main advance is not a designated "
                       "formal-release dispatch record binding this exact target")
                    + "; accepted main moved — A must reconcile the release "
                    "decision (never auto-retarget a frozen release)",
                    INELIGIBLE, requested_target=target,
                    current_main=current_main)
        if _run(["git", "cat-file", "-e", f"{target}^{{commit}}"], check=False).returncode:
            fetched = _run(["git", "fetch", "-q", ctx.remote, target], check=False)
            if fetched.returncode or _run(["git", "cat-file", "-e",
                                           f"{target}^{{commit}}"], check=False).returncode:
                raise CommandFailure(f"requested target {target[:12]!r} is not a commit in "
                                     "the target repository", INELIGIBLE)
        tagged = _run(["git", "tag", version, target], check=False)
        if tagged.returncode:
            raise CommandFailure(f"cannot create local tag {version!r}: "
                                 f"{tagged.stderr.strip()}", OWNERSHIP_LOST)
        pushed = _run(["git", "push", ctx.remote, f"refs/tags/{version}"], check=False)
        if pushed.returncode:
            raise CommandFailure(f"cannot publish tag {version!r}: "
                                 f"{pushed.stderr.strip()}", OWNERSHIP_LOST)
        tag_sha = _release_tag_remote_sha(ctx, version)
        tag_state = "created"
    else:
        tag_state = "idempotent"
    if tag_sha != target:
        raise CommandFailure(f"tag read-back mismatch for {version!r}", OWNERSHIP_LOST)

    # --- Phase 2: GitHub Release on the same tag (AC4).
    if existing_release is None:
        created = _run([gh_executable(), "api", "-X", "POST",
                        f"repos/{slug}/releases", "--input", "-"],
                       input_text=json.dumps({"tag_name": version, "name": version,
                                              "body": notes, "draft": False,
                                              "prerelease": False}), check=False)
        if created.returncode:
            raise CommandFailure(f"cannot create the GitHub Release for {version!r}: "
                                 f"{created.stderr.strip() or created.stdout.strip()}",
                                 OWNERSHIP_LOST)
        release_state = "created"
    else:
        release_state = "idempotent"
    release = _release_read_gh_json(ctx, f"releases/tags/{version}")
    if (not release or release.get("tag_name") != version
            or release.get("draft") or release.get("prerelease")):
        raise CommandFailure(f"Release read-back mismatch for {version!r}; the "
                             "release operation is not DONE", OWNERSHIP_LOST)

    # --- Phase 3: stamp the distribution from a source checkout that sits
    # exactly on the release tag, then sync the immutable capsule (AC5).
    # The capsule is the `skills/github-task` distribution (attempt-bound
    # dispatch requires `scripts/ght.py` at the capsule root), while the
    # enclosing release checkout proves the requested release identity. The
    # tag is minted by Phase 1, so the default packaging source is a fresh
    # temporary clone checked out at that exact tag; an explicit --checkout
    # is the resume/pinned path and must itself sit on the tag. R3 finding
    # 1: BOTH paths are then proven to be the EXACT CLEAN frozen target
    # (HEAD == the requested SHA, tree clean) before anything is stamped,
    # synced, or uploaded.
    import shutil
    import tempfile
    temp_checkout = None
    if args.checkout:
        checkout = Path(args.checkout).resolve()
        if not checkout.is_dir():
            raise CommandFailure(f"release source checkout {str(checkout)!r} is not a "
                                 "directory", INELIGIBLE)
        describe = _run(["git", "-C", str(checkout), "describe", "--tags",
                         "--exact-match", "--match", "v*", "HEAD"], check=False)
        if describe.returncode or describe.stdout.strip() != version:
            found = describe.stdout.strip() if describe.returncode == 0 else None
            raise CommandFailure(
                f"release source checkout {str(checkout)!r} does not sit exactly on "
                f"{version!r}" + (f" (HEAD is exactly on {found!r})" if found else
                                  " (HEAD is not exactly on any v* tag)") +
                "; check out the release tag there, then re-run — completed tag/Release "
                "facts are never rewritten (resume)", INELIGIBLE,
                checkout=str(checkout), requested_release=version)
    else:
        temp_checkout = tempfile.mkdtemp(prefix="ght-release-src-")
        remote_url = _run(["git", "remote", "get-url", ctx.remote],
                          check=False).stdout.strip() or ctx.remote
        cloned = _run(["git", "clone", "-q", remote_url, temp_checkout], check=False)
        on_tag = _run(["git", "-C", temp_checkout, "checkout", "-q", version],
                      check=False) if not cloned.returncode else None
        if cloned.returncode or not on_tag or on_tag.returncode:
            detail = (cloned.stderr.strip() if cloned.returncode
                      else (on_tag.stderr.strip() if on_tag else "no checkout attempted"))
            shutil.rmtree(temp_checkout, ignore_errors=True)
            raise CommandFailure(f"cannot materialize a packaging checkout at tag "
                                 f"{version!r}; re-run to resume ({detail})",
                                 OWNERSHIP_LOST)
        checkout = Path(temp_checkout)
    # R3 finding 1 (producer): BOTH packaging paths must now prove the
    # checkout is the EXACT CLEAN frozen target BEFORE anything is stamped,
    # synced, or uploaded — the tag NAME matching above is not enough.
    _validate_release_frozen_checkout(checkout, version, target)
    distribution_root = checkout / "skills" / "github-task"
    if not (distribution_root / "scripts" / "ght.py").is_file():
        shutil.rmtree(temp_checkout, ignore_errors=True) if temp_checkout else None
        raise CommandFailure(
            f"the release checkout {str(checkout)!r} does not carry the github-task "
            "distribution at skills/github-task (scripts/ght.py missing); the runtime "
            "capsule must be the skill distribution, not the whole repository",
            INELIGIBLE)
    stamp_io, sync_io, activate_io = io.StringIO(), io.StringIO(), io.StringIO()
    try:
        with redirect_stdout(stamp_io):
            _cmd_stamp_distribution(argparse.Namespace(
                release=version, source=str(checkout), root=str(distribution_root),
                release_repo=slug, remote=args.remote, repo=args.repo))
        # R3 finding 1 (producer chain): the stamped manifest is read back
        # and must bind the frozen target BEFORE the capsule is synced —
        # frozen target → packaged bytes is a verified step, not an
        # assumption.
        stamped_release, stamped_sha = _carried_release(distribution_root)
        # #178 AC1: the read-back is EXACT source equality — a manifest that
        # merely carries a PREFIX of the frozen target (the v1.1.2
        # abbreviation form) is not a proven release identity.
        if (stamped_release != version or not stamped_sha
                or stamped_sha != target):
            raise CommandFailure(
                "the stamped distribution manifest does not exactly bind the frozen "
                f"target {target[:12]!r} (stamped release {stamped_release!r}, source "
                f"{stamped_sha!r}); the packaged bytes are not proven release bytes — "
                "fail closed, nothing was synced or uploaded", OWNERSHIP_LOST)
        with redirect_stdout(sync_io):
            _cmd_sync_runtime(argparse.Namespace(
                source=str(distribution_root), remote=args.remote, repo=args.repo))
        capsule = json.loads(sync_io.getvalue())
        digest = capsule["digest"]

        # --- Phase 3b: the canonical downstream install surface (#165 AC1).
        # The release asset IS the stamped distribution: the exact same
        # deterministic capsule payload bytes published at
        # refs/ght/runtime/<digest>, attached to the GitHub Release so a
        # downstream host installs the released Skill with download +
        # extract only — no Harry Dev source checkout, no release-tag
        # checkout, no consumer-side stamp-distribution — and `ght version`
        # mechanically proves the release/source identity from the
        # installed DISTRIBUTION.json alone.
        asset_name = f"github-task-{version}.zip"
        asset_payload, _asset_manifest = _runtime_capsule_payload(distribution_root)
        # R1: the uploaded bytes are PROVEN identical to the capsule digest
        # sync-runtime just published — never a silent re-serialization. The
        # capsule ref name IS the payload digest, so the asset's SHA-256
        # must equal it exactly; divergence fails the release closed before
        # anything is uploaded.
        asset_digest = hashlib.sha256(asset_payload).hexdigest()
        if asset_digest != digest:
            raise CommandFailure(
                f"the distribution asset serialization {asset_digest[:12]} does not "
                f"match the published runtime capsule digest {digest[:12]}; the "
                "install surface must be the capsule byte for byte — fail closed, "
                "nothing was uploaded", OWNERSHIP_LOST)
        # gh names the asset after the file's basename, so the payload is
        # staged under the canonical asset name inside a private temp dir.
        # The upload targets the SELECTED repository (R1): the same slug
        # every other phase of this release addresses.
        #
        # R2 finding 4: reconciliation across retries is NEVER destructive.
        # A Release that already carries the canonical asset is a completed
        # install surface: it is read back (``gh release download``) and
        # digest-verified IN PLACE — identical bytes ⇒ idempotent success,
        # no upload; divergent bytes ⇒ fail closed with an actionable
        # message, never an overwrite (removal is an explicit human/A
        # remediation). Only an ABSENT asset is uploaded, and without
        # ``--clobber``: if an asset races into existence, the upload fails
        # closed and a re-run reconciles it by digest.
        current_release = _release_read_gh_json(ctx, f"releases/tags/{version}")
        existing_names = {asset.get("name")
                          for asset in ((current_release or {}).get("assets") or [])}
        asset_state = "uploaded"
        if asset_name in existing_names:
            with tempfile.TemporaryDirectory(
                    prefix="ght-asset-verify-") as verify_dir:
                fetched = _run([gh_executable(), "--repo", slug, "release",
                                "download", version, "--pattern", asset_name,
                                "--dir", verify_dir], check=False)
                if fetched.returncode:
                    raise CommandFailure(
                        f"cannot verify the existing distribution asset "
                        f"{asset_name!r} on Release {version!r} "
                        f"({fetched.stderr.strip() or fetched.stdout.strip()}); "
                        "fail closed — a completed install surface is never "
                        "overwritten blindly; reconcile explicitly (human/A "
                        "decision) and re-run", OWNERSHIP_LOST)
                stored_digest = hashlib.sha256(
                    (Path(verify_dir) / asset_name).read_bytes()).hexdigest()
            if stored_digest != asset_digest:
                raise CommandFailure(
                    f"the existing distribution asset {asset_name!r} on Release "
                    f"{version!r} does not verify against the published capsule "
                    f"digest {asset_digest[:12]}; the release surface was never "
                    "overwritten — remove the divergent asset explicitly (human/A "
                    "remediation), then re-run to republish",
                    OWNERSHIP_LOST, existing_asset_digest=stored_digest,
                    expected_digest=asset_digest)
            asset_state = "reconciled"
        else:
            with tempfile.TemporaryDirectory(prefix="ght-asset-") as asset_stage:
                asset_path = Path(asset_stage) / asset_name
                asset_path.write_bytes(asset_payload)
                uploaded = _run([gh_executable(), "--repo", slug, "release",
                                 "upload", version, str(asset_path)], check=False)
            if uploaded.returncode:
                raise CommandFailure(
                    f"cannot publish the distribution asset {asset_name!r} on Release "
                    f"{version!r}: {uploaded.stderr.strip() or uploaded.stdout.strip()}; "
                    "the release never overwrites an existing asset (--clobber is "
                    "never used) — if an asset raced into existence, re-run to "
                    "reconcile it by digest", OWNERSHIP_LOST)
        published_release = _release_read_gh_json(ctx, f"releases/tags/{version}")
        asset_names = [asset.get("name") for asset in
                       (published_release or {}).get("assets", [])]
        if asset_name not in asset_names:
            raise CommandFailure(
                f"distribution asset read-back mismatch for {version!r}: "
                f"{asset_name!r} is not on the Release; the released Skill install "
                "surface is not DONE", OWNERSHIP_LOST, assets=asset_names)

        # --- Phase 4: explicit activation + full read-back (AC6).
        with redirect_stdout(activate_io):
            _cmd_activate_runtime(argparse.Namespace(
                digest=digest, remote=args.remote, repo=args.repo))
    finally:
        if temp_checkout:
            shutil.rmtree(temp_checkout, ignore_errors=True)
    pin = _verify_release_runtime_publication(ctx, digest, version, target)

    print(json.dumps({"ok": True, "issue": None, "version": version,
                      "target": target, "repo": slug, "tag": tag_state,
                      "release": release_state, "runtime": pin,
                      "distribution_asset": {"name": asset_name, "digest": digest,
                                             "state": asset_state},
                      "stamped_checkout": str(checkout)}))


def _cmd_sync_runtime(args: argparse.Namespace) -> None:
    """Mechanical bootstrap/sync of the immutable runtime capsule (AC21
    downstream model): serialize the installed, stamped github-task
    distribution into a content-addressed capsule published at
    ``refs/ght/runtime/<digest>`` in the TARGET repo, where the repo's own
    thin workflow fetches it. The capsule never enters the working tree,
    never vendors runtime source downstream, and is never overwritten:
    absent ref → CAS create; exact-identical → idempotent success;
    same-identity content divergence → fail closed. Syncing a second
    identity publishes it alongside the old one and changes nothing else —
    upgrading or rolling back the runtime is an explicit, reviewed pin
    change in the downstream workflow."""
    ctx = Context(args.remote, args.repo)
    source = Path(getattr(args, "source", None)
                  or os.environ.get("GHT_SYNC_SOURCE_DIR", "")
                  or Path(__file__).resolve().parents[1])
    if not source.is_dir():
        raise CommandFailure(f"runtime source {str(source)!r} is not a directory; "
                             "the installed distribution must be present", INELIGIBLE)
    release, source_sha = _carried_release(source)
    if not release:
        raise CommandFailure(
            "the installed distribution is not stamped with a Harry Dev release "
            "identity; sync-runtime bootstraps only from a stamped distribution",
            INELIGIBLE)
    payload, manifest = _runtime_capsule_payload(source)
    digest = manifest["digest"]
    ref = f"{RUNTIME_REF_PREFIX}{digest}"
    existing = _run(["git", "ls-remote", ctx.remote, ref], check=False).stdout.strip()
    if existing:
        _verify_runtime_capsule(ctx, ref, payload, manifest)
        status = "idempotent"
    else:
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            payload_file = Path(tmp) / "runtime.zip"
            payload_file.write_bytes(payload)
            manifest_file = Path(tmp) / "MANIFEST.json"
            manifest_file.write_text(json.dumps(manifest, sort_keys=True))
            payload_blob = _run(["git", "hash-object", "-w", str(payload_file)]
                                ).stdout.strip()
            manifest_blob = _run(["git", "hash-object", "-w", str(manifest_file)]
                                 ).stdout.strip()
        tree = _run(["git", "mktree"], input_text=(
            f"100644 blob {payload_blob}\truntime.zip\n"
            f"100644 blob {manifest_blob}\tMANIFEST.json\n")).stdout.strip()
        identity_env = {**os.environ,
                        "GIT_AUTHOR_NAME": "ght", "GIT_AUTHOR_EMAIL": "ght@harry-dev",
                        "GIT_COMMITTER_NAME": "ght", "GIT_COMMITTER_EMAIL": "ght@harry-dev"}
        commit = _run(["git", "commit-tree", tree, "-m",
                       f"ght: runtime capsule {digest[:12]} ({release})"],
                      env=identity_env).stdout.strip()
        # Create-only CAS: an empty expected lease refuses to overwrite any
        # capsule that raced into existence. R3 finding 3: the server's
        # rejection of the REAL update is authoritative (a passing dry-run
        # never proved update authorization) and is surfaced verbatim so
        # the failure stays actionable and reconcilable.
        pushed = _run(["git", "push", f"--force-with-lease={ref}:", ctx.remote,
                       f"{commit}:{ref}"], check=False)
        if pushed.returncode:
            detail = pushed.stderr.strip() or pushed.stdout.strip() or "no detail"
            raise CommandFailure(
                f"runtime capsule {ref} could not be created: the update was "
                f"rejected ({detail}); the server's rejection is authoritative "
                "for the real update and the capsule is never overwritten — "
                "resolve the rejection and re-run to verify exact identity",
                OWNERSHIP_LOST)
        status = "created"
    print(json.dumps({"status": status, "digest": digest, "ref": ref,
                      "release": release, "source_sha": source_sha,
                      "identity": "immutable; upgrade/rollback = explicit pin change "
                                  "in the downstream workflow"}))


def _discover_my_active_claims(ctx: Context) -> list[dict[str, Any]]:
    """This executor's non-terminal attempts, from remote truth only (AC4).

    Dual-read discovery with the canonical same-logical-claim ambiguity
    guard: an Issue whose lineage exists in BOTH namespaces fails closed
    exactly like `ght claim`/`verify` — discovery never auto-prefers a
    copy of an ambiguous ownership state.
    """
    by_number: dict[str, list[str]] = {}
    for ref in ctx.claim_refs():
        for prefix in (ctx.claims_prefix, ctx.legacy_claims_prefix):
            if ref.startswith(prefix):
                by_number.setdefault(ref[len(prefix):], []).append(ref)
                break
    claims: list[dict[str, Any]] = []
    for number, refs in sorted(by_number.items()):
        if len(refs) > 1:
            raise CommandFailure(
                f"AMBIGUOUS claim state: #{number} exists in both namespaces; "
                "zero-prompt discovery must not auto-prefer — fail closed until "
                "A reconciles", OWNERSHIP_LOST, refs=sorted(refs))
        record, _sha = ctx.remote_json(refs[0])
        owner = (record or {}).get("executor_id") or ""
        # #98 (AC5(d)): ownership lineage is dual — an attempt under this
        # executor_id but a different github_principal is NOT this
        # identity's lineage; discovery surfaces it as an explicit
        # dual-lineage diagnostic instead of an own continuation.
        owned = ((owner == ctx.executor_id
                  or owner.startswith(f"{ctx.executor_id}/orch-"))
                 and (record or {}).get("github_principal") == ctx.github_principal)
        if not (record and record.get("v") == 3 and owned):
            continue
        if record.get("status") == "active":
            # Durable attempt ownership survives an expired liveness lease.
            # The separate capacity classifier below decides whether this
            # identity may reacquire, must wait for grace, or is parked.
            claims.append(record)
    return sorted(claims, key=lambda claim: claim.get("task") or 0)


def _discover_foreign_lineage(ctx: Context, own_tasks: set) -> dict[str, list]:
    """#98 (AC3/AC5(d)): foreign-lineage parked attempts surfaced as
    explicit diagnostics — never folded into a silent 0-runnable answer,
    and never auto-taken-over.

    Ownership lineage is dual: an attempt is this identity's own only when
    BOTH executor_id and github_principal match. Within the foreign/
    mismatched set, "resumable" is the SAME durable predicate own attempts
    use (`_discover_resume_candidate`): durable Candidate delivery on an
    OPEN PR, no live execution lease, and an authoritative exact-SHA
    REQUEST_CHANGES — an unreadable verdict surface fails closed. Parked
    foreign deliveries without a current REQUEST_CHANGES, and
    principal-mismatched lineages, surface as ownership notes only.
    """

    resumable: list[dict[str, Any]] = []
    ownership: list[dict[str, Any]] = []
    for ref in ctx.claim_refs():
        for prefix in (ctx.claims_prefix, ctx.legacy_claims_prefix):
            if not ref.startswith(prefix):
                continue
            number_str = ref[len(prefix):]
            if not number_str.isdigit() or int(number_str) in own_tasks:
                break
            record, _sha = ctx.remote_json(ref)
            if not (record and record.get("v") == 3
                    and record.get("status") == "active"):
                break
            capacity = _execution_capacity(ctx, record)
            owner = (record.get("executor_id") or "")
            own_executor = (owner == ctx.executor_id
                            or owner.startswith(f"{ctx.executor_id}/orch-"))
            own_principal = record.get("github_principal") == ctx.github_principal
            if own_executor and own_principal:
                break  # own lineage — the own continuation path handles it
            principal = record.get("github_principal")
            if not own_principal:
                # Dual-lineage mismatch (executor, principal, or both):
                # this identity cannot acquire/resume the attempt; name the
                # mismatch and the canonical recovery, never auto-takeover.
                # Surfaced regardless of lease state — the lineage itself,
                # not scheduling, is what blocks this identity.
                ownership.append({
                    "issue": int(number_str),
                    "executor_id": owner,
                    "github_principal": principal,
                    "reason": (f"attempt on #{number_str} was started under "
                               f"github principal {principal!r}, not "
                               f"{ctx.github_principal!r}; the ownership "
                               "lineage is dual (executor_id AND "
                               "github_principal), so acquire/resume from "
                               "this identity is refused — resume from the "
                               "originating principal identity or reconcile "
                               "with A"),
                })
                break
            if not _is_parked(ctx, record):
                if capacity["state"] in ("absent", "expired_residue"):
                    ownership.append({
                        "issue": int(number_str),
                        "executor_id": owner,
                        "reason": (f"attempt on #{number_str} remains durably owned by "
                                   f"executor {owner!r}, while its execution capacity is "
                                   f"{capacity['state']}; lease expiry alone does not "
                                   "authorize `ght takeover` — takeover requires a stale "
                                   "claim plus durable evidence. The originating executor "
                                   "must use `ght acquire`, or A must reconcile ownership"),
                    })
                break  # a live attempt stays with its executing holder
            if _discover_resume_candidate(ctx, record) is not None:
                resumable.append({
                    "issue": int(number_str),
                    "executor_id": owner,
                    "reason": (f"attempt on #{number_str} carries an "
                               "authoritative exact-SHA REQUEST_CHANGES on "
                               f"PR #{(record.get('delivery') or {}).get('pr')} "
                               "with no live lease — a resumable correction "
                               f"owned by executor {owner!r}; the owning "
                               "executor resumes it with `ght acquire`, "
                               "cross-executor recovery is an evidence-backed "
                               "`ght takeover` — never auto-takeover"),
                })
            else:
                if (capacity["state"] == "expired_residue" and
                        not capacity["reacquirable"]):
                    reason = (f"attempt on #{number_str} is durably owned by executor "
                              f"{owner!r}; its execution lease expired but stale-holder "
                              f"grace remains until {capacity['recovery_after']}. The "
                              "originating executor may use `ght acquire` after grace; "
                              "this executor must not take over")
                else:
                    reason = (f"attempt on #{number_str} is parked (durable delivered "
                              f"Candidate, no live lease) owned by executor {owner!r} "
                              "with no current authoritative exact-SHA REQUEST_CHANGES — "
                              "not resumable; it awaits review, and recovery belongs to "
                              "the owning executor")
                ownership.append({
                    "issue": int(number_str),
                    "executor_id": owner,
                    "reason": reason,
                })
            break
    return {"resumable": sorted(resumable, key=lambda item: item["issue"]),
            "ownership": sorted(ownership, key=lambda item: item["issue"])}


def _discover_resume_candidate(ctx: Context, claim: dict[str, Any], *,
                              capacity: dict[str, Any] | None = None) -> dict[str, Any] | None:
    """Same-attempt continuation check for one ACTIVE attempt (AC4/AC7).

    Returns the durable claim when the attempt is resumable by this
    executor: durable Candidate delivery on an OPEN PR whose authoritative
    A outcome is an exact-SHA REQUEST_CHANGES, with no live execution
    lease (a fresh lease comes from the canonical `ght acquire`). Composed
    from the same durable predicates `ght acquire` and the orchestrator's
    resume eligibility run — never a second authorization model.
    """
    delivery = claim.get("delivery") or {}
    candidate = claim.get("candidate") or {}
    pr_number = delivery.get("pr")
    if not _has_durable_delivery(claim) or not pr_number:
        return None
    capacity = capacity or _execution_capacity(ctx, claim)
    if (capacity["state"] == "live" or
            (capacity["state"] == "expired_residue" and
             not capacity["reacquirable"])):
        return None
    pr = ctx.github.pr_view(int(pr_number))
    if not pr or pr.get("state") != "OPEN":
        return None
    blocking, unreadable = has_exact_sha_change_request(
        reviews=ctx.github.pr_reviews(int(pr_number)),
        comments=ctx.github.pr_comments(int(pr_number)),
        candidate_sha=delivery.get("sha") or candidate.get("sha"))
    if unreadable:
        # #98 (AC4): an unreadable verdict surface is fail-closed — it
        # must never degrade into "no REQUEST_CHANGES" or a no-work exit.
        raise CommandFailure(
            f"the review surface for PR #{pr_number} is unreadable "
            f"({', '.join(unreadable)}); discovery cannot classify the "
            "attempt's verdict and must not guess", OWNERSHIP_LOST)
    if not blocking:
        return None
    return claim


def _discover_direct_ready_eligible(ctx: Context, number: int) -> tuple[bool, str, str | None]:
    """Mechanical eligibility for auto-claiming one direct-ready Issue.

    Composed from the same claim-intake primitives `ght claim` enforces —
    open-Issue target with a parseable Contract, implementation authority,
    clean lineage/ownership state — minus anything that would consume the
    authorization. Read-only by construction.

    Returns ``(runnable, reason, claim_mode)``: ``claim_mode`` is
    ``"investigate"`` for a runnable investigation-only decision (#164) —
    the existing investigate-mode claim path is the admission, and the
    mode/authority binding at claim time still refuses implement mode —
    and ``None`` for an implementation claim or any non-runnable verdict.
    """
    try:
        issue_view = ctx.github.issue_view(number)
        contract = _validate_issue_intake(ctx, number, issue_view, require_ready=False)
    except (CommandFailure, IntakeError) as exc:
        return False, str(exc), None
    investigation_only = (contract.get("authority", {}).get("implementation")
                          != "allowed")
    # #164 R2 (AC3): the investigation mode is derived INSIDE the same
    # lineage/claim-intake gates an implementation start runs — never ahead
    # of them. `ctx.remote_claim` fail-closes on dual-namespace ambiguity
    # and unreadable/malformed claim truth for either mode, and the
    # ACTIVE/STALE/terminal classification below admits only a genuinely
    # eligible new start; emitting `mode: investigate` before these gates
    # would promise an admission the canonical claim refuses (a prior
    # ACTIVE/STALE/parked lineage or a terminal `investigated` result is
    # never a false-runnable investigation start).
    prior, _sha = ctx.remote_claim(number)
    if prior is None:
        if investigation_only:
            return True, (f"#{number} authority is investigation-only: run "
                          f"`ght claim {number} --mode investigate` "
                          "(the existing investigate-mode claim; implement "
                          "mode is refused)"), "investigate"
        return True, "", None
    # #164 R3 (AC3): the canonical pending-reclaim fence (#147) precedes
    # terminal classification in the claim intake — a normally re-startable
    # blocked lineage carrying a pending `resource_reclaim` marker (the
    # reclaim tombstone) fences EVERY new start until the removal confirms.
    # The same shared predicate gates discovery here, so no direct-ready
    # verdict (either mode) advertises a runnable start the canonical
    # `ght claim` would refuse. Read-only: discovery never mutates the
    # marker or grants new authority.
    if _pending_resource_reclaim(prior):
        return False, (f"#{number} has a pending execution-resource reclaim marker "
                       "(destructive worktree removal in flight at the cleanup "
                       "boundary); reconcile via `ght reclaim-execution-resource "
                       f"{number} --confirm-removal` before a new start"), None
    state = claim_state(prior)
    if state == "ACTIVE":
        return False, f"#{number} has an ACTIVE claim lineage", None
    if state == "STALE":
        return False, f"#{number} has a STALE claim; recovery is `ght takeover`", None
    if prior.get("status") not in ("delivered", "blocked", "failed"):
        return False, f"#{number} claim lineage is terminal ({prior.get('status')})", None
    if investigation_only:
        return True, (f"#{number} authority is investigation-only: run "
                      f"`ght claim {number} --mode investigate` "
                      "(the existing investigate-mode claim; implement "
                      "mode is refused)"), "investigate"
    return True, "", None


def _discover_first_entry_guidance(args: argparse.Namespace,
                                   failure: CommandFailure) -> None:
    """Entry ordering for the documented fresh-host first entry (review R3
    finding 2). Called ONLY when Context construction already failed
    gracefully (a CommandFailure — never a crash): the degraded-host
    runtime-namespace condition is then recognized with probe calls that
    degrade the same way, and an UNINITIALIZED (or unprovable) runtime
    routes into the supported-host bootstrap/preflight path — provisioning
    plus the ONE actionable User-owned blocker — instead of dying in
    ``gh api user`` before any guidance exists. A healthy invocation runs
    zero extra probes (the ordinary Context path is byte-identical, and
    the #93 one-batched-fetch contract and the freshness read-only gh
    surface are untouched), and an INITIALIZED runtime re-raises the
    original failure — every existing initialized-path semantic is
    preserved. Entry ordering ONLY."""

    git_ok = _run(["git", "--version"], check=False).returncode == 0
    runtime_refs: dict[str, str] | None = None
    if git_ok and _run(["git", "rev-parse", "--is-inside-work-tree"],
                       check=False).returncode == 0:
        listed = _run(["git", "ls-remote", args.remote, "refs/ght/runtime/*"],
                      check=False)
        if listed.returncode == 0:
            runtime_refs = {
                row[1]: row[0] for row in
                (line.split() for line in listed.stdout.splitlines()
                 if len(line.split()) == 2)}
    if runtime_refs:
        # Initialized runtime: the original failure IS the existing
        # behavior (e.g. the principal refusal) — nothing is rerouted.
        raise failure
    # First-entry routing: the runtime state is uninitialized (or cannot
    # be proven) while the identity context could not be established —
    # establish what the supported-host preflight establishes (gh
    # provisioning included) and hand over ONE actionable blocker list
    # plus the bootstrap entry.
    report = _host_preflight_report(args.remote, args.repo)
    state = ("the repository is not initialized for Harry Dev execution "
             "(no refs/ght/runtime/*)" if runtime_refs == {} else
             "the repository runtime state could not be proven from this "
             "checkout")
    detail = "; ".join(report["blockers"]) if report["blockers"] else \
        "no blockers remain"
    raise CommandFailure(
        f"first-entry bootstrap path: {state}, and the supported-host/auth "
        f"preflight does not pass yet: {detail}. Run `ght preflight` to "
        "re-check (it establishes the missing tooling user-space), complete "
        "the one User-owned step it names (authentication consent), then run "
        "`ght bootstrap` — it mechanically materializes the exact installed "
        "released distribution and returns the fresh discovery verdict in "
        "the same activation; it grants no Issue authority, so durable "
        "ready/Plan authorization still governs every start",
        INELIGIBLE, preflight=report, installed_identity=distribution_identity())


def _cmd_discover(args: argparse.Namespace, extra: dict[str, Any] | None = None,
                  ctx: Context | None = None) -> None:
    """B zero-prompt entrypoint (AC4/AC8): read-only durable-state
    discovery that selects the next canonical action — same-attempt
    continuation (exact-SHA REQUEST_CHANGES) first, then the current
    Execution Plan (orchestrator) or, absent a Plan, the complete
    independent direct-ready workset (a single eligible Issue routes to
    the canonical auto claim) — and otherwise stops safely (no-work,
    ambiguous authority, unreadable truth). Nothing is claimed, acquired,
    started, or mutated here: every durable predicate is composed from the
    same ght primitives the canonical commands run, and B follows the
    emitted decision through `ght acquire` / `ght orchestrate` /
    `ght claim`.

    ``extra`` (bootstrap surface, #165 AC5) attaches additional durable
    facts to the SAME emitted verdict document — it never changes the
    verdict schema or semantics. ``ctx`` lets the bootstrap surface share
    this invocation's identity/context.
    """
    if ctx is None:
        # R3 finding 2 (entry ordering): a Context that fails gracefully on
        # an UNINITIALIZED runtime is the fresh-host first entry — route
        # into the bootstrap/preflight path (provisioning + the one
        # actionable auth blocker) instead of dying before any guidance.
        # Healthy invocations run zero extra probes; initialized runtimes
        # keep the original failure unchanged.
        try:
            ctx = Context(args.remote, args.repo)
        except CommandFailure as failure:
            _discover_first_entry_guidance(args, failure)
    ctx = ctx or Context(args.remote, args.repo)
    decision: dict[str, Any] = {"action": "no_work", **(extra or {})}

    # Repo auto-detection (AC1): the checkout's own remote must resolve.
    slug = ctx.github.slug()
    if not slug:
        raise CommandFailure(
            "cannot identify the target repository from this checkout (no resolvable "
            "origin); provide the repo identity once, explicitly", INELIGIBLE)
    decision["repo"] = slug

    # #93 (AC2): ONE batched remote round-trip establishes this
    # invocation's read-only snapshot of the durable-truth namespaces;
    # every subsequent discovery predicate resolves against it locally
    # (same authority/safety semantics, deletions pruned, failure
    # fail-closed). Mutating commands never use the snapshot. The
    # snapshot is invocation-isolated (unique per-invocation namespace)
    # and deterministically cleaned up when the invocation ends, however
    # it ends.
    ctx.begin_remote_snapshot()
    try:
        _discover_from_snapshot(args, ctx, decision)
    finally:
        ctx.end_remote_snapshot()


def _discover_freshness_preflight(ctx: Context, decision: dict[str, Any]) -> bool:
    """#102 (AC1/AC2/AC3): the mechanical freshness preflight every
    discovery runs BEFORE compiling any resume/handoff/claim/stop/no_work
    verdict — the effective execution semantics (this process's own tree,
    content-digested by the same deterministic serialization sync-runtime
    publishes) must align with the repo's canonical activated distribution
    identity, the project runtime pin ``refs/ght/runtime/current`` read
    through this invocation's own snapshot. Reuses the existing Harry Dev
    distribution/runtime identity primitives — no second version system,
    update registry, or manifest authority, and accepted-main movement is
    never an input: the activated pin is the only canonical identity.

    Exactly three outcomes, mechanically distinguished:
      - canonical runtime not yet activated (pin ref absent) → fail closed
        with the canonical activation path;
      - canonical identity unreadable/ambiguous (pin present but its
        manifest unreadable or without a usable digest, the pinned capsule
        ref ``refs/ght/runtime/<digest>`` not published, or the pin and the
        capsule ref pointing at different objects) → fail closed for A
        reconciliation;
      - stale/different effective identity → emit the machine-readable
        ``refresh_required`` decision as the ONLY verdict (both identities
        plus the canonical local refresh/reload guidance) and return True —
        the durable frontier is never compiled.

    Returns False when the effective identity is current (caller proceeds).
    The preflight is strictly read-only: it never mutates Plan/ready/claim
    state, never moves ``refs/ght/runtime/current``, and never publishes a
    release (AC3/AC5(e))."""
    # Both canonical-identity ref SHAs are read remotely up front (through
    # this invocation's own snapshot when one is active — one batched fetch,
    # deletions pruned, so the two reads are one consistent point in time).
    pin_sha = ctx.ls_remote(RUNTIME_PIN_REF)
    try:
        pin = _read_runtime_pin(ctx)
    except CommandFailure as exc:
        raise CommandFailure(
            "the repo's canonical runtime identity proof is unreadable/ambiguous: "
            f"{exc}; discovery fails closed and must not compile a verdict — "
            f"reconcile the runtime pin {RUNTIME_PIN_REF} with A",
            OWNERSHIP_LOST) from exc
    if pin is None:
        if pin_sha is None:
            if not _remote_runtime_refs(ctx):
                # Provably uninitialized repository (#165): the ONE case
                # where B's intentional first launch is the mechanical
                # bootstrap root-of-trust for the installed released
                # identity — never a verdict compiled from unproven
                # identity, and never an A relay.
                raise CommandFailure(
                    "the repository is not initialized for Harry Dev execution: "
                    f"no {RUNTIME_PIN_REF} and no refs/ght/runtime/* exist. Run "
                    "`ght bootstrap` — it mechanically materializes the exact "
                    "installed released distribution (publish the capsule, "
                    "activate the identity, read it back) and returns the fresh "
                    "discovery verdict in the same activation; it grants no Issue "
                    "authority, so durable ready/Plan authorization still governs "
                    "every start. (A may also activate explicitly via "
                    "`ght sync-runtime` + `ght activate-runtime`.)",
                    OWNERSHIP_LOST)
            raise CommandFailure(
                "the repo's canonical runtime identity is not activated: "
                f"{RUNTIME_PIN_REF} is not published while other refs/ght/runtime/* "
                "refs exist — an ambiguous runtime namespace, so discovery cannot "
                "mechanically prove the effective execution semantics and must not "
                "compile a verdict from unproven identity — reconcile the runtime "
                "namespace with A", OWNERSHIP_LOST)
        manifest, _sha = ctx.remote_json(RUNTIME_PIN_REF, document="MANIFEST.json")
        raise CommandFailure(
            "the repo's canonical runtime identity proof is unreadable/ambiguous: "
            f"{RUNTIME_PIN_REF} exists but its manifest does not declare a usable "
            f"capsule digest (digest={manifest.get('digest')!r}); discovery fails "
            "closed and must not compile a verdict — reconcile the runtime pin "
            "with A", OWNERSHIP_LOST)
    # #102 R2 (canonical identity is a dual-ref proof): a readable pin
    # manifest alone is not canonical — a moved/tampered pin can carry a
    # perfectly readable MANIFEST. The declared capsule must be published at
    # its content-addressed ref AND the pin must point at exactly that
    # object; anything else is an ambiguous canonical identity → fail closed.
    digest_ref = f"{RUNTIME_REF_PREFIX}{pin['digest']}"
    digest_sha = ctx.ls_remote(digest_ref)
    if digest_sha is None:
        detail = (f"{digest_ref} is not published, so the pin declares a capsule "
                  "identity the repo cannot materialize (never synced, deleted, "
                  f"or a tampered pin); pin object is {str(pin_sha)[:12]}")
    elif pin_sha != digest_sha:
        detail = (f"{RUNTIME_PIN_REF} ({str(pin_sha)[:12]}) and {digest_ref} "
                  f"({digest_sha[:12]}) are different objects — a moved/tampered "
                  "pin, not a canonical activation")
    else:
        detail = None
    if detail is not None:
        raise CommandFailure(
            "the repo's canonical runtime identity proof is unreadable/ambiguous: "
            f"{detail}; discovery fails closed and must not compile a verdict — "
            "reconcile the runtime pin with A", OWNERSHIP_LOST)
    self_digest = _runtime_payload_digest(_runtime_self_root())
    if self_digest == pin.get("digest"):
        return False  # effective execution semantics are the activated identity
    decision.update({
        "action": "refresh_required",
        "reason": (
            f"the effective github-task Skill/distribution identity "
            f"{self_digest[:12]} is not the repo's activated runtime capsule "
            f"{str(pin.get('digest'))[:12]} (release {pin.get('release')!r}); "
            "discovery must not compile a verdict from stale semantics"),
        "effective_identity": {"digest": self_digest},
        "expected_identity": {"digest": pin.get("digest"),
                              "release": pin.get("release"),
                              "source_sha": pin.get("source_sha")},
        "refresh": [
            ("reload the local github-task Skill/distribution to the activated "
             "runtime identity (materialize the activated capsule "
             f"{RUNTIME_PIN_REF} -> refs/ght/runtime/<digest> from the target "
             "repo and run `ght discover` from it) — the durable frontier is "
             "then recompiled with no change to Issue lifecycle, authorization, "
             "claim/branch/PR lineage, or running executors"),
            ("never resolve freshness by publishing or activating the stale "
             "local tree — `ght sync-runtime` / `ght activate-runtime` are "
             "release/activation actions, not a B freshness action"),
        ],
    })
    _emit_discovery(decision)
    return True


def _discover_contract_drift(ctx: Context, claim: dict[str, Any]) -> dict[str, Any] | None:
    """Contract-drift classification for one own non-terminal attempt
    (#166 incident class): the claim's recorded contract_digest is compared
    against the ONE canonical digest primitive (`parse_contract` +
    `contract_digest` — the exact comparison `_assert_contract_unchanged`
    fail-closes on).

    A mismatch means the attempt is fenced for EVERY continuation
    (acquire/preserve/deliver fail closed under the stale authority), so
    the only truthful discovery verdict is this distinct non-runnable
    `blocked` classification: it supersedes the plain resume, the
    execution-recovery, the stale-holder grace wait, AND the parked
    awaiting-review wait (even A's acceptance could never complete under
    the stale authority), and it names the canonical exit — `ght release
    --status blocked` terminates the stale attempt, and a NEW claim still
    requires A's fresh one-shot authorization and binds the CURRENT
    Contract digest. An unreadable Contract is a different failure
    surface: None keeps the ordinary classification behavior (the digest
    comparison is undefined for it — never guessed here)."""
    task = claim.get("task")
    try:
        contract = parse_contract(ctx.github.issue_view(int(task)).get("body", ""))
    except (ContractError, IntakeError, TypeError, ValueError):
        return None
    if contract_digest(contract) == claim.get("contract_digest"):
        return None
    return {"issue": int(task), "source": "resume", "kind": "blocked",
            "runnable": False, "claim_id": claim.get("claim_id"),
            "reason": ("Task Contract changed during the active attempt; the attempt is "
                       "fenced (acquire/preserve/deliver fail closed under the stale "
                       "authority). Terminate it with `ght release " + str(task) +
                       " --status blocked --note ...`; a fresh claim then requires A "
                       "re-authorization (fresh one-shot READY / Plan authorization) and "
                       "binds the current Contract")}


def _discover_from_snapshot(args: argparse.Namespace, ctx: Context,
                            decision: dict[str, Any]) -> None:
    """The discovery predicates themselves, reading ONLY the invocation's
    own snapshot (see _cmd_discover for the lifecycle)."""
    # #102 (AC1/AC2/AC3): before compiling any verdict, mechanically prove
    # the effective execution semantics against the repo's canonical
    # activated distribution identity. Current → proceed into the frontier;
    # stale/different → only the machine-readable `refresh_required`
    # verdict; canonical identity missing/unreadable/ambiguous → fail
    # closed (see _discover_freshness_preflight).
    if _discover_freshness_preflight(ctx, decision):
        return

    stops: list[dict[str, Any]] = []

    # 1) same-attempt continuation (highest precedence, AC7).
    resumes: list[dict[str, Any]] = []
    execution_recoveries: list[dict[str, Any]] = []
    blocked_recoveries: list[dict[str, Any]] = []
    awaiting_review: list[dict[str, Any]] = []
    executing_elsewhere: list[dict[str, Any]] = []
    contract_drifts: list[dict[str, Any]] = []
    my_claim_tasks: set = set()
    for claim in _discover_my_active_claims(ctx):
        my_claim_tasks.add(claim.get("task"))
        drift = _discover_contract_drift(ctx, claim)
        if drift is not None:
            # A digest-drifted attempt is fenced for every continuation;
            # the drift classification is its ONLY verdict (never a plain
            # resume/recovery/wait, and never folded into no_work — it
            # rides work[] below as a non-runnable blocked item).
            contract_drifts.append(drift)
            continue
        capacity = _execution_capacity(ctx, claim)
        resume = _discover_resume_candidate(ctx, claim, capacity=capacity)
        if resume is not None:
            resumes.append(resume)
        elif capacity["state"] == "live":
            executing_elsewhere.append(claim)
        elif (capacity["state"] == "expired_residue" and
              not capacity["reacquirable"]):
            blocked_recoveries.append({"issue": claim.get("task"),
                                       "claim_id": claim.get("claim_id"),
                                       **capacity})
        elif _has_durable_delivery(claim):
            delivery = claim.get("delivery") or {}
            awaiting_review.append({"issue": claim.get("task"),
                                    "claim_id": claim.get("claim_id"),
                                    "pr": delivery.get("pr"),
                                    "execution_capacity": capacity["state"],
                                    "reason": ("durable Candidate is parked and awaits "
                                               "A's exact-SHA review; do not start a new "
                                               "attempt or take over this lineage")})
        else:
            execution_recoveries.append(claim)
    if executing_elsewhere:
        # A live lease this executor already holds is an attempt executing
        # in another session — never auto-touch it (one-live-lease rule).
        stops.append({"issues": [c.get("task") for c in executing_elsewhere],
                      "reason": "attempt holds a live execution lease (executing "
                                "elsewhere); stop — do not double-execute"})
    # #98 (AC3/AC5(d)): foreign-lineage parked attempts carrying durable
    # resumable truth, and dual-lineage (principal) mismatches, are surfaced
    # as explicit diagnostics — never folded into a silent 0-runnable
    # answer and never auto-taken-over.
    foreign = _discover_foreign_lineage(ctx, own_tasks=my_claim_tasks)

    def _attach_foreign(target: dict[str, Any]) -> None:
        if blocked_recoveries:
            target["blocked_recoveries"] = blocked_recoveries
        if awaiting_review:
            target["awaiting_review"] = awaiting_review
        if foreign["resumable"]:
            target["foreign_resumable"] = foreign["resumable"]
        if foreign["ownership"]:
            target["foreign_ownership"] = foreign["ownership"]

    # 2) current Execution Plan → host-native handoff of the COMPLETE
    # authorized workset (#75/#89 AC3/AC10): Plan nodes (including
    # correction resumes), the executor's non-Plan resumable attempts, and
    # independently direct-ready Issues all appear in ONE
    # admission-priority-ordered set — continuation first, then A priority
    # DESC, then direct-ready. Discovery never consumes an authorization:
    # ready labels and Plan nodes are only read, and consumption stays at
    # canonical claim time. Unreadable ready truth fails closed; ambiguity
    # rides the item as a not-runnable durable reason.
    plan, _revision = _remote_plan(ctx)
    if plan is not None:
        from .orchestrator import plan_handoff
        decision.update({"action": "handoff", **plan_handoff(ctx)})
        work = decision["work"]
        for claim in resumes:
            work.append({"issue": claim.get("task"), "source": "resume",
                         "kind": "resume", "runnable": True,
                         "reason": "own attempt carries an exact-SHA REQUEST_CHANGES; "
                                   "resume with `ght acquire`"})
        for claim in execution_recoveries:
            item = {"issue": claim.get("task"), "source": "resume",
                    "kind": "resume", "runnable": True,
                    "claim_id": claim.get("claim_id"),
                    "recovery": "execution_lease",
                    "reason": ("owned ACTIVE attempt has no live execution capacity; "
                               "resume the same attempt with `ght acquire" +
                               f" {claim.get('task')}`")}
            existing = next((entry for entry in work
                             if entry.get("issue") == item["issue"]), None)
            if existing is not None:
                existing.update(item)
            else:
                work.append(item)
        for item in contract_drifts:
            # The drift classification supersedes whatever the same Issue's
            # plan/resume entry said — the attempt is fenced, and the drift
            # verdict is the canonical one for it.
            existing = next((entry for entry in work
                             if entry.get("issue") == item["issue"]), None)
            if existing is not None:
                existing.update(item)
            else:
                work.append(item)
        ready_numbers = ctx.github.issue_list_ready(ctx.ready_label)
        if ready_numbers is None:
            raise CommandFailure(
                "the ready-issue listing surface is unavailable; durable truth is unreadable "
                "and discovery must not guess", OWNERSHIP_LOST)
        for number in ready_numbers:
            existing = next((w for w in work if w["issue"] == number), None)
            if existing is not None and (existing["runnable"] or
                                         existing.get("kind") == "blocked"):
                continue  # a live node/continuation already represents the Issue;
                          # a contract-drift entry is the canonical verdict for it
            node = next((e for e in plan["nodes"] if e["issue"] == number), None)
            if (node is not None and _plan_authorization_consumption(
                    ctx, node["authorization_id"]) is None):
                continue  # dual authority: the live node's ambiguity reason
                          # already fail-closes it — never expose an
                          # auto-claimable entry alongside it
            # A consumed/non-runnable historical node (or no node) plus a
            # fresh valid `ready`: the new grant stays visible (AC10).
            ok, detail, mode = _discover_direct_ready_eligible(ctx, number)
            item = {"issue": number, "source": "direct-ready",
                    "kind": "new", "runnable": ok, "reason": detail}
            if ok and mode:
                # #164: an investigation-only decision carries its
                # investigate-mode admission on the typed item.
                item["mode"] = mode
            work.append(item)
        def _admission_order(item: dict[str, Any]) -> tuple[int, int, int]:
            if item.get("kind") == "resume":
                return (0, 0, int(item["issue"]))
            if item.get("source") == "direct-ready":
                return (2, 0, int(item["issue"]))
            return (1, -int(item.get("priority", 0)), int(item["issue"]))
        work.sort(key=_admission_order)
        if executing_elsewhere:
            decision["executing_elsewhere"] = [c.get("task")
                                               for c in executing_elsewhere]
        _attach_foreign(decision)
        _emit_discovery(decision)
        return
    # 3) no current Plan → the COMPLETE resumable + direct-ready workset
    # (#89 R7/R8 AC3/AC10): continuation precedence is admission
    # priority, never global exclusivity — resumable attempts ride ahead
    # of fresh direct-ready work in ONE deterministic handoff whenever
    # more than one independent item exists. Single-item convenience
    # paths remain (one continuation → resume; one eligible direct-ready
    # → claim) and never truncate another runnable/resumable item.
    # Discovery never consumes a `ready` label, and real ambiguity
    # (dual authority, ownership, unreadable truth) stays fail-closed.
    ready_numbers = ctx.github.issue_list_ready(ctx.ready_label)
    if ready_numbers is None:
        raise CommandFailure(
            "the ready-issue listing surface is unavailable; durable truth is unreadable "
            "and discovery must not guess", OWNERSHIP_LOST)

    resume_items: list[dict[str, Any]] = []
    for entry in sorted(resumes, key=lambda c: int(c.get("task") or 0)):
        delivery = entry.get("delivery") or {}
        resume_items.append({
            "issue": entry.get("task"), "source": "resume",
            "kind": "resume", "runnable": True,
            "claim_id": entry.get("claim_id"),
            "pr": delivery.get("pr"),
            "reason": "own attempt carries an exact-SHA REQUEST_CHANGES; "
                      "resume with `ght acquire`"})
    for claim in sorted(execution_recoveries, key=lambda c: int(c.get("task") or 0)):
        resume_items.append({
            "issue": claim.get("task"), "source": "resume",
            "kind": "resume", "runnable": True,
            "claim_id": claim.get("claim_id"),
            "recovery": "execution_lease",
            "reason": ("owned ACTIVE attempt has no live execution capacity; "
                       "resume the same attempt with `ght acquire "
                       f"{claim.get('task')}`")})
    resume_items.sort(key=lambda item: int(item["issue"]))
    contract_drifts.sort(key=lambda item: int(item["issue"]))

    eligible: list[int] = []
    ineligible: list[dict[str, Any]] = []
    direct_items: list[dict[str, Any]] = []
    investigation_modes: dict[int, str] = {}
    for number in ready_numbers:
        if (any(item["issue"] == number for item in resume_items) or
                any(item["issue"] == number for item in contract_drifts)):
            continue  # already represented as the continuation/drift entry
        ok, detail, mode = _discover_direct_ready_eligible(ctx, number)
        if ok:
            eligible.append(number)
            if mode:
                # #164: remember the investigate-mode admission for the
                # typed decision surface.
                investigation_modes[number] = mode
        else:
            ineligible.append({"issue": number, "reason": detail})
        item = {"issue": number, "source": "direct-ready",
                "kind": "new", "runnable": ok, "reason": detail}
        if ok and mode:
            item["mode"] = mode
        direct_items.append(item)
    direct_items.sort(key=lambda item: int(item["issue"]))
    # Continuations first, then the non-runnable drift classifications,
    # then direct-ready entries ride the array tail (#121).
    work = resume_items + contract_drifts + direct_items

    if (not stops and len(resume_items) == 1 and not direct_items
            and not contract_drifts):
        # True single-item convenience: the continuation is the only
        # ready-surface item, so nothing else is hidden by the shortcut.
        only = resume_items[0]
        decision.update({"action": "resume", "issue": only["issue"],
                         "claim_id": only.get("claim_id"),
                         "pr": only.get("pr"),
                         "resumable": [item["issue"] for item in resume_items],
                         "reason": only.get("reason")})
        if only.get("recovery"):
            decision["recovery"] = only["recovery"]
        _attach_foreign(decision)
        _emit_discovery(decision)
        return
    if (not stops and not resume_items and not contract_drifts
            and len(direct_items) == 1 and len(eligible) == 1):
        # True single-item convenience: the one eligible Issue is also the
        # only ready-surface entry — blocked entries elsewhere would lose
        # their durable reasons if this shortcut fired.
        decision.update({"action": "claim", "issue": eligible[0]})
        if eligible[0] in investigation_modes:
            # #164: the investigation admission rides the verdict so the
            # canonical B consumer runs the existing investigate-mode
            # claim — never a silent implement-mode default.
            decision["mode"] = investigation_modes[eligible[0]]
        _attach_foreign(decision)
        _emit_discovery(decision)
        return
    if work:
        decision.update({"action": "handoff", "work": work})
        if executing_elsewhere:
            decision["executing_elsewhere"] = [c.get("task")
                                               for c in executing_elsewhere]
        _attach_foreign(decision)
        _emit_discovery(decision)
        return

    if stops:
        # Real fail-closed stops (e.g. an own attempt executing elsewhere)
        # with no direct-ready work to represent; --evidence-comment leaves
        # durable, idempotent evidence A can reconcile.
        decision.update({"action": "stop", "stops": stops,
                         "eligible": eligible, "ineligible": ineligible})
        _attach_foreign(decision)
        if args.evidence_comment:
            for stop in stops:
                for number in stop.get("issues", []):
                    try:
                        ctx.github.comment(
                            number,
                            f"<!-- {DISCOVERY_EVIDENCE_MARKER} -->\n"
                            f"**B AUTO-DISCOVERY STOPPED** — {stop['reason']}\n"
                            f"- ready issues considered: "
                            f"{[i for i in ready_numbers or []]}",
                            DISCOVERY_EVIDENCE_MARKER)
                    except MirrorError as exc:
                        print(f"ght: WARNING — discovery evidence comment failed: {exc}",
                              file=sys.stderr)
        _emit_discovery(decision)
        return
    if foreign["resumable"] or foreign["ownership"]:
        # #98 (AC3/AC5(d)): nothing runnable for this identity, but
        # foreign-lineage resumable corrections and/or dual-lineage
        # ownership notes exist — surface the explicit diagnostics instead
        # of a bare no-work answer.
        decision.update({"action": "stop",
                         "stops": [{"issues": [item["issue"]],
                                    "reason": item["reason"]}
                                   for item in (foreign["resumable"]
                                                + foreign["ownership"])]})
        _attach_foreign(decision)
        _emit_discovery(decision)
        return

    if blocked_recoveries or awaiting_review:
        # These are explicit, read-only waits rather than reconciliation
        # stops; in particular, --evidence-comment must not post an A-facing
        # blocker comment for an ordinary grace period or parked review.
        decision["action"] = "stop"
        if blocked_recoveries:
            decision["reason"] = (
                "owned execution lease residue is inside stale-holder grace; retry "
                "`ght acquire` after the reported recovery_after")
        else:
            decision["reason"] = "owned Candidate is parked and awaits A review"
        _attach_foreign(decision)
        _emit_discovery(decision)
        return

    # 4) safe no-work exit (AC9).
    decision["reason"] = "no resumable attempt, no current Plan, no direct-ready work"
    _emit_discovery(decision)


def _emit_discovery(decision: dict[str, Any]) -> None:
    print(json.dumps(decision, indent=2))


CANDIDATE_SNAPSHOT_START = "<!-- ght:candidate-snapshot:v1 -->"
CANDIDATE_SNAPSHOT_END = "<!-- /ght:candidate-snapshot:v1 -->"


def _discover_previous_reviewed(ctx: Context, claim: dict[str, Any],
                                pr: int) -> str | None:
    """The previously REVIEWED Candidate SHA, from durable exact-SHA A
    review evidence only (AC19) — a merely-delivered-but-never-reviewed
    SHA is never presented as reviewed. Both canonical exact-SHA outcomes
    count: an ACCEPT/APPROVED review bound to the SHA, or an exact-SHA
    REQUEST_CHANGES. Unreadable/absent evidence renders as None."""
    delivery = claim.get("delivery") or {}
    prev_sha = delivery.get("sha")
    if not prev_sha or prev_sha == "unknown":
        return None
    try:
        reviews = ctx.github.pr_reviews(int(delivery.get("pr") or pr))
        comments = ctx.github.pr_comments(int(delivery.get("pr") or pr))
    except Exception:  # noqa: BLE001 - unreadable surface is "unknown", not reviewed
        return None
    if reviews is None or comments is None:
        return None
    acceptance = evaluate_exact_sha_acceptance(reviews=reviews, comments=comments,
                                               candidate_sha=prev_sha)
    if acceptance.get("unreadable"):
        return None
    changed, _unreadable = has_exact_sha_change_request(reviews=reviews,
                                                        comments=comments,
                                                        candidate_sha=prev_sha)
    if acceptance.get("accepted") or changed:
        return prev_sha
    return None


def _candidate_snapshot_text(*, issue: int, pr: int, claim: dict[str, Any],
                             candidate: dict[str, Any], previous_reviewed: str | None,
                             note: str, detail: str) -> str:
    """Mechanical Current Candidate Snapshot body (AC14/AC19): durable
    identity facts are rendered by ght; the concise AC checkbox
    verification, validation summary, and known limitations come from B's
    evidence file verbatim — with any snapshot envelope markers stripped,
    so repeated re-delivery can never nest or duplicate the envelope.
    Re-delivery replaces the whole body — round history stays in
    Git/review/comments, never appended here."""
    detail = re.sub(r"<!--\s*/?ght:candidate-snapshot:v1\s*-->\n?", "", detail)
    authorization = claim.get("authorization") or {}
    if authorization:
        authority = (f"Plan authorization `{authorization.get('authorization_id')}` "
                     f"(plan `{authorization.get('plan_id')}`)")
    else:
        authority = "direct `ready`"
    delivered_at = (claim.get("delivery") or {}).get("delivered_at", "")
    lines = [
        CANDIDATE_SNAPSHOT_START,
        f"## Current Candidate Snapshot — #{issue} / PR #{pr}",
        "",
        f"- exact Candidate: `{candidate.get('sha', '')}`",
        f"- previous reviewed Candidate: "
        f"{f'`{previous_reviewed}`' if previous_reviewed else 'none — no durable exact-SHA review of a prior Candidate'}",
        f"- claim: `{claim.get('claim_id')}` · branch: `{claim.get('branch')}` · "
        f"execution_base: `{claim.get('execution_base')}`",
        f"- authority: {authority} · delivered: {delivered_at}",
        "",
        "### Change summary",
        note or "_(no note)_",
        "",
        detail.strip(),
        "",
        CANDIDATE_SNAPSHOT_END,
        "",
    ]
    return "\n".join(lines)


def _cmd_orchestrate(args: argparse.Namespace) -> None:
    """Evaluate the current Execution Plan (AC11, #75 handoff model).

    Bare `ght orchestrate` is the production surface: it mechanically
    evaluates the Plan and hands the authorized work to the already-online
    primary B — no orchestrator slot, no driver, no nested engineering
    Agent. `--execute --driver reference` is the EXPLICIT test/dev fixture
    that runs the legacy launch pipeline (slot + rounds + synthetic task
    command); production activation never reaches it.
    """
    from .orchestrator import orchestrate, plan_handoff

    ctx = Context(args.remote, args.repo)
    if not args.execute:
        # Production handoff (#75): mechanically evaluate the current Plan
        # and hand the authorized work to the already-online primary B. No
        # orchestrator slot, no driver, no nested engineering Agent — the
        # reference/synthetic surface exists only as an explicit test/dev
        # fixture (--execute --driver reference).
        print(json.dumps({"action": "handoff", **plan_handoff(ctx)}))
        return
    if args.driver != "reference":
        raise CommandFailure(
            f"unknown Execution Driver {args.driver!r}; the reference driver "
            "is the only fixture surface and must be requested explicitly",
            INELIGIBLE)
    operator_cap = args.max_parallel
    if operator_cap is None:
        operator_cap = int(os.environ.get("GHT_ORCHESTRATOR_MAX_PARALLEL", "1"))
    if operator_cap < 0:
        raise CommandFailure("--max-parallel must be >= 0", INELIGIBLE)
    report = orchestrate(ctx, max_parallel=operator_cap, driver_name=args.driver)
    print(json.dumps(report))


# ---------------------------------------------------------------- main

def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="ght",
                                     description="Harry Dev github-task claim-state tool")
    parser.add_argument("--version", action=_LazyVersionAction)
    parser.add_argument("--remote", default="origin")
    parser.add_argument("--repo", default=None, help="optional gh --repo override")
    parser.add_argument("--json", action="store_true", help="emit JSON errors (success output is JSON)")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("version")
    sub.add_parser("identity")
    sub.add_parser("status")
    sub.add_parser(
        "preflight",
        help="supported-host/install preflight (AC2/#165): one pass over the "
             "standard host tooling and GitHub credential surfaces; missing "
             "gh is provisioned user-space from the official cli/cli release "
             "on supported hosts, and every remaining missing piece lands in "
             "ONE actionable blocker list (after provisioning: auth consent)")
    sub.add_parser(
        "bootstrap",
        help="one-time mechanical downstream bootstrap (#165): for a provably "
             "uninitialized target repo and an exact installed RELEASED "
             "distribution, publish + activate + read back that identity and "
             "return the fresh discover verdict in the same activation; "
             "first adoption also applies the project AGENTS contract (#166) "
             "before anything is published; never touches an initialized "
             "runtime, grants no Issue authority")
    agents_adopt = sub.add_parser(
        "agents-adopt",
        help="project AGENTS contract adoption (#166): apply/reconcile the "
             "released canonical managed block in the target repository's "
             "root AGENTS.md — idempotent, project-owned content preserved, "
             "nested AGENTS.md/AGENTS.override.md never touched; material "
             "authority/security conflicts fail closed for A reconciliation; "
             "a newer installed Skill never implicitly upgrades an adopted "
             "block (--upgrade is only the execution selector for a release "
             "upgrade ALREADY authorized for the project — the flag is not "
             "itself the authorization); prepares a working-tree change "
             "only — never commits or pushes")
    agents_adopt.add_argument("--root", default=None, metavar="DIR",
                              help="target repository root (default: the git "
                                   "toplevel of the current directory)")
    agents_adopt.add_argument(
        "--upgrade", action="store_true",
        help="execution selector for a release-upgrade reconciliation of "
             "the managed block to the installed release contract, used "
             "only when an explicit Harry Dev release upgrade has ALREADY "
             "been authorized for this project (block only; project-owned "
             "content is preserved; material conflicts still fail closed); "
             "the flag is not itself the authorization and never "
             "establishes it, and this surface cannot mechanically verify "
             "the authorization exists")
    inspect = sub.add_parser("inspect")
    inspect.add_argument("issue", type=int)
    validate_ready = sub.add_parser("validate-ready")
    validate_ready.add_argument("issue", type=int)
    contract_digest_cmd = sub.add_parser("contract-digest")
    contract_digest_cmd.add_argument("issue", type=int)
    for name in ("claim", "verify", "heartbeat", "takeover", "scope-check", "preserve",
                 "ready-repair", "acquire"):
        command = sub.add_parser(name)
        command.add_argument("issue", type=int)
    claim = sub.choices["claim"]
    claim.add_argument("--mode", choices=("implement", "investigate"), default="implement")
    claim.add_argument("--plan-authorization", default=None,
                       help="start via a Plan authorization identity instead of the ready label")
    heartbeat = sub.choices["heartbeat"]
    heartbeat.add_argument("--force", action="store_true")
    takeover = sub.choices["takeover"]
    takeover.add_argument("--mode", choices=("implement", "investigate"), default="implement")
    takeover.add_argument("--evidence", required=True)
    reclaim = sub.add_parser(
        "reclaim-execution-resource",
        help="authorize/confirm fenced destructive worktree removal (#147): "
             "atomic CAS transition on the Issue's claim ref that prevents an "
             "ACTIVE transition from becoming valid between authorization and "
             "destructive removal")
    reclaim.add_argument("issue", type=int)
    reclaim.add_argument("--expect-claim-sha", default="",
                         help="claim_sha of the authorizing eligibility read "
                              "(marker commit for --confirm-removal; empty for "
                              "a true orphan)")
    reclaim.add_argument("--confirm-removal", action="store_true",
                         help="clear the pending-reclaim marker after the removal")
    release = sub.add_parser("release")
    release.add_argument("issue", type=int)
    release.add_argument("--status", required=True, choices=("investigated", "blocked"))
    release.add_argument("--note", default="")
    deliver = sub.add_parser("deliver")
    deliver.add_argument("issue", type=int)
    deliver.add_argument("--pr", type=int, required=True)
    deliver.add_argument("--note", default="")
    deliver.add_argument("--snapshot", default=None, metavar="FILE",
                         help="concise evidence file (AC checkbox verification, "
                              "validation summary, known limitations); when provided, "
                              "delivery mechanically updates the PR body as the Current "
                              "Candidate Snapshot (AC19)")
    complete = sub.add_parser("complete")
    complete.add_argument("issue", type=int)
    complete.add_argument("--pr", type=int, default=None)
    sub.add_parser("migrate-claims")
    plan_publish = sub.add_parser("plan-publish")
    plan_publish.add_argument("plan_file", help="path to the Plan v1 JSON document, or - for stdin")
    plan_publish.add_argument("--bind-contract-digests", action="store_true",
                              help="#156 remote-A surface: mechanically bind every node "
                                   "that omits contract_digest from a fresh canonical "
                                   "digest read at publication time (the workflow glue "
                                   "always passes this; the local direct run is the "
                                   "equivalent break-glass path)")
    plan_publish.add_argument("--replace", default=None, metavar="PRIOR_REVISION_SHA",
                              help="exact prior revision this publication supersedes (CAS)")
    plan_view = sub.add_parser("plan-view")
    plan_view.add_argument("--revision", default=None,
                           help="read an exact historical revision instead of the current pointer")
    orchestrate = sub.add_parser("orchestrate")
    orchestrate.add_argument("--execute", action="store_true",
                             help="EXPLICIT test/dev fixture: run the legacy "
                                  "reference-driver launch pipeline instead of "
                                  "the production handoff")
    orchestrate.add_argument("--max-parallel", type=int, default=None,
                             help="operator/runtime concurrency ceiling for this invocation")
    orchestrate.add_argument("--driver", default="reference",
                             help="Execution Driver adapter to launch engineering executions")
    discover = sub.add_parser("discover")
    discover.add_argument("--evidence-comment", action="store_true",
                          help="post durable evidence on the affected Issues when "
                               "discovery stops (multiple direct-ready / ambiguous "
                               "authority); idempotent via a dedup marker")
    sync_runtime = sub.add_parser("sync-runtime")
    sync_runtime.add_argument(
        "--source", default=None, metavar="DIR",
        help="runtime source distribution dir (default: this installed, stamped "
             "github-task Skill); publishes its immutable content-addressed "
             "capsule to refs/ght/runtime/<digest> in the target repo")
    activate_runtime = sub.add_parser("activate-runtime")
    activate_runtime.add_argument(
        "digest", help="content digest of an already-synced runtime capsule "
                       "(refs/ght/runtime/<digest>) to make the project pin")
    stamp = sub.add_parser("stamp-distribution")
    stamp.add_argument("--release", required=True, metavar="RELEASE_TAG",
                       help="exact Harry Dev release tag to carry, e.g. v1.0.3")
    stamp.add_argument("--source", default=None,
                       help="release source checkout that must sit exactly on the "
                            "requested tag (defaults to --root, then the package tree)")
    stamp.add_argument("--root", default=None,
                       help="distribution root to stamp (defaults to the source)")
    stamp.add_argument("--release-repo", default=None, dest="release_repo",
                       metavar="OWNER/REPO",
                       help="canonical release repository to record for consumer "
                            "corroboration (review R3 finding 1; release packaging "
                            "passes the selected repository)")
    supervise = sub.add_parser("supervise")
    supervise.add_argument("issue", type=int)
    release_publish = sub.add_parser(
        "release-publish",
        help="A-facing canonical release publication: after User release "
             "authorization and A exact-target reconciliation, mechanically "
             "publish (exact tag, GitHub Release, stamp, sync, activate, "
             "read-back); it never chooses version/target/membership/time")
    release_publish.add_argument("--version", required=True, metavar="RELEASE_TAG",
                                 help="exact Harry Dev release tag, e.g. v1.0.5")
    release_publish.add_argument("--target", required=True, metavar="SHA",
                                 help="exact accepted-main commit SHA to publish")
    release_publish.add_argument("--notes-file", required=True, metavar="FILE",
                                 help="file holding the release notes body")
    release_publish.add_argument(
        "--checkout", default=None, metavar="DIR",
        help="release source checkout that must sit exactly on the tag "
             "(defaults to the current working repository)")
    # #125 R4: there is deliberately NO caller-supplied governance-path
    # flag on this surface. The governance-only release-cut exception is
    # bound mechanically to the canonical formal-release dispatch record
    # (FORMAL_RELEASE_DISPATCH_PATH) and is granted only by that record's
    # own durable frozen-target binding; every other fresh publication
    # keeps the exact current-main equality rule.

    args = parser.parse_args(argv)
    if args.command == "version":
        _cmd_version(args)
        return
    handlers = {"identity": _cmd_identity, "status": _cmd_status, "inspect": _cmd_inspect,
                "validate-ready": _cmd_validate_ready,
                "contract-digest": _cmd_contract_digest,
                "claim": _cmd_claim, "ready-repair": _cmd_ready_repair, "verify": _cmd_verify,
                "heartbeat": _cmd_heartbeat, "takeover": _cmd_takeover, "acquire": _cmd_acquire,
                "reclaim-execution-resource": _cmd_reclaim_execution_resource,
                "scope-check": _cmd_scope_check, "preserve": _cmd_preserve,
                "release": _cmd_release, "deliver": _cmd_deliver, "complete": _cmd_complete,
                "migrate-claims": _cmd_migrate_claims, "supervise": _cmd_supervise,
                "release-publish": _cmd_release_publish,
                "plan-publish": _cmd_plan_publish, "plan-view": _cmd_plan_view,
                "stamp-distribution": _cmd_stamp_distribution,
                "orchestrate": _cmd_orchestrate, "discover": _cmd_discover,
                "sync-runtime": _cmd_sync_runtime,
                "activate-runtime": _cmd_activate_runtime,
                "preflight": _cmd_preflight, "bootstrap": _cmd_bootstrap,
                "agents-adopt": _cmd_agents_adopt}
    try:
        # R4-1: a runtime-bound attempt continues under its own bound
        # runtime — this must run before any local-identity gate so the
        # dispatched (bound) runtime re-applies every rule itself.
        _runtime_dispatch_guard(args)
        # The machine/reconciler identity is completion-only: refuse it on
        # every other command (ownership-sensitive or not) so a forgeable
        # environment principal can never reach beyond the completion audit
        # surface.
        if (os.environ.get("GHT_RECONCILER_ID", "").strip()
                and args.command not in ("complete", "version")):
            raise CommandFailure(
                f"GHT_RECONCILER_ID is a completion-only machine identity; "
                f"'{args.command}' requires the canonical authenticated principal "
                "(`gh api user`) — unset it", OWNERSHIP_LOST)
        if (os.environ.get("GHT_PLAN_PUBLISHER_ID", "").strip()
                and args.command not in ("plan-publish", "version")):
            raise CommandFailure(
                "GHT_PLAN_PUBLISHER_ID is a Plan-publication-only machine identity; "
                f"'{args.command}' requires the canonical authenticated principal "
                "(`gh api user`) — unset it", OWNERSHIP_LOST)
        if (os.environ.get("GHT_RELEASE_PUBLISHER_ID", "").strip()
                and args.command not in ("release-publish", "version")):
            raise CommandFailure(
                "GHT_RELEASE_PUBLISHER_ID is a release-publication-only machine "
                f"identity; '{args.command}' requires the canonical authenticated "
                "principal (`gh api user`) — unset it", OWNERSHIP_LOST)
        handlers[args.command](args)
    except CommandFailure as failure:
        _fail(failure, args.json)
    except IntakeError as exc:
        _fail(CommandFailure(str(exc), INELIGIBLE), args.json)
