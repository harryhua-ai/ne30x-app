"""Pure contract, claim-state, and scope helpers for github-task.

No GitHub or subprocess access lives here; the CLI layer adapts remote
surfaces into these primitives so the safety logic stays mechanically
testable.
"""

from __future__ import annotations

import fnmatch
import hashlib
import json
import re
import uuid
from datetime import datetime, timezone
from typing import Any


class ContractError(ValueError):
    """Raised when an Issue does not contain a valid v3 Task Contract."""


def _scalar(value: str) -> Any:
    value = value.strip()
    if value in ("[]", "[ ]"):
        return []
    if value in ("{}", "{ }"):
        return {}
    if value.lower() in ("true", "false"):
        return value.lower() == "true"
    if re.fullmatch(r"-?\d+", value):
        return int(value)
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "'\"":
        return value[1:-1]
    if value.startswith("[") and value.endswith("]"):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            pass
    return value


def _next_content(lines: list[str], index: int) -> tuple[int, int, str] | None:
    while index < len(lines) and not lines[index].strip():
        index += 1
    if index >= len(lines):
        return None
    raw = lines[index]
    return index, len(raw) - len(raw.lstrip(" ")), raw.strip()


def _parse_yaml_subset(text: str) -> dict[str, Any]:
    """Parse the small YAML subset used by the v3 Contract.

    Deliberately not a general YAML parser: the Contract format only needs
    mappings, sequences, scalars, and folded/literal blocks, and staying
    parser-local keeps the runtime free of third-party dependencies.
    Unsupported syntax raises ContractError instead of guessing.
    """

    lines = text.splitlines()

    def parse_node(index: int, indent: int) -> tuple[Any, int]:
        first = _next_content(lines, index)
        if first is None or first[1] < indent:
            return {}, index
        if first[1] > indent:
            raise ContractError(f"unexpected indentation at line {first[0] + 1}")
        is_list = first[2].startswith("-")
        result: Any = [] if is_list else {}

        while True:
            current = _next_content(lines, index)
            if current is None:
                break
            line_no, current_indent, content = current
            if current_indent < indent or current_indent != indent:
                break
            if is_list:
                if not content.startswith("-"):
                    break
                rest = content[1:].strip()
                if not rest:
                    child = _next_content(lines, line_no + 1)
                    if child is None or child[1] <= indent:
                        value, index = {}, line_no + 1
                    else:
                        value, index = parse_node(line_no + 1, child[1])
                elif ":" in rest:
                    key, raw_value = rest.split(":", 1)
                    item: dict[str, Any] = {key.strip(): None}
                    index = line_no + 1
                    if raw_value.strip() in (">", "|"):
                        value, index = parse_block(index, indent, raw_value.strip())
                        item[key.strip()] = value
                    elif raw_value.strip():
                        item[key.strip()] = _scalar(raw_value)
                    else:
                        child = _next_content(lines, index)
                        if child is not None and child[1] > indent:
                            value, index = parse_node(index, child[1])
                            item[key.strip()] = value
                    child = _next_content(lines, index)
                    if child is not None and child[1] > indent:
                        extra, index = parse_node(index, child[1])
                        if not isinstance(extra, dict):
                            raise ContractError(f"list item at line {line_no + 1} is not a mapping")
                        item.update(extra)
                    value = item
                else:
                    value, index = _scalar(rest), line_no + 1
                result.append(value)
            else:
                if content.startswith("-") or ":" not in content:
                    raise ContractError(f"expected mapping entry at line {line_no + 1}")
                key, raw_value = content.split(":", 1)
                key = key.strip()
                if not key:
                    raise ContractError(f"empty mapping key at line {line_no + 1}")
                index = line_no + 1
                raw_value = raw_value.strip()
                if raw_value in (">", "|"):
                    value, index = parse_block(index, indent, raw_value)
                elif raw_value:
                    value = _scalar(raw_value)
                else:
                    child = _next_content(lines, index)
                    if child is not None and child[1] > indent:
                        value, index = parse_node(index, child[1])
                    else:
                        value = None
                result[key] = value
        return result, index

    def parse_block(index: int, parent_indent: int, style: str) -> tuple[str, int]:
        values: list[str] = []
        while index < len(lines):
            raw = lines[index]
            if raw.strip() and len(raw) - len(raw.lstrip(" ")) <= parent_indent:
                break
            values.append(raw.strip() if raw.strip() else "")
            index += 1
        if style == ">":
            return " ".join(value for value in values if value), index
        return "\n".join(values).rstrip(), index

    first = _next_content(lines, 0)
    if first is None:
        raise ContractError("empty ght-contract block")
    result, _ = parse_node(0, first[1])
    if not isinstance(result, dict):
        raise ContractError("ght-contract root must be a mapping")
    return result


AUTHORITY_PROFILES = ("allowed", "investigation-only")


def parse_contract(body: str) -> dict[str, Any]:
    """Extract and validate exactly one machine-readable ``ght-contract`` block."""

    matches = re.findall(r"```ght-contract\s*\n(.*?)\n```", body, flags=re.DOTALL)
    if len(matches) != 1:
        raise ContractError(f"expected exactly one ght-contract block, found {len(matches)}")
    contract = _parse_yaml_subset(matches[0])
    required = ("version", "intent", "acceptance", "authority")
    missing = [key for key in required if key not in contract]
    if missing:
        raise ContractError(f"missing Contract field(s): {missing}")
    if contract["version"] != 1:
        raise ContractError("unsupported Contract version")
    if not isinstance(contract["intent"], str) or not contract["intent"].strip():
        raise ContractError("intent must be non-empty text")
    if not isinstance(contract["acceptance"], list) or not contract["acceptance"]:
        raise ContractError("acceptance must be a non-empty list")
    for criterion in contract["acceptance"]:
        if not isinstance(criterion, dict) or not criterion.get("id") or not criterion.get("requirement"):
            raise ContractError("each acceptance item needs id and requirement")
    authority = contract["authority"]
    if not isinstance(authority, dict) or authority.get("implementation") not in AUTHORITY_PROFILES:
        raise ContractError(f"authority.implementation must be one of {list(AUTHORITY_PROFILES)}")
    depends_on = contract.get("depends_on", [])
    if not isinstance(depends_on, list):
        raise ContractError("depends_on must be a list")
    if not all((isinstance(item, int) and not isinstance(item, bool)) or
               (isinstance(item, str) and re.fullmatch(r"#?\d+", item.strip()))
               for item in depends_on):
        raise ContractError("depends_on must contain Issue numbers")
    scope = contract.get("scope", {})
    if not isinstance(scope, dict):
        raise ContractError("scope must be a mapping")
    forbidden = scope.get("forbidden", [])
    if not isinstance(forbidden, list) or not all(isinstance(item, str) and item for item in forbidden):
        raise ContractError("scope.forbidden must be a list of non-empty path patterns")
    contract["depends_on"] = depends_on
    contract["scope"] = {**scope, "forbidden": forbidden}
    return contract


def canonical_contract(contract: dict[str, Any]) -> str:
    return json.dumps(contract, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def contract_digest(contract: dict[str, Any]) -> str:
    """Digest over canonicalized Contract semantics only.

    Planning metadata outside the fenced block never enters the digest, so
    unrelated Issue edits cannot invalidate an active attempt (no
    whole-policy-digest coupling).
    """

    return hashlib.sha256(canonical_contract(contract).encode("utf-8")).hexdigest()


def classify_paths(paths: list[str], scope: dict[str, Any] | None,
                   main_attributable: set[str] | None = None) -> dict[str, Any]:
    """Mechanically classify changed paths against the Contract's forbidden
    boundaries. v3 has no default expected-path allowlist; anything not
    forbidden is ALLOWED and remains reviewable through the actual diff.

    ``main_attributable`` (#104) is the CLI-proven set of candidate-diff
    paths whose content in the Candidate tree is byte-identical to accepted
    main's tree — i.e. paths that entered the diff only through a
    reconciliation with advanced accepted main, never through the
    Candidate's own edits. Only a proven path is exempted from violation
    (classified MAIN_ATTRIBUTED); every unproven forbidden match stays a
    strict violation, and an allowed path is never reported attributed.
    """

    forbidden = (scope or {}).get("forbidden", [])
    proven = main_attributable or set()
    classified: dict[str, str] = {}
    violations: list[dict[str, str]] = []
    for path in sorted(set(paths)):
        if any(path == pattern or fnmatch.fnmatchcase(path, pattern) for pattern in forbidden):
            if path in proven:
                classified[path] = "MAIN_ATTRIBUTED"
            else:
                classified[path] = "FORBIDDEN"
                violations.append({"path": path, "reason": "forbidden path changed"})
        else:
            classified[path] = "ALLOWED"
    return {
        "pass": not violations,
        "paths": classified,
        "violations": violations,
        "main_attributed_paths": sorted(
            path for path, verdict in classified.items() if verdict == "MAIN_ATTRIBUTED"),
        "counts": {
            "ALLOWED": sum(value == "ALLOWED" for value in classified.values()),
            "FORBIDDEN": sum(value == "FORBIDDEN" for value in classified.values()),
            "MAIN_ATTRIBUTED": sum(value == "MAIN_ATTRIBUTED" for value in classified.values()),
        },
    }


def new_claim_id(executor_id: str, now: datetime) -> str:
    stamp = now.strftime("%Y%m%dT%H%M%S")
    return f"{executor_id}-{stamp}-{uuid.uuid4().hex[:8]}"


def build_claim(*, issue: int, github_principal: str, executor_id: str,
                execution_base: str, branch: str, contract: dict[str, Any],
                now: str, lease_expires_at: str,
                supersedes: dict[str, Any] | None = None) -> dict[str, Any]:
    record = {
        "v": 3,
        "task": issue,
        "claim_id": new_claim_id(executor_id, datetime.strptime(now, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)),
        "github_principal": github_principal,
        "executor_id": executor_id,
        "claimed_at": now,
        "lease_expires_at": lease_expires_at,
        "execution_base": execution_base,
        "status": "active",
        "branch": branch,
        "heartbeat_at": now,
        "supersedes": supersedes,
        "contract_digest": contract_digest(contract),
        "candidate": None,
    }
    return record


TERMINAL_STATUSES = {"delivered", "investigated", "partial", "failed", "blocked"}


class ExecutionPlanError(ValueError):
    """Raised when a document is not a valid v1 Execution Plan."""


EXECUTION_PLAN_VERSION = 1
EXECUTION_PLAN_GATES = ("merged", "issue_done")

# Canonical durable exact-SHA A-acceptance surfaces (see
# prompts/resume-as-A.md): a native APPROVED review bound to the exact
# Candidate SHA, or — when platform identity prevents native review
# actions — a structured top-level PR comment in exactly this shape:
#
#     A REVIEW — ACCEPTED
#
#     Reviewed exact Candidate:
#     <candidate sha>
ACCEPTANCE_HEADER = "A REVIEW — ACCEPTED"
ACCEPTANCE_SHA_FIELD = "Reviewed exact Candidate:"
_ACCEPTANCE_HEADER_LINE = re.compile(r"#*\s*" + re.escape(ACCEPTANCE_HEADER) + r"\s*")

# Plan v1 carries ONLY the scheduling/authorization desired state. Runtime
# observation fields (worker, trace, started_at, candidate identity, review
# status, retry counters, ...) are rejected outright so a Plan can never
# silently become a second lifecycle state store.
_PLAN_ALLOWED_FIELDS = {"version", "plan_id", "max_concurrency", "nodes"}
_PLAN_NODE_ALLOWED_FIELDS = {"issue", "contract_digest", "authorization_id",
                             "priority", "after"}
_PLAN_BARRIER_ALLOWED_FIELDS = {"gate", "issue"}


def _plan_int(value: Any, *, minimum: int | None = None) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    if minimum is not None and value < minimum:
        return None
    return value


def _parse_plan_barrier(entry: Any, where: str) -> dict[str, Any]:
    if not isinstance(entry, dict):
        raise ExecutionPlanError(f"{where}: each barrier must be an object")
    unknown = set(entry) - _PLAN_BARRIER_ALLOWED_FIELDS
    if unknown:
        raise ExecutionPlanError(f"{where}: unknown barrier field(s) {sorted(unknown)}")
    gate = entry.get("gate")
    if gate not in EXECUTION_PLAN_GATES:
        raise ExecutionPlanError(
            f"{where}: barrier gate must be one of {list(EXECUTION_PLAN_GATES)}")
    issue = _plan_int(entry.get("issue"), minimum=1)
    if issue is None:
        raise ExecutionPlanError(f"{where}: barrier issue must be a positive integer")
    return {"gate": gate, "issue": issue}


def _validate_plan_barrier_graph(nodes: list[dict[str, Any]]) -> None:
    """Refuse barrier graphs that are not a DAG over the Plan's own nodes.

    A self-edge or a Plan-internal cycle leaves every participating node
    permanently blocked and would only surface later as an ordinary "no
    runnable work"; Plan v1 therefore fails closed at validation and never
    publishes such a graph. Barriers pointing at Issues outside the current
    Plan are external dependencies and never participate in cycle detection.
    """

    for node in sorted(nodes, key=lambda entry: entry["issue"]):
        for barrier in node["after"]:
            if barrier["issue"] == node["issue"]:
                raise ExecutionPlanError(
                    "Execution Plan barrier graph must be a DAG: self-edge on issue "
                    f"#{node['issue']}")
    in_plan = {node["issue"] for node in nodes}
    edges: dict[int, list[int]] = {
        node["issue"]: sorted({barrier["issue"] for barrier in node["after"]
                               if barrier["issue"] in in_plan})
        for node in nodes}
    indegree: dict[int, int] = {issue: 0 for issue in edges}
    for targets in edges.values():
        for target in targets:
            indegree[target] += 1
    ready = sorted(issue for issue, degree in indegree.items() if degree == 0)
    resolved = 0
    while ready:
        current = ready.pop(0)
        resolved += 1
        for target in edges[current]:
            indegree[target] -= 1
            if indegree[target] == 0:
                ready.append(target)
                ready.sort()
    if resolved == len(edges):
        return
    # Deterministically extract one concrete cycle for the error message:
    # every unresolved node has at least one unresolved predecessor, so the
    # backward walk always continues until it revisits a node.
    stalled = sorted(issue for issue, degree in indegree.items() if degree > 0)
    stalled_set = set(stalled)
    predecessors: dict[int, list[int]] = {issue: [] for issue in edges}
    for source, targets in edges.items():
        for target in targets:
            predecessors[target].append(source)
    walk = [stalled[0]]
    positions = {stalled[0]: 0}
    current = stalled[0]
    while True:
        current = min(target for target in predecessors[current] if target in stalled_set)
        if current in positions:
            cycle = walk[positions[current]:] + [current]
            break
        positions[current] = len(walk)
        walk.append(current)
    raise ExecutionPlanError(
        "Execution Plan barrier graph must be a DAG: cycle "
        + " -> ".join(f"#{issue}" for issue in cycle))


def _parse_plan_document(text: str, *, allow_unbound_digest: bool) -> dict[str, Any]:
    """Shared Execution Plan v1 validation (one schema truth).

    ``allow_unbound_digest`` is the ONLY knob and it belongs to the #156
    Plan AUTHORING surface: an authoring document may omit a node's
    ``contract_digest`` so the canonical publication gate can bind it
    mechanically. Every other rule — field allowlists, identity/priority/
    barrier validation, the barrier DAG — is identical for both parsers.
    """

    try:
        plan = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ExecutionPlanError(f"Execution Plan is not valid JSON: {exc}") from exc
    if not isinstance(plan, dict):
        raise ExecutionPlanError("Execution Plan root must be a JSON object")
    unknown = set(plan) - _PLAN_ALLOWED_FIELDS
    if unknown:
        raise ExecutionPlanError(f"unknown Execution Plan field(s) {sorted(unknown)}")
    version = plan.get("version")
    if isinstance(version, bool) or version != EXECUTION_PLAN_VERSION:
        raise ExecutionPlanError(f"unsupported Execution Plan version {version!r}")
    plan_id = plan.get("plan_id")
    if not isinstance(plan_id, str) or not plan_id.strip():
        raise ExecutionPlanError("plan_id must be non-empty text")
    max_concurrency = plan.get("max_concurrency")
    if max_concurrency is not None:
        checked = _plan_int(max_concurrency, minimum=0)
        if checked is None:
            raise ExecutionPlanError("max_concurrency must be an integer >= 0")
    nodes = plan.get("nodes")
    if not isinstance(nodes, list) or not nodes:
        raise ExecutionPlanError("nodes must be a non-empty list")
    parsed_nodes: list[dict[str, Any]] = []
    seen_issues: set[int] = set()
    seen_authorizations: set[str] = set()
    for index, entry in enumerate(nodes):
        where = f"nodes[{index}]"
        if not isinstance(entry, dict):
            raise ExecutionPlanError(f"{where}: node must be an object")
        unknown = set(entry) - _PLAN_NODE_ALLOWED_FIELDS
        if unknown:
            raise ExecutionPlanError(f"{where}: unknown node field(s) {sorted(unknown)}")
        issue = _plan_int(entry.get("issue"), minimum=1)
        if issue is None:
            raise ExecutionPlanError(f"{where}: issue must be a positive integer")
        if issue in seen_issues:
            raise ExecutionPlanError(f"{where}: duplicate Plan node for issue #{issue}")
        seen_issues.add(issue)
        raw_digest = entry.get("contract_digest")
        if raw_digest is None and allow_unbound_digest:
            digest = None  # mechanical-binding territory (#156); strict parser refuses
        elif not isinstance(raw_digest, str) or not re.fullmatch(r"[0-9a-f]{64}", raw_digest):
            raise ExecutionPlanError(f"{where}: contract_digest must be a 64-char hex digest")
        else:
            digest = raw_digest
        authorization_id = entry.get("authorization_id")
        if not isinstance(authorization_id, str) or not authorization_id.strip():
            raise ExecutionPlanError(f"{where}: authorization_id must be non-empty text")
        if authorization_id in seen_authorizations:
            raise ExecutionPlanError(
                f"{where}: duplicate authorization identity {authorization_id!r}")
        seen_authorizations.add(authorization_id)
        priority = _plan_int(entry.get("priority"))
        if priority is None:
            raise ExecutionPlanError(f"{where}: priority must be an integer")
        barriers = entry.get("after")
        parsed_barriers = ([_parse_plan_barrier(item, where) for item in barriers]
                           if barriers is not None else [])
        parsed_nodes.append({"issue": issue, "contract_digest": digest,
                             "authorization_id": authorization_id, "priority": priority,
                             "after": parsed_barriers})
    _validate_plan_barrier_graph(parsed_nodes)
    parsed: dict[str, Any] = {"version": EXECUTION_PLAN_VERSION, "plan_id": plan_id,
                              "nodes": parsed_nodes}
    if max_concurrency is not None:
        parsed["max_concurrency"] = max_concurrency
    return parsed


def parse_execution_plan(text: str) -> dict[str, Any]:
    """Parse and strictly validate one Execution Plan v1 document (JSON).

    The Plan is the machine authority for future starts; anything not in
    the v1 schema — especially runtime observation state — fails closed,
    and the Plan-internal barrier graph must be a DAG (external barriers
    are legal dependencies). Every node must carry its 64-hex
    ``contract_digest``; digest-free authoring documents go through
    ``parse_plan_authoring`` (#156) and are bound at publication.
    """

    return _parse_plan_document(text, allow_unbound_digest=False)


def parse_plan_authoring(text: str) -> dict[str, Any]:
    """Parse one Plan v1 AUTHORING document (JSON) for the #156 remote-A
    surface: a node may omit ``contract_digest`` so the canonical
    publication gate can bind it mechanically from a fresh canonical digest
    read. A node that DOES carry a digest keeps it verbatim (the gate then
    verifies it exactly as in the direct path). Every other validation rule
    is the shared strict v1 validation of ``parse_execution_plan`` — the
    authoring surface never relaxes schema, barrier-DAG, or identity rules.
    """

    return _parse_plan_document(text, allow_unbound_digest=True)


def claim_state(claim: dict[str, Any] | None, now: datetime | None = None) -> str:
    """NONE / TERMINAL / ACTIVE / STALE classification of a claim record."""

    if claim is None:
        return "NONE"
    if claim.get("status") in TERMINAL_STATUSES:
        return "TERMINAL"
    try:
        expiry = datetime.strptime(claim["lease_expires_at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except (KeyError, TypeError, ValueError):
        return "STALE"
    return "ACTIVE" if expiry > (now or datetime.now(timezone.utc)) else "STALE"


def _structured_exact_sha_hit(body: str, header: str, candidate_sha: str) -> bool:
    """Parse one comment body against the canonical exact-SHA review
    structure for the given review header.

    The header must be the comment's actual review header (the first
    non-empty line, optionally a markdown heading) — not a quoted, negated,
    or explanatory occurrence inside the body. The ``Reviewed exact
    Candidate:`` field must be present and its bound value (same line or
    the next non-empty line, backtick-wrapped or bare) must equal the
    Candidate SHA exactly. Anything else is not that review outcome.
    """

    lines = body.replace("\r\n", "\n").split("\n")
    header_at = next((index for index, line in enumerate(lines) if line.strip()), None)
    if header_at is None:
        return False
    header_line = lines[header_at].strip()
    if header == ACCEPTANCE_HEADER:
        if not _ACCEPTANCE_HEADER_LINE.fullmatch(header_line):
            return False
    else:
        pattern = re.compile(r"#*\s*" + re.escape(header) + r"\s*")
        if not pattern.fullmatch(header_line):
            return False
    field_at = next((index for index in range(header_at + 1, len(lines))
                     if lines[index].strip().startswith(ACCEPTANCE_SHA_FIELD)), None)
    if field_at is None:
        return False
    bound = lines[field_at].strip()[len(ACCEPTANCE_SHA_FIELD):].strip()
    if not bound:
        bound = next((lines[index].strip() for index in range(field_at + 1, len(lines))
                      if lines[index].strip()), "")
    if len(bound) >= 2 and bound.startswith("`") and bound.endswith("`"):
        bound = bound[1:-1].strip()
    return bound == candidate_sha


def _structured_acceptance_hit(body: str, candidate_sha: str) -> bool:
    """Acceptance variant of the canonical exact-SHA structure."""
    return _structured_exact_sha_hit(body, ACCEPTANCE_HEADER, candidate_sha)


CHANGE_REQUEST_HEADER = "A REVIEW — REQUEST_CHANGES"


def has_exact_sha_change_request(*, reviews: list[dict[str, Any]] | None,
                                 comments: list[dict[str, Any]] | None,
                                 candidate_sha: str) -> tuple[bool, list[str]]:
    """Mechanical REQUEST_CHANGES outcome check over the same two canonical
    surfaces as the acceptance predicate: a native CHANGES_REQUESTED review
    bound to the exact Candidate SHA, or a structured top-level PR comment
    with the canonical REQUEST_CHANGES header binding it. Returns
    (has_blocking_outcome, unreadable_surfaces); an unreadable surface
    fails closed for callers that would act on the outcome."""

    unreadable = sorted(name for name, surface in (("reviews", reviews),
                                                   ("comments", comments))
                        if surface is None)
    if unreadable:
        return False, unreadable
    for review in reviews:
        if (isinstance(review, dict) and review.get("state") == "CHANGES_REQUESTED"
                and review.get("commit_id") == candidate_sha):
            return True, []
    for comment in comments:
        if isinstance(comment, dict) and _structured_exact_sha_hit(
                str(comment.get("body", "")), CHANGE_REQUEST_HEADER, candidate_sha):
            return True, []
    return False, []


def evaluate_exact_sha_acceptance(*, reviews: list[dict[str, Any]] | None,
                                  comments: list[dict[str, Any]] | None,
                                  candidate_sha: str) -> dict[str, Any]:
    """Mechanical verdict over the two canonical exact-SHA A-acceptance surfaces.

    Acceptance requires a native APPROVED review whose ``commit_id`` equals
    the delivered Candidate SHA, or a top-level PR comment that parses
    against the canonical structured fallback (see
    ``_structured_acceptance_hit``). An unreadable surface fails closed via
    ``unreadable``; APPROVED reviews bound to other SHAs are reported in
    ``approved_other_shas`` so callers can explain the refusal. The single
    shared implementation keeps ``merged``, completion, and later
    reconciliation from drifting into divergent string matching.
    """

    unreadable = sorted(name for name, surface in (("reviews", reviews),
                                                   ("comments", comments))
                        if surface is None)
    if unreadable:
        return {"accepted": False, "source": None, "unreadable": unreadable,
                "approved_other_shas": []}
    approved = [str(review.get("commit_id")) for review in reviews
                if isinstance(review, dict) and review.get("state") == "APPROVED"]
    if candidate_sha in approved:
        return {"accepted": True, "source": "native-review", "unreadable": [],
                "approved_other_shas": []}
    fallback = any(isinstance(comment, dict) and
                   _structured_acceptance_hit(str(comment.get("body", "")), candidate_sha)
                   for comment in comments)
    if fallback:
        return {"accepted": True, "source": "structured-comment", "unreadable": [],
                "approved_other_shas": []}
    return {"accepted": False, "source": None, "unreadable": [],
            "approved_other_shas": sorted({sha for sha in approved if sha})}
