"""One tracked workflow, no copied scripts: guarded proposal only (#249).

This module prepares source changes; it never activates a ref, merges a PR,
or authorizes an upgrade. Legacy multi-file adoption requires explicit
migration rather than silent deletion of project-owned source.
"""
from __future__ import annotations

import fcntl
import os
import re
import secrets
import stat
from pathlib import Path
from typing import Any

PIN = re.compile(r"[0-9a-f]{64}\Z")
DESTINATION = ".github/workflows/ght.yml"
TEMPLATE = "workflow_templates/ght.yml"
MARKER = "# ght-adoption-managed: ght-single/v1"
OWNER_GATE = "github.repository_owner == 'harryhua-ai'"
LEGACY = (
    ".github/workflows/ght-complete.yml",
    ".github/workflows/ght-plan-publish.yml",
    ".github/scripts/ght-gha-adapter.sh",
    ".github/scripts/ght-gha-review-trigger.py",
    ".github/scripts/ght-gha-review-verdict.py",
    "scripts/ght/ght-gha-adapter.sh",
    "scripts/ght/ght-gha-resolve.sh",
    "scripts/ght/materialize-runtime.sh",
)
PARENT_COMPONENTS = (".github", "workflows")
WORKFLOW_NAME = "ght.yml"


class SingleWorkflowAdoptionError(ValueError):
    """Untrusted or incompatible tracked workflow/adoption state."""


# Public exception contract used by CLI bootstrap and workflows-adopt.
WorkflowAdoptionError = SingleWorkflowAdoptionError


def _path(root: Path, relative: str) -> tuple[Path, bytes | None]:
    parent = root
    for component in Path(relative).parts[:-1]:
        parent = parent / component
        if parent.is_symlink() or (parent.exists() and not parent.is_dir()):
            raise SingleWorkflowAdoptionError(f"unsafe parent for {relative}")
    target = root / relative
    if target.is_symlink() or (target.exists() and not target.is_file()):
        raise SingleWorkflowAdoptionError(f"not a regular file: {relative}")
    return target, target.read_bytes() if target.exists() else None


def _directory_flags() -> int:
    if not hasattr(os, "O_DIRECTORY") or not hasattr(os, "O_NOFOLLOW"):
        raise SingleWorkflowAdoptionError(
            "safe directory-relative workflow updates are unavailable")
    return os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW


def _directory_identity(info: os.stat_result) -> tuple[int, ...]:
    return (info.st_dev, info.st_ino, info.st_uid, info.st_gid,
            stat.S_IMODE(info.st_mode))


def _file_identity(info: os.stat_result) -> tuple[int, ...]:
    return (info.st_dev, info.st_ino, info.st_uid, info.st_gid,
            stat.S_IMODE(info.st_mode), info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def _check_directory(info: os.stat_result, label: str) -> None:
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid()
            or stat.S_IMODE(info.st_mode) & 0o022):
        raise SingleWorkflowAdoptionError(
            f"unsafe ownership or permissions for {label}")


def _open_directory_path(path: Path) -> int:
    flags = _directory_flags()
    current = os.open(path.anchor or "/", flags)
    try:
        for component in path.parts[1:]:
            following = os.open(component, flags, dir_fd=current)
            os.close(current)
            current = following
        _check_directory(os.fstat(current), str(path))
        return current
    except OSError as exc:
        os.close(current)
        raise SingleWorkflowAdoptionError(
            f"unsafe repository directory: {path}") from exc
    except BaseException:
        os.close(current)
        raise


def _open_child_directory(parent_fd: int, name: str) -> int:
    try:
        child = os.open(name, _directory_flags(), dir_fd=parent_fd)
    except OSError as exc:
        raise SingleWorkflowAdoptionError(
            f"unsafe workflow parent component: {name}") from exc
    try:
        _check_directory(os.fstat(child), name)
        return child
    except BaseException:
        os.close(child)
        raise


def _locate_parent(root_fd: int) -> tuple[int | None, int | None]:
    current = os.dup(root_fd)
    try:
        for index, component in enumerate(PARENT_COMPONENTS):
            try:
                following = _open_child_directory(current, component)
            except SingleWorkflowAdoptionError as exc:
                cause = exc.__cause__
                if isinstance(cause, FileNotFoundError):
                    os.close(current)
                    return None, index
                raise
            os.close(current)
            current = following
        return current, None
    except BaseException:
        try:
            os.close(current)
        except OSError:
            pass
        raise


def _lock_directory(directory_fd: int) -> None:
    try:
        fcntl.flock(directory_fd, fcntl.LOCK_EX)
    except OSError as exc:
        raise SingleWorkflowAdoptionError(
            "could not lock workflow parent for update") from exc


def _assert_path_binding(root: Path, root_identity: tuple[int, ...],
                         parent_identity: tuple[int, ...] | None,
                         missing_at: int | None = None) -> None:
    root_fd = _open_directory_path(root)
    try:
        if _directory_identity(os.fstat(root_fd)) != root_identity:
            raise SingleWorkflowAdoptionError(
                "repository directory changed after preflight")
        parent_fd, actual_missing_at = _locate_parent(root_fd)
        if parent_identity is None:
            if parent_fd is not None or actual_missing_at != missing_at:
                if parent_fd is not None:
                    os.close(parent_fd)
                raise SingleWorkflowAdoptionError(
                    "workflow parent changed after preflight")
            return
        if parent_fd is None:
            raise SingleWorkflowAdoptionError(
                "workflow parent changed after preflight")
        try:
            if _directory_identity(os.fstat(parent_fd)) != parent_identity:
                raise SingleWorkflowAdoptionError(
                    "workflow parent changed after preflight")
        finally:
            os.close(parent_fd)
    finally:
        os.close(root_fd)


def _read_workflow(parent_fd: int) -> tuple[bytes | None, tuple[int, ...] | None,
                                               int | None]:
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    try:
        fd = os.open(WORKFLOW_NAME, flags, dir_fd=parent_fd)
    except FileNotFoundError:
        return None, None, None
    except OSError as exc:
        raise SingleWorkflowAdoptionError(
            "unsafe workflow destination") from exc
    try:
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.geteuid()
                or stat.S_IMODE(before.st_mode) & 0o022):
            raise SingleWorkflowAdoptionError(
                "unsafe ownership, permissions, or type for workflow destination")
        chunks = []
        while True:
            chunk = os.read(fd, 65536)
            if not chunk:
                break
            chunks.append(chunk)
        after = os.fstat(fd)
        try:
            named = os.stat(WORKFLOW_NAME, dir_fd=parent_fd,
                            follow_symlinks=False)
        except OSError as exc:
            raise SingleWorkflowAdoptionError(
                "workflow changed while being read") from exc
        if (_file_identity(before) != _file_identity(after)
                or not stat.S_ISREG(named.st_mode)
                or (named.st_dev, named.st_ino) != (after.st_dev, after.st_ino)):
            raise SingleWorkflowAdoptionError(
                "workflow changed while being read")
        return b"".join(chunks), _file_identity(after), stat.S_IMODE(after.st_mode)
    finally:
        os.close(fd)


def _create_parent(root_fd: int, missing_at: int) -> int:
    current = os.dup(root_fd)
    try:
        for index, component in enumerate(PARENT_COMPONENTS):
            if index >= missing_at:
                try:
                    os.mkdir(component, 0o755, dir_fd=current)
                except OSError as exc:
                    raise SingleWorkflowAdoptionError(
                        "workflow parent changed during creation") from exc
            following = _open_child_directory(current, component)
            os.close(current)
            current = following
        return current
    except BaseException:
        try:
            os.close(current)
        except OSError:
            pass
        raise


def _write_all(fd: int, contents: bytes) -> None:
    view = memoryview(contents)
    while view:
        written = os.write(fd, view)
        if written <= 0:
            raise OSError("short write while creating workflow")
        view = view[written:]


def _sync_directory(fd: int) -> None:
    try:
        os.fsync(fd)
    except OSError as exc:
        raise SingleWorkflowAdoptionError(
            "workflow parent directory could not be synced") from exc


def _unlink_if_inode(parent_fd: int, name: str, inode: tuple[int, int] | None) -> None:
    if inode is None:
        return
    try:
        current = os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
        if (current.st_dev, current.st_ino) == inode:
            os.unlink(name, dir_fd=parent_fd)
    except FileNotFoundError:
        pass


def _create_staged_file(parent_fd: int, contents: bytes, mode: int
                        ) -> tuple[str, tuple[int, int]]:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
    for _ in range(32):
        name = f".ght-adoption-{secrets.token_hex(8)}"
        try:
            fd = os.open(name, flags, 0o600, dir_fd=parent_fd)
            break
        except FileExistsError:
            continue
        except OSError as exc:
            raise SingleWorkflowAdoptionError(
                "could not stage workflow update") from exc
    else:
        raise SingleWorkflowAdoptionError("could not allocate workflow staging file")
    inode = None
    try:
        info = os.fstat(fd)
        inode = (info.st_dev, info.st_ino)
        _write_all(fd, contents)
        os.fchmod(fd, mode)
        os.fsync(fd)
        return name, inode
    except BaseException as exc:
        _unlink_if_inode(parent_fd, name, inode)
        if isinstance(exc, OSError):
            raise SingleWorkflowAdoptionError(
                "could not stage workflow update") from exc
        raise
    finally:
        os.close(fd)


def _managed_runtime_pin(trusted: Path, contents: bytes) -> str | None:
    template_path = trusted / TEMPLATE
    if template_path.is_symlink() or not template_path.is_file():
        return None
    template = template_path.read_text(encoding="utf-8").encode()
    parts = template.split(b"@GHT_RUNTIME_REF@")
    if len(parts) != 4:
        return None
    expression = re.escape(parts[0])
    for part in parts[1:]:
        expression += rb"([0-9a-f]{64})" + re.escape(part)
    match = re.fullmatch(expression, contents)
    if match is None:
        return None
    pins = match.groups()
    if not pins or any(pin != pins[0] for pin in pins[1:]):
        return None
    pin = pins[0].decode("ascii")
    if not PIN.fullmatch(pin) or _asset(trusted, pin) != contents:
        return None
    return pin


def _asset(root: Path, pin: str) -> bytes:
    file = root / TEMPLATE
    if file.is_symlink() or not file.is_file():
        raise SingleWorkflowAdoptionError("trusted single-workflow template unavailable")
    body = file.read_text(encoding="utf-8")
    if (body.count("@GHT_RUNTIME_REF@") != 3
            or body.count("uses: actions/checkout@11d5960a326750d5838078e36cf38b85af677262") != 3
            or body.splitlines().count(MARKER) != 1
            # #254: every adopted Workflow must keep the exact target-owner
            # gate on all three jobs; a template without it is not adoptable.
            or body.count(OWNER_GATE) != 3
            or not all(anchor in body for anchor in (
                "pull_request_review:", "issue_comment:", "pull_request:",
                "workflow_dispatch:", "push:", "review_verdict:", "complete:",
                "publish:", "checks: write", "refs/ght/runtime/$GHT_RUNTIME_REF",
                "sha256(payload).hexdigest() != pin", "ght-gha-review-trigger.py",
                "ght-gha-adapter.sh", "GHT_RECONCILER_ID:",
                "GHT_PLAN_PUBLISHER_ID:"))):
        raise SingleWorkflowAdoptionError("trusted single-workflow asset invariant failed")
    return body.replace("@GHT_RUNTIME_REF@", pin).encode()


def _legacy_surfaces(root: Path) -> list[str]:
    """Reject all known GHT-owned historical paths, not only named versions."""
    candidates = set(LEGACY)
    for directory, pattern in (
        (".github/workflows", "ght*.yml"),
        (".github/workflows", "ght*.yaml"),
        (".github/scripts", "ght-*"),
        ("scripts/ght", "*"),
    ):
        parent = root / directory
        if parent.is_symlink():
            raise SingleWorkflowAdoptionError(f"unsafe legacy directory: {directory}")
        if parent.exists() and not parent.is_dir():
            raise SingleWorkflowAdoptionError(f"unsafe legacy directory: {directory}")
        if parent.is_dir():
            for found in parent.glob(pattern):
                relative = found.relative_to(root).as_posix()
                if relative != DESTINATION:
                    candidates.add(relative)
    result = []
    for relative in sorted(candidates):
        _target, contents = _path(root, relative)
        if contents is not None:
            result.append(relative)
    agents = root / "AGENTS.md"
    if agents.is_file() and not agents.is_symlink():
        if b"harry-dev:agents-managed begin" in agents.read_bytes():
            result.append("AGENTS.md (legacy GHT-managed block)")
    return result


def inspect(root: str | Path, pin: str, *, upgrade_selector: bool = False,
            package_root: str | Path | None = None) -> dict[str, Any]:
    if not isinstance(pin, str) or not PIN.fullmatch(pin):
        raise SingleWorkflowAdoptionError("expected exact 64-hex activated Runtime digest")
    target = Path(root).resolve()
    trusted = (Path(package_root).resolve() if package_root is not None
               else Path(__file__).resolve().parents[1])
    # All legacy tracked files are explicitly rejected. There is no
    # permission to destroy them, even with --upgrade: require a separately
    # approved, audited migration with intentional deletions.
    legacy = _legacy_surfaces(target)
    if legacy:
        raise SingleWorkflowAdoptionError(
            "legacy GHT files need A-reviewed migration (no implicit deletion): "
            + ", ".join(legacy))
    desired = _asset(trusted, pin)
    root_fd = _open_directory_path(target)
    try:
        root_identity = _directory_identity(os.fstat(root_fd))
        parent_fd, parent_missing_at = _locate_parent(root_fd)
        parent_identity = None
        current = None
        file_identity = None
        if parent_fd is not None:
            try:
                _lock_directory(parent_fd)
                parent_identity = _directory_identity(os.fstat(parent_fd))
                _assert_path_binding(target, root_identity, parent_identity)
                current, file_identity, _file_mode = _read_workflow(parent_fd)
                _assert_path_binding(target, root_identity, parent_identity)
            finally:
                os.close(parent_fd)
        else:
            _assert_path_binding(target, root_identity, None, parent_missing_at)
    finally:
        os.close(root_fd)
    if current is not None and current != desired:
        if _managed_runtime_pin(trusted, current) is None:
            raise SingleWorkflowAdoptionError(
                "project-owned or malformed workflow preserved: " + DESTINATION)
        if not upgrade_selector:
            raise SingleWorkflowAdoptionError(
                "existing managed Workflow differs; explicit authorized --upgrade required")
    changed = [DESTINATION] if current != desired else []
    return {"root": target, "runtime_ref": pin, "path": target / DESTINATION,
            "previous": current, "rendered": desired, "changed_files": changed,
            "compatible_files": [] if changed else [DESTINATION],
            "integration": "not_verified", "review_check": "prepared",
            "upgrade_selector": upgrade_selector,
            "root_identity": root_identity,
            "parent_identity": parent_identity,
            "parent_missing_at": parent_missing_at,
            "previous_identity": file_identity}


def apply(plan: dict[str, Any]) -> dict[str, Any]:
    root: Path = plan["root"]
    original = plan["previous"]
    changed = plan["changed_files"]
    if _legacy_surfaces(plan["root"]):
        raise SingleWorkflowAdoptionError("legacy GHT files appeared after preflight")
    root_fd = _open_directory_path(root)
    parent_fd = None
    created_inode = None
    staged_name = None
    staged_inode = None
    try:
        if _directory_identity(os.fstat(root_fd)) != plan["root_identity"]:
            raise SingleWorkflowAdoptionError("repository directory changed after preflight")
        parent_fd, missing_at = _locate_parent(root_fd)
        if plan["parent_identity"] is None:
            if parent_fd is not None or missing_at != plan["parent_missing_at"]:
                if parent_fd is not None:
                    os.close(parent_fd)
                    parent_fd = None
                raise SingleWorkflowAdoptionError("workflow parent changed after preflight")
            _lock_directory(root_fd)
            check_fd, check_missing = _locate_parent(root_fd)
            if check_fd is not None:
                os.close(check_fd)
                raise SingleWorkflowAdoptionError("workflow parent changed after preflight")
            if check_missing != plan["parent_missing_at"]:
                raise SingleWorkflowAdoptionError("workflow parent changed after preflight")
            parent_fd = _create_parent(root_fd, plan["parent_missing_at"])
            _lock_directory(parent_fd)
            parent_identity = _directory_identity(os.fstat(parent_fd))
        else:
            if (parent_fd is None or missing_at is not None
                    or _directory_identity(os.fstat(parent_fd)) != plan["parent_identity"]):
                if parent_fd is not None:
                    os.close(parent_fd)
                    parent_fd = None
                raise SingleWorkflowAdoptionError("workflow parent changed after preflight")
            _lock_directory(parent_fd)
            parent_identity = plan["parent_identity"]

        _assert_path_binding(root, plan["root_identity"], parent_identity)
        current, current_identity, current_mode = _read_workflow(parent_fd)
        if (current != original
                or current_identity != plan["previous_identity"]):
            raise SingleWorkflowAdoptionError("workflow changed after preflight")

        if changed:
            if original is None:
                flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
                try:
                    fd = os.open(WORKFLOW_NAME, flags, 0o644, dir_fd=parent_fd)
                except FileExistsError as exc:
                    raise SingleWorkflowAdoptionError(
                        "workflow changed after preflight") from exc
                except OSError as exc:
                    raise SingleWorkflowAdoptionError(
                        "could not create workflow") from exc
                try:
                    info = os.fstat(fd)
                    created_inode = (info.st_dev, info.st_ino)
                    _write_all(fd, plan["rendered"])
                    os.fsync(fd)
                except OSError as exc:
                    if created_inode is not None:
                        _unlink_if_inode(parent_fd, WORKFLOW_NAME, created_inode)
                    raise SingleWorkflowAdoptionError(
                        "could not create workflow") from exc
                finally:
                    os.close(fd)
                try:
                    _assert_path_binding(root, plan["root_identity"], parent_identity)
                    written, written_identity, _mode = _read_workflow(parent_fd)
                    if written != plan["rendered"] or written_identity is None:
                        raise SingleWorkflowAdoptionError(
                            "workflow changed during creation")
                    if (written_identity[0], written_identity[1]) != created_inode:
                        raise SingleWorkflowAdoptionError(
                            "workflow changed during creation")
                    _sync_directory(parent_fd)
                except BaseException:
                    _unlink_if_inode(parent_fd, WORKFLOW_NAME, created_inode)
                    raise
            else:
                staged_mode = current_mode if current_mode is not None else 0o644
                staged_name, staged_inode = _create_staged_file(
                    parent_fd, plan["rendered"], staged_mode)
                try:
                    _assert_path_binding(root, plan["root_identity"], parent_identity)
                    current, current_identity, _mode = _read_workflow(parent_fd)
                    if (current != original
                            or current_identity != plan["previous_identity"]):
                        raise SingleWorkflowAdoptionError(
                            "workflow changed during upgrade")
                    try:
                        os.replace(staged_name, WORKFLOW_NAME,
                                   src_dir_fd=parent_fd, dst_dir_fd=parent_fd)
                    except OSError as exc:
                        raise SingleWorkflowAdoptionError(
                            "workflow changed or could not be replaced") from exc
                    staged_name = None
                    _assert_path_binding(root, plan["root_identity"], parent_identity)
                    written, written_identity, _mode = _read_workflow(parent_fd)
                    if (written != plan["rendered"] or written_identity is None
                            or (written_identity[0], written_identity[1]) != staged_inode):
                        raise SingleWorkflowAdoptionError(
                            "workflow changed during upgrade")
                    _sync_directory(parent_fd)
                finally:
                    if staged_name is not None:
                        _unlink_if_inode(parent_fd, staged_name, staged_inode)
        return {"status": "proposal_prepared" if changed else "already_compatible",
                "integration": "not_verified", "changed_files": list(changed),
                "compatible_files": plan["compatible_files"],
                "runtime_ref": plan["runtime_ref"],
                "upgrade_selector": plan["upgrade_selector"],
                "review_check": plan["review_check"],
                "formal_release": "optional_not_installed_by_default"}
    finally:
        if parent_fd is not None:
            os.close(parent_fd)
        os.close(root_fd)


def prepare(root: str | Path, pin: str, *, upgrade_selector: bool = False,
            package_root: str | Path | None = None) -> dict[str, Any]:
    return apply(inspect(root, pin, upgrade_selector=upgrade_selector,
                         package_root=package_root))
